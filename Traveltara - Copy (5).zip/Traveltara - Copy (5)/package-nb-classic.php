<?php
// Top of package-nb-classic.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹19,500"; 
$sheet_affordable_price = "₹32,000";
$sheet_super_price = "₹55,000";

// EXACT package name from Google Sheet
$target_package = "Himalayan Classic 7D/6N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels & Clean Homestays</li>
            <li><i class="fa-solid fa-car"></i> Dedicated WagonR / Swift for the Entire Route</li>
            <li><i class="fa-solid fa-ticket"></i> Standard Tsomgo Lake Permit Included</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Mountain Resorts & Heritage Tea Bungalows</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-train-tram"></i> <strong>Darjeeling Toy Train Joyride Included</strong></li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Luxury (e.g., Mayfair Gangtok, Taj Chia Kutir Darjeeling)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> VIP Nathu La Permits & Private English-Speaking Guide</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining & Authentic Himalayan Feasts</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Himalayan Classic & Gangtok 7 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="north-bengal-itinerary.php">North Bengal</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Himalayan Classic (7D/6N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['darjeeling classic hero']) ? $tourImages['darjeeling classic hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 7 Days / 6 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Himalayan Classic & Gangtok</h1>
            <p>A sweeping journey through the Queen of Hills, the capital of Sikkim, and hidden, mist-covered pine hamlets.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Himalayan Classic 7D/6N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Experience the definitive Eastern Himalayan loop. This meticulously crafted 7-day circuit takes you through the vibrant, Buddhist-influenced capital of Sikkim (Gangtok) and the legendary colonial tea estates of Darjeeling. But we don't just stop at the classics—we take you off the beaten path into the serene pine forests of Lamahatta, the misty valleys of Takdah, and the hidden viewpoint of Lepchajagat, ensuring a perfect balance of iconic sights and untouched mountain silence.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & Ascent to the Capital (Gangtok)</h3>
                <p>Welcome to the Himalayas! Arrive at Bagdogra Airport (IXB) or NJP Railway Station. Your chauffeur will drive you along the beautiful Teesta River toward Gangtok, the capital of Sikkim (approx. 4.5 hours). Check into your hotel. Spend your evening taking a leisurely stroll down the beautifully illuminated, vehicle-free MG Marg, soaking in the vibrant café culture.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Glacial Lake: Tsomgo & Baba Mandir</h3>
                <p>After breakfast, embark on a breathtaking full-day excursion to Tsomgo Lake (12,400 ft). This stunning, oval-shaped glacial lake is considered sacred by the locals and freezes completely in winter. Continue higher to the Baba Harbhajan Singh Mandir, a unique shrine dedicated to an Indian Army soldier. <em>(Optional: Extension to the Indo-China border at Nathu La Pass, subject to permit availability and weather).</em> Return to Gangtok for the night.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Gangtok to Kalimpong via Offbeat Icchey Gaon</h3>
                <p>Depart Gangtok and drive toward the serene town of Kalimpong. En route, stop at the mesmerizing Triveni View Point, where the Teesta and Rangeet rivers converge. Before reaching your hotel, take an offbeat detour to Icchey Gaon (Wishing Village), a pristine eco-village surrounded by dense pine forests offering spectacular views of Mount Kanchenjunga. Later, visit Deolo Hill and check into your Kalimpong hotel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> The Hidden Hamlets: Lamahatta & Takdah to Darjeeling</h3>
                <p>Today is a journey through untouched nature. Drive from Kalimpong to Darjeeling via an exceptionally beautiful, offbeat route. Stop at Lamahatta Eco Park to walk among towering pine trees adorned with colorful Buddhist prayer flags. Continue through the misty, heritage tea estates of Takdah and the hanging bridge of Tinchuley. Arrive in the "Queen of Hills," Darjeeling, by late afternoon and check into your hotel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Darjeeling Classics: Sunrise & The Toy Train</h3>
                <p>Wake up at 4:00 AM and drive to Tiger Hill to witness the sun illuminating the colossal peaks of Mount Kanchenjunga and Mount Everest. On the way back, visit the Batasia Loop and Ghoom Monastery. After breakfast, visit the Himalayan Mountaineering Institute, the Padmaja Naidu Himalayan Zoological Park (home to Snow Leopards and Red Pandas), and the Tibetan Refugee Self Help Center. <em>(Optional: Afternoon heritage joyride on the Darjeeling Himalayan Railway).</em></p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Offbeat Darjeeling: Lepchajagat & Mirik Valley</h3>
                <p>Escape the city crowds today. Drive to the nearby hidden hamlet of Lepchajagat (approx. 45 mins). Reserved as a forest area, it offers some of the most serene, unobstructed views of the Kanchenjunga range through dense oak and rhododendron forests. Later, continue your scenic drive to the Mirik Valley, famous for the beautiful, pine-encircled Sumendu Lake. Enjoy a boat ride or a walk across the arching footbridge before returning to Darjeeling.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Departure via the Kurseong Tea Gardens</h3>
                <p>Enjoy your final Himalayan breakfast and a warm cup of world-famous Darjeeling tea. Your chauffeur will begin the descent to the plains via the beautiful town of Kurseong. Enjoy sweeping views of the tea gardens and the plains below from Eagle's Crag. You will be seamlessly dropped off at Bagdogra Airport (IXB) or NJP Railway Station for your onward journey home.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels & Clean Homestays</li>
                <li><i class="fa-solid fa-car"></i> Dedicated WagonR / Swift for the Entire Route</li>
                <li><i class="fa-solid fa-ticket"></i> Standard Tsomgo Lake Permit Included</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/nb-classic-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- NB INSIGHTS HUB (6 GRID CARDS)                            -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Himalayan Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your journey through Sikkim and North Bengal is perfectly planned and executed.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-id-card"></i></div>
                <h3>Sikkim Border Permits</h3>
                <p>Tsomgo Lake and Nathu La are highly restricted border areas:</p>
                <ul>
                    <li><strong>Documents:</strong> You must carry 4 passport-size photographs and original Government IDs (Voter ID or Passport). <em>Note: Aadhar Cards are often not accepted for border permits in Sikkim.</em></li>
                    <li><strong>Nathu La:</strong> The pass is closed to visitors on Mondays and Tuesdays. Permits depend heavily on military clearance and weather conditions.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-train-tram"></i></div>
                <h3>Toy Train Logistics</h3>
                <p>Riding the Darjeeling Himalayan Railway:</p>
                <ul>
                    <li><strong>Advance Booking:</strong> The 2-hour Joyride from Darjeeling to Ghoom sells out months in advance during peak season. If you wish to ride, it must be requested at the time of booking.</li>
                    <li><strong>Steam vs. Diesel:</strong> The heritage steam engine is more expensive and iconic, while the diesel engine offers larger viewing windows.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time for Kanchenjunga</h3>
                <p>The mountains play hide and seek:</p>
                <ul>
                    <li><strong>Autumn/Spring (Oct-Nov & Mar-May):</strong> Offers the clearest, most spectacular views of the snow-capped peaks and pleasant weather.</li>
                    <li><strong>Monsoon (Jun-Sep):</strong> The mountains will likely be hidden by dense fog, and the offbeat roads (like Takdah and Lamahatta) can be muddy, but the tea gardens are breathtakingly green.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Altitude & Packing</h3>
                <p>Prepare for shifting temperatures:</p>
                <ul>
                    <li><strong>Tsomgo Lake:</strong> At over 12,000 feet, Tsomgo Lake is freezing year-round. Heavy winter jackets, gloves, and caps are mandatory. (Snow boots and jackets can be rented locally on the way up).</li>
                    <li><strong>Darjeeling:</strong> The mornings at Tiger Hill (4:00 AM) are bitterly cold, even in summer. Layering is essential.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car-side"></i></div>
                <h3>Offbeat Driving Realities</h3>
                <p>Embrace the mountain terrain:</p>
                <ul>
                    <li><strong>The Roads:</strong> Reaching hidden gems like Icchey Gaon, Lamahatta, and Lepchajagat involves navigating narrow, steep, and sometimes unpaved mountain roads.</li>
                    <li><strong>Vehicle Shift:</strong> In Gangtok, large SUVs/Innovas are not allowed on local sightseeing routes due to traffic rules; you will transfer to local taxis (WagonR/Sumo) for city tours.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Himalayan Cuisine</h3>
                <p>Warm up with local flavors:</p>
                <ul>
                    <li><strong>Sikkim:</strong> Enjoy authentic steaming Momos, Thukpa (noodle soup), and Sha Phaley (fried meat bread) at MG Marg.</li>
                    <li><strong>Darjeeling:</strong> Do not miss a classic English breakfast at Glenary's or Keventer's, and obviously, pot after pot of the world's finest Darjeeling First Flush tea.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream Himalayan Classic journey.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Himalayan Classic 7D/6N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>