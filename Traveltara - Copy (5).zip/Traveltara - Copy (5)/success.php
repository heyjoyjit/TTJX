<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmed | Traveltara</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="css/booking.css">
    <link rel="stylesheet" href="css/success.css">
</head>
<body>

    <header class="compact-hero">
        <h1 class="brand-logo">traveltara</h1>
        <div class="hero-subtitle">Booking Confirmed & Invoice Generated</div>
    </header>

    <main class="booking-container" style="text-align: center; padding: 60px 20px;">
        <div class="success-card-inner">
            
            <i class="fa-solid fa-circle-check success-icon"></i>
            <h1 class="success-title">Your Journey Begins Here</h1>
            <p class="success-message">Thank you for choosing Traveltara. Your payment was successful, and your official Tax Invoice has been securely downloaded to your device.</p>
            
            <div class="booking-ref-display">
                <span class="ref-label">Booking Reference ID</span>
                <span id="finalRefId" class="ref-value">TRV-SUCCESS</span>
            </div>

            <p class="next-steps-text">Our concierge team is preparing your bespoke itinerary. If you have any specific requests or need immediate assistance, your dedicated agent is ready.</p>

            <div class="success-actions">
                <a href="#" target="_blank" id="waButton" class="btn-whatsapp">
                    <i class="fa-brands fa-whatsapp" style="font-size: 1.3rem;"></i> Chat with Support
                </a>
                <a href="index.php" class="btn-home">Return to Home Page</a>
            </div>

        </div>
    </main>

<script src="js/success.js"></script>
</body>
</html>