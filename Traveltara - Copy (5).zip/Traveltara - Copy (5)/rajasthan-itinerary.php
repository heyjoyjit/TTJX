<?php
// Top of rajasthan-itinerary.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rajasthan Tour Packages | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Rajasthan Packages</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['rajasthan hero']) ? $tourImages['rajasthan hero'] : $fallbackImg; ?>') center/cover;">
        <div class="subpage-hero-content">
            <h1>Royal Rajasthan</h1>
            <p>From the golden sands of the Thar Desert to the shimmering lakes of Udaipur, select your ultimate royal expedition.</p>
        </div>
    </header>

    <!-- MAIN GRID SECTION -->
    <section class="section-padding" style="background-color: #fcfcfc;">
        <div style="max-width: 1200px; margin: auto; text-align: center; margin-bottom: 50px; padding: 0 20px;">
            <h2 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; color: #0A1128; margin-bottom: 15px;">Available Royal Circuits</h2>
            <p style="color: #666; max-width: 800px; margin: 0 auto;">Experience the grandeur of kings and the vibrant culture of the desert. Our bespoke Rajasthan itineraries offer a perfect blend of heritage luxury, wildlife, and offbeat desert safaris.</p>
        </div>

        <div class="grid-container" id="rajasthanPackagesGrid">
            
            <!-- CARD 1: CLASSIC RAJASTHAN -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['jaipur']) ? $tourImages['jaipur'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">7 Days / 6 Nights</div>
                </div>
                <div class="card-content">
                    <h3>The Classic Heritage</h3>
                    <p>The quintessential royal escape. Explore the Pink City of Jaipur, the blue hues of Jodhpur, and the romantic lake palaces of Udaipur.</p>
                    <h4 class="package-price">Starts at ₹22,500</h4>
                    <a href="package-rajasthan-classic.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 2: DESERT SAFARI -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['jaisalmer']) ? $tourImages['jaisalmer'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">6 Days / 5 Nights</div>
                </div>
                <div class="card-content">
                    <h3>Royal Desert Safari</h3>
                    <p>Venture into the heart of the Thar. Experience the Golden Fort of Jaisalmer, luxury Swiss tents in the Sam Sand Dunes, and the heritage of Bikaner.</p>
                    <h4 class="package-price">Starts at ₹18,000</h4>
                    <a href="package-rajasthan-desert.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 3: MEWAR & LAKES -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['udaipur']) ? $tourImages['udaipur'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">5 Days / 4 Nights</div>
                </div>
                <div class="card-content">
                    <h3>Palaces of Mewar</h3>
                    <p>A deeply romantic and relaxed route. Sail on Lake Pichola in Udaipur, explore the massive Kumbhalgarh Fort, and visit the serene hill station of Mount Abu.</p>
                    <h4 class="package-price">Starts at ₹16,500</h4>
                    <a href="package-rajasthan-mewar.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 4: WILDLIFE SAFARI -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['ranthambore']) ? $tourImages['ranthambore'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">4 Days / 3 Nights</div>
                </div>
                <div class="card-content">
                    <h3>Wild Rajasthan</h3>
                    <p>Track the majestic Bengal Tiger in the ruins of Ranthambore National Park, and spot leopards in the dramatic, rocky landscapes of Jawai.</p>
                    <h4 class="package-price">Starts at ₹15,000</h4>
                    <a href="package-rajasthan-wildlife.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 5: GRAND EPIC -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['rajasthan grand']) ? $tourImages['rajasthan grand'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">10-12 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Grand Rajasthan Epic</h3>
                    <p>The ultimate bucket-list royal tour. A complete circuit covering Jaipur, Bikaner, Jaisalmer, Jodhpur, and Udaipur with premium heritage stays.</p>
                    <h4 class="package-price">Starts at ₹42,000</h4>
                    <a href="package-rajasthan-grand.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 6: CUSTOM -->
            <div class="destination-card" style="background: #0A1128; color: #fff;">
                <div class="card-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%; padding: 40px 20px;">
                    <i class="fa-solid fa-compass" style="font-size: 3rem; color: #C5A059; margin-bottom: 20px;"></i>
                    <h3 style="color: #fff;">Build Your Own</h3>
                    <p style="color: #ccc;">Want to combine a tiger safari with the deserts of Jaisalmer? Or plan an exclusive palace wedding trip? Let us craft your bespoke royal escape.</p>
                    <button class="btn-primary" onclick="openLeadPopup()" style="margin-top: 20px; width: 100%;">Consult an Expert</button>
                </div>
            </div>

        </div>
    </section>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream royal escape to Rajasthan.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Rajasthan Packages" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>