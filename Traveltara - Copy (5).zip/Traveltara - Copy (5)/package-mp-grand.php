<?php
// Top of package-mp-grand.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹45,000"; 
$sheet_affordable_price = "₹72,000";
$sheet_super_price = "₹1,15,000";

// EXACT package name from Google Sheet
$target_package = "M.P. Grand Odyssey 13D/12N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels & Clean Jungle Lodges</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the 13-Day Mega Loop</li>
            <li><i class="fa-solid fa-paw"></i> 1 Shared Core Zone Gypsy Safari in Bandhavgarh</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Heritage Palaces, Hill Resorts & Safari Camps</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> 2 Private Open Gypsy Safaris & Exclusive Marble Rocks Boat Ride</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP Plan)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Luxury Palaces, Taj Safaris & Premium Eco-Resorts</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-crown"></i> VIP Bhasma Aarti Access, Premium Safari Zones & Private Guides</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining, Jungle BBQs & Malwi Feasts</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Grand M.P. Odyssey 13 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="madhya-pradesh-itinerary.php">Madhya Pradesh</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Grand M.P. Odyssey (13D/12N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['mp grand hero']) ? $tourImages['mp grand hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 13 Days / 12 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Grand M.P. Odyssey</h1>
            <p>The definitive 13-day central Indian expedition, combining heritage, wildlife, nature, and spirituality.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="M.P. Grand Odyssey 13D/12N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Experience the sheer magnitude of the "Heart of India". This 13-day mega-circuit takes you from the invincible forts of Gwalior and the erotic temples of Khajuraho into the dense, tiger-rich forests of Bandhavgarh. You will sail through the towering Marble Rocks of Jabalpur, ascend into the misty Satpura hills of Pachmarhi, trace the dawn of humanity at Bhimbetka, and conclude with the profound spiritual energy of Ujjain and the romantic ruins of Mandu.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Gwalior & The Pearl of Fortresses</h3>
                <p>Welcome to Madhya Pradesh! Arrive at Gwalior Airport or Railway Station. Your luxury chauffeur will transfer you to your heritage hotel. Spend the afternoon exploring the massive Gwalior Fort, featuring the stunning blue-tiled Man Singh Palace and the intricate Sas-Bahu Temples. Conclude your day with the fort's mesmerizing evening Sound & Light show.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Riverside Time Capsule: Gwalior to Orchha</h3>
                <p>After breakfast, depart for Orchha (approx. 3.5 hours). Frozen in time, this 16th-century town sits beautifully on the banks of the Betwa River. Explore the colossal Orchha Fort complex, including the Jahangir Mahal and Raj Mahal. In the evening, witness a spectacular sunset behind the Royal Chhatris (cenotaphs) along the river.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Orchha to Khajuraho (UNESCO Heritage)</h3>
                <p>Drive to the world-renowned temple town of Khajuraho (approx. 4 hours). Check into your premium resort. Spend the afternoon exploring the Western Group of Temples, a UNESCO World Heritage site globally famous for its stunning, intricate Nagara-style architecture and the beautifully carved Kamasutra sculptures. Enjoy the evening Sound & Light show.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Khajuraho to the Tiger's Domain (Bandhavgarh)</h3>
                <p>After an optional visit to the Eastern Group of Temples, depart the heritage plains and drive into the dense jungles of Bandhavgarh National Park (approx. 5 hours). This reserve boasts one of the highest densities of Royal Bengal Tigers in India. Check into your wilderness lodge and relax by the campfire.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Tracking the Royal Bengal Tiger</h3>
                <p>Wake up before dawn for a thrilling open 4x4 Gypsy safari into the core zones (Tala, Magdhi, or Khitauli) of Bandhavgarh. Keep your cameras ready for tigers, leopards, and diverse birdlife. Return to the lodge for lunch and relaxation, followed by a second afternoon safari to maximize your wildlife tracking experience.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Jungle to the Marble Rocks (Jabalpur)</h3>
                <p>Bid farewell to the forest and drive to the historic city of Jabalpur (approx. 3.5 hours). After checking into your hotel, head to Bhedaghat. Embark on a spectacular boat ride along the Narmada River as it cuts through 100-foot-tall, brilliantly white magnesium limestone cliffs known as the Marble Rocks. Visit the roaring Dhuandhar Falls nearby.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Jabalpur to the Queen of Satpura (Pachmarhi)</h3>
                <p>Leave the plains behind and begin your scenic ascent into the misty Satpura Range toward Pachmarhi, MP's only hill station (approx. 5 hours). Check into your heritage hill resort. Spend a relaxed evening walking through the colonial-era town center or enjoying the cool mountain breeze.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Waterfalls & Ravines of Pachmarhi</h3>
                <p>Spend the day exploring the lush plateau. Take a short hike down to the spectacular Bee Falls. Visit the ancient Pandav Caves and the naturally formed Jata Shankar Shiva shrine hidden within a deep rocky ravine. In the late afternoon, drive up to Dhoopgarh, the highest point in Madhya Pradesh, for a breathtaking sunset over the forest valleys.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Prehistory to the City of Lakes (Bhimbetka & Bhopal)</h3>
                <p>Descend the mountains and drive toward the capital city, Bhopal (approx. 5 hours). En route, stop at the UNESCO-listed Bhimbetka Rock Shelters, featuring vibrant cave paintings dating back 30,000 years. Arrive in Bhopal, check into your lake-view hotel, and enjoy a peaceful evening boat ride on the Upper Lake.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> The Buddhist Legacy (Sanchi) & Drive to Ujjain</h3>
                <p>Take a morning excursion to the UNESCO World Heritage Site of Sanchi (approx. 1 hour from Bhopal). Marvel at the Great Stupa commissioned by Emperor Ashoka. After exploring the ancient Buddhist monuments, embark on a scenic drive west to the holy city of Ujjain (approx. 4.5 hours). Check into your hotel upon arrival.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> The City of Mahakal & Drive to Indore</h3>
                <p>Begin your day with Darshan at the immensely powerful Mahakaleshwar Jyotirlinga (one of the 12 sacred Shiva shrines). Visit the Kal Bhairav Temple and the ancient Sandipani Ashram. In the afternoon, take a short drive to Indore (approx. 1.5 hours), the commercial and culinary capital of MP. In the evening, dive into the famous Sarafa Bazaar street food market.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> The Romantic Ruins of Mandu (Day Trip)</h3>
                <p>Take a spectacular day trip to Mandu (approx. 2 hours from Indore), an ancient fortified city perched on a forested plateau. Explore India's finest Afghan architecture, including the surreal Jahaz Mahal (Ship Palace), Hoshang Shah's Tomb, and Roopmati's Pavilion overlooking the Narmada Valley. Return to Indore for a farewell Malwi dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Departure from Indore</h3>
                <p>Enjoy a relaxed final morning. If time permits, visit the Rajwada Palace and Lal Bagh Palace to witness the grandeur of the Holkar dynasty. Your chauffeur will provide a seamless transfer to the Devi Ahilya Bai Holkar Airport or Indore Railway Station, bringing your grand, 13-day central Indian odyssey to a close.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels & Clean Jungle Lodges</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the 13-Day Mega Loop</li>
                <li><i class="fa-solid fa-paw"></i> 1 Shared Core Zone Gypsy Safari in Bandhavgarh</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/mp-grand-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- MP GRAND INSIGHTS HUB (6 GRID CARDS)                      -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Odyssey Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your massive 13-day cross-state journey is seamless, comfortable, and brilliantly executed.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>The Crucial Travel Window</h3>
                <p>This grand loop requires specific timing:</p>
                <ul>
                    <li><strong>Winter (Oct - Mar):</strong> The optimal window. Bandhavgarh is open, the weather is cool for the heritage walks in Gwalior and Khajuraho, and Pachmarhi is deeply pleasant.</li>
                    <li><strong>Monsoon Exclusion:</strong> If traveling between July and September, the Bandhavgarh safari segment must be entirely replaced or skipped as all national park core zones are strictly closed.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Extensive Highway Travel</h3>
                <p>Prepare for significant transition days:</p>
                <ul>
                    <li><strong>The Distances:</strong> This circuit covers well over 1,500 kilometers. Days 4, 7, and 9 involve 4 to 5 hours of driving.</li>
                    <li><strong>Vehicle Comfort:</strong> We strongly advise upgrading to an SUV (Innova Crysta) for groups of 3 or more to ensure superior legroom and shock absorption across the varied terrains.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-ticket"></i></div>
                <h3>Safari & Aarti Bookings</h3>
                <p>Advance planning is mandatory:</p>
                <ul>
                    <li><strong>Bandhavgarh:</strong> Core zone open gypsy safaris sell out exactly 120 days in advance. We must secure your permits at the earliest stage of booking.</li>
                    <li><strong>Mahakaleshwar:</strong> The early morning Bhasma Aarti in Ujjain requires special online registration weeks prior to arrival.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Packing for Extremes</h3>
                <p>You will cross multiple micro-climates:</p>
                <ul>
                    <li><strong>The Jungle & Hills:</strong> Early morning safaris in Bandhavgarh and evenings in Pachmarhi are freezing during winter (requiring heavy jackets).</li>
                    <li><strong>The Plains:</strong> Afternoons exploring Khajuraho, Sanchi, or Mandu can still be quite warm, requiring light cottons, sunglasses, and high-SPF sunscreen. Layering is critical.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-person-walking"></i></div>
                <h3>Physical Endurance</h3>
                <p>A 13-day trip requires stamina:</p>
                <ul>
                    <li><strong>Monument Fatigue:</strong> You will be walking through massive forts (Gwalior), vast temple complexes (Khajuraho), and sprawling ruins (Mandu). Supportive, broken-in walking shoes are an absolute must to prevent blisters and fatigue.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Journey</h3>
                <p>Taste the distinct regions of MP:</p>
                <ul>
                    <li><strong>Bundelkhand:</strong> In Orchha and Khajuraho, enjoy rustic, hearty dals and Bafla.</li>
                    <li><strong>Malwa:</strong> In Indore and Ujjain, dive into sweeter, tangier street food. Do not miss Indore's Poha-Jalebi breakfast and the midnight treats at Sarafa Bazaar.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your ultimate 13-Day Madhya Pradesh Odyssey.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="M.P. Grand Odyssey 13D/12N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>