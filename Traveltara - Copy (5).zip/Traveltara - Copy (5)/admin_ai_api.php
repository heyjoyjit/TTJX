<?php
// 🚀 TRAVELTARA DEEP-SCAN AI ENGINE
ob_start();
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) { 
    echo json_encode(["answer" => "System Alert: Cannot connect to the master database."]); 
    exit; 
}
$conn->set_charset("utf8mb4");

$input = json_decode(file_get_contents('php://input'), true);
$query = strtolower(trim($input['query'] ?? ''));

function fmt($num) { return "₹ " . number_format((float)$num, 0, '.', ','); }

$answer = "FALLBACK_TO_LOCAL"; // Default to your existing JS logic if no special intent is found

// 🤖 INTENT 1: Search for a Specific Booking ID
if (preg_match('/trv-\d+/i', $query, $matches)) {
    $bookId = strtoupper($matches[0]);
    $stmt = $conn->prepare("SELECT * FROM bookings WHERE `Booking ID` = ?");
    $stmt->bind_param("s", $bookId);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $answer = "<b>Booking Found (${bookId}):</b><br>👤 Client: {$row['First Name']} {$row['Last Name']}<br>📍 Destination: {$row['Destination']}<br>💳 Status: {$row['Status']}<br>💰 Amount Paid: {$row['Total Paid']}<br>📞 Phone: {$row['Primary Phone']}";
    } else {
        $answer = "I searched the database but could not find any booking with the ID <b>$bookId</b>.";
    }
}
// 🤖 INTENT 2: Deep Search for a Person (Name or Email)
elseif (preg_match('/search (for )?([a-z0-9@.\s]+)|find ([a-z0-9@.\s]+)|details (for|of) ([a-z0-9@.\s]+)/i', $query, $matches)) {
    $search_term = trim($matches[2] ?: ($matches[3] ?: ($matches[4] ?: $matches[5])));
    if(!empty($search_term) && strlen($search_term) > 2 && $search_term != 'revenue' && $search_term != 'profit' && $search_term != 'sales') {
        $term = "%".$search_term."%";
        // Scan Bookings First
        $stmt = $conn->prepare("SELECT * FROM bookings WHERE `First Name` LIKE ? OR `Last Name` LIKE ? OR `Email` LIKE ? LIMIT 3");
        $stmt->bind_param("sss", $term, $term, $term);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            $answer = "<b>I found the following matches in Bookings:</b><br>";
            while($row = $res->fetch_assoc()) {
                $answer .= "- {$row['First Name']} {$row['Last Name']} (ID: {$row['Booking ID']}) traveling to {$row['Destination']}.<br>";
            }
        } else {
            // Scan CRM Leads if not in Bookings
            $stmt2 = $conn->prepare("SELECT * FROM master_crm WHERE `Name` LIKE ? OR `Email Address` LIKE ? LIMIT 3");
            $stmt2->bind_param("ss", $term, $term);
            $stmt2->execute();
            $res2 = $stmt2->get_result();
            if ($res2->num_rows > 0) {
                $answer = "<b>I found them in your CRM Leads:</b><br>";
                while($row = $res2->fetch_assoc()) {
                    $answer .= "- {$row['Name']} (Phone: {$row['Phone Number']}) - Current Status: {$row['Action Status']}.<br>";
                }
            } else {
                $answer = "I ran a deep scan across all CRM files and Bookings for '<b>$search_term</b>' but found zero matches.";
            }
        }
    }
}
// 🤖 INTENT 3: Real-Time Live SQL Analytics
elseif (strpos($query, 'last hour') !== false || strpos($query, 'past hour') !== false) {
    $sql = "SELECT COUNT(*) as c, SUM(CAST(REPLACE(REPLACE(`Total Paid`, '₹', ''), ',', '') AS DECIMAL(10,2))) as r FROM bookings WHERE `Timestamp` >= DATE_SUB(NOW(), INTERVAL 1 HOUR) AND `Status` = 'Payment Complete'";
    $res = $conn->query($sql)->fetch_assoc();
    $amt = $res['r'] ? fmt($res['r']) : "₹ 0";
    $answer = "⏱️ Checking live data... In the <b>last 1 hour</b>, you have successfully closed <b>{$res['c']} bookings</b> generating exactly <b>{$amt}</b> in revenue.";
}
elseif (strpos($query, 'today') !== false) {
    $sql = "SELECT COUNT(*) as c, SUM(CAST(REPLACE(REPLACE(`Total Paid`, '₹', ''), ',', '') AS DECIMAL(10,2))) as r FROM bookings WHERE DATE(`Timestamp`) = CURRENT_DATE() AND `Status` = 'Payment Complete'";
    $res = $conn->query($sql)->fetch_assoc();
    $amt = $res['r'] ? fmt($res['r']) : "₹ 0";
    $answer = "📅 <b>Today's Live Performance:</b> You have closed <b>{$res['c']} bookings</b> generating <b>{$amt}</b> in gross revenue.";
}

ob_clean();
echo json_encode(["answer" => $answer]);
ob_end_flush();
$conn->close();
?>