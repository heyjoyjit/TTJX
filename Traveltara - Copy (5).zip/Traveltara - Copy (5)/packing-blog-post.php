<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Packing for the Himalayas: A Luxury Traveler's Guide | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <header class="hero" style="height: 50vh; background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/pack-blog.jpg') center/cover;"></header>

    <main class="single-post-container section-padding">
        <div class="post-header">
            <span class="blog-category">Preparation</span>
            <h1>Packing for the Himalayas: A Luxury Traveler's Guide</h1>
            <div class="post-meta-details">
                <p><i class="fa-regular fa-calendar"></i> March 05, 2026</p>
                <p><i class="fa-regular fa-user"></i> By Traveltara Experts</p>
                <p><i class="fa-regular fa-clock"></i> 3 min read</p>
            </div>
        </div>

        <article class="post-content">
            <p class="lead-paragraph">How to pack light while ensuring you have the right layers for the unpredictable mountain weather in Himachal, Darjeeling, and Sikkim.</p>

            <p>Traveling to the Himalayas presents a unique packing challenge. You need to be prepared for freezing morning temperatures at high-altitude lakes, warm afternoon sun in the valleys, and elegant evenings dining at 5-star heritage properties. The secret is not packing *more*, but packing *smarter*.</p>

            <blockquote class="post-quote">
                "There is no such thing as bad weather, only inappropriate clothing."
            </blockquote>

            <h2>The Art of Layering</h2>
            <p>Forget the massive, bulky winter coats that take up half your suitcase. The luxury traveler relies on premium layering. Start with thermal base layers made of ultra-fine merino wool. Over this, a cashmere sweater or a sleek fleece provides warmth without restricting movement. Finally, a lightweight, premium windproof and waterproof shell jacket is essential for deflecting the biting mountain winds.</p>

            <h2>Footwear: Function Meets Style</h2>
            <p>You do not need heavy mountaineering boots for a luxury tour. A pair of waterproof, stylish leather walking shoes with good grip is perfect for navigating cobbled paths in Shimla or Darjeeling tea estates. Pack a pair of elegant flats or loafers for the evenings when relaxing in your resort.</p>

            <div class="in-post-cta">
                <h3>Let us handle the details.</h3>
                <p>When you book with Traveltara, you receive a custom, destination-specific packing list.</p>
                <button class="btn-primary" onclick="openLeadPopup()">Consult an Expert</button>
            </div>

            <h2>Luggage Considerations</h2>
            <p>Mountain roads can be winding, and some boutique heritage properties have narrow staircases. We highly recommend using premium soft-shell luggage or duffel bags on wheels rather than rigid, oversized hard cases. Remember, when you travel with Traveltara, your porter and driver handle all the heavy lifting, allowing you to simply enjoy the view.</p>
        </article>
        
        <div class="author-box">
            <div class="author-avatar"><i class="fa-solid fa-user-tie"></i></div>
            <div class="author-info">
                <h4>Traveltara Experts</h4>
                <p>Your guides to effortless and stylish travel.</p>
            </div>
        </div>
    </main>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">Internation</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/917439877604" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

    <a href="https://wa.me/917439877604" class="whatsapp-sticky" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Plan Your Trip</h3>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Reference *</label><input type="text" value="Packing Guide Post" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>