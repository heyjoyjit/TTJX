<?php
// Top of andhra-pradesh-itinerary.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Andhra Pradesh Tour Packages | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Andhra Pradesh Packages</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['andhra hero']) ? $tourImages['andhra hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="subpage-hero-content">
            <h1>The Essence of Incredible India</h1>
            <p>From the mystical canyons of Gandikota to the serene Araku valleys and the world's richest spiritual corridors.</p>
        </div>
    </header>

    <!-- MAIN GRID SECTION -->
    <section class="section-padding" style="background-color: #fcfcfc;">
        <div style="max-width: 1200px; margin: auto; text-align: center; margin-bottom: 50px; padding: 0 20px;">
            <h2 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; color: #0A1128; margin-bottom: 15px;">Andhra Pradesh Curated Circuits</h2>
            <p style="color: #666; max-width: 800px; margin: 0 auto;">Unveil the best-kept secrets of the Southeast. Whether you are seeking high-octane adventure in ancient caves, a peaceful cruise down the mighty Godavari, or a spiritual awakening in Tirumala, our itineraries offer a complete and uncrowded perspective of Andhra.</p>
        </div>

        <div class="grid-container" id="andhraPackagesGrid">
            
            <!-- CARD 1: COASTAL & COFFEE -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['andhra coastal coffee']) ? $tourImages['andhra coastal coffee'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">5-6 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Coastal & Coffee Circuit</h3>
                    <p><strong>Vizag & Araku Valley:</strong> A stunning contrast of blue and green. Explore the submarine museum on Vizag's coast, ride the glass-domed train through 58 tunnels, and wake up in the misty coffee plantations of Araku.</p>
                    <h4 class="package-price">Starts at ₹14,500</h4>
                    <a href="package-andhra-coastal.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 2: CANYONS & CAVES -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['andhra canyons']) ? $tourImages['andhra canyons'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">4-5 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Canyons & Caves Adventure</h3>
                    <p><strong>Gandikota & Belum Caves:</strong> Witness India's answer to the Grand Canyon. Stand on the towering red sandstone cliffs of the Pennar River and descend into the deepest underground cave systems in the subcontinent.</p>
                    <h4 class="package-price">Starts at ₹12,500</h4>
                    <a href="package-andhra-adventure.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 3: DIVINE HERITAGE -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['andhra heritage']) ? $tourImages['andhra heritage'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">5-6 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Divine Heritage Trail</h3>
                    <p><strong>Tirupati, Kalahasti & Lepakshi:</strong> A journey of faith and architectural wonder. Experience the unparalleled spiritual energy of Tirumala Hills and marvel at the hanging pillars and monolithic Nandi of the 16th-century Lepakshi temple.</p>
                    <h4 class="package-price">Starts at ₹15,500</h4>
                    <a href="package-andhra-divine.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 4: GODAVARI CRUISE -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['andhra river']) ? $tourImages['andhra river'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">4 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Godavari River & Delta Cruise</h3>
                    <p><strong>Rajahmundry & Papikondalu:</strong> Drift through the majestic "Papi Hills" on a spectacular river cruise. Experience the lush delta life, ancient riverside temples, and the serene, untouched Konaseema backwaters.</p>
                    <h4 class="package-price">Starts at ₹11,500</h4>
                    <a href="package-andhra-river.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 5: COMPLETE EXPEDITION -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['andhra ultimate']) ? $tourImages['andhra ultimate'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">15 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Royal Andhra Expedition</h3>
                    <p><strong>The Grand Complete Tour:</strong> The ultimate masterpiece. A 15-day odyssey spanning every horizon—from the Buddhist stupas of Amaravati to the canyons, caves, hills, and pristine beaches of the East Coast.</p>
                    <h4 class="package-price">Starts at ₹45,000</h4>
                    <a href="package-andhra-ultimate.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 6: TAILORED -->
            <div class="destination-card" style="background: #0A1128; color: #fff;">
                <div class="card-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%; padding: 40px 20px;">
                    <i class="fa-solid fa-map-location-dot" style="font-size: 3rem; color: #C5A059; margin-bottom: 20px;"></i>
                    <h3 style="color: #fff;">Bespoke Andhra Experience</h3>
                    <p style="color: #ccc;">Looking for a specialized Buddhist circuit in Nagarjunakonda or a luxury beach retreat in Nellore? Let our experts craft a journey that fits your exact pace and preferences.</p>
                    <button class="btn-primary" onclick="openLeadPopup()" style="margin-top: 20px; width: 100%;">Consult an Expert</button>
                </div>
            </div>

        </div>
    </section>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, Tamil Nadu, Andhra Pradesh, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream Andhra Pradesh exploration.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Andhra Pradesh Packages" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>