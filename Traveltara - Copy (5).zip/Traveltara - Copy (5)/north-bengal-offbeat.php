<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offbeat North Bengal - 5 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="north-bengal-itinerary.php">North Bengal Packages</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Offbeat North Bengal (5D/4N)</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/north-bengal-offbeat.jpg') center/cover;">
        <div class="subpage-hero-content">
            <h1>Offbeat North Bengal</h1>
            <p>5 Days / 4 Nights of Hidden Himalayan Hamlets</p>
        </div>
    </header>

    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Escape the commercial crowds and discover the raw, untouched beauty of North Bengal. This carefully curated itinerary takes you through pine forests, eco-villages, and misty viewpoints in Sittong, Tinchuley, and Lepchajagat, offering an authentic Himalayan experience.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & Transfer to Sittong</h3>
                <p>Arrive at Bagdogra Airport or NJP. Begin your scenic drive to Sittong, fondly known as the 'Orange Village'. Check into a premium eco-homestay nestled amidst lush orchards and enjoy organic, home-cooked local cuisine.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Sittong to Tinchuley</h3>
                <p>Wake up to the sounds of nature. Visit the ancient Sittong Monastery and the steel bridge over the Riyang River. After lunch, transfer to the misty village of Tinchuley. Check into your retreat and enjoy a quiet evening.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Tinchuley Sightseeing</h3>
                <p>Start your day with a mesmerizing sunrise from the Tinchuley viewpoint. Visit the sprawling Takdah Tea Estate, the beautiful Orchid Center, and take a peaceful walk through the nearby pine forests.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Transfer to Lepchajagat</h3>
                <p>After breakfast, drive to Lepchajagat, a secluded village surrounded by dense forests of oak, pine, and rhododendron. Enjoy unobstructed views of the Kanchenjunga range away from the city noise.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Departure</h3>
                <p>Soak in the final views of the mountains during your morning tea. Your chauffeur will provide a private, comfortable transfer back down to Bagdogra Airport.</p>
            </div>
        </div>

        <aside class="itinerary-sidebar">
            <div class="sidebar-price-box">
                <span class="price-label">Starting From</span>
                <div class="price-amount">₹16,500<span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list">
                <li><i class="fa-solid fa-house"></i> Premium Eco-Homestays</li>
                <li><i class="fa-solid fa-car"></i> Private Dedicated Cab</li>
                <li><i class="fa-solid fa-bowl-rice"></i> Authentic Local Meals Included</li>
                <li><i class="fa-solid fa-tree"></i> Crowd-Free Scenic Locations</li>
            </ul>
            
            <hr class="sidebar-divider">
            
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/offbeat-bengal-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">Internation</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/917439877604" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

    <a href="https://wa.me/917439877604" class="whatsapp-sticky" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Speak with a Travel Expert</h3>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Offbeat North Bengal (5D/4N)" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>