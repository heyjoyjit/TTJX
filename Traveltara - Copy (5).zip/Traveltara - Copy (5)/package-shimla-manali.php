<?php
// Top of package-shimla-manali.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹19,500"; 
$sheet_affordable_price = "₹28,000";
$sheet_super_price = "₹45,000";

// EXACT package name from Google Sheet
$target_package = "Classic Himachal 7D/6N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Valley View Hotels</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for all Transfers</li>
            <li><i class="fa-solid fa-mountain"></i> Standard Rohtang / Solang Tour</li>
            <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Boutique Resorts</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> Priority Rohtang Permit Assistance</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Luxury (e.g., Wildflower Hall, Span Resort)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-crown"></i> VIP Atal Tunnel & Rohtang Access</li>
            <li><i class="fa-solid fa-utensils"></i> Exclusive Fine Dining & Bonfires</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Classic Himachal Tour | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="himachal-itinerary.php">Himachal</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Classic Himachal (7D/6N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['shimla manali hero']) ? $tourImages['shimla manali hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 7 Days / 6 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Classic Himachal</h1>
            <p>A perfectly paced, breathtaking journey through the Queen of Hills and the Valley of Gods.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Classic Himachal 7D/6N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Welcome to the ultimate Himalayan escape. We have structured this 7-day itinerary to ensure you experience the absolute best of Shimla and Manali without the exhaustion of rushed travel. You will stroll through colonial-era heritage streets, drive alongside the roaring Beas River in Kullu, and ascend to magnificent snow-capped altitudes, returning to premium comforts every evening.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Chandigarh & Ascent to Shimla</h3>
                <p>Your journey begins at the Chandigarh Airport or Railway Station. Your private luxury chauffeur will greet you and commence the scenic 4-hour ascent into the Himalayas. Arrive in Shimla, the former summer capital of British India. Check into your hotel and spend a relaxed evening taking a leisurely walk along the famous, vehicle-free Mall Road.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Charm of Kufri & Shimla Heritage</h3>
                <p>After a hearty mountain breakfast, embark on a short drive to Kufri, a picturesque hill station known for its panoramic views and Himalayan Nature Park. Enjoy optional horse riding or yak riding up to Mahasu Peak. In the afternoon, return to Shimla to explore the grand Viceregal Lodge, the neo-Gothic Christ Church, and The Ridge. Dinner and overnight stay in Shimla.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Great Himalayan Drive: Shimla to Manali</h3>
                <p>Today features one of India's most stunning road trips. Depart Shimla for Manali (approx. 7-8 hours). The drive takes you past the beautiful Sundernagar Lake, the Mandi hills, and the magnificent Pandoh Dam. You will then enter the Kullu Valley, driving alongside the roaring, crystal-clear Beas River. Arrive in Manali by evening, check into your resort, and relax.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Old Manali & Local Sightseeing</h3>
                <p>Immerse yourself in the local culture of Manali. Visit the ancient, towering cedar-fringed Hadimba Devi Temple, a wooden architectural marvel. Proceed to the Vashisht Village, famous for its natural hot sulfur springs and ancient temples. Spend the afternoon exploring the vibrant cafes and bohemian vibe of Old Manali. Dinner at your resort.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Snow Peaks: Solang Valley & Rohtang Pass</h3>
                <p>Dedicate today to high-altitude adventure. Drive to the breathtaking Solang Valley to enjoy optional adventure sports like paragliding, zorbing, or ATV rides. If weather and National Green Tribunal (NGT) permits allow, continue your ascent to the legendary Rohtang Pass or the engineering marvel of the Atal Tunnel into the Sissu Valley for an unforgettable snow experience. Return to Manali in the evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Kullu Valley Excursion & Drive to Chandigarh</h3>
                <p>After breakfast, begin your descent from Manali. Stop in the Kullu Valley, world-renowned for its exquisite pashmina shawls and thrilling white-water river rafting on the Beas River. After enjoying Kullu, continue your drive back down to Chandigarh. Check into a premium city hotel for your final night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Departure</h3>
                <p>Enjoy your final breakfast. Depending on your flight or train schedule, you may opt for a quick visit to the Chandigarh Rock Garden or Sukhna Lake. Your chauffeur will provide a seamless drop-off at the Chandigarh Airport or Railway station, concluding your magnificent Himalayan tour.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Valley View Hotels</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for all Transfers</li>
                <li><i class="fa-solid fa-mountain"></i> Standard Rohtang / Solang Tour</li>
                <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/himachal-classic-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- HIMACHAL INSIGHTS HUB (6 GRID CARDS)                      -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- UNIVERSAL CORE ICONS USED FOR 100% COMPATIBILITY          -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Himalayan Travel Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details and seasonal rules to ensure a flawless journey through the mountains.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time to Visit</h3>
                <p>Himachal offers two distinct, equally beautiful experiences:</p>
                <ul>
                    <li><strong>Summer (Mar - Jun):</strong> The peak season. Perfect, pleasant weather (15°C to 25°C) ideal for families escaping the heat.</li>
                    <li><strong>Winter (Nov - Feb):</strong> The snow season. Temperatures drop below freezing. Ideal for honeymooners and snow enthusiasts.</li>
                    <li><strong>Monsoon (Jul - Aug):</strong> Not recommended due to heavy rains causing frequent landslides and road blockages.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-file-signature"></i></div>
                <h3>Rohtang Pass Permits</h3>
                <p>Access to Rohtang Pass is strictly regulated by the government:</p>
                <ul>
                    <li><strong>NGT Rules:</strong> The National Green Tribunal strictly limits the number of vehicles allowed up to Rohtang daily to protect the ecology.</li>
                    <li><strong>Pre-Booking:</strong> Permits must be applied for online, often weeks in advance. Access is <strong>never 100% guaranteed</strong> and is always subject to weather clearance.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-snowflake"></i></div>
                <h3>Winter Logistics</h3>
                <p>If traveling between December and March, preparation is key:</p>
                <ul>
                    <li><strong>Snow Gear:</strong> Do not buy expensive snow gear. You can easily rent heavy snowsuits and boots at affordable rates in Manali/Solang.</li>
                    <li><strong>Road Closures:</strong> Rohtang Pass is completely closed during peak winter due to extreme snowfall. Sightseeing will be diverted to Solang Valley or Atal Tunnel.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Mountain Transport</h3>
                <p>Mountain driving requires patience and the right mindset:</p>
                <ul>
                    <li><strong>Motion Sickness:</strong> The winding roads from Chandigarh to Shimla, and Shimla to Manali, can cause nausea. Carry basic medication.</li>
                    <li><strong>Travel Times:</strong> In the hills, distance is measured in hours, not kilometers. A 40km drive can easily take 2 hours.</li>
                    <li><strong>No Night Driving:</strong> For safety, all intercity travel must be completed before sunset.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-mountain"></i></div>
                <h3>Altitude & Health</h3>
                <p>As you ascend rapidly from the plains, your body needs time to adjust:</p>
                <ul>
                    <li><strong>Acclimatization:</strong> Shimla and Manali sit above 2,000 meters. Take it slow on your first day; do not rush into heavy trekking.</li>
                    <li><strong>Hydration:</strong> Drink plenty of water. The mountain air is dry and can cause rapid dehydration.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Highlights</h3>
                <p>The cold weather is perfect for rich, warming Himalayan cuisine:</p>
                <ul>
                    <li><strong>Himachali Dham:</strong> A traditional, multi-course vegetarian feast slow-cooked by specialized Brahmin chefs, usually available on request at premium resorts.</li>
                    <li><strong>Siddu:</strong> A local steamed bread stuffed with walnut or poppy seed paste, best enjoyed with generous amounts of warm ghee.</li>
                    <li><strong>Trout Fish:</strong> Kullu Valley is famous for its incredibly fresh, pan-fried river trout.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Classic Himachal 7D/6N" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>