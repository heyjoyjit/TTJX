<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="dyn-page-title">Loading Package... | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page" id="dyn-breadcrumb">Loading...</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" id="dyn-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), #0A1128 center/cover;">
        <div class="subpage-hero-content">
            <h1 id="dyn-title">Loading...</h1>
            <p id="dyn-duration">... Days / ... Nights</p>
        </div>
    </header>

    <div class="itinerary-layout-container" style="display: none;" id="content-container">
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p id="dyn-overview">Fetching the perfect high-value itinerary for you...</p>
            </div>
            
            <div id="dyn-itinerary-blocks">
                </div>
        </div>

        <aside class="itinerary-sidebar">
            <div class="sidebar-price-box">
                <span class="price-label">Starting From</span>
                <div class="price-amount" id="dyn-price">₹---<span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list">
                <li><i class="fa-solid fa-bed"></i> Authentic Homestays & Stays</li>
                <li><i class="fa-solid fa-car"></i> Reliable Transport</li>
                <li><i class="fa-solid fa-compass"></i> Curated Local Experiences</li>
                <li><i class="fa-solid fa-wallet"></i> High-Value Economy Focus</li>
            </ul>
            
            <hr class="sidebar-divider">
            
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="#" id="dyn-brochure" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>

    <div id="loading-spinner" style="text-align: center; padding: 100px 20px;">
        <i class="fa-solid fa-circle-notch fa-spin" style="font-size: 3rem; color: #D4AF37;"></i>
        <p style="margin-top: 15px; font-family: 'Lato', sans-serif; color: #666;">Crafting your itinerary...</p>
    </div>

    <section class="suggestion-strip-section">
        <div style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
            <div class="suggestion-header">
                <h3><i class="fa-solid fa-sparkles" style="color: #D4AF37;"></i> Recommended For You</h3>
            </div>
            <div class="suggestion-scroll-container" id="dynamicSuggestionBox"></div>
        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

    <div class="popup-overlay" id="leadPopup">
        </div>

    <script src="js/main.js"></script>

</body>
</html>