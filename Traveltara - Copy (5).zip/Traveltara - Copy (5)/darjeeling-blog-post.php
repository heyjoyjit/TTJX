<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colonial Charm: Top Tea Estate Bungalows in Darjeeling | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <header class="hero" style="height: 50vh; background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/darjeeling-blog.jpg') center/cover;"></header>

    <main class="single-post-container section-padding">
        <div class="post-header">
            <span class="blog-category">Heritage Stays</span>
            <h1>Colonial Charm: Top Tea Estate Bungalows in Darjeeling</h1>
            <div class="post-meta-details">
                <p><i class="fa-regular fa-calendar"></i> March 28, 2026</p>
                <p><i class="fa-regular fa-user"></i> By Traveltara Experts</p>
                <p><i class="fa-regular fa-clock"></i> 4 min read</p>
            </div>
        </div>

        <article class="post-content">
            <p class="lead-paragraph">Step back in time and wake up to the aroma of fresh tea leaves. Experience the "Champagne of Teas" while wrapped in old-world colonial luxury.</p>

            <p>Darjeeling is more than just a hill station; it is a legacy. While the main town offers bustling markets and views of the mighty Kanchenjunga, the true luxury of North Bengal lies hidden within its sprawling, emerald tea estates. At <strong>traveltara</strong>, we specialize in curating stays at heritage bungalows that offer an unparalleled mix of history, nature, and bespoke service.</p>

            <blockquote class="post-quote">
                "There is no Wi-Fi in the tea gardens, but we promise you will find a better connection."
            </blockquote>

            <h2>The Glenburn Experience</h2>
            <p>Imagine a century-old boutique hotel sitting high above the River Rungeet. Your day begins with bed tea brought by a personal butler, followed by a guided walk through the estate, learning the art of plucking. Evenings are spent by a crackling fireplace with a gin and tonic in hand.</p>

            <h2>Makaibari & Kurseong Retreats</h2>
            <p>For those who want to be closer to the historic Toy Train routes, the lower elevations of Kurseong offer magnificent heritage properties. Here, luxury meets sustainability. You can indulge in world-class tea tasting sessions hosted by the estate managers themselves.</p>

            <div class="in-post-cta">
                <h3>Ready for High Tea in the Himalayas?</h3>
                <p>Let our Kolkata-based experts book your exclusive heritage stay today.</p>
                <button class="btn-primary" onclick="openLeadPopup()">Consult an Expert</button>
            </div>

            <h2>Why Choose a Heritage Stay?</h2>
            <p>Unlike standard luxury hotels, heritage bungalows offer privacy and personalized attention. With only a handful of suites per property, you are treated as a house guest rather than a tourist. Meals are often farm-to-table, customized to your palate, and served in grand dining rooms.</p>
        </article>
        
        <div class="author-box">
            <div class="author-avatar"><i class="fa-solid fa-user-tie"></i></div>
            <div class="author-info">
                <h4>Traveltara Experts</h4>
                <p>Unlocking the hidden luxury of North Bengal for discerning travelers.</p>
            </div>
        </div>
    </main>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">Internation</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/917439877604" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

     <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Book Your Heritage Stay</h3>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Reference *</label><input type="text" value="Darjeeling Tea Estates" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>