<?php
// Top of package-punjab-9d.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹28,500"; 
$sheet_affordable_price = "₹42,000";
$sheet_super_price = "₹65,000";

// EXACT package name from Google Sheet
$target_package = "Golden Punjab 9D/8N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star City Hotels</li>
            <li><i class="fa-solid fa-car"></i> Private Sedan for Intercity Travel</li>
            <li><i class="fa-solid fa-camera"></i> Standard Sightseeing Tours</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Heritage & Farm Stays</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> VIP Wagah Border Assistance</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Authentic Punjabi Meals</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Luxury (e.g., Taj Swarna) & Boutique Palaces</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Guided Heritage Walks</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Fine Dining Experiences</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Golden Punjab Tour | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* ==========================================================================
           DESIGN: DESTINATION HUB (GRID CARDS) WITH UNIVERSAL ICONS
           ========================================================================== */
        .info-hub-section {
            background: #f9fafb;
            border-top: 1px solid #eaeaea;
            padding: 80px 0;
        }
        .info-hub-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .info-card {
            background: #fff;
            border-radius: 12px;
            padding: 35px 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            border-top: 5px solid #C5A059;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .info-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.08);
        }
        .info-icon-wrapper {
            width: 60px;
            height: 60px;
            background: rgba(197, 160, 89, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        .info-icon-wrapper i {
            font-size: 1.5rem;
            color: #C5A059;
        }
        .info-card h3 {
            font-family: 'Playfair Display', serif;
            font-size: 1.4rem;
            color: #0A1128;
            margin-bottom: 15px;
        }
        .info-card p, .info-card li {
            font-family: 'Lato', sans-serif;
            font-size: 0.95rem;
            color: #555;
            line-height: 1.6;
        }
        .info-card ul {
            padding-left: 18px;
            margin-top: 10px;
        }
        .info-card li {
            margin-bottom: 8px;
        }
    </style>
</head>
<body>

    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Golden Punjab (9D/8N)</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['golden punjab hero']) ? $tourImages['golden punjab hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 9 Days / 8 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Golden Punjab Tour</h1>
            <p>A 9-Day majestic journey through Royal Palaces, Golden Shrines, and Vibrant Farms.</p>
        </div>
    </header>
    
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Golden Punjab 9D/8N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Immerse yourself in the vibrant heart and soul of India with our 9-Day Golden Punjab itinerary. From the profound spiritual serenity of the Golden Temple in Amritsar to the regal Goldeneur of Patiala and the modern architecture of Chandigarh, this journey perfectly balances heritage, agriculture, history, and unparalleled Punjabi hospitality in premium comfort.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Amritsar & The Golden Aura</h3>
                <p>Touch down at Sri Guru Ram Dass Jee International Airport. Your luxury chauffeur will transfer you to your premium hotel. In the evening, visit the resplendent Golden Temple (Sri Harmandir Sahib) to witness the magical Palki Sahib ceremony under the stars.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Heritage Walk & The Wagah Border</h3>
                <p>After breakfast, visit the historic Jallianwala Bagh and explore the emotionally moving Partition Museum. In the afternoon, head toward the India-Pakistan border. Experience the electrifying Beating Retreat ceremony at Wagah Border. Return for an authentic Amritsari Kulcha dinner.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Amritsar to Jalandhar (Farm Stay Experience)</h3>
                <p>Drive to Jalandhar and check into a premium, luxury farm retreat. Experience the true essence of 'Pind' (village) life without sacrificing modern comforts. Enjoy tractor rides through lush mustard fields and indulge in 'Sarson da Saag & Makki di Roti' prepared by expert chefs.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Jalandhar to Ludhiana</h3>
                <p>Travel to the industrial hub of Ludhiana. Visit the majestic Maharaja Ranjit Singh War Museum and explore the bustling local textile markets, famous worldwide for their hosiery and woolens. Check into your premium city hotel and enjoy a relaxed evening.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Royal Heritage of Patiala</h3>
                <p>Drive to Patiala, a city steeped in royal history. Visit the awe-inspiring Qila Mubarak complex and the beautiful Sheesh Mahal (Palace of Mirrors). Spend your evening shopping for exquisite Phulkari dupattas and handcrafted Punjabi Juttis in the vibrant Adalat Bazaar.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Patiala to Chandigarh</h3>
                <p>After breakfast, take a scenic drive to Chandigarh, India's first planned, modern city. Check into your hotel and spend a peaceful evening strolling along the serene shores of Sukhna Lake, watching the sunset over the Shivalik foothills.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Exploring the Modern City</h3>
                <p>Embark on a full-day sightseeing tour of Chandigarh. Marvel at the unique sculptures in Nek Chand's famous Rock Garden, visit the expansive Zakir Hussain Rose Garden, and explore the architectural brilliance of the Capitol Complex. Spend your evening café-hopping in Sector 17.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Excursion to Anandpur Sahib</h3>
                <p>Take a day trip to the holy city of Anandpur Sahib, the birthplace of the Khalsa. Visit the spectacular Virasat-e-Khalsa museum, which beautifully chronicles the history and culture of Punjab and Sikhism through immersive, world-class exhibits. Return to Chandigarh for your final night.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Departure</h3>
                <p>Enjoy a lavish farewell breakfast. Your chauffeur will provide a seamless transfer to the Chandigarh International Airport or Railway Station for your onward journey, carrying with you the vibrant spirit of Punjab.</p>
            </div>
        </div>

        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star City Hotels</li>
                <li><i class="fa-solid fa-car"></i> Private Sedan for Intercity Travel</li>
                <li><i class="fa-solid fa-camera"></i> Standard Sightseeing Tours</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/punjab-9d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Punjab Travel Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical information for a smooth, culturally respectful, and delicious journey through North India.</p>
        </div>

        <div class="info-hub-grid">
            
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time to Visit</h3>
                <p>Punjab experiences extreme weather variations. Plan your visit accordingly:</p>
                <ul>
                    <li><strong>Oct to March:</strong> The golden window. Cool, pleasant days and chilly nights. Perfect for sightseeing.</li>
                    <li><strong>April to June:</strong> Blistering summers. Daytime temperatures frequently exceed 40°C.</li>
                    <li><strong>July to Sept:</strong> Monsoon season brings high humidity and heavy rainfall.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-sun"></i></div>
                <h3>Seasonal Landscapes</h3>
                <p>The agricultural heartland of India shifts colors with the seasons:</p>
                <ul>
                    <li><strong>Winter (Jan-Feb):</strong> Vast, cinematic fields of bright yellow mustard (Sarson) flowers.</li>
                    <li><strong>Spring (March):</strong> The wheat harvest season brings golden, glowing fields across the state.</li>
                    <li><strong>Monsoon:</strong> Deep, lush greens as the paddy (rice) fields are flooded.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-camera"></i></div>
                <h3>Festivals & Fairs</h3>
                <p>Time your trip to witness Punjab's unmatched energy and vibrancy:</p>
                <ul>
                    <li><strong>Baisakhi (April):</strong> The massive harvest festival. Expect vibrant Bhangra, Giddha, and bustling fairs.</li>
                    <li><strong>Diwali / Bandi Chhor Divas:</strong> The Golden Temple is illuminated with thousands of lights and spectacular fireworks.</li>
                    <li><strong>Hola Mohalla (March):</strong> Witness breathtaking martial arts (Gatka) displays in Anandpur Sahib.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Cultural Etiquette</h3>
                <p>Punjab is deeply spiritual. Keep these rules in mind when visiting Gurudwaras:</p>
                <ul>
                    <li><strong>Head Coverings:</strong> Both men and women must cover their heads before entering any Gurudwara. Carry a scarf.</li>
                    <li><strong>Footwear:</strong> Shoes must be removed and feet washed at the entrance.</li>
                    <li><strong>Dress Code:</strong> Modest clothing is required. Avoid shorts or sleeveless tops.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Transport & Roads</h3>
                <p>Navigating the state is relatively smooth compared to mountain regions:</p>
                <ul>
                    <li><strong>Highways:</strong> Punjab boasts some of the finest, widest national highways in India, making road travel comfortable.</li>
                    <li><strong>Wagah Border:</strong> Reach the border at least 2 hours early to secure a seat, as it gets heavily crowded.</li>
                    <li><strong>Fog Alerts:</strong> In December and January, dense morning fog can cause highway and flight delays.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>The Culinary Journey</h3>
                <p>Punjab is the food capital of India. Prepare for rich, heavy, and unforgettable flavors:</p>
                <ul>
                    <li><strong>Dhaba Culture:</strong> Stop at a highway Dhaba for authentic Dal Makhani, Paneer, and stuffed Parathas loaded with white butter.</li>
                    <li><strong>Amritsari Special:</strong> Do not miss the legendary crispy Amritsari Kulcha paired with chilled Lassi.</li>
                    <li><strong>The Langar:</strong> Partake in the community kitchen at the Golden Temple—a profoundly humbling and delicious experience.</li>
                </ul>
            </div>

        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Golden Punjab 9D/8N" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>