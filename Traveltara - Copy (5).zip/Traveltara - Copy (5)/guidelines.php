<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Guidelines | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Travel Guidelines</h1>
        <p>Important information for a seamless journey.</p>
    </header>

    <main class="info-container">
        <h2>Identification & Documentation</h2>
        <p>For all domestic travel within India, a valid government-issued ID is mandatory. Guests are required to submit their Aadhaar details during the booking process. For international travel, a passport with at least six months of validity from the date of return is strictly required.</p>

        <h2>Understanding Our Tour Tiers</h2>
        <p>To ensure we meet your specific expectations, our packages are categorized into distinct tiers:</p>
        <ul>
            <li><strong>Budget:</strong> Comfortable, clean, and highly authentic stays focusing on value.</li>
            <li><strong>Affordable Luxury:</strong> Premium 4-star equivalent accommodations with upgraded transport.</li>
            <li><strong>Super Luxury:</strong> Exclusive 5-star heritage properties, private guides, and top-tier amenities.</li>
            <li><strong>Customised:</strong> Fully bespoke itineraries built from the ground up by our travel agents.</li>
        </ul>

        <h2>Health & Safety</h2>
        <p>Your safety is our ultimate priority. We partner exclusively with verified transport providers and highly-rated hotel chains. We recommend all guests review specific state or international health guidelines prior to their commencement date.</p>
    </main>

</body>
</html>