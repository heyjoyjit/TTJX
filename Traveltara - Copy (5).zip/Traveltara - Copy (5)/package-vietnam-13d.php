<?php
// Top of package-vietnam-13d.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

$sheet_budget_price = "₹88,500"; 
$sheet_affordable_price = "₹1,32,000";
$sheet_super_price = "₹2,05,000";

$target_package = "The Essential Vietnam & Island Expedition 13D/12N"; 

$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 3-Star Boutique Stays & Shared Halong Cruise</li>
            <li><i class="fa-solid fa-van-shuttle"></i> Group Limousine Transfers & Domestic Flights</li>
            <li><i class="fa-solid fa-ticket"></i> Fansipan Cable Car, Ba Na Hills & Basket Boat</li>
            <li><i class="fa-solid fa-utensils"></i> All Breakfasts + 5 Lunches Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 4-Star Hotels & Private Balcony Halong Cruise</li>
            <li><i class="fa-solid fa-car"></i> Private AC Transfers Throughout</li>
            <li><i class="fa-solid fa-camera"></i> Guided Sapa Trekking & Private Island Tour</li>
            <li><i class="fa-solid fa-utensils"></i> All Breakfasts + 4 Premium Dinners Included</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Icon Resorts (JW Marriott/Hotel de la Coupole)</li>
            <li><i class="fa-solid fa-crown"></i> VIP Fast-Track Immigration & SUV Transfers</li>
            <li><i class="fa-solid fa-ship"></i> Ultra-Luxury Halong Cruise & Private Yacht in Phu Quoc</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining, Champagne Brunches & Private BBQ</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Essential Vietnam Expedition 13 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="vietnam-itinerary.php">Vietnam Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Essential Expedition (13D/12N)</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['vietnam 13d hero']) ? $tourImages['vietnam 13d hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 13 Days / 12 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Essential Vietnam & Island Expedition</h1>
            <p>From the high-altitude mists of Sapa to the turquoise tranquility of Phu Quoc. A perfectly balanced 13-day odyssey through Southeast Asia's jewel.</p>
        </div>
    </header>
    
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Essential Vietnam & Island Expedition 13D/12N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Thirteen days allows us to weave together Vietnam's diverse tapestry—Northern mountains, Central heritage, and Southern islands—without a breakneck pace. This itinerary focuses on the "Big Five": The ethnic culture of Sapa, the legendary karsts of Halong Bay, the photogenic Golden Bridge in Da Nang, the historic pulse of Ho Chi Minh City, and a restorative finale on Phu Quoc Island. Experience the iconic coconut boat rides and Fansipan peak with ample time for relaxation.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Hanoi Arrival & Old Quarter Soul</h3>
                <p>Welcome to Hanoi. Transfer to your hotel and start with a stroll through the 36 streets of the Old Quarter. In the evening, enjoy a welcome dinner and the famous Water Puppet Show.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Sapa & The Muong Hoa Valley</h3>
                <p>Luxury limousine transfer to Sapa. In the afternoon, trek through the rice terraces of Cat Cat Village and witness the stunning lifestyle of the Black H'mong community.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Fansipan Peak & Cloud Hunting</h3>
                <p>Take the world-record cable car to the summit of Fansipan (3,143m). Explore the mountain pagodas and enjoy the views of Indochina from above. Afternoon at leisure in Sapa town.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Return to Hanoi & City Highlights</h3>
                <p>Travel back to Hanoi. Visit the Temple of Literature and the Ho Chi Minh Mausoleum complex. Spend your evening exploring the vibrant Bia Hoi Junction.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Halong Bay Luxury Cruise</h3>
                <p>Depart for Halong Bay. Board your cruise for an overnight journey. Kayak through limestone lagoons, visit a floating village, and enjoy a sunset party on the deck.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Sunrise on the Bay & Flight to Da Nang</h3>
                <p>Tai Chi at sunrise. Explore a hidden cave before cruising back to shore. Transfer to the airport for a short flight to Da Nang. Relax by the Han River in the evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Ba Na Hills & The Golden Bridge</h3>
                <p>Full day at Ba Na Hills. Walk the Golden Bridge held by giant stone hands and explore the French Village. Return to Da Nang for a seafood feast.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Coconut Boat Adventure & Hoi An</h3>
                <p>Experience the Cam Thanh Coconut Village in a bamboo basket boat. In the afternoon, explore the ancient town of Hoi An, famous for its yellow walls and silk lanterns.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Flight to Saigon & Cu Chi Tunnels</h3>
                <p>Fly to Ho Chi Minh City. Direct afternoon excursion to the Cu Chi Tunnels to learn about the underground history of the Vietnam War.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Flight to Phu Quoc: The Island Escape</h3>
                <p>Short morning flight to Phu Quoc. Check into your beach resort. Spend the afternoon at Sao Beach, known for its white sand and starfish.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Island Hopping & Coral Reefs</h3>
                <p>Speedboat tour to the southern islets. Snorkel at Gam Ghi island and enjoy a fresh BBQ lunch on a secluded beach. Sunset cocktails at a beach club.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> Hon Thom Cable Car & Grand World</h3>
                <p>Ride the world's longest over-sea cable car to Hon Thom island. In the evening, visit the Venetian-themed Grand World for the water and light show.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Departure from Phu Quoc</h3>
                <p>Enjoy a final tropical breakfast and a swim. Transfer to Phu Quoc International Airport for your flight home via HCMC or Hanoi.</p>
            </div>
        </div>

        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> 3-Star Boutique Stays & Shared Halong Cruise</li>
                <li><i class="fa-solid fa-van-shuttle"></i> Group Limousine Transfers & Domestic Flights</li>
                <li><i class="fa-solid fa-ticket"></i> Fansipan Cable Car, Ba Na Hills & Basket Boat</li>
                <li><i class="fa-solid fa-utensils"></i> All Breakfasts + 5 Lunches Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/vietnam-13d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>

    <!-- REUSED FOOTER & SCRIPTS AS PER PREVIOUS PACKAGES -->
    <script>const tourTierData = <?php echo json_encode($tierDataArray); ?>;</script>
    <script src="js/main.js"></script>

</body>
</html>