<?php
// 🚀 FORCE PURE JSON OUTPUT & BLOCK ERRORS
ob_start();
error_reporting(0);
ini_set('display_errors', 0);

$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    ob_clean(); header("Content-Type: application/json"); echo json_encode(["error" => "DB Error"]); exit;
}
$conn->set_charset("utf8mb4");

// 🚀 AUTO-HEALING: Create the expenses table automatically if it doesn't exist
$conn->query("CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exp_date DATE NOT NULL,
    category VARCHAR(100) NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL
)");

// Safely capture incoming JSON from the Javascript Fetch API
$input = json_decode(file_get_contents('php://input'), true);
$action = $_GET['action'] ?? ($input['action'] ?? ($_POST['action'] ?? ''));

// --- ADD NEW EXPENSE ---
if ($action === 'ADD_EXPENSE') {
    $date = $input['date'] ?? $_POST['date'];
    $cat = $input['category'] ?? $_POST['category'];
    $desc = $input['description'] ?? $_POST['description'];
    $amt = $input['amount'] ?? $_POST['amount'];
    
    $stmt = $conn->prepare("INSERT INTO expenses (exp_date, category, description, amount) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssd", $date, $cat, $desc, $amt);
    if($stmt->execute()) {
        ob_clean(); echo json_encode(["status" => "success"]); exit;
    } else {
        ob_clean(); echo json_encode(["status" => "error", "message" => $conn->error]); exit;
    }
}

// --- DELETE EXPENSE ---
if ($action === 'DELETE_EXPENSE') {
    $id = $input['id'] ?? $_POST['id'];
    $stmt = $conn->prepare("DELETE FROM expenses WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    ob_clean(); echo json_encode(["status" => "success"]); exit;
}

// --- FETCH DATA FOR DASHBOARD & TRACKER ---
if ($action === 'GET_DATA') {
    $range = $_GET['range'] ?? '30days';
    $whereBookings = "WHERE `Timestamp` >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
    $whereExpenses = "WHERE `exp_date` >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
    
    if($range == 'mtd') {
        $whereBookings = "WHERE `Timestamp` >= DATE_FORMAT(NOW() ,'%Y-%m-01')";
        $whereExpenses = "WHERE `exp_date` >= DATE_FORMAT(NOW() ,'%Y-%m-01')";
    } elseif($range == 'last_month') {
        $whereBookings = "WHERE `Timestamp` >= DATE_FORMAT(CURRENT_DATE - INTERVAL 1 MONTH, '%Y-%m-01') AND `Timestamp` < DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')";
        $whereExpenses = "WHERE `exp_date` >= DATE_FORMAT(CURRENT_DATE - INTERVAL 1 MONTH, '%Y-%m-01') AND `exp_date` < DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')";
    } elseif($range == 'all_time') {
        $whereBookings = "WHERE 1";
        $whereExpenses = "WHERE 1";
    }
    
    // 1. Calculate Gross Revenue
    $sqlTotal = "SELECT SUM(CAST(REPLACE(REPLACE(`Total Paid`, '₹', ''), ',', '') AS DECIMAL(10,2))) as gross FROM bookings $whereBookings AND `Status` = 'Payment Complete'";
    $resTotal = $conn->query($sqlTotal);
    $gross = $resTotal ? ($resTotal->fetch_assoc()['gross'] ?? 0) : 0;
    
    // 2. Calculate Total Expenses
    $sqlExpTotal = "SELECT SUM(amount) as exp FROM expenses $whereExpenses";
    $resExpTotal = $conn->query($sqlExpTotal);
    $expTotal = $resExpTotal ? ($resExpTotal->fetch_assoc()['exp'] ?? 0) : 0;
    
    // 3. Fetch Expense Ledger
    $sqlList = "SELECT * FROM expenses $whereExpenses ORDER BY exp_date DESC";
    $resList = $conn->query($sqlList);
    $list = [];
    if($resList) { while($row = $resList->fetch_assoc()){ $list[] = $row; } }
    
    $output = [
        "revenue" => (float)$gross,
        "expenses_total" => (float)$expTotal,
        "profit_loss" => (float)($gross - $expTotal),
        "expense_list" => $list
    ];
    
    ob_clean(); // Wipe any hidden warnings
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode($output);
    exit;
}
?>