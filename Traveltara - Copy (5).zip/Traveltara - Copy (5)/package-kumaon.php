<?php
// Top of package-kumaon.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹26,500"; 
$sheet_affordable_price = "₹42,000";
$sheet_super_price = "₹65,000";

// EXACT package name from Google Sheet
$target_package = "Kumaon Mystique 12D/11N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hill-View Guesthouses</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Route</li>
            <li><i class="fa-solid fa-water"></i> Shared Naini Lake Boat Ride</li>
            <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Boutique Lake-View & Orchard Resorts</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-camera"></i> Guided Walks in Binsar Wildlife Sanctuary</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners featuring Kumaoni Cuisine</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Heritage Stays & Luxury Eco-Lodges</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Sunset High-Tea facing Panchachuli</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining & Private Bonfire Evenings</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Kumaon Mystique 12 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="uttarakhand-itinerary.php">Uttarakhand</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">The Kumaon Mystique (12D/11N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['kumaon hero']) ? $tourImages['kumaon hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 12 Days / 11 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Kumaon Mystique</h1>
            <p>A mesmerizing journey from the emerald lakes of Nainital to the towering peaks of Munsiyari.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Kumaon Mystique 12D/11N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Discover the serene, untouched beauty of Uttarakhand's eastern flank. This 12-day Kumaon circuit escapes the heavy pilgrimage crowds of Garhwal, offering a peaceful, deeply immersive mountain experience. You will boat on the famous Naini Lake, walk through the ancient pine forests of Binsar, witness unforgettable sunrises over the Trishul peaks in Kausani, and ascend the thrilling, rugged roads to Munsiyari to stand face-to-face with the magnificent Panchachuli range.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & Ascent to Nainital</h3>
                <p>Arrive at Pantnagar Airport or Kathgodam Railway Station. Your private hill chauffeur will welcome you and begin the scenic drive up to the famous lake city of Nainital (approx. 2 hours). Check into your premium lake-view or hillside resort. Spend a relaxed evening walking along the bustling Mall Road beside the shimmering Naini Lake.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Lake District Experience</h3>
                <p>Start your morning with a peaceful boat ride on Naini Lake, followed by a visit to the highly revered Naina Devi Temple. Take the Aerial Ropeway up to Snow View Point for your first panoramic glimpse of the Himalayas. In the afternoon, visit the serene Eco Cave Gardens and the High Altitude Zoo.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Nainital to the Pine Forests of Almora / Binsar</h3>
                <p>Depart Nainital and drive to the cultural heart of Kumaon, Almora, or the adjacent Binsar Wildlife Sanctuary (approx. 3-4 hours). En route, stop at Kainchi Dham, famous for the ashram of Neem Karoli Baba. Arrive and check into your boutique pine-forest retreat. Enjoy the complete silence of the mountains.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Ancient Temples & Binsar Wildlife Sanctuary</h3>
                <p>Take a morning jeep ride or a guided nature walk into the Binsar Wildlife Sanctuary, reaching Zero Point for an incredible 300-kilometer panoramic view of Himalayan peaks like Nanda Devi and Kedarnath. In the afternoon, visit the magnificent Jageshwar Dham, a cluster of 124 ancient stone temples nestled in a dense deodar forest.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Binsar to Kausani (The Switzerland of India)</h3>
                <p>After breakfast, take a highly scenic, short drive to Kausani (approx. 2.5 hours). Kausani is globally renowned for offering one of the most spectacular, close-up sunset and sunrise views of the majestic Trishul and Nanda Devi peaks. Visit the Anasakti Ashram (where Mahatma Gandhi stayed) and the local tea estates.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Kausani to Chaukori</h3>
                <p>Wake up early to witness the sun turning the snow-capped peaks golden. After breakfast, drive deeper into Kumaon toward the offbeat hamlet of Chaukori (approx. 3-4 hours). Surrounded by tea gardens and virgin forests, Chaukori offers absolute peace. Check into your resort and enjoy a quiet evening stargazing.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Chaukori to Munsiyari (The Base of the Himalayas)</h3>
                <p>Today features one of the most thrilling and beautiful drives in India. Traverse the plunging valleys and massive waterfalls en route to Munsiyari (approx. 4-5 hours), a high-altitude town located right at the base of the Panchachuli peaks. Arrive and check into your mountain lodge, witnessing the peaks looming impossibly close.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Munsiyari Exploration & Khaliya Top Base</h3>
                <p>A full day in Munsiyari. Visit the Nanda Devi Temple, an easy hike offering stunning views. If you are adventurous, take a moderate trek toward the base of Khaliya Top for an even higher vantage point. Visit the Tribal Heritage Museum to learn about the fascinating local Bhotia culture and their ancient trade routes with Tibet.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Descent to Pithoragarh</h3>
                <p>Begin your descent from the extreme heights of Munsiyari. Drive through the stunning Ramganga and Saryu river valleys to the beautiful "Little Kashmir" town of Pithoragarh (approx. 4.5 hours). Check into your hotel and spend the evening exploring the historic Pithoragarh Fort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Pithoragarh to Mukteshwar (The Apple Orchards)</h3>
                <p>Drive to the incredibly serene, fruit-orchard town of Mukteshwar (approx. 5.5 hours). Check into a premium boutique cottage. Visit the 350-year-old Mukteshwar Dham temple and Chauli Ki Jali, a dramatic rocky cliff offering plunging views of the valley below.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Mukteshwar / Bhimtal Leisure Day</h3>
                <p>Spend your final full day completely relaxing. Take a gentle walk through the apple and peach orchards. Alternatively, drive down to Bhimtal to enjoy a quiet boat ride to the island aquarium in the center of the lake. Enjoy a farewell Kumaoni dinner at your resort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> Departure</h3>
                <p>Enjoy a final, unhurried mountain breakfast. Your chauffeur will provide a seamless and smooth drive back down the hills, dropping you at Kathgodam Railway Station or Pantnagar Airport for your journey home, carrying a lifetime of Kumaoni memories.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hill-View Guesthouses</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Route</li>
                <li><i class="fa-solid fa-water"></i> Shared Naini Lake Boat Ride</li>
                <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/kumaon-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- KUMAON INSIGHTS HUB (6 GRID CARDS)                        -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Kumaon Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your journey through the eastern Himalayas is safe, respectful, and perfectly paced.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time to Visit</h3>
                <p>Kumaon changes dramatically throughout the year:</p>
                <ul>
                    <li><strong>Spring/Summer (Mar - Jun):</strong> The most popular time. Perfect weather for sightseeing, though Nainital can get crowded. Munsiyari remains delightfully cool.</li>
                    <li><strong>Autumn (Oct - Nov):</strong> The absolute best time for crystal-clear, razor-sharp views of the Himalayan peaks from Kausani and Chaukori.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-mountain"></i></div>
                <h3>The Road to Munsiyari</h3>
                <p>Munsiyari is an extreme mountain destination:</p>
                <ul>
                    <li><strong>Terrain:</strong> The road from Chaukori to Munsiyari is spectacular but rugged and narrow. It is prone to landslides during heavy rains.</li>
                    <li><strong>Vehicle Type:</strong> While a sedan can manage Nainital and Almora, an SUV with high ground clearance (Innova/Fortuner) is strongly recommended for the Munsiyari leg.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Altitude & Cold</h3>
                <p>Prepare for significant temperature drops:</p>
                <ul>
                    <li><strong>Micro-Climates:</strong> While Bhimtal or Nainital might feel pleasant, Munsiyari (at 7,200 ft directly facing the glaciers) can be freezing at night, even in summer.</li>
                    <li><strong>Packing:</strong> Always carry thermal wear and a heavy windproof jacket, regardless of the month you travel.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Cultural Etiquette</h3>
                <p>The Kumaoni people are deeply traditional and welcoming:</p>
                <ul>
                    <li><strong>Sacred Sites:</strong> Jageshwar Dham is an incredibly sacred temple complex. Dress modestly and do not take photographs inside the main sanctums.</li>
                    <li><strong>Photography:</strong> Ask for permission before photographing the local Bhotia tribal people in Munsiyari.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-water"></i></div>
                <h3>Lake Regulations</h3>
                <p>Nainital and Bhimtal are eco-sensitive zones:</p>
                <ul>
                    <li><strong>Plastic Ban:</strong> There is a strict ban on single-use plastics around the lakes. Heavy fines are levied for littering.</li>
                    <li><strong>Mall Road:</strong> Vehicles are strictly prohibited on Nainital's Mall Road during the evening hours. Prepare to walk and enjoy the cool breeze.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Kumaoni Culinary Highlights</h3>
                <p>Do not miss the authentic, hyper-local flavors of the region:</p>
                <ul>
                    <li><strong>Bhatt ki Churkani:</strong> A rich, highly nutritious black bean curry served with rice, a staple of Kumaoni households.</li>
                    <li><strong>Bal Mithai & Singori:</strong> Famous roasted milk sweets unique to Almora. Be sure to buy a box to take home.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream Kumaon expedition.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Kumaon Mystique 12D/11N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>