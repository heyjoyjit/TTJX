<?php
// Top of package-swiss-romance.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹1,25,000"; 
$sheet_affordable_price = "₹1,85,000";
$sheet_super_price = "₹2,80,000";

// EXACT package name from Google Sheet
$target_package = "The Swiss Romance Retreat 7D/6N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Cozy 3-Star Alpine Boutique Hotels & City Inns</li>
            <li><i class="fa-solid fa-train"></i> 2nd Class Swiss Travel Pass (Unlimited Trains & Boats)</li>
            <li><i class="fa-solid fa-ticket"></i> Standard Excursions to Mt. Rigi & Chillon Castle</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Continental Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Romantic Chalets with Balcony Views</li>
            <li><i class="fa-solid fa-train"></i> 1st Class Swiss Travel Pass for Superior Panoramic Seating</li>
            <li><i class="fa-solid fa-spa"></i> Couples Pass to Rigi Kaltbad Mineral Baths & Spa</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast + A Romantic Swiss Fondue Experience</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Ultra-Luxury (e.g., Bürgenstock Resort, Fairmont Montreux)</li>
            <li><i class="fa-solid fa-crown"></i> Prestige Class GoldenPass Seating & Private Limousine Transfers</li>
            <li><i class="fa-solid fa-wine-glass"></i> Private Lavaux Vineyard Wine Tasting & Gourmet Chocolate Tour</li>
            <li><i class="fa-solid fa-utensils"></i> Michelin-Star Dining & Private Lakeside Candlelit Dinners</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Swiss Romance Retreat 7 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="europe-itinerary.php">Europe Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Swiss Romance Retreat (7D/6N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['swiss romance hero']) ? $tourImages['swiss romance hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 7 Days / 6 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Swiss Romance Retreat</h1>
            <p>An enchanting journey crafted for couples. Experience the magic of thermal spas, lakeside castles, and intimate Alpine chalets in the heart of Europe.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Swiss Romance Retreat 7D/6N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Designed for honeymooners and couples seeking an unforgettable getaway, this itinerary moves at a relaxed pace, prioritizing intimate experiences over a rushed schedule. Utilizing the impeccable Swiss Travel Pass, you will explore the cobblestone romance of Lucerne, soak in the restorative mineral baths atop Mount Rigi, wake up to unparalleled views of the Eiger in Grindelwald, and sip world-class wine on the sun-drenched terraced vineyards of the Swiss Riviera.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Zurich & The Charm of Lucerne</h3>
                <p>Arrive at Zurich Airport (ZRH). Validate your Swiss Travel Pass and board a direct train to the incredibly romantic city of Lucerne (approx. 1 hour). Check into your lakeside hotel. Spend the afternoon wandering hand-in-hand across the iconic 14th-century Chapel Bridge (Kapellbrücke), adorned with beautiful flowers. Walk through the beautifully preserved Old Town, and enjoy a quiet, candlelit welcome dinner by the Reuss River.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Mount Rigi & The Alpine Thermal Spas</h3>
                <p>Today is dedicated to relaxation. Take a scenic boat cruise across Lake Lucerne to Vitznau, where you will board Europe’s oldest cogwheel railway up to Mount Rigi, the "Queen of the Mountains." After taking in the breathtaking panoramic views of the Alps and 13 lakes, descend slightly to Rigi Kaltbad. Here, immerse yourselves in the famous mineral baths and spa, swimming in the heated outdoor infinity pool while overlooking the snow-capped mountains. Return to Lucerne by cable car and boat in the late afternoon.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The GoldenPass Line to Grindelwald</h3>
                <p>Check out and board the Luzern-Interlaken Express, part of the famous GoldenPass scenic route. The train features panoramic windows that offer sweeping views of crystal-clear lakes and cascading waterfalls. Upon reaching Interlaken, take a short connecting train deep into the valley to the storybook alpine village of Grindelwald. Check into your cozy chalet hotel. Enjoy a warm, traditional Swiss fondue dinner as you gaze up at the imposing North Face of the Eiger.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Jungfraujoch: The Top of Europe</h3>
                <p>After a leisurely breakfast, embark on an unforgettable journey to the "Top of Europe." Board the Eiger Express gondola and the historic cogwheel train up to Jungfraujoch (3,454m). Experience the magic of walking through the Ice Palace, take romantic photos on the Sphinx Observatory deck with the massive Aletsch Glacier in the background, and share a cup of hot Swiss chocolate in the eternal snow. Descend back to Grindelwald for a relaxing evening by the fireplace.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Swiss Riviera & Montreux</h3>
                <p>Check out and take the train toward the French-speaking region of Switzerland, arriving in the elegant town of Montreux on the shores of Lake Geneva (Lac Léman). The climate here is famously mild, with palm trees lining the promenades. Check into your hotel. In the afternoon, take a romantic walk along the flower-lined lakefront to the majestic Chillon Castle (Château de Chillon), a 12th-century island fortress that inspired poets like Lord Byron.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Lavaux Vineyards & Swiss Chocolate</h3>
                <p>Spend the morning exploring the UNESCO-listed Lavaux Vineyard Terraces. Take the "Wine Train" or walk through the steep, terraced vineyards that drop dramatically into Lake Geneva, stopping at local cellars to taste the region's crisp Chasselas wine. In the afternoon, indulge your sweet tooth with a visit to a traditional Swiss chocolatier (such as Maison Cailler in nearby Broc) for a tasting experience. Enjoy a grand farewell dinner overlooking the serene lake.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Departure from Geneva</h3>
                <p>Enjoy your final European breakfast on your balcony. Montreux is very well connected to Geneva Airport (GVA). Use your Swiss Travel Pass for a smooth, direct train ride right into the airport terminal (approx. 1 hour). Check in for your flight home, taking with you the unforgettable memories of your romantic Alpine escape.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Cozy 3-Star Alpine Boutique Hotels & City Inns</li>
                <li><i class="fa-solid fa-train"></i> 2nd Class Swiss Travel Pass (Unlimited Trains & Boats)</li>
                <li><i class="fa-solid fa-ticket"></i> Standard Excursions to Mt. Rigi & Chillon Castle</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Continental Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/swiss-romance-7d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- ROMANCE INSIGHTS HUB (6 GRID CARDS)                       -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Couples' Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for this premium romantic getaway.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-train"></i></div>
                <h3>First Class Rail Upgrade</h3>
                <p>Maximizing comfort:</p>
                <ul>
                    <li><strong>Panoramic Privacy:</strong> For honeymooners, we highly recommend the 1st Class Swiss Travel Pass. The carriages are significantly quieter, offer wider seats, have fewer crowds, and provide much larger panoramic windows for viewing the spectacular scenery.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-spa"></i></div>
                <h3>Thermal Spa Etiquette</h3>
                <p>Rigi Kaltbad rules:</p>
                <ul>
                    <li><strong>Preparation:</strong> The mineral baths at Rigi require proper swimwear. While some traditional Swiss saunas are strictly nude zones, the main public outdoor infinity pools and thermal baths we book require standard swimming attire. Towels are provided on-site.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-plane-departure"></i></div>
                <h3>Flight Routing</h3>
                <p>Optimizing your travel:</p>
                <ul>
                    <li><strong>Multi-City Booking:</strong> To avoid a long train ride back across the country, this itinerary is designed as a linear route. You should book your arrival flight into Zurich (ZRH) and your departure flight out of Geneva (GVA).</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase"></i></div>
                <h3>Luggage Forwarding</h3>
                <p>Hands-free romance:</p>
                <ul>
                    <li><strong>Swiss Express Baggage:</strong> If you do not want to handle your luggage on the trains, the Swiss rail network offers a service where your bags are transported securely from hotel to hotel. This is an optional add-on that significantly increases travel comfort.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-camera-retro"></i></div>
                <h3>Photoshoot Opportunities</h3>
                <p>Capturing the memories:</p>
                <ul>
                    <li><strong>Professional Photographers:</strong> If you are celebrating a special anniversary or honeymoon, we can arrange for professional, local "Flytographers" to meet you for a 1-hour candid photoshoot in iconic locations like the Lucerne waterfront or the Montreux promenade.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-cheese"></i></div>
                <h3>The Fondue Experience</h3>
                <p>Culinary notes:</p>
                <ul>
                    <li><strong>Authentic Swiss Cuisine:</strong> Traditional Swiss cheese fondue often contains a splash of white wine or Kirsch (cherry schnapps) mixed into the melted cheese. If you require an alcohol-free or fully vegetarian/halal version, please inform us so we can make the appropriate restaurant reservations.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, Tamil Nadu, Andhra Pradesh, Andaman, Lakshadweep, Dubai, Europe, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Swiss Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized romantic Alpine getaway.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="The Swiss Romance Retreat 7D/6N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>