<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visa & Immigration | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Visa Guidelines</h1>
        <p>Prepare for your international journey.</p>
    </header>

    <main class="info-container">
        <h2>Passport Requirements</h2>
        <p>For any international travel booked through Traveltara, guests must possess a passport that is valid for at least six (6) months beyond the scheduled return date of the trip. Ensure your passport has adequate blank pages for entry and exit stamps.</p>

        <h2>Visa Processing Assistance</h2>
        <p>While Traveltara does not directly issue visas, our travel concierges provide comprehensive guidance on documentation and application processes for your chosen destination. Approval is strictly at the discretion of the respective embassy or consulate.</p>

        <h2>E-Visas & On-Arrival</h2>
        <p>For destinations offering Visa-on-Arrival or E-Visas, we will provide you with the official government portals to secure your documentation prior to departure. Guests are responsible for carrying printed copies of all necessary electronic travel authorizations.</p>
    </main>

</body>
</html>