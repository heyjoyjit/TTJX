<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kashmir Tour Packages | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .packages-list-container { max-width: 1100px; margin: 50px auto; padding: 0 5%; }
        
        .package-block {
            display: flex;
            background: var(--white);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            margin-bottom: 40px;
            overflow: hidden;
            border: 1px solid #eaeaea;
        }

        .pkg-image { flex: 1; min-height: 250px; background-size: cover; background-position: center; }
        
        .pkg-details { flex: 2; padding: 30px; display: flex; flex-direction: column; justify-content: space-between; }
        
        .pkg-title-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; }
        .pkg-title h3 { font-size: 1.8rem; color: var(--dark-navy); margin-bottom: 5px; }
        .pkg-nights { font-size: 0.9rem; font-weight: bold; color: var(--primary-gold); background: rgba(197, 160, 89, 0.1); padding: 5px 12px; border-radius: 5px; }
        
        .pkg-price-box { text-align: right; }
        .pkg-price-box p { font-size: 0.8rem; color: #888; margin: 0; }
        .pkg-price-box h2 { color: var(--dark-navy); font-size: 2rem; margin: 0; }
        
        .pkg-route { color: #555; margin-bottom: 20px; font-size: 0.95rem; }
        .pkg-route i { color: var(--primary-gold); margin-right: 5px; }

        .inclusions { display: flex; gap: 20px; margin-bottom: 25px; border-top: 1px dashed #ddd; border-bottom: 1px dashed #ddd; padding: 15px 0; }
        .inc-item { text-align: center; color: #666; font-size: 0.8rem; }
        .inc-item i { font-size: 1.5rem; color: var(--dark-navy); margin-bottom: 5px; display: block; }

        .pkg-actions { display: flex; justify-content: flex-end; gap: 15px; }
        
        @media (max-width: 768px) {
            .package-block { flex-direction: column; }
            .pkg-title-row { flex-direction: column; gap: 15px; }
            .pkg-price-box { text-align: left; }
            .inclusions { flex-wrap: wrap; justify-content: center; }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
        </div>
        <div class="nav-contact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <header class="hero" style="height: 40vh; background: linear-gradient(rgba(10, 17, 40, 0.6), rgba(10, 17, 40, 0.6)), url('images/dest-kashmir.jpg') center/cover;">
        <div class="hero-content">
            <h1>Kashmir Tour Packages</h1>
            <p>Select the perfect duration for your paradise getaway.</p>
        </div>
    </header>

    <div class="packages-list-container">

        <div class="package-block">
            <div class="pkg-image" style="background-image: url('images/kashmir-1.jpg');"></div>
            <div class="pkg-details">
                <div class="pkg-title-row">
                    <div class="pkg-title">
                        <h3>Glimpse of Paradise</h3>
                        <span class="pkg-nights">4 Nights / 5 Days</span>
                    </div>
                    <div class="pkg-price-box">
                        <p>Starting from</p>
                        <h2>₹18,500</h2>
                    </div>
                </div>
                
                <p class="pkg-route"><i class="fa-solid fa-map"></i> Srinagar (2N) &rarr; Gulmarg (1N) &rarr; Pahalgam (1N)</p>
                
                <div class="inclusions">
                    <div class="inc-item"><i class="fa-solid fa-hotel"></i> 4 Star Hotel</div>
                    <div class="inc-item"><i class="fa-solid fa-utensils"></i> Meals Included</div>
                    <div class="inc-item"><i class="fa-solid fa-car"></i> Transfers</div>
                    <div class="inc-item"><i class="fa-solid fa-camera"></i> Sightseeing</div>
                </div>

                <div class="pkg-actions">
                    <button class="btn-outline" onclick="openLeadPopup()">Download PDF</button>
                    <button class="btn-primary" onclick="openLeadPopup()">Book Now</button>
                </div>
            </div>
        </div>

        <div class="package-block">
            <div class="pkg-image" style="background-image: url('images/kashmir-2.jpg');"></div>
            <div class="pkg-details">
                <div class="pkg-title-row">
                    <div class="pkg-title">
                        <h3>The Grand Kashmir Valley</h3>
                        <span class="pkg-nights">7 Nights / 8 Days</span>
                    </div>
                    <div class="pkg-price-box">
                        <p>Starting from</p>
                        <h2>₹32,999</h2>
                    </div>
                </div>
                
                <p class="pkg-route"><i class="fa-solid fa-map"></i> Srinagar (2N) &rarr; Gulmarg (2N) &rarr; Pahalgam (2N) &rarr; Sonamarg (1N)</p>
                
                <div class="inclusions">
                    <div class="inc-item"><i class="fa-solid fa-hotel"></i> 5 Star Hotel</div>
                    <div class="inc-item"><i class="fa-solid fa-sailboat"></i> Shikara Ride</div>
                    <div class="inc-item"><i class="fa-solid fa-car"></i> Premium SUV</div>
                    <div class="inc-item"><i class="fa-solid fa-camera"></i> Sightseeing</div>
                </div>

                <div class="pkg-actions">
                    <button class="btn-outline" onclick="openLeadPopup()">Download PDF</button>
                    <button class="btn-primary" onclick="openLeadPopup()">Book Now</button>
                </div>
            </div>
        </div>

    </div>

    <div class="popup-overlay" id="leadPopup">
        </div>
    <script src="js/main.js"></script>

</body>
</html>