<?php
// Top of package-nb-offbeat.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹22,000"; 
$sheet_affordable_price = "₹35,000";
$sheet_super_price = "₹55,000";

// EXACT package name from Google Sheet
$target_package = "North Bengal Offbeat 9D/8N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Basic but Clean & Authentic Himalayan Homestays</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Hatchback (WagonR/Swift) for Narrow Roads</li>
            <li><i class="fa-solid fa-mountain-sun"></i> Kanchenjunga Views from Rooms (Subject to Weather)</li>
            <li><i class="fa-solid fa-utensils"></i> All Meals Included (AP Plan - Simple Local Veg/Non-Veg)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium Boutique Homestays & Heritage Tea Estate Bungalows</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta or Xylo for Superior Comfort</li>
            <li><i class="fa-solid fa-star"></i> Guided Tea Garden Walks & Riverside Bonfires</li>
            <li><i class="fa-solid fa-utensils"></i> Upgraded AP Plan with Regional Delicacies</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Top-Tier Eco-Resorts & Luxury Glamping Tents (Where Available)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) for Mountain Terrain</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Riverside Picnics at Srikhola & Private BBQs</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Dining, Custom Menus & High Tea Sessions</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>North Bengal Offbeat Escape 9 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="north-bengal-itinerary.php">North Bengal</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Offbeat Escape (9D/8N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['north bengal offbeat hero']) ? $tourImages['north bengal offbeat hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 9 Days / 8 Nights</div>
        <div class="subpage-hero-content">
            <h1>North Bengal Offbeat Escape</h1>
            <p>A completely crowdless, drive-in expedition through the most serene, hidden hamlets of the Eastern Himalayas.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="North Bengal Offbeat 9D/8N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Escape the commercial hill stations and dive into the absolute tranquility of North Bengal's lesser-known mountain villages. This 9-day itinerary is meticulously designed to provide a comprehensive, crowdless experience <strong>without any trekking required</strong>. You will drive through the orange orchards of Sittong, the pine forests of Lepchajagat and Tinchuley, the pristine viewpoints of Dawaipani, the riverside serenity of Srikhola, and the tea-carpeted slopes of Tabakoshi.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & Ascent to the Orange Village (Sittong)</h3>
                <p>Your offbeat adventure begins at Bagdogra Airport (IXB) or NJP Railway Station. Your chauffeur will drive you away from the highway traffic, taking a scenic route along the Teesta River towards Sittong (approx. 2.5 hours). Known as the 'Orange Village' for its winter citrus orchards, Sittong is incredibly peaceful. Check into your homestay, breathe in the fresh mountain air, and relax.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Mungpoo, Pine Forests & Tinchuley</h3>
                <p>After breakfast, take a short drive to Mungpoo to visit the Rabindra Bhavan, the summer retreat of Nobel Laureate Rabindranath Tagore, surrounded by Cinchona plantations. Continue your drive through the dense, towering pine forests to reach Tinchuley. This eco-village gets its name from three prominent hilltops ('Tin Chulah' or three ovens). Enjoy the sunset from the Tinchuley viewpoint.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Takdah Orchids & Drive to Lepchajagat</h3>
                <p>Wake up to the sounds of Himalayan birds. Drive to the nearby heritage cantonment of Takdah, walking through its foggy trails and visiting the vibrant Orchid Centre. Later, drive past the majestic Lamahatta Eco Park towards Lepchajagat (approx. 2 hours). Reserved mostly as a forest area, Lepchajagat is famed for its unobstructed, sweeping views of the Kanchenjunga range directly from your balcony.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Jorpokhri & The Hidden Viewpoint of Dawaipani</h3>
                <p>In the morning, take a short, picturesque drive to Jorpokhri, a twin-lake sanctuary offering stunning reflections of the Himalayas and a chance to spot the rare Himalayan Salamander. Proceed towards Dawaipani (approx. 2 hours), an incredibly secluded hamlet near Darjeeling. Dawaipani translates to "medicated water," and the village offers a panoramic 180-degree view of the entire Kanchenjunga massif.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Drive-In Riverside Retreat (Srikhola)</h3>
                <p>Today features a brilliant drive. Bypass the trekking routes entirely as your vehicle takes you through Manebhanjan, Dhotrey, and Rimbick, winding through the Singalila National Park borders to reach Srikhola. Named after the Khola (river) that runs through it, this pristine valley is absolute bliss. Check into your riverside wooden lodge and spend the evening listening to the roaring mountain stream.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> A Day of Absolute Serenity at Srikhola</h3>
                <p>A zero-travel day dedicated to pure relaxation. There are no treks scheduled. You can take short, flat walks along the Srikhola bridge, dip your feet in the ice-cold, crystal-clear river water, read a book by the banks, or simply enjoy a riverside barbecue prepared by your hosts. It is the perfect mid-trip digital detox.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Srikhola to the Tea Slopes of Tabakoshi</h3>
                <p>Bid farewell to the river and drive down toward the Mirik valley region, arriving at the offbeat hamlet of Tabakoshi (approx. 4 hours). Situated along the Rangbhang River and completely surrounded by the lush green slopes of the Gopaldhara Tea Estate, Tabakoshi is an offbeat alternative to commercial Mirik. Check into your tea-garden homestay.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Exploring Tabakoshi & Mirik Lake</h3>
                <p>Spend the morning taking leisurely, guided walks through the Gopaldhara tea gardens, learning about the tea-plucking process directly from the locals. In the afternoon, take a short drive up to Mirik to see the famous Sumendu Lake and the Bokar Monastery, before returning to the crowdless peace of Tabakoshi for your final mountain dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Descent to the Plains & Departure</h3>
                <p>Enjoy a final, quiet breakfast surrounded by endless green tea slopes. Your chauffeur will begin the descent to the plains via the picturesque Dudhia route. You will be seamlessly transferred to Bagdogra Airport (IXB) or NJP Railway Station (approx. 2.5 hours) for your onward journey, completely rejuvenated by the hidden Himalayas.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Basic but Clean & Authentic Himalayan Homestays</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Hatchback (WagonR/Swift) for Narrow Roads</li>
                <li><i class="fa-solid fa-mountain-sun"></i> Kanchenjunga Views from Rooms (Subject to Weather)</li>
                <li><i class="fa-solid fa-utensils"></i> All Meals Included (AP Plan - Simple Local Veg/Non-Veg)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/nb-offbeat-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- OFFBEAT INSIGHTS HUB (6 GRID CARDS)                       -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Offbeat Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for a journey into the deep, commercial-free villages of North Bengal.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bed"></i></div>
                <h3>The Homestay Reality</h3>
                <p>Embrace authentic mountain living:</p>
                <ul>
                    <li><strong>No 5-Star Giants:</strong> These hidden hamlets do not have commercial hotels or room service. You will stay in homestays run by local families.</li>
                    <li><strong>Amenities:</strong> Rooms are incredibly clean with attached western toilets and geysers, but do not expect TVs, high-speed Wi-Fi, or luxury hotel toiletries.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car-side"></i></div>
                <h3>Driving & Vehicle Types</h3>
                <p>The terrain dictates the transport:</p>
                <ul>
                    <li><strong>Narrow Roads:</strong> The roads to Dawaipani and Srikhola are extremely narrow, steep, and sometimes unpaved.</li>
                    <li><strong>The Right Car:</strong> We often use robust hatchbacks (WagonR) or specialized utility vehicles (Bolero/Innova) because standard luxury sedans simply cannot navigate these specific offbeat ascents.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-money-bill-1-wave"></i></div>
                <h3>Cash & Connectivity</h3>
                <p>Prepare for a digital detox:</p>
                <ul>
                    <li><strong>Network Drops:</strong> In places like Srikhola and Lepchajagat, mobile networks (especially Airtel/Vodafone) fluctuate heavily. Jio and BSNL work best, but expect periods of zero connectivity.</li>
                    <li><strong>Carry Cash:</strong> ATMs are non-existent in these hamlets, and UPI/Card payments fail due to bad network. Carry sufficient cash from NJP/Bagdogra.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>AP Meal Plans</h3>
                <p>Dining is localized and pre-planned:</p>
                <ul>
                    <li><strong>What is AP?</strong> Your package includes American Plan (Breakfast, Lunch, Evening Snacks, and Dinner).</li>
                    <li><strong>The Food:</strong> Meals are fixed, home-cooked, and predominantly feature organic local produce, rice, roti, dal, local chicken, and farm-fresh vegetables. There are no nearby restaurants to order from.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Weather & Medical Prep</h3>
                <p>Be self-sufficient in the mountains:</p>
                <ul>
                    <li><strong>Cold Nights:</strong> Villages like Lepchajagat and Dawaipani are at higher altitudes and get extremely cold at night. Room heaters are rare in homestays; they provide heavy blankets and hot water bags instead.</li>
                    <li><strong>Pharmacies:</strong> Carry all essential medications. There are no late-night pharmacies in these isolated areas.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-person-hiking"></i></div>
                <h3>No Trekking Guarantee</h3>
                <p>Accessibility for all ages:</p>
                <ul>
                    <li><strong>Drive-in Srikhola:</strong> While Srikhola is famously a trekking hub on the Sandakphu route, new roads allow us to drive you directly to the riverside lodges via Rimbick, guaranteeing a zero-trek experience while still accessing the deep wilderness.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your completely crowdless offbeat escape.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="North Bengal Offbeat 9D/8N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>