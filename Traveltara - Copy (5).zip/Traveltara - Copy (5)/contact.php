<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Contact Traveltara</h1>
        <p>We are here to assist you.</p>
    </header>

    <main class="info-container">
        <h2>Get in Touch</h2>
        <p>Whether you are looking to design a custom itinerary, need help with an existing booking, or require immediate on-ground assistance during your tour, our concierge team is available.</p>

        <div style="background: #f9f9f9; padding: 25px; border-radius: 4px; border-left: 4px solid #C5A059; margin-top: 30px;">
            <p style="margin: 0 0 15px 0;"><strong><i class="fa-solid fa-envelope"></i> Email Inquiries:</strong><br> <a href="mailto:booking.traveltara@gmail.com" style="color: #0A1128; text-decoration: none;">booking.traveltara@gmail.com</a></p>
            
            <p style="margin: 0 0 15px 0;"><strong><i class="fa-solid fa-phone"></i> Direct Support Lines:</strong><br> +91 9477709755 <br> +91 7439877604</p>

            <p style="margin: 0;"><strong><i class="fa-brands fa-whatsapp"></i> WhatsApp Concierge:</strong><br> <a href="https://wa.me/919477709755" target="_blank" style="color: #25D366; font-weight: bold; text-decoration: none;">Click here to chat instantly</a></p>
        </div>

        <h2>Business Hours</h2>
        <p>Our standard booking and inquiry desk operates Monday through Saturday, from 10:00 AM to 7:00 PM (IST). For guests currently on an active tour, your provided emergency ground-contact number is available 24/7.</p>
    </main>

</body>
</html>