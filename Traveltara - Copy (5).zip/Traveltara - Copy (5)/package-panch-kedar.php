<?php
// Top of package-panch-kedar.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹32,000"; 
$sheet_affordable_price = "₹48,000";
$sheet_super_price = "₹75,000";

// EXACT package name from Google Sheet
$target_package = "Panch Kedar 14D/13N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Basic Guesthouses & Clean Trekking Tents</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Non-AC SUV for Mountain Terrain</li>
            <li><i class="fa-solid fa-person-hiking"></i> Experienced Local Trekking Guide</li>
            <li><i class="fa-solid fa-utensils"></i> All Meals Included During Treks (Simple Veg)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 3/4-Star Hotels (Basecamps) & Best Available Tents</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-helicopter"></i> Helicopter Assistance Available for Kedarnath (Optional/Extra)</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners & Packed Energy Lunches</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Top-Tier Luxury Eco-Resorts at Basecamps & Premium Alpine Camping</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-crown"></i> VIP Darshan Assistance & Private Porters</li>
            <li><i class="fa-solid fa-utensils"></i> Premium Vegetarian Fine Dining</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panch Kedar Pilgrimage 14 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="uttarakhand-itinerary.php">Uttarakhand</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Panch Kedar (14D/13N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['panch kedar hero']) ? $tourImages['panch kedar hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 14 Days / 13 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Panch Kedar Pilgrimage</h1>
            <p>A profound, life-changing 14-day trekking expedition to the five sacred shrines of Lord Shiva.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Panch Kedar 14D/13N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>The Panch Kedar is one of the most revered and rigorous pilgrimages in Hinduism, tracing the mythology of the Pandavas. Over 14 days, you will physically and spiritually challenge yourself by trekking to five remote, high-altitude temples. You will visit the hump of Shiva at <strong>Kedarnath</strong>, the navel at <strong>Madhyamaheshwar</strong>, the arms at <strong>Tungnath</strong> (the highest Shiva temple in the world), the face at <strong>Rudranath</strong>, and the matted hair at <strong>Kalpeshwar</strong>.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Dehradun & Drive to Guptkashi</h3>
                <p>Arrive at Jolly Grant Airport or Haridwar/Dehradun Railway Station. Your mountain chauffeur will drive you alongside the sacred Ganges and Mandakini rivers to the town of Guptkashi (approx. 7-8 hours). Arrive, check into your basecamp hotel, complete your mandatory biometric registration, and rest for the rigorous days ahead.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Kedar 1: Trek to Kedarnath (The Hump)</h3>
                <p>Drive early to Sonprayag/Gaurikund to begin the 18 km trek to Kedarnath (11,755 ft). You may opt to walk, hire a pony, or use a palanquin. The steep ascent is physically demanding but spiritually uplifting. Arrive at the breathtaking Kedarnath Temple, surrounded by towering, snow-clad peaks. Attend the powerful evening Aarti. Overnight in a basic lodge in Kedarnath.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Kedarnath Darshan & Descent</h3>
                <p>Wake up before dawn for the main temple Darshan. Witness the morning sunlight striking the Kedarnath peak. After breakfast, begin the 18 km descent back to Gaurikund. Reconnect with your chauffeur and drive back to Guptkashi. Enjoy a hot shower, dinner, and a deeply restful night.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Drive to Ransi & Trek to Gaundar</h3>
                <p>After breakfast, drive to Ransi village. From here, your second major trek begins toward Madhyamaheshwar. Today is a relatively moderate 6 km descent into the lush Kedarnath Wildlife Sanctuary, ending at the beautiful riverside village of Gaundar. Overnight in a village homestay or camp.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Kedar 2: Trek to Madhyamaheshwar (The Navel)</h3>
                <p>Begin a steep 10 km ascent from Gaundar through dense forests of oak and rhododendron. Emerge into the stunning, high-altitude meadow where the Madhyamaheshwar Temple (11,450 ft) is situated, with the spectacular Chaukhamba peaks in the backdrop. Perform your Darshan and spend the night in a local homestay/tent.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Descent to Ransi & Drive to Chopta</h3>
                <p>Wake up early for a spectacular sunrise over the Chaukhamba range. Trek 16 km continuously downhill, back through Gaundar to Ransi village. Meet your vehicle and enjoy a scenic drive to the pristine meadows of Chopta (often called the Mini Switzerland of Uttarakhand). Check into your cozy alpine camp.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Kedar 3: Tungnath (The Arms) & Chandrashila Peak</h3>
                <p>Begin a well-paved, 4 km trek from Chopta to Tungnath (12,073 ft), the highest Shiva temple in the world. After Darshan, if energy permits, embark on an additional 1.5 km steep climb to Chandrashila Peak (13,123 ft) for an unparalleled 360-degree view of the Himalayas. Descend back to Chopta for the night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Chopta to Sagar Village & Trek to Panar Bugyal</h3>
                <p>Drive from Chopta to Sagar Village (near Gopeshwar). This is the starting point for the toughest trek of the circuit: Rudranath. Begin a steep, relentless 12 km ascent through dense forests, climbing into the magnificent high-altitude alpine meadow known as Panar Bugyal. Overnight in a basic trekking tent.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Kedar 4: Trek to Rudranath (The Face)</h3>
                <p>Trek 8 km from Panar Bugyal along perilous ridges to reach the solitary, mystic temple of Rudranath (11,800 ft), where Lord Shiva's face is worshipped. The trail offers jaw-dropping views of Nanda Devi and Trishul. Perform Darshan at the naturally formed rock temple, then trek back to Panar Bugyal for the night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Descent to Sagar & Drive to Helang</h3>
                <p>Begin the massive 12 km descent from Panar Bugyal back down to Sagar village. Your knees will feel the strain, so pacing is vital. Reconnect with your vehicle and drive to Helang/Pipalkoti to check into a comfortable hotel for a much-needed hot shower and a soft bed.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Kedar 5: Kalpeshwar (The Hair) & Drive to Rudraprayag</h3>
                <p>Drive to the beautiful Urgam Valley. From the road head, it is a short, easy 2 km walk to Kalpeshwar (7,200 ft), the only Panch Kedar shrine accessible all year round, where Lord Shiva's matted hair (Jata) is worshipped in a cave. Complete your sacred Panch Kedar Yatra! Drive down to Rudraprayag for the night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> Rudraprayag to Rishikesh</h3>
                <p>With the physical toll behind you, enjoy a relaxed morning. Drive down the mountains, passing the holy confluences of Devprayag, and arrive in the spiritual city of Rishikesh. Check into your hotel. In the evening, attend the soothing Ganga Aarti at Parmarth Niketan to give thanks for a successful pilgrimage.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Rishikesh Leisure & Rejuvenation</h3>
                <p>A full buffer and relaxation day. Your body needs to recover from 12 days of extreme trekking. Treat yourself to a traditional Ayurvedic massage, relax by the Ganges, or explore the local cafes and ashrams. Reflect on the monumental spiritual and physical feat you have just accomplished.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 14</span> Departure</h3>
                <p>Enjoy a final, peaceful breakfast by the holy river. Your chauffeur will provide a seamless transfer to the Jolly Grant Airport (Dehradun) or the Haridwar Railway Station, concluding your epic, life-altering Panch Kedar Pilgrimage.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Basic Guesthouses & Clean Trekking Tents</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Non-AC SUV for Mountain Terrain</li>
                <li><i class="fa-solid fa-person-hiking"></i> Experienced Local Trekking Guide</li>
                <li><i class="fa-solid fa-utensils"></i> All Meals Included During Treks (Simple Veg)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/panch-kedar-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- PANCH KEDAR INSIGHTS HUB (6 GRID CARDS)                   -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Pilgrimage Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Panch Kedar is not a vacation; it is a serious expedition. Critical operational and fitness details to ensure your survival and success.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Strict Travel Window</h3>
                <p>The high-altitude shrines are governed by snowfall:</p>
                <ul>
                    <li><strong>May to June / Sep to Oct:</strong> The ONLY times this full circuit is viable.</li>
                    <li><strong>Winter Closures:</strong> Kedarnath, Tungnath, Rudranath, and Madhyamaheshwar close completely for 6 months during winter due to heavy snow.</li>
                    <li><strong>Monsoon Risk:</strong> July and August are highly dangerous due to extreme landslides. We strongly advise against trekking then.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-heart-pulse"></i></div>
                <h3>Extreme Fitness Required</h3>
                <p>This is a grueling, multi-day physical endurance test:</p>
                <ul>
                    <li><strong>The Rudranath Test:</strong> The trek to Rudranath is notoriously steep and punishing. Only those with high cardiovascular fitness should attempt it.</li>
                    <li><strong>Preparation:</strong> Begin intense cardio and stair-climbing training at least 2 months before your departure date.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase-medical"></i></div>
                <h3>Altitude & Medical Care</h3>
                <p>You will repeatedly cross the 11,000 to 13,000 ft marks:</p>
                <ul>
                    <li><strong>AMS:</strong> Acute Mountain Sickness is a severe risk. Hydrate relentlessly. Carry Diamox (consult your doctor).</li>
                    <li><strong>First Aid:</strong> Carry muscle relaxants, knee-support bands, crepe bandages, and blister plasters. Medical facilities are virtually non-existent on the trails to Madhyamaheshwar and Rudranath.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bed"></i></div>
                <h3>Accommodation Reality</h3>
                <p>Luxury ends where the treks begin:</p>
                <ul>
                    <li><strong>Basecamps vs. Trails:</strong> While we provide premium hotels in Guptkashi and Rishikesh, accommodations at Kedarnath, Madhyamaheshwar, and Rudranath are extremely basic ashrams, homestays, or trekking tents.</li>
                    <li><strong>Amenities:</strong> Do not expect hot running water or attached western toilets at the high-altitude shrines.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-person-hiking"></i></div>
                <h3>Porters & Ponies</h3>
                <p>Managing your load is essential for success:</p>
                <ul>
                    <li><strong>Pack Light:</strong> Leave heavy luggage at the basecamp hotels (Guptkashi/Sagar). Carry only a small 30-40L backpack with essentials for the multi-day treks.</li>
                    <li><strong>Support:</strong> Ponies and Dandi (palanquins) are available for Kedarnath and Tungnath, but the trails to Madhyamaheshwar and Rudranath often require you to walk the entire way.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Spiritual Etiquette</h3>
                <p>Respecting the sanctity of Devbhoomi:</p>
                <ul>
                    <li><strong>Diet:</strong> This entire circuit is strictly vegetarian. Alcohol and eggs are completely prohibited.</li>
                    <li><strong>Photography:</strong> Taking photographs of the main idols (Lingams) inside the inner sanctums is strictly forbidden across all five temples.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your ultimate Devbhoomi Pilgrimage.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Panch Kedar 14D/13N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>