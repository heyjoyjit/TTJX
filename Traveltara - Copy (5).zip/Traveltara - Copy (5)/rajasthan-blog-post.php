<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>When is the Best Time to Visit Rajasthan? | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <header class="hero" style="height: 50vh; background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/rajasthan-blog.jpg') center/cover;"></header>

    <main class="single-post-container section-padding">
        <div class="post-header">
            <span class="blog-category">Travel Tips</span>
            <h1>When is the Best Time to Visit Rajasthan?</h1>
            <div class="post-meta-details">
                <p><i class="fa-regular fa-calendar"></i> March 15, 2026</p>
                <p><i class="fa-regular fa-user"></i> By Traveltara Experts</p>
                <p><i class="fa-regular fa-clock"></i> 4 min read</p>
            </div>
        </div>

        <article class="post-content">
            <p class="lead-paragraph">Avoid the extreme heat and experience the royal state at its finest. A month-by-month breakdown of weather, luxury festivals, and the perfect time to book your palace stay.</p>

            <p>Rajasthan is a land of extremes. The same desert that looks overwhelmingly golden and romantic in the winter can become punishingly hot in the summer. For the luxury traveler, timing is everything to ensure that exploring forts and dining under the stars remains a comfortable, magical experience.</p>

            <blockquote class="post-quote">
                "To see Rajasthan is a privilege; to see it in the right season is pure magic."
            </blockquote>

            <h2>The Golden Window: October to March</h2>
            <p>This is the undisputed peak season for Rajasthan. The days are pleasantly warm and sun-drenched, while the evenings offer a crisp chill perfect for a bonfire at a desert camp in Jaisalmer or courtyard dining at a heritage hotel in Jaipur.</p>
            <p><strong>Highlights:</strong> The Pushkar Camel Fair (November) and the Jaipur Literature Festival (January) are vibrant cultural experiences. We highly recommend booking 5-star accommodations at least 4-6 months in advance during this window.</p>

            <h2>The Monsoon Romance: July to September</h2>
            <p>While the desert regions get hot and humid, the "City of Lakes," Udaipur, transforms during the monsoon. The Aravalli hills turn lush green, and the lakes fill to the brim. Staying at the Taj Lake Palace while the rain dances on Lake Pichola is an unparalleled luxury experience.</p>

            <div class="in-post-cta">
                <h3>Planning a winter getaway?</h3>
                <p>Our concierges can secure VIP access to Rajasthan's most exclusive palaces.</p>
                <button class="btn-primary" onclick="openLeadPopup()">Request an Itinerary</button>
            </div>

            <h2>The Summer Season: April to June</h2>
            <p>We generally advise against extensive sightseeing during these months, as temperatures regularly exceed 40°C (104°F). However, if you must travel, Mount Abu (the only hill station in Rajasthan) offers cooler climates. Alternatively, use this time for "staycations" in ultra-luxury spa resorts, where you can relax indoors by private pools during the day.</p>
        </article>
        
        <div class="author-box">
            <div class="author-avatar"><i class="fa-solid fa-user-tie"></i></div>
            <div class="author-info">
                <h4>Traveltara Experts</h4>
                <p>Ensuring your royal journey is timed to absolute perfection.</p>
            </div>
        </div>
    </main>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">Internation</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/917439877604" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

    <a href="https://wa.me/917439877604" class="whatsapp-sticky" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Plan Your Rajasthan Trip</h3>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Reference *</label><input type="text" value="Rajasthan Blog Post" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>