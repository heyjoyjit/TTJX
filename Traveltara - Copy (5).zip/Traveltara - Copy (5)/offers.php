<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offers & Promotions | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Exclusive Offers</h1>
        <p>Elevate your journey for less.</p>
    </header>

    <main class="info-container">
        <h2>Early Bird Discounts</h2>
        <p>We reward guests who plan ahead. Book your premium itinerary well in advance to unlock our exclusive Early Bird discount plans, offering up to 25% off standard dynamic rates. These rates are automatically factored into eligible dates on our booking engine.</p>

        <h2>Using Coupon Codes</h2>
        <p>If you possess a valid promotional code, you may apply it directly on the Checkout page prior to confirming your payment. The engine will instantly recalculate your final payable amount.</p>
        <ul>
            <li>Coupons are strictly single-use per booking reference.</li>
            <li>Discounts are applied strictly to the base package rate and do not bypass mandatory government taxes.</li>
            <li>Traveltara reserves the right to withdraw promotional codes at any time without prior notice.</li>
        </ul>
    </main>

</body>
</html>