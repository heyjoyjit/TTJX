<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Switzerland Tour Packages | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Switzerland Packages</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/swiss-hero.jpg') center/cover;">
        <div class="subpage-hero-content">
            <h1>Majestic Switzerland</h1>
            <p>Experience the pinnacle of alpine luxury, from snow-capped peaks to serene lakes.</p>
        </div>
    </header>

    <section class="section-padding" style="background-color: #fcfcfc;">
        <div style="max-width: 1200px; margin: auto; text-align: center; margin-bottom: 50px; padding: 0 20px;">
            <h2 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; color: #222; margin-bottom: 15px;">Available Switzerland Packages</h2>
            <p style="font-family: 'Lato', sans-serif; font-size: 1.1rem; color: #666; max-width: 700px; margin: auto;">From quick panoramic getaways in Lucerne to extended luxury expeditions on the Glacier Express.</p>
        </div>

        <div class="grid-container" id="switzerlandPackagesGrid">
            
            <div class="destination-card">
                <div class="card-image" style="background: url('assets/swiss-alpine.jpg') center/cover; position: relative;">
                    <div class="duration-badge">5 Days / 4 Nights</div>
                </div>
                <div class="card-content">
                    <h3>Alpine Express</h3>
                    <p>A rapid immersion into the Swiss Alps. Covers the cosmopolitan city of Zurich and the stunning landscapes of Lucerne.</p>
                    <h4 class="package-price">Starts at ₹1,25,000</h4>
                    <a href="package-swiss-alpine.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <div class="destination-card">
                <div class="card-image" style="background: url('assets/swiss-romance.jpg') center/cover; position: relative;">
                    <div class="duration-badge">7 Days / 6 Nights</div>
                </div>
                <div class="card-content">
                    <h3>Swiss Romance</h3>
                    <p>Designed for couples. Sail across crystal lakes in Interlaken and stay in premium alpine chalets with private views.</p>
                    <h4 class="package-price">Starts at ₹1,85,000</h4>
                    <a href="package-swiss-romance.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <div class="destination-card">
                <div class="card-image" style="background: url('assets/swiss-panoramic.jpg') center/cover; position: relative;">
                    <div class="duration-badge">9 Days / 8 Nights</div>
                </div>
                <div class="card-content">
                    <h3>Panoramic Switzerland</h3>
                    <p>The ultimate scenic route. Journey on the world-famous Glacier Express through breathtaking valleys and mountain passes.</p>
                    <h4 class="package-price">Starts at ₹2,45,000</h4>
                    <a href="package-swiss-panoramic.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <div class="destination-card">
                <div class="card-image" style="background: url('assets/swiss-family.jpg') center/cover; position: relative;">
                    <div class="duration-badge">6 Days / 5 Nights</div>
                </div>
                <div class="card-content">
                    <h3>Family Adventure</h3>
                    <p>Perfect for all ages. Enjoy interactive chocolate factories, traditional cheese making, and easy mountain trails.</p>
                    <h4 class="package-price">Starts at ₹1,65,000</h4>
                    <a href="package-swiss-family.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <div class="destination-card">
                <div class="card-image" style="background: url('assets/swiss-luxury.jpg') center/cover; position: relative;">
                    <div class="duration-badge">11 Days / 10 Nights</div>
                </div>
                <div class="card-content">
                    <h3>Ultimate Swiss Luxury</h3>
                    <p>Private guides, 5-star spa resorts, and exclusive helicopter tours over the iconic Matterhorn in Zermatt.</p>
                    <h4 class="package-price">Starts at ₹3,95,000</h4>
                    <a href="package-swiss-luxury.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <div class="destination-card" style="background: #0A1128; color: #fff;">
                <div class="card-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%; padding: 40px 20px;">
                    <i class="fa-solid fa-compass" style="font-size: 3rem; color: #D4AF37; margin-bottom: 20px;"></i>
                    <h3 style="color: #fff;">Build Your Own</h3>
                    <p style="color: #ccc;">Have specific Alpine destinations in mind? Let us create a bespoke Swiss itinerary just for you.</p>
                    <button class="btn-primary" onclick="openLeadPopup()" style="margin-top: 20px; width: 100%;">Consult an Expert</button>
                </div>
            </div>

        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">International</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/919477709755" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
            </div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
        </div>
    </div>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Speak with a Travel Expert</h3>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Switzerland Packages" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>