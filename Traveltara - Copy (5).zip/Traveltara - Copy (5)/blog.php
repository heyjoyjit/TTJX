<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Chronicles | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        
        <div class="menu-toggle" id="mobile-menu">
            <i class="fa-solid fa-bars"></i>
        </div>

        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        
        <div class="nav-contact" id="navContact">
            <i class="fa-solid fa-phone"></i> +91 7439877604
        </div>
    </nav>

    <header class="hero" style="height: 40vh; background: linear-gradient(rgba(10, 17, 40, 0.7), rgba(10, 17, 40, 0.7)), url('images/blog-hero.jpg') center/cover;">
        <div class="hero-content">
            <h1>The Traveltara Journal</h1>
            <p>Expert insights, destination guides, and luxury travel tips.</p>
        </div>
    </header>

    <section class="section-padding">
        <div class="blog-layout">
            
            <div class="blog-main-content">
                
                <article class="featured-post" data-category="destination">
                    <a href="sikkim-blog-post.php" class="featured-image" style="background: url('images/sikkim-blog.jpg') center/cover; display: block;"></a>
                    
                    <div class="featured-text">
                        <span class="blog-category">Destination Guide</span>
                        <h2><a href="sikkim-blog-post.php">The Ultimate 5-Day Luxury Itinerary for North Sikkim</a></h2>
                        
                        <p class="blog-meta"><i class="fa-regular fa-calendar"></i> April 2, 2026 &nbsp;|&nbsp; <i class="fa-regular fa-user"></i> Traveltara Experts</p>
                        <p>Discover the secrets of high-altitude luxury. From the sacred Gurudongmar Lake to boutique chalets in Lachen, here is how to experience Sikkim without compromising on comfort.</p>
                        
                        <a href="sikkim-blog-post.php" class="btn-outline">Read Full Article</a>
                    </div>
                </article>

                <hr style="margin: 50px 0; border: 0; border-top: 1px solid #eaeaea;">

                <div class="blog-grid">
                    
                    <div class="blog-card" data-category="heritage">
                        <a href="darjeeling-blog-post.php" class="blog-card-img" style="background: url('images/darjeeling-blog.jpg') center/cover; display: block;"></a>
                        <div class="blog-card-content">
                            <span class="blog-category">Heritage Stays</span>
                            <h3><a href="darjeeling-blog-post.php">Colonial Charm: Top Tea Estate Bungalows in Darjeeling</a></h3>
                            <p class="blog-meta">March 28, 2026</p>
                            <p>Step back in time and wake up to the aroma of fresh tea leaves in these handpicked heritage properties across North Bengal.</p>
                        </div>
                    </div>

                    <div class="blog-card" data-category="tips">
                        <a href="rajasthan-blog-post.php" class="blog-card-img" style="background: url('images/rajasthan-blog.jpg') center/cover; display: block;"></a>
                        <div class="blog-card-content">
                            <span class="blog-category">Travel Tips</span>
                            <h3><a href="rajasthan-blog-post.php">When is the Best Time to Visit Rajasthan?</a></h3>
                            <p class="blog-meta">March 15, 2026</p>
                            <p>Avoid the extreme heat and experience the royal state at its finest. A month-by-month breakdown of weather and festivals.</p>
                        </div>
                    </div>
                    
                    <div class="blog-card" data-category="tips">
                        <a href="packing-blog-post.php" class="blog-card-img" style="background: url('images/pack-blog.jpg') center/cover; display: block;"></a>
                        <div class="blog-card-content">
                            <span class="blog-category">Preparation</span>
                            <h3><a href="packing-blog-post.php">Packing for the Himalayas: A Luxury Traveler's Guide</a></h3>
                            <p class="blog-meta">March 05, 2026</p>
                            <p>How to pack light while ensuring you have the right layers for the unpredictable mountain weather in Himachal and Sikkim.</p>
                        </div>
                    </div>

                </div>

                <div class="pagination">
                    <a href="#" class="active">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">Next &raquo;</a>
                </div>

            </div>

            <aside class="blog-sidebar">
                
                <div class="sidebar-widget expert-widget">
                    <div class="expert-avatar" style="font-size: 2.5rem; color: var(--primary-gold); margin-bottom: 15px; text-align: center;">
                        <i class="fa-solid fa-user-tie"></i>
                    </div>
                    <h3 style="text-align: center; display: block; border-bottom: none;">Plan Your Dream Trip</h3>
                    <p style="text-align: center;">Reading about the Himalayas? Let our Kolkata-based experts craft a tailored itinerary just for you.</p>
                    
                    <button class="btn-primary full-width" onclick="openLeadPopup()" style="font-size: 1.1rem; padding: 15px; margin-top: 15px;">
                        <i class="fa-solid fa-phone"></i> Consult an Expert
                    </button>
                </div>
                
                <div class="sidebar-widget">
                    <h3>Search Articles</h3>
                    <form id="searchForm" class="sidebar-search" onsubmit="event.preventDefault();">
                        <input type="text" id="searchInput" placeholder="Search destinations, tips...">
                        <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                    </form>
                </div>

                <div class="sidebar-widget">
                    <h3>Categories</h3>
                    <ul class="category-list">
                        <li><a href="#" class="category-filter" data-target="all" style="color: var(--primary-gold);">All Articles <span>(4)</span></a></li>
                        <li><a href="#" class="category-filter" data-target="destination">Destination Guides <span>(1)</span></a></li>
                        <li><a href="#" class="category-filter" data-target="heritage">Heritage Stays <span>(1)</span></a></li>
                        <li><a href="#" class="category-filter" data-target="tips">Travel Tips & Prep <span>(2)</span></a></li>
                    </ul>
                </div>

                <div class="sidebar-widget newsletter-widget">
                    <h3>Join the Elite Club</h3>
                    <p>Get exclusive travel guides and tailored itinerary offers straight to your inbox.</p>
                    <form action="#" onsubmit="event.preventDefault(); alert('Subscribed successfully!');">
                        <input type="email" placeholder="Email Address" required style="width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 4px;">
                        <button type="submit" class="btn-primary full-width">Subscribe</button>
                    </form>
                </div>

            </aside>

        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-grid">
            
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a>
                <a href="#">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="#">Career</a>
            </div>
            
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="#">Travel Guidelines</a>
            </div>
            
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
            
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

     <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>
    </a>

    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Speak with a Travel Expert</h3>
            <p>Fill out the details below, and we will craft a custom itinerary for you.</p>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label>Phone Number *</label>
                    <input type="tel" name="phone" required>
                </div>
                <div class="form-group">
                    <label>Interested Destinations *</label>
                    <input type="text" name="destination" placeholder="e.g. North Bengal, Rajasthan" required>
                </div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>