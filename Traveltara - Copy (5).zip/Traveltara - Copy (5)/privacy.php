<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy | Traveltara</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="css/privacy.css">
</head>
<body>

    <header class="slim-hero">
        <div class="logo"><b>traveltara</b></div>
        <h1>Privacy Policy</h1>
    </header>

    <main class="policy-container">
        <p class="effective-date"><strong>Effective Date:</strong> April 20, 2026</p>
        
        <p>Welcome to Traveltara ("we," "our," or "us"). We are committed to protecting your personal information and your right to privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our travel booking services.</p>

        <h2>1. Information We Collect</h2>
        <p>To provide you with our bespoke travel services, we collect personal information when you voluntarily submit it through our booking and checkout forms. This includes:</p>
        <ul>
            <li><strong>Contact & Identity Information:</strong> Full name, prefix, phone numbers, and email address.</li>
            <li><strong>Demographic Information:</strong> Residential, permanent, and optional office addresses.</li>
            <li><strong>Travel & Verification Data:</strong> Aadhaar number, Passport number, travel destination, commencement date, and tour tier preferences.</li>
            <li><strong>Group Details:</strong> Number of adults, children, and room requirements for dynamic pricing.</li>
            <li><strong>Financial Information:</strong> Payment data necessary to process your booking via secure third-party gateways. We do not store complete credit card details.</li>
        </ul>

        <h2>2. How We Use Your Information</h2>
        <p>We use the personal information collected to facilitate and manage your travel experience. Specifically, we use your data to process bookings, generate Tax Invoices, communicate via Email and WhatsApp, calculate dynamic pricing, and fulfill legal identity verification requirements.</p>

        <h2>3. How We Share Your Information</h2>
        <p>We do not sell or trade your personal information. We only share it with necessary service providers (airlines, hotels, transport) strictly for fulfilling your itinerary, and with payment processors to securely complete your transaction.</p>

        <h2>4. Data Security</h2>
        <p>We implement industry-standard administrative, technical, and physical security measures to protect your personal information during transmission and storage.</p>

        <h2>5. Contact Us</h2>
        <p>If you have questions about this Privacy Policy, please contact us at:</p>
        <p>
            <strong>Email:</strong> booking.traveltara@gmail.com<br>
            <strong>WhatsApp:</strong> +91 9477709755
        </p>
        
        <br><br>
    </main>

    <div class="action-bar">
        <button id="understandBtn" class="btn-understand">
            <i class="fa-solid fa-check"></i> I Understand & Agree
        </button>
    </div>

    <script src="js/privacy.js"></script>
</body>
</html>