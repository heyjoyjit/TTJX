<?php
// Top of package-karnataka-ultimate.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹45,000"; 
$sheet_affordable_price = "₹68,000";
$sheet_super_price = "₹1,10,000";

// EXACT package name from Google Sheet
$target_package = "Ultimate Karnataka Expedition 15D/14N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hotels / Homestays</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the 15-Day Route</li>
            <li><i class="fa-solid fa-camera"></i> 2 Standard Jungle Safaris Included</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Resorts, Heritage Bungalows & Jungle Lodges</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta for Maximum Inter-City Comfort</li>
            <li><i class="fa-solid fa-map-location-dot"></i> Expert Guided Monument Tours & Premium Safaris</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP) highlighting Regional Cuisines</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Palaces & Ultra-Luxury Wilderness Retreats (e.g., Evolve Back)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Boat Safaris, VIP Darshans & Private Coffee Masterclasses</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Dining, Royal Feasts & Private Beach BBQs</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Ultimate Karnataka Expedition 15 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="karnataka-itinerary.php">Karnataka Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Ultimate Expedition (15D/14N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['karnataka grand loop hero']) ? $tourImages['karnataka grand loop hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 15 Days / 14 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Ultimate Karnataka Expedition</h1>
            <p>A complete 15-day grand loop through royal palaces, deep tiger reserves, misty coffee estates, pristine coasts, and ancient empires.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Ultimate Karnataka Expedition 15D/14N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>To truly understand Karnataka, one must traverse its profound contrasts. We have designed this 15-day expedition to be entirely comprehensive, ensuring no region is left unexplored or rushed. You will begin in the royal city of Mysore, descend into the dense tiger reserves of Kabini and Bandipur, climb into the cool, aromatic heights of Coorg and Chikmagalur, trace the spectacular Arabian coastline from Udupi to Gokarna, and finally, stand amidst the colossal, time-frozen ruins of the Vijayanagara Empire in Hampi.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Bengaluru & The Royal City (Mysuru)</h3>
                <p>Arrive at Kempegowda International Airport (BLR). Your private chauffeur will receive you and begin the smooth drive to the cultural capital, Mysuru (approx. 3.5 hours). Check into your hotel. In the afternoon, visit the spectacularly opulent Amba Vilas (Mysore Palace), a masterpiece of Indo-Saracenic architecture. In the evening, take a sensory walk through the vibrant, historic Devaraja Market, filled with sandalwood, silk, and spices.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Descent into the Wilderness (Kabini / Bandipur)</h3>
                <p>After breakfast, visit the Chamundeshwari Temple atop the Chamundi Hills. Then, check out and drive into the Nilgiri Biosphere Reserve (approx. 2 hours). Check into your premium jungle lodge in Kabini or Bandipur. After lunch, embark on your first thrilling afternoon Safari. Traverse the dense, dry deciduous forests tracking wild Asiatic elephants, leopards, and the elusive Bengal Tiger. Return to the lodge for a campfire dinner.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Safaris & The River Corridors</h3>
                <p>Wake up before dawn for a crisp morning jeep safari, maximizing your chances of predator sightings. Return for breakfast and relaxation. In the afternoon, if staying in Kabini, embark on a unique Boat Safari on the Kabini backwaters. This silent approach allows you to witness massive herds of elephants grazing on the banks and provides a chance to spot the legendary melanistic leopard (Black Panther) resting in the overarching branches.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Ascent to the "Scotland of India" (Coorg)</h3>
                <p>Take one final morning safari. After breakfast, leave the plains and drive up into the cool, misty elevations of the Western Ghats towards Madikeri, Coorg (approx. 3 hours). Check into your lush coffee estate resort. Spend the late afternoon visiting the roaring Abbey Falls and watching a spectacular sunset from Raja’s Seat, overlooking the vast, verdant valleys.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Golden Temple & Kodava Culture</h3>
                <p>Begin your day interacting with the gentle giants at the Dubare Elephant Camp. Next, drive to Kushalnagar to explore the breathtaking Namdroling Monastery (The Golden Temple), a vibrant piece of Tibet in South India. In the afternoon, take a guided walking tour through your coffee plantation, learning the art of brewing. Enjoy a traditional dinner featuring authentic Kodava Pandi Curry.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Hoysala Architecture & The Coffee Capital (Chikmagalur)</h3>
                <p>Check out and drive north toward Chikmagalur (approx. 4 hours). En route, stop at Belur and Halebidu. These 12th-century Hoysala temples are architectural marvels, featuring soapstone carvings so intricate they resemble lacework. After exploring the temples, continue to Chikmagalur, the birthplace of coffee in India. Check into your heritage bungalow or resort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> The Highest Peak in Karnataka</h3>
                <p>After breakfast, take a scenic, winding drive up to Mullayanagiri, the highest peak in Karnataka (6,300 ft). The panoramic views of the Western Ghats from here are unparalleled. Visit the nearby Seethalayanagiri and the cascading Jhari Waterfalls. Return to the resort for an afternoon of relaxation, perhaps enjoying a specialized coffee-tasting session.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Descend to the Coast (Udupi & St. Mary's Island)</h3>
                <p>Say goodbye to the hills and drive down the spectacular Agumbe Ghats towards the Arabian Sea coast, arriving in Udupi (approx. 4 hours). Head straight to Malpe Beach and take a ferry to St. Mary's Island to witness the rare, hexagonal basalt rock formations. In the evening, seek blessings at the legendary Sri Krishna Temple and enjoy an authentic, purely vegetarian Udupi feast.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> The Coastal Highway & The Giant Shiva (Murdeshwar)</h3>
                <p>Check out and drive north along the stunning NH66 coastal highway, with the Arabian Sea beside you. Arrive in Murdeshwar (approx. 2 hours) and visit the towering 123-foot Lord Shiva statue. Take the elevator up the massive 18-story Rajagopuram for an incredible aerial view of the statue and the ocean. Relax on the Murdeshwar beach for the evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> The Cliffside Beaches of Gokarna</h3>
                <p>Continue your coastal drive to the deeply spiritual and laid-back town of Gokarna (approx. 2 hours). Check into your cliff-side resort. Spend the day trekking between the famous interconnected shores: walk from Kudle Beach over the laterite cliffs to the naturally shaped Om Beach, and further down to Half Moon Beach. Watch the sunset from a beachside café.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Transition to the Ancient Empire (Drive to Hampi)</h3>
                <p>Begin the longest transition of the journey. Leave the coast and drive inland across the vast Deccan Plateau towards the ancient ruins of Hampi (approx. 5 to 6 hours). Watch the landscape transform from lush greens to dramatic, boulder-strewn arid plains. Arrive in Hampi or Kamalapura by late afternoon, check into your heritage hotel, and rest.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> The Sacred Center of Vijayanagara</h3>
                <p>Step into the 14th century. Begin at the active Virupaksha Temple, standing tall amidst the ruins. Walk along the Tungabhadra River, taking a traditional coracle boat ride. In the afternoon, explore the magnificent Vittala Temple complex, famous for the iconic Stone Chariot and the musical pillars. The scale of this UNESCO World Heritage site is staggering.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> The Royal Enclosure & Sunset at Matanga Hill</h3>
                <p>Explore the secular side of the empire: The Royal Enclosure, the symmetric Lotus Mahal, the grand Elephant Stables, and the beautifully carved Hazara Rama Temple. In the late afternoon, hike up the boulders of Matanga Hill or Hemakuta Hill. The view of the ruined city glowing golden in the sunset is the absolute pinnacle of this expedition.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 14</span> The Chalukyan Rock-Cut Caves (Badami)</h3>
                <p>Take a day trip (or check out and drive) to the town of Badami (approx. 3 hours). Explore the extraordinary Badami Cave Temples—four majestic temples carved directly out of the monolithic red sandstone cliffs overlooking the Agastya Lake. Visit the nearby sites of Aihole and Pattadakal if time permits. Return to your hotel and prepare for your departure.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 15</span> Departure from Hubballi or Bengaluru</h3>
                <p>Your ultimate Karnataka expedition comes to an end. After breakfast, check out of your hotel. Your chauffeur will drive you to the nearest major airport—either Hubballi Airport (HBX) (approx. 3.5 hours) or back to Kempegowda International Airport (BLR) in Bengaluru (approx. 6 hours) for your onward flight home.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hotels / Homestays</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the 15-Day Route</li>
                <li><i class="fa-solid fa-camera"></i> 2 Standard Jungle Safaris Included</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/karnataka-ultimate-15d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- GRAND LOOP INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The 15-Day Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for a massive, multi-terrain endurance journey across an entire state.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase-rolling"></i></div>
                <h3>Packing for 4 Climates</h3>
                <p>Strategic layering is key:</p>
                <ul>
                    <li><strong>The Variations:</strong> You will experience four distinct micro-climates. Bengaluru/Mysore is pleasant; Kabini is humid in the day and cold at night; Coorg/Chikmagalur is misty and chilly; the Coast (Gokarna/Udupi) is hot and tropical; and Hampi is extremely dry and sunny. Pack layers, sturdy walking shoes, and strong sun protection.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car-side"></i></div>
                <h3>Vehicle Upgrade Recommended</h3>
                <p>Managing the long drives:</p>
                <ul>
                    <li><strong>Road Fatigue:</strong> Over 15 days, you will be on the road frequently, transitioning between mountains, coasts, and plains. We highly advise upgrading to an Innova Crysta (even for couples) simply for the superior suspension and legroom over thousands of kilometers.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-paw"></i></div>
                <h3>Safari Realities</h3>
                <p>Understanding the Nilgiris:</p>
                <ul>
                    <li><strong>JLR Monopoly:</strong> Safaris in Kabini and Bandipur are strictly controlled by the government (JLR). We manage these complex bookings, but vehicle type (Jeep vs. Canter) depends heavily on the tier you book and advance availability.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Temple Etiquette (Strict)</h3>
                <p>Coast to Ruins:</p>
                <ul>
                    <li><strong>Dress Codes:</strong> At Udupi Sri Krishna, Gokarna Mahabaleshwar, and Hampi Virupaksha, modest clothing is strictly enforced. Men may need to remove shirts at specific coastal temples, and women must wear traditional attire or fully covered clothing.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-camera-retro"></i></div>
                <h3>Hampi ASI Rules</h3>
                <p>Photographing the ruins:</p>
                <ul>
                    <li><strong>No Drones:</strong> Drones are strictly banned across all UNESCO sites in Hampi, Badami, and Pattadakal. Tripods also require special permission from the Archaeological Survey of India (ASI) guards on-site.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Diversity</h3>
                <p>Changing flavors:</p>
                <ul>
                    <li><strong>The Transitions:</strong> You will eat royal Mughlai/South Indian in Mysore, Kodava Pandi Curry in Coorg, purely vegetarian temple food in Udupi, spicy seafood on the coast, and North Karnataka Jowar Roti meals in Hampi. Embrace the local diet!</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized 15-day Grand Loop.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Ultimate Karnataka Expedition 15D/14N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>