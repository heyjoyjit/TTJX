<?php
// Top of package-kerala-malabar.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹18,000"; 
$sheet_affordable_price = "₹28,000";
$sheet_super_price = "₹45,000";

// EXACT package name from Google Sheet
$target_package = "The Untamed Malabar Circuit 7D/6N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hill Resorts & Beach Homestays</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the Entire Route</li>
            <li><i class="fa-solid fa-ticket"></i> Entry Tickets for Edakkal Caves & Bekal Fort Included</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Nature Resorts & Heritage Coastal Stays</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta for Superior Comfort</li>
            <li><i class="fa-solid fa-camera"></i> Guided Theyyam Experience (Seasonal) & Wayanad Safari</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP) highlighting Malabar Cuisine</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Ultra-Luxury (e.g., Taj Wayanad, Taj Bekal Resort & Spa)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Valiyaparamba Backwater Cruise & VIP Fort Access</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Dining, Private Beach BBQs & Premium Mappila Feasts</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Untamed Malabar Circuit 7 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="kerala-itinerary.php">Kerala Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">The Malabar Circuit (7D/6N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['kerala malabar hero']) ? $tourImages['kerala malabar hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 7 Days / 6 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Untamed Malabar Circuit</h1>
            <p>Journey through prehistoric caves in Wayanad, witness intense Theyyam rituals in Kannur, and relax at the majestic Bekal Fort.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Untamed Malabar Circuit 7D/6N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Welcome to Northern Kerala, the region known as the Malabar Coast. Often bypassed by standard tourist crowds, this 7-day circuit offers an authentic, raw, and culturally intense experience. You will begin high in the pristine mountains of Wayanad, exploring prehistoric petroglyphs and dense wildlife sanctuaries. From there, descend to the historically rich coastal town of Kannur to witness the fascinating, colorful Theyyam rituals, before ending your journey in Kasaragod to explore the colossal, ocean-facing Bekal Fort and the secluded Valiyaparamba backwaters.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Calicut & Ascent to Wayanad</h3>
                <p>Arrive at Calicut International Airport (CCJ). Your private chauffeur will receive you and begin the highly scenic drive up the Thamarassery Churam (mountain pass) towards Wayanad (approx. 3.5 hours). Featuring 9 hairpin bends, the drive offers spectacular views of the rolling Western Ghats. Arrive in the district of Wayanad and check into your lush, nature-enveloped resort. Spend the evening relaxing and acclimatizing to the crisp mountain air.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Prehistoric Caves & Spices</h3>
                <p>After a hearty breakfast, embark on a trek to the Edakkal Caves. Situated at 4,000 feet, these natural rock shelters contain prehistoric petroglyphs (rock carvings) dating back to 6,000 BC. The trek is steep but highly rewarding. In the afternoon, visit the roaring Soochipara Waterfalls (Sentinel Rock Waterfalls). Conclude the day with a guided walk through local spice and coffee plantations before returning to your resort for dinner.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Wildlife Safari & Descent to the Coast (Kannur)</h3>
                <p>Wake up early for a thrilling morning jeep safari in the Muthanga Wildlife Sanctuary, an integral part of the Nilgiri Biosphere Reserve. Look out for wild elephant herds, bison, and the occasional tiger. After the safari, return for breakfast, check out, and begin your descent toward the historic coastal city of Kannur (approx. 4 hours). Check into your beachside heritage hotel or resort and enjoy an evening stroll along the pristine Muzhappilangad Drive-in Beach.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> The Rituals of Theyyam & Coastal Forts</h3>
                <p>Today is deeply cultural. Begin your morning with a visit to a local Kaavu (shrine) to witness a Theyyam performance (subject to seasonal calendars, primarily Oct-May). This intense, colorful, and vibrant ritual dance is a deeply rooted spiritual tradition of the Malabar region. In the afternoon, visit the formidable St. Angelo Fort, built by the Portuguese in 1505, offering commanding views of the Arabian Sea and the Moppila Bay.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Drive to Kasaragod & The Majestic Bekal Fort</h3>
                <p>Check out and drive further north along the coast to Kasaragod (approx. 2.5 hours). Head straight to the colossal Bekal Fort. Built in 1650, it is the largest fort in Kerala, uniquely designed to rise directly out of the Arabian Sea. Walk along its ancient ramparts, visit the observation towers, and enjoy the sea breeze. Check into your luxury resort in Bekal and spend the evening indulging in authentic Malabari cuisine.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Valiyaparamba Backwaters</h3>
                <p>Experience the backwaters of Northern Kerala, which are vastly different and significantly less crowded than Alleppey. Take a serene morning boat cruise on the Valiyaparamba backwaters, drifting past tiny island villages and dense coconut groves. Spend your final afternoon at your resort, perhaps enjoying a traditional Ayurvedic massage or a quiet walk along the secluded Kappil Beach.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Departure from Malabar</h3>
                <p>Enjoy your final breakfast overlooking the Arabian Sea. Check out of your resort. Your chauffeur will transfer you to either Mangaluru International Airport (IXE) (approx. 2 hours) or Kannur International Airport (CNN) (approx. 2.5 hours) for your onward journey, bringing your incredible Northern Kerala adventure to a close.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hill Resorts & Beach Homestays</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the Entire Route</li>
                <li><i class="fa-solid fa-ticket"></i> Entry Tickets for Edakkal Caves & Bekal Fort Included</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/kerala-malabar-7d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- MALABAR INSIGHTS HUB (6 GRID CARDS)                       -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Northern Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for a seamless journey through Northern Kerala.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-masks-theater"></i></div>
                <h3>Theyyam Seasonality</h3>
                <p>Timing the rituals:</p>
                <ul>
                    <li><strong>The Calendar:</strong> Theyyam is an active spiritual ritual, not a staged tourist performance. The season generally runs from late October to May. Schedules are set by local shrines (Kaavus). If visiting outside this period, the itinerary will pivot to local handloom and heritage tours.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-person-hiking"></i></div>
                <h3>Edakkal Caves Trek</h3>
                <p>Physical fitness required:</p>
                <ul>
                    <li><strong>The Climb:</strong> Reaching the Edakkal Caves requires a steep, 45-minute uphill trek on an uneven, rocky path. It is physically demanding. Elderly travelers or those with mobility or heart issues should consult their doctor before attempting this climb.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-plane-departure"></i></div>
                <h3>Flight Gateways</h3>
                <p>Avoiding backtracking:</p>
                <ul>
                    <li><strong>Logistics:</strong> To optimize this linear route, we highly recommend booking your arrival flight into Calicut (CCJ) and your departure flight out of Mangaluru (IXE) or Kannur (CNN). Driving back to Calicut on Day 7 adds unnecessary travel time.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Malabari Cuisine</h3>
                <p>A culinary shift:</p>
                <ul>
                    <li><strong>Mappila Flavors:</strong> The food in Northern Kerala differs significantly from the south. This region is famous for its rich, aromatic Mappila (Moppila) cuisine, heavily influenced by Arab traders. Do not miss the authentic Thalassery or Kozhikode Biryani.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-moon"></i></div>
                <h3>Forest Night Closures</h3>
                <p>Navigating Wayanad:</p>
                <ul>
                    <li><strong>Highway Bans:</strong> Similar to Bandipur, the national highways passing through the Wayanad and Muthanga forest zones are strictly closed to all traffic from 9:00 PM to 6:00 AM to protect wildlife. Travel times must be strictly adhered to.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-monument"></i></div>
                <h3>Exploring Bekal Fort</h3>
                <p>Timing the visit:</p>
                <ul>
                    <li><strong>Sun Exposure:</strong> Bekal Fort is entirely open to the sky and involves significant walking over massive laterite laterite ramps. It is best visited either early in the morning or late afternoon to avoid the intense midday coastal sun. The sunset view from here is spectacular.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized Malabar escape.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="The Untamed Malabar Circuit 7D/6N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>