<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Booking | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/booking.css">
</head>
<body>

    <header class="compact-hero">
        <h1 class="brand-logo">traveltara</h1>
        <div class="hero-subtitle">Guest Information & Itinerary Customization</div>
    </header>

    <main class="booking-container">
        <form id="leadForm">
            
            <h2>Primary Guest Details</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label>Prefix <span class="required">*</span></label>
                    <select id="prefix" required>
                        <option value="Mr.">Mr.</option>
                        <option value="Mrs.">Mrs.</option>
                        <option value="Ms.">Ms.</option>
                        <option value="Dr.">Dr.</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>First Name <span class="required">*</span></label>
                    <input type="text" id="fName" required>
                </div>
                <div class="form-group">
                    <label>Middle Name</label>
                    <input type="text" id="mName">
                </div>
                <div class="form-group">
                    <label>Last Name <span class="required">*</span></label>
                    <input type="text" id="lName" required>
                </div>
            </div>

            <h2>Contact Information</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label>Primary Phone <span class="required">*</span></label>
                    <input type="tel" id="primaryPhone" maxlength="10" required>
                </div>
                <div class="form-group">
                    <label>Alternate Phone</label>
                    <input type="tel" id="altPhone" maxlength="10">
                </div>
                <div class="form-group">
                    <label>Email Address <span class="required">*</span></label>
                    <input type="email" id="email" required>
                </div>
                <div class="form-group">
                    <label>Confirm Email Address <span class="required">*</span></label>
                    <input type="email" id="confirmEmail" required autocomplete="off">
                </div>
            </div>

            <h2>Residential Address</h2>
            <div class="form-grid">
                <div class="form-group"><label>Address Line 1 <span class="required">*</span></label><input type="text" id="resLine1" required></div>
                <div class="form-group"><label>Landmark <span class="required">*</span></label><input type="text" id="resLandmark" required></div>
                <div class="form-group"><label>Pincode <span class="required">*</span></label><input type="text" id="resPin" maxlength="6" oninput="fetchPincodeData(this.value, 'res')" required></div>
                
                <div class="form-group"><label>City <span class="required">*</span></label><input type="text" id="resCity" required></div>
                <div class="form-group"><label>District <span class="required">*</span></label><input type="text" id="resDist" required></div>
                <div class="form-group"><label>State <span class="required">*</span></label><input type="text" id="resState" required></div>
                <div class="form-group"><label>Country <span class="required">*</span></label><input type="text" id="resCountry" required></div>
            </div>

            <h2>Permanent Address</h2>
            <div style="margin-bottom: 20px;">
                <input type="checkbox" id="sameAsResCheck" checked> 
                <label for="sameAsResCheck" style="display:inline; font-size:15px;">Same as Residential Address</label>
            </div>
            <div class="form-grid hidden-section" id="permAddressBlock">
                <div class="form-group"><label>Address Line 1 <span class="required">*</span></label><input type="text" id="permLine1"></div>
                <div class="form-group"><label>Landmark <span class="required">*</span></label><input type="text" id="permLandmark"></div>
                <div class="form-group"><label>Pincode <span class="required">*</span></label><input type="text" id="permPin" maxlength="6" oninput="fetchPincodeData(this.value, 'perm')"></div>
                <div class="form-group"><label>City <span class="required">*</span></label><input type="text" id="permCity"></div>
                <div class="form-group"><label>District <span class="required">*</span></label><input type="text" id="permDist"></div>
                <div class="form-group"><label>State <span class="required">*</span></label><input type="text" id="permState"></div>
                <div class="form-group"><label>Country <span class="required">*</span></label><input type="text" id="permCountry"></div>
            </div>

            <h2>Office Address</h2>
            <div style="margin-bottom: 20px;">
                <input type="checkbox" id="addOfficeCheck"> 
                <label for="addOfficeCheck" style="display:inline; font-size:15px;">I want to add an Office Address</label>
            </div>
            <div class="form-grid hidden-section" id="officeAddressBlock">
                <div class="form-group"><label>Address Line 1 <span class="required">*</span></label><input type="text" id="offLine1"></div>
                <div class="form-group"><label>Landmark <span class="required">*</span></label><input type="text" id="offLandmark"></div>
                <div class="form-group"><label>Pincode <span class="required">*</span></label><input type="text" id="offPin" maxlength="6" oninput="fetchPincodeData(this.value, 'off')"></div>
                <div class="form-group"><label>City <span class="required">*</span></label><input type="text" id="offCity"></div>
                <div class="form-group"><label>District <span class="required">*</span></label><input type="text" id="offDist"></div>
                <div class="form-group"><label>State <span class="required">*</span></label><input type="text" id="offState"></div>
                <div class="form-group"><label>Country <span class="required">*</span></label><input type="text" id="offCountry"></div>
            </div>

            <h2>Delivery Preference</h2>
            <div class="form-grid">
                <div class="form-group full-width">
                    <label>Where should we deliver physical documents/merchandise? <span class="required">*</span></label>
                    <div id="deliveryRadios" style="display: flex; flex-wrap: wrap; gap: 20px; margin-top: 10px; font-size: 15px;">
                        </div>
                </div>
            </div>

            <h2>Verification & Tour Details</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label>Aadhaar Number <span class="required">*</span></label>
                    <input type="text" id="aadhaar" maxlength="12" required>
                </div>
                <div class="form-group">
                    <label>Tour Type <span class="required">*</span></label>
                    <select id="tourType" required>
                        <option value="Domestic">Domestic</option>
                        <option value="International">International</option>
                    </select>
                </div>
                <div class="form-group hidden-section" id="passportGroup">
                    <label>Passport No.</label>
                    <input type="text" id="passport">
                </div>
                <div class="form-group">
                    <label>Destination Itinerary <span class="required">*</span></label>
                    <input type="text" id="destination" readonly required style="background:#e9ecef;">
                </div>
                <div class="form-group">
                    <label>Commencement Date (DD/MM/YYYY) <span class="required">*</span></label>
                    <input type="date" id="startDate" required>
                </div>
                <div class="form-group">
                    <label>Tour Tier <span class="required">*</span></label>
                    <select id="tier" required>
                        <option value="Budget">Budget</option>
                        <option value="Affordable Luxury">Affordable Luxury</option>
                        <option value="Super Luxury">Super Luxury</option>
                        <option value="Customised">Customised</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="submit-btn" id="submitBtn">Proceed to Configure Room Allocation</button>
        </form>
    </main>

    <!-- 🚀 ADDED CACHE BUSTER HERE -->
    <script src="js/booking.js?v=3"></script>
</body>
</html>