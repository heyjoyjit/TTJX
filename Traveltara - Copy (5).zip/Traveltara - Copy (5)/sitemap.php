<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Map | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Site Map</h1>
        <p>Navigate Traveltara.</p>
    </header>

    <main class="info-container">
        <h2>Core Navigation</h2>
        <ul>
            <li><a href="index.php" style="color: #0A1128; font-weight: bold;">Home</a></li>
            <li><a href="destinations.php" style="color: #0A1128; font-weight: bold;">Destinations</a></li>
            <li><a href="tailored.php" style="color: #0A1128; font-weight: bold;">Tailored Trips</a></li>
            <li><a href="blog.php" style="color: #0A1128; font-weight: bold;">Travel Blog</a></li>
        </ul>

        <h2>Company & Support</h2>
        <ul>
            <li><a href="about.php" style="color: #0A1128;">About Us</a></li>
            <li><a href="contact.php" style="color: #0A1128;">Contact Support</a></li>
            <li><a href="career.php" style="color: #0A1128;">Careers</a></li>
            <li><a href="products.php" style="color: #0A1128;">Products & Services</a></li>
            <li><a href="group-travel.php" style="color: #0A1128;">Group Travels</a></li>
        </ul>

        <h2>Legal & Guidelines</h2>
        <ul>
            <li><a href="terms.php" style="color: #0A1128;">Terms & Conditions</a></li>
            <li><a href="privacy.php" style="color: #0A1128;">Privacy Policy</a></li>
            <li><a href="refunds.php" style="color: #0A1128;">Refunds & Cancellations</a></li>
            <li><a href="payments.php" style="color: #0A1128;">Payment Policy</a></li>
            <li><a href="disclaimer.php" style="color: #0A1128;">Legal Disclaimer</a></li>
            <li><a href="visa.php" style="color: #0A1128;">Visa & Immigration</a></li>
        </ul>
    </main>

</body>
</html>