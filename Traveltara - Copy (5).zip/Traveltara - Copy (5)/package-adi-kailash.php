<?php
// Top of package-adi-kailash.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹45,000"; 
$sheet_affordable_price = "₹65,000";
$sheet_super_price = "₹90,000";

// EXACT package name from Google Sheet
$target_package = "Adi Kailash 12D/11N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Basic Guesthouses & KMVN Rest Houses</li>
            <li><i class="fa-solid fa-truck-monster"></i> Shared 4x4 Camper/Bolero for Vyas Valley</li>
            <li><i class="fa-solid fa-id-card"></i> Inner Line Permits & Police Clearance Included</li>
            <li><i class="fa-solid fa-utensils"></i> All Meals Included (Basic Vegetarian)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium Boutique Hotels (Kathgodam-Dharchula) & Best Available Camps</li>
            <li><i class="fa-solid fa-truck-monster"></i> Dedicated Private 4x4 Bolero for Extreme Terrains</li>
            <li><i class="fa-solid fa-star"></i> Medical Checkup Assistance & Premium Oxygen Backup</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners & Packed High-Energy Lunches</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Top-Tier Luxury Resorts (Basecamps) & Upgraded Alpine Camping</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV to Dharchula + Premium Private 4x4 Beyond</li>
            <li><i class="fa-solid fa-crown"></i> VIP Darshan Assistance, Private Guide & Satellite Phone Backup</li>
            <li><i class="fa-solid fa-utensils"></i> Premium Vegetarian Fine Dining & Customized Diet Support</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adi Kailash & Om Parvat 12 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="uttarakhand-itinerary.php">Uttarakhand</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Adi Kailash & Om Parvat (12D/11N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['adi kailash hero']) ? $tourImages['adi kailash hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 12 Days / 11 Nights</div>
        <div class="subpage-hero-content">
            <h1>Adi Kailash & Om Parvat</h1>
            <p>Journey into the mystic Vyas Valley to witness the sacred snow formations of the high Himalayas.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Adi Kailash 12D/11N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Prepare for one of the most exclusive and spiritually profound expeditions in the Indian Himalayas. Deep within the Pithoragarh district, bordering Tibet and Nepal, lie the revered peaks of Adi Kailash and Om Parvat. This 12-day journey transitions from comfortable hill stations to rugged, high-altitude 4x4 trails. You will undergo strict permit processes, traverse the dramatic Vyas Valley, and stand before the miraculous, naturally formed "Om" snow script on the mountain face.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Kathgodam & Drive to Pithoragarh</h3>
                <p>Your journey begins at Pantnagar Airport or Kathgodam Railway Station. Your chauffeur will drive you deep into the Kumaon region toward the beautiful town of Pithoragarh (approx. 7 hours), known as "Little Kashmir." Check into your hotel, rest, and breathe in the crisp mountain air.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Pithoragarh to Dharchula (Permit Processing)</h3>
                <p>After breakfast, drive along the Kali River, which forms the natural border between India and Nepal, arriving in the frontier town of Dharchula (approx. 3-4 hours). Today is crucial for administration. You will undergo mandatory medical check-ups and process your Inner Line Permits (ILP) required to enter the restricted border zones. Check into your hotel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Dharchula to Gunji / Narayan Ashram</h3>
                <p>Leave your standard vehicle behind and transfer to a specialized 4x4 mountain vehicle. Begin the thrilling, rugged ascent into the pristine Vyas Valley. The terrain is extreme and breathtaking. You will pass by beautiful waterfalls and remote villages, arriving at the high-altitude settlement of Gunji (10,500 ft). Overnight in a basic homestay or camp.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Acclimatization in Gunji & Local Walks</h3>
                <p>Given the rapid gain in altitude and the extreme terrain ahead, today is dedicated to acclimatization. Take short, slow walks around the village of Gunji, interacting with the local Bhotia tribe. Visit the confluence of the Kali and Kuti rivers. Hydrate heavily and prepare your body for the higher altitudes.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Gunji to Jyolingkong (Base of Adi Kailash)</h3>
                <p>Drive further up the extreme mountain terrain to Jyolingkong (13,700 ft). The air grows incredibly thin, and the landscape turns stark and glacial. This is the base camp for Adi Kailash. Arrive and check into your highly basic alpine camp. The towering, majestic peak of Mount Adi Kailash will dominate your view.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Adi Kailash Darshan & Parvati Sarovar</h3>
                <p>Wake up to a freezing but spiritually charged morning. Walk approx. 3-4 km to reach the pristine Parvati Sarovar (Lake) and the Gauri Kund, located directly at the foot of Adi Kailash. Witness the flawless reflection of the sacred peak in the lake. Perform your pujas and meditations. In the afternoon, drive back to Gunji for a safer, lower-altitude overnight stay.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Gunji to Nabhidhang (Om Parvat)</h3>
                <p>Embark on the journey toward the Indo-Tibetan border. Drive from Gunji to Nabhidhang (14,000 ft). As you reach the viewpoint, gaze upon the awe-inspiring Om Parvat, where the snow miraculously falls to form a perfect, natural "Om" symbol against the black rock. Absorb the profound energy of this phenomenon.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Return from Nabhidhang to Dharchula</h3>
                <p>After a final morning prayer facing Om Parvat, begin the long, bumpy descent out of the Vyas Valley. Retrace your rugged 4x4 path through Gunji and down the mountainsides, returning to the comforts of Dharchula. Check into your hotel and enjoy your first hot shower and reliable electricity in days.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Dharchula to Chaukori / Patal Bhuvaneshwar</h3>
                <p>Transfer back to your luxury SUV/Sedan. Drive toward the serene, offbeat hamlet of Chaukori (approx. 5 hours). En route, you may opt to visit Patal Bhuvaneshwar, a fascinating underground limestone cave temple dedicated to Lord Shiva. Arrive in Chaukori, surrounded by tea gardens, and check into your resort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Chaukori to the Spiritual Forests of Jageshwar</h3>
                <p>Wake up early for a spectacular sunrise over the Panchachuli peaks. Drive to Jageshwar Dham (approx. 4 hours), a magnificent complex of 124 ancient stone temples hidden within a dense, mystical deodar forest. Check into a boutique forest retreat and enjoy the overwhelming peace of the region.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Jageshwar to Bhimtal / Nainital</h3>
                <p>Descend further through the Kumaon hills to the beautiful lake district of Bhimtal or Nainital (approx. 4 hours). Check into your premium lake-view resort. Spend your final evening celebrating the success of your rigorous pilgrimage with a quiet boat ride and a lavish dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> Departure</h3>
                <p>Enjoy a leisurely morning breakfast overlooking the lakes. Your chauffeur will provide a smooth, 1.5-hour drive down to the Kathgodam Railway Station or Pantnagar Airport, concluding your extraordinary and deeply spiritual Adi Kailash expedition.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Basic Guesthouses & KMVN Rest Houses</li>
                <li><i class="fa-solid fa-truck-monster"></i> Shared 4x4 Camper/Bolero for Vyas Valley</li>
                <li><i class="fa-solid fa-id-card"></i> Inner Line Permits & Police Clearance Included</li>
                <li><i class="fa-solid fa-utensils"></i> All Meals Included (Basic Vegetarian)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/adi-kailash-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- EXPEDITION INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Border Pilgrimage Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Adi Kailash is a highly restricted, extreme-altitude zone. Strict adherence to medical and governmental protocols is mandatory.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-id-card"></i></div>
                <h3>Inner Line Permits (ILP)</h3>
                <p>This region borders Tibet and Nepal and is heavily militarized:</p>
                <ul>
                    <li><strong>Mandatory Documents:</strong> A valid Passport or Aadhar Card, passport-sized photos, and a Police Verification Certificate (PCC) are required to process your permit in Dharchula.</li>
                    <li><strong>Foreign Nationals:</strong> Face extremely strict regulations and must apply for specialized Protected Area Permits well in advance.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase-medical"></i></div>
                <h3>Medical & Altitude</h3>
                <p>You will be sleeping at altitudes above 13,000 feet:</p>
                <ul>
                    <li><strong>Medical Certificate:</strong> A physical fitness certificate from a registered MBBS doctor is mandatory for the permit.</li>
                    <li><strong>AMS Risk:</strong> Acute Mountain Sickness is a severe risk. Premium tours carry emergency oxygen. Hydrate heavily and ascend slowly.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-truck-monster"></i></div>
                <h3>Extreme Terrain 4x4</h3>
                <p>The road beyond Dharchula is not meant for normal vehicles:</p>
                <ul>
                    <li><strong>Vehicle Swap:</strong> You must leave your comfortable SUV in Dharchula and switch to a heavy-duty, locally driven 4x4 Bolero or Camper.</li>
                    <li><strong>The Ride:</strong> Expect hours of extremely bumpy, dusty, and perilous driving alongside steep gorges.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bed"></i></div>
                <h3>Accommodation Reality</h3>
                <p>Luxury ends at Dharchula:</p>
                <ul>
                    <li><strong>Gunji & Jyolingkong:</strong> Do not expect hotel comforts. You will be staying in highly basic KMVN rest houses, homestays, or alpine tents.</li>
                    <li><strong>Amenities:</strong> Electricity is erratic (generator-based), and running hot water is unavailable. You will be provided buckets of hot water upon request.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-wifi"></i></div>
                <h3>Total Network Blackout</h3>
                <p>Prepare for a complete digital detox:</p>
                <ul>
                    <li><strong>No Signal:</strong> Beyond Dharchula, there is absolutely zero mobile network coverage. You will be cut off from the outside world for 4 to 5 days.</li>
                    <li><strong>Emergencies:</strong> Only the local military and ITBP base camps have satellite communication for extreme emergencies.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Weather & Survival Gear</h3>
                <p>The Vyas Valley is unforgivingly cold:</p>
                <ul>
                    <li><strong>Temperatures:</strong> Even in May or June, nighttime temperatures at Jyolingkong and Nabhidhang can drop well below freezing.</li>
                    <li><strong>Essentials:</strong> Heavy thermal innerwear, down jackets, windproof layers, high-SPF sunscreen, and UV-protection sunglasses are absolute necessities.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your life-changing Adi Kailash expedition.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Adi Kailash 12D/11N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>