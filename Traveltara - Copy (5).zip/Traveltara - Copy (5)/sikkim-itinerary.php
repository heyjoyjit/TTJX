<?php
// Top of sikkim-itinerary.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sikkim Tour Packages | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Sikkim Packages</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['sikkim hero']) ? $tourImages['sikkim hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="subpage-hero-content">
            <h1>Mystical Sikkim</h1>
            <p>From the freezing alpine deserts of Gurudongmar to the ancient, misty monasteries of Pelling.</p>
        </div>
    </header>

    <!-- MAIN GRID SECTION -->
    <section class="section-padding" style="background-color: #fcfcfc;">
        <div style="max-width: 1200px; margin: auto; text-align: center; margin-bottom: 50px; padding: 0 20px;">
            <h2 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; color: #0A1128; margin-bottom: 15px;">Available Sikkim Circuits</h2>
            <p style="color: #666; max-width: 800px; margin: 0 auto;">Whether you seek the extreme altitudes of North Sikkim, the heritage trails of the West, or the winding hairpins of the ancient Silk Route, our curated itineraries deliver the ultimate Himalayan adventure.</p>
        </div>

        <div class="grid-container" id="sikkimPackagesGrid">
            
            <!-- CARD 1: SILK ROUTE -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['sikkim silk route']) ? $tourImages['sikkim silk route'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">5 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Silk Route Expedition</h3>
                    <p><strong>East Sikkim:</strong> Drive through history. Navigate the legendary 95-hairpin bends of Zuluk, witness breathtaking sunrises from Thambi Viewpoint, and experience the stark beauty of Nathang Valley.</p>
                    <h4 class="package-price">Starts at ₹12,500</h4>
                    <a href="package-sikkim-silk-route.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 2: NORTH SIKKIM -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['north sikkim']) ? $tourImages['north sikkim'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">6 Days</div>
                </div>
                <div class="card-content">
                    <h3>North Sikkim Alpine Safari</h3>
                    <p><strong>Lachen & Lachung:</strong> An expedition to the extremes. Marvel at the frozen, sacred Gurudongmar Lake at 17,800 ft and wander through the rhododendron-filled Valley of Flowers in Yumthang.</p>
                    <h4 class="package-price">Starts at ₹18,000</h4>
                    <a href="package-sikkim-north.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 3: WEST SIKKIM -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['west sikkim']) ? $tourImages['west sikkim'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">5 Days</div>
                </div>
                <div class="card-content">
                    <h3>West Sikkim Heritage Trail</h3>
                    <p><strong>Pelling & Ravangla:</strong> A deeply spiritual journey. Stand before the towering Buddha Park in Ravangla, visit the ancient Pemayangtse Monastery, and gaze upon the majestic Mount Kanchenjunga from Pelling.</p>
                    <h4 class="package-price">Starts at ₹14,000</h4>
                    <a href="package-sikkim-west.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>
            
            <!-- CARD 4: COMPLETE SIKKIM -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['complete sikkim']) ? $tourImages['complete sikkim'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">10 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Complete Sikkim Grand Loop</h3>
                    <p><strong>The Ultimate Journey:</strong> Cover it all. From the bustling cafes of Gangtok to the icy deserts of the North and the spiritual sanctuaries of the West. A comprehensive, 10-day Himalayan odyssey.</p>
                    <h4 class="package-price">Starts at ₹32,000</h4>
                    <a href="package-sikkim-complete.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 5: CUSTOM -->
            <div class="destination-card" style="background: #0A1128; color: #fff;">
                <div class="card-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%; padding: 40px 20px;">
                    <i class="fa-solid fa-compass" style="font-size: 3rem; color: #C5A059; margin-bottom: 20px;"></i>
                    <h3 style="color: #fff;">Build Your Own</h3>
                    <p style="color: #ccc;">Want to combine a luxury stay in Gangtok with an offbeat drive into the Silk Route? Let us craft your bespoke Himalayan adventure.</p>
                    <button class="btn-primary" onclick="openLeadPopup()" style="margin-top: 20px; width: 100%;">Consult an Expert</button>
                </div>
            </div>

        </div>
    </section>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream Sikkim exploration.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Sikkim Packages" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>