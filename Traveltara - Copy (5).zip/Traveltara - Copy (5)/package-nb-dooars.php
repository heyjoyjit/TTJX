<?php
// Top of package-nb-dooars.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹15,000"; 
$sheet_affordable_price = "₹24,000";
$sheet_super_price = "₹38,000";

// EXACT package name from Google Sheet
$target_package = "Complete Dooars Safari 6D/5N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Jungle Resorts & Lodges</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Hatchback/Sedan for the Entire Route</li>
            <li><i class="fa-solid fa-paw"></i> 2 Core Zone Jeep Safaris (Gorumara & Jaldapara)</li>
            <li><i class="fa-solid fa-utensils"></i> All Meals Included (AP Plan) During Jungle Stays</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Forest Eco-Resorts with Pool</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta / Xylo</li>
            <li><i class="fa-solid fa-star"></i> Elephant Safari (Subject to Availability) & Sikiajhora Boat Ride</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners & Tribal Dance Evenings</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Equivalent Premium Safari Tents & Heritage Bungalows</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) for Maximum Comfort</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Safari Allocation, VIP Permits & Private Guide</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining, Riverside BBQs & Packed Safari Breakfasts</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Complete Dooars Safari 6 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="north-bengal-itinerary.php">North Bengal</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Complete Dooars Safari (6D/5N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Profile) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['dooars safari hero']) ? $tourImages['dooars safari hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 6 Days / 5 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Complete Dooars Safari</h1>
            <p>An untamed journey through elephant corridors, ancient jungle ruins, and the deep wildlife reserves of North Bengal.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Complete Dooars Safari 6D/5N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>The Dooars (derived from "doors" to Bhutan) is a vast, rolling carpet of tea gardens, crisscrossing rivers, and incredibly dense wildlife sanctuaries. This 6-day comprehensive circuit ensures you experience the raw thrill of tracking rhinos and elephants in Gorumara and Jaldapara, while intentionally weaving in hidden, offbeat gems like the narrow boat channels of Sikiajhora, the rocky streams of Suntalekhola, and the ancient, overgrown ruins of Nalrajar Garh.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & The Gorumara Gateway</h3>
                <p>Arrive at Bagdogra Airport (IXB) or NJP Railway Station. Your chauffeur will drive you into the lush Dooars region towards Lataguri/Gorumara (approx. 2 hours). After checking into your jungle resort, spend the late afternoon taking a peaceful walk along the pebble-strewn banks of the Murti River. Enjoy a quiet evening listening to the sounds of the surrounding forest.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Gorumara Safari & The Hidden Valleys</h3>
                <p>Wake up early for a thrilling Jeep Safari deep into Gorumara National Park, famous for its population of wild Asiatic elephants, Indian bison (Gaur), and the one-horned rhinoceros. After breakfast, head out for a breathtaking offbeat excursion to Samsing, Suntalekhola, and Rocky Island. These lesser-visited, pristine areas feature hanging bridges, orange orchards, and crystal-clear mountain streams cascading over massive boulders.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Leopard Rescue & Jaldapara</h3>
                <p>Check out and drive eastward toward Jaldapara (approx. 2.5 hours). En route, we make a special stop at the South Khayerbari Leopard and Tiger Rescue Center, an often-missed but incredibly impactful sanctuary dedicated to rehabilitating big cats rescued from circuses and poachers. Continue your drive through vast tea estates, arriving at your Jaldapara/Madarihat lodge in the afternoon.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Rhino Tracking & Ancient Jungle Ruins</h3>
                <p>Embrace the early morning mist with an Elephant Safari or open Jeep Safari into Jaldapara National Park, home to India’s second-largest population of the one-horned rhinoceros. After lunch, take an offbeat drive into the extraordinarily dense canopy of the Chilapata Forest. Here, hidden deep within the foliage, you will explore the overgrown, 5th-century ruins of Nalrajar Garh, the fort of the legendary Nala Kings.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Buxa Tiger Reserve & Jayanti Riverbed</h3>
                <p>Leave Jaldapara and travel further east to the Buxa Tiger Reserve (approx. 1.5 hours). Drive to the highly offbeat and stunningly beautiful Jayanti village, often called the "Queen of Dooars," situated right on the dry, white-pebble bed of the Jayanti River with the Bhutan hills towering in the background. Take a serene trek (or drive, depending on permissions) to the sacred Pokhri Lake, surrounded by dense forests and filled with giant, sacred catfish.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The "Amazon of Dooars" & Departure</h3>
                <p>Before beginning your journey home, we have saved one of the best offbeat experiences for last. Visit Sikiajhora, widely known as the "Amazon of Dooars." Here, you will take a small wooden boat ride through a narrow, incredibly dense, winding forest channel—a surreal and deeply peaceful experience. Following this, your chauffeur will transfer you to Alipurduar Railway Station (approx. 45 mins) or drive you back to Bagdogra/NJP for your departure.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Jungle Resorts & Lodges</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Hatchback/Sedan for the Entire Route</li>
                <li><i class="fa-solid fa-paw"></i> 2 Core Zone Jeep Safaris (Gorumara & Jaldapara)</li>
                <li><i class="fa-solid fa-utensils"></i> All Meals Included (AP Plan) During Jungle Stays</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/nb-dooars-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- DOOARS INSIGHTS HUB (6 GRID CARDS)                        -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Safari Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Wilderness Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your wildlife tracking experience in North Bengal is seamless and respectful of the forest.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Park Closures</h3>
                <p>Wildlife tourism is heavily regulated:</p>
                <ul>
                    <li><strong>Monsoon Shutdown:</strong> All national parks and wildlife sanctuaries in the Dooars (Gorumara, Jaldapara, Buxa, Chilapata) are <strong>strictly closed from June 15th to September 15th</strong> every year.</li>
                    <li><strong>Weekly Closures:</strong> Different zones have weekly closures (often Thursdays). We schedule your itinerary to avoid these.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-ticket"></i></div>
                <h3>Safari & Elephant Ride Permits</h3>
                <p>Securing the best wildlife experiences:</p>
                <ul>
                    <li><strong>Elephant Safaris:</strong> Highly limited and extremely sought-after in Jaldapara. They cannot be guaranteed purely online and often require standing in line at dawn. We try our best to secure them for luxury tiers.</li>
                    <li><strong>ID Required:</strong> Original government-issued photo IDs (Aadhar, Voter ID) are mandatory for all safari entries.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-shirt"></i></div>
                <h3>Jungle Etiquette & Clothing</h3>
                <p>Blend in with nature:</p>
                <ul>
                    <li><strong>Colors:</strong> Strictly wear muted, earth tones (khaki, olive, brown, dark green). Bright colors (red, white, neon) are not permitted inside the core zones.</li>
                    <li><strong>Silence:</strong> Maintain absolute silence in the jeep to hear the alarm calls of deer or monkeys, which signal a predator nearby.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bug"></i></div>
                <h3>Forest Realities & Packing</h3>
                <p>You are entering dense, tropical forests:</p>
                <ul>
                    <li><strong>Insects:</strong> A high-quality mosquito and insect repellent is an absolute necessity, especially during the evenings around the resorts.</li>
                    <li><strong>Dust:</strong> The open jeep safari tracks are incredibly dusty. Bring a bandana or scarf to cover your nose and mouth.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-camera"></i></div>
                <h3>Photography in the Dooars</h3>
                <p>Capturing the elusive wildlife:</p>
                <ul>
                    <li><strong>Lenses:</strong> While rhinos in Jaldapara can often be seen up close, elephants and leopards are shy. A good zoom lens (300mm+) is highly recommended.</li>
                    <li><strong>No Flash:</strong> The use of flash photography is strictly prohibited inside the forest reserves.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-route"></i></div>
                <h3>The Highway & Tea Gardens</h3>
                <p>The journey between the parks:</p>
                <ul>
                    <li><strong>The Drives:</strong> The transitions between Gorumara, Jaldapara, and Buxa are breathtaking, slicing right through endless, manicured tea estates and known elephant corridors. Keep your eyes on the road, as wild elephant crossings are common!</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized Dooars Safari.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Complete Dooars Safari 6D/5N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>