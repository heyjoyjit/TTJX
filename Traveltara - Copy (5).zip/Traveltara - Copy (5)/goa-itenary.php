<?php
// Top of goa-itenary.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹18,500"; 
$sheet_affordable_price = "₹34,000";
$sheet_super_price = "₹65,000";

// EXACT package name from Google Sheet
$target_package = "Complete Goa Tour 10D/9N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels in North & South Goa</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for Airport & Sightseeing</li>
            <li><i class="fa-solid fa-ship"></i> <strong>Includes 1-Hour Mandovi River Cruise</strong></li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Beach Resorts & Heritage Properties</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-water"></i> <strong>Includes Dolphin Safari & Premium Dinner Cruise</strong></li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Ultra-Luxury Beachfront Resorts (e.g., Taj, Leela)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-anchor"></i> <strong>Exclusive Private Yacht / Luxury Cruise Experience</strong></li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining, Seafood Specials & Beach Cabana Setup</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Complete Goa Tour 10 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Complete Goa Tour (10D/9N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['goa hero']) ? $tourImages['goa hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 10 Days / 9 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Complete Goa Experience</h1>
            <p>A sweeping 10-day coastal odyssey blending vibrant beaches, deep heritage, roaring waterfalls, and tailored luxury cruises.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Complete Goa Tour 10D/9N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Experience the ultimate deep-dive into India's sunshine state. Over 10 glorious days, you will transition from the high-energy beaches and historic forts of North Goa to the lush, spice-scented jungles of the Western Ghats, before finally unwinding on the pristine, silent shores of Deep South Goa. This itinerary is perfectly paced to include thrilling marine life encounters and unforgettable sunset cruise experiences tailored exactly to your chosen level of luxury.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & Acclimatization in North Goa</h3>
                <p>Welcome to Goa! Arrive at Dabolim Airport (GOI) or Mopa Airport (GOX). Your luxury chauffeur will transfer you to your hotel in North Goa. Spend the afternoon shaking off your travel fatigue by the pool or taking a leisurely sunset walk along the bustling shores of Baga or Calangute beach.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Fortresses & Beaches of the North</h3>
                <p>After breakfast, begin your North Goa exploration. Visit the imposing 17th-century Fort Aguada and its historic lighthouse overlooking the vast Arabian Sea. Continue to the picturesque, rocky coves of Vagator Beach and the legendary shores of Anjuna. Spend your evening exploring the vibrant night markets and beachfront shacks of the north.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> UNESCO Heritage & The Great Cruise Experience</h3>
                <p>Drive to Old Goa, the former capital of Portuguese India. Marvel at the spectacular Basilica of Bom Jesus and the towering Se Cathedral. Walk through the Latin Quarter of Fontainhas in Panjim, admiring the colorful colonial houses. As evening approaches, head to the Mandovi River for your <strong>Signature Cruise Experience</strong> (Standard River Cruise, Premium Dinner Cruise, or Private Yacht, as per your selected tier) to watch the sunset over the Arabian Sea.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Marine Life & Water Sports</h3>
                <p>Get ready for a thrilling marine adventure. Head out into the Arabian Sea for your <strong>Dolphin Safari</strong> (included in Affordable & Super Luxury tiers) to spot these magnificent creatures playing in the surf. Spend the afternoon indulging in exhilarating water sports at Sinquerim or Candolim beach, including parasailing, jet-skiing, or banana boat rides.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Into the Jungle: Dudhsagar Falls & Spice Plantations</h3>
                <p>Take a full-day excursion away from the coast and deep into the Bhagwan Mahavir Wildlife Sanctuary. Embark on a thrilling jeep ride through the jungle streams to reach the majestic Dudhsagar Waterfalls, one of India's tallest falls cascading down the Western Ghats. On the way back, visit a lush Goan Spice Plantation, enjoy a traditional Goan lunch served on banana leaves, and learn about the region's famous exotic spices.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> North to South: The Coastal Transition</h3>
                <p>Check out from your North Goa hotel and enjoy a scenic drive down the coast to the serene, palm-fringed shores of South Goa. Check into your new, tranquil resort. The contrast is immediate—enjoy the quiet, pristine sands of Colva or Benaulim Beach. Spend the evening relaxing with the sound of gentle waves.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> The Serenity of the Deep South</h3>
                <p>Dedicate today to South Goa's most beautiful beaches. Visit the crescent-shaped paradise of Palolem Beach, surrounded by dense coconut groves. Take a short boat ride to Butterfly Beach or Honeymoon Beach for absolute privacy. In the evening, enjoy a lavish, quiet seafood dinner by the sea.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Cabo de Rama & The Turtle Beach</h3>
                <p>Drive to the ancient Cabo de Rama Fort, steeped in the legends of the Ramayana and offering plunging, dramatic views of the Arabian Sea from its cliffs. Later, drive further south to Galgibaga Beach, famous as a protected nesting site for Olive Ridley turtles. Enjoy the untouched, pristine ecology of this extreme southern tip of Goa.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Leisure, Spa & Authentic Culinary Day</h3>
                <p>Your final full day in Goa is reserved entirely for relaxation. Unwind at your luxury resort, indulge in an Ayurvedic massage or spa treatment, and soak up the sun. For your final dinner, treat yourself to an authentic Goan culinary experience, savoring dishes like Goan Fish Curry, Prawn Balchao, or a rich Bebinca dessert.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Departure with Sun-Kissed Memories</h3>
                <p>Enjoy your final, unhurried coastal breakfast. Take one last walk along the beach before your chauffeur provides a seamless, comfortable transfer to Dabolim Airport (GOI), Mopa Airport (GOX), or the railway station, concluding your magnificent 10-day Goan odyssey.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels in North & South Goa</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for Airport & Sightseeing</li>
                <li><i class="fa-solid fa-ship"></i> <strong>Includes 1-Hour Mandovi River Cruise</strong></li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/goa-10day-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- GOA INSIGHTS HUB (6 GRID CARDS)                           -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Coastal Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your 10-day Goan holiday is safe, relaxing, and perfectly executed.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-anchor"></i></div>
                <h3>The Cruise Experiences</h3>
                <p>Your aquatic experience depends directly on your chosen tier:</p>
                <ul>
                    <li><strong>Budget:</strong> A fun, 1-hour shared evening cruise on the Mandovi River featuring DJ music and Goan folk dances.</li>
                    <li><strong>Affordable Luxury:</strong> A premium Dinner Cruise on the river, plus an exhilarating morning Dolphin Safari.</li>
                    <li><strong>Super Luxury:</strong> An exclusive, private yacht or luxury catamaran chartered solely for your group.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-water"></i></div>
                <h3>Dudhsagar Excursion Realities</h3>
                <p>Reaching the waterfalls is an adventure:</p>
                <ul>
                    <li><strong>The Journey:</strong> Your comfortable sedan/SUV will drop you at Kulem. From there, you <strong>must</strong> transfer to a shared, rugged forest jeep (arranged by us) to cross rivers and muddy tracks to reach the falls.</li>
                    <li><strong>Timing:</strong> The falls are closed during the heavy monsoon (June - September) for safety.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-umbrella-beach"></i></div>
                <h3>North vs. South Dynamics</h3>
                <p>Enjoying the best of both worlds:</p>
                <ul>
                    <li><strong>North Goa (Days 1-5):</strong> Embrace the crowds, the vibrant shack culture, the water sports, and the intense nightlife.</li>
                    <li><strong>South Goa (Days 6-10):</strong> Prepare for absolute quiet. South Goa shuts down early; it is designed for luxury resorts, reading by the beach, and ultimate relaxation.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-motorcycle"></i></div>
                <h3>Local Transport & Scooters</h3>
                <p>Exploring the village lanes:</p>
                <ul>
                    <li>While your chauffeur manages major transitions and sightseeing, renting a scooter locally is highly recommended for short hops between beaches.</li>
                    <li><strong>Safety Law:</strong> Helmets are strictly mandatory for both the rider and the pillion passenger. Traffic police heavily fine violators.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-sun"></i></div>
                <h3>Beach Safety & Sun Protection</h3>
                <p>Respecting the powerful Arabian Sea:</p>
                <ul>
                    <li><strong>Lifeguards:</strong> Always swim in zones monitored by Drishti lifeguards (look for the red and yellow flags). Do not enter the water if red flags are hoisted.</li>
                    <li><strong>Essentials:</strong> Reapply high-SPF sunscreen constantly, wear sunglasses, and stay highly hydrated.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>The Goan Culinary Trail</h3>
                <p>A fusion of Portuguese and Konkani flavors:</p>
                <ul>
                    <li><strong>Must Try:</strong> Authentic Goan Fish Curry, Prawn Balchao, Chicken Xacuti, and the legendary Bebinca dessert.</li>
                    <li><strong>Vegetarians:</strong> Goa features an incredible array of vegetarian cafes, vegan hubs, and traditional Saraswat Brahmin vegetarian thalis.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Goa, Gujarat, Madhya Pradesh, Uttarakhand, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your ultimate 10-Day Goan escape.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Complete Goa Tour 10D/9N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>