<?php
ob_start(); 
error_reporting(0);
ini_set('display_errors', 0);

$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    ob_clean(); header("Content-Type: application/json"); echo json_encode(["error" => "DB Error"]); exit;
}
$conn->set_charset("utf8mb4");

$range = $_GET['range'] ?? '30days';
$whereBookings = "WHERE `Timestamp` >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
$whereExpenses = "WHERE `exp_date` >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
$whereLeads = "WHERE `Timestamp` >= DATE_SUB(NOW(), INTERVAL 30 DAY)";

if($range == 'mtd') {
    $whereBookings = "WHERE `Timestamp` >= DATE_FORMAT(NOW() ,'%Y-%m-01')";
    $whereExpenses = "WHERE `exp_date` >= DATE_FORMAT(NOW() ,'%Y-%m-01')";
    $whereLeads = "WHERE `Timestamp` >= DATE_FORMAT(NOW() ,'%Y-%m-01')";
} elseif($range == 'last_month') {
    $whereBookings = "WHERE `Timestamp` >= DATE_FORMAT(CURRENT_DATE - INTERVAL 1 MONTH, '%Y-%m-01') AND `Timestamp` < DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')";
    $whereExpenses = "WHERE `exp_date` >= DATE_FORMAT(CURRENT_DATE - INTERVAL 1 MONTH, '%Y-%m-01') AND `exp_date` < DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')";
    $whereLeads = "WHERE `Timestamp` >= DATE_FORMAT(CURRENT_DATE - INTERVAL 1 MONTH, '%Y-%m-01') AND `Timestamp` < DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')";
} elseif($range == 'last_year') {
    $whereBookings = "WHERE `Timestamp` >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
    $whereExpenses = "WHERE `exp_date` >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
    $whereLeads = "WHERE `Timestamp` >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
} elseif($range == 'prev_fy') {
    $whereBookings = "WHERE `Timestamp` >= CONCAT(YEAR(NOW())-2, '-04-01') AND `Timestamp` < CONCAT(YEAR(NOW())-1, '-04-01')";
    $whereExpenses = "WHERE `exp_date` >= CONCAT(YEAR(NOW())-2, '-04-01') AND `exp_date` < CONCAT(YEAR(NOW())-1, '-04-01')";
    $whereLeads = "WHERE `Timestamp` >= CONCAT(YEAR(NOW())-2, '-04-01') AND `Timestamp` < CONCAT(YEAR(NOW())-1, '-04-01')";
}

// 1. Gross Revenue
$sqlTotal = "SELECT SUM(CAST(REPLACE(REPLACE(`Total Paid`, '₹', ''), ',', '') AS DECIMAL(10,2))) as gross FROM bookings $whereBookings AND `Status` = 'Payment Complete'";
$resTotal = $conn->query($sqlTotal);
$gross = $resTotal ? ($resTotal->fetch_assoc()['gross'] ?? 0) : 0;

// 2. Real Expenses 
$real_expenses = 0;
$checkTable = $conn->query("SHOW TABLES LIKE 'expenses'");
if($checkTable && $checkTable->num_rows > 0) {
    $sqlExp = "SELECT SUM(amount) as exp FROM expenses $whereExpenses";
    $resExp = $conn->query($sqlExp);
    $real_expenses = $resExp ? ($resExp->fetch_assoc()['exp'] ?? 0) : 0;
}

// 3. Leads
$sqlLeads = "SELECT COUNT(DISTINCT `Phone Number`) as leads FROM interactions $whereLeads";
$resLeads = $conn->query($sqlLeads);
$leads = $resLeads ? ($resLeads->fetch_assoc()['leads'] ?? 0) : 0;

// 4. Timeline
$sqlTime = "SELECT DATE(`Timestamp`) as Date, SUM(CAST(REPLACE(REPLACE(`Total Paid`, '₹', ''), ',', '') AS DECIMAL(10,2))) as DailyTotal FROM bookings $whereBookings AND `Status` = 'Payment Complete' GROUP BY DATE(`Timestamp`) ORDER BY DATE(`Timestamp`) ASC";
$resTime = $conn->query($sqlTime);
$timeline = [];
if($resTime) { while($row = $resTime->fetch_assoc()){ $timeline[] = $row; } }

// 5. Destinations
$sqlDest = "SELECT Destination, COUNT(*) as Count, SUM(CAST(REPLACE(REPLACE(`Total Paid`, '₹', ''), ',', '') AS DECIMAL(10,2))) as DestTotal FROM bookings $whereBookings AND `Status` = 'Payment Complete' GROUP BY Destination ORDER BY DestTotal DESC";
$resDest = $conn->query($sqlDest);
$destinations = [];
if($resDest) { while($row = $resDest->fetch_assoc()){ $destinations[] = $row; } }

// 6. Locations
$sqlLoc = "SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(`Residential Address`, ',', -2), ',', 1) as State, COUNT(*) as Count FROM bookings $whereBookings AND `Status` = 'Payment Complete' GROUP BY State ORDER BY Count DESC LIMIT 6";
$resLoc = $conn->query($sqlLoc);
$locations = [];
if($resLoc) { while($row = $resLoc->fetch_assoc()){ if(trim($row['State']) != "") $locations[] = $row; } }

// 7. Tiers
$sqlTier = "SELECT `Tour Tier` as Tier, COUNT(*) as Count FROM bookings $whereBookings AND `Status` = 'Payment Complete' GROUP BY `Tour Tier`";
$resTier = $conn->query($sqlTier);
$tiers = [];
if($resTier) { while($row = $resTier->fetch_assoc()){ if(trim($row['Tier']) != "") $tiers[] = $row; } }

// 8. Types
$sqlType = "SELECT `Tour Type (Dom/Int)` as Type, COUNT(*) as Count FROM bookings $whereBookings AND `Status` = 'Payment Complete' GROUP BY `Tour Type (Dom/Int)`";
$resType = $conn->query($sqlType);
$types = [];
if($resType) { while($row = $resType->fetch_assoc()){ if(trim($row['Type']) != "") $types[] = $row; } }

// 9. Pax
$sqlPax = "SELECT SUM(`Adults`) as adults, SUM(`Children`) as children FROM bookings $whereBookings AND `Status` = 'Payment Complete'";
$resPax = $conn->query($sqlPax);
$total_adults = 0; $total_children = 0;
if($resPax) {
    $paxData = $resPax->fetch_assoc();
    $total_adults = (int)($paxData['adults'] ?? 0);
    $total_children = (int)($paxData['children'] ?? 0);
}

// 10. RAW DATA FOR CUSTOM RELATIONAL EXPLORER
$sqlRaw = "SELECT `Destination`, `Tour Tier` as Tier, `Tour Type (Dom/Int)` as Type, 
           TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(`Residential Address`, ',', -2), ',', 1)) as State, 
           CAST(REPLACE(REPLACE(`Total Paid`, '₹', ''), ',', '') AS DECIMAL(10,2)) as Revenue, 
           (`Adults` + `Children`) as Pax 
           FROM bookings $whereBookings AND `Status` = 'Payment Complete'";
$resRaw = $conn->query($sqlRaw);
$raw_bookings = [];
if($resRaw) { while($row = $resRaw->fetch_assoc()){ $raw_bookings[] = $row; } }

$output = [
    "status" => "success",
    "gross_revenue" => (float)$gross,
    "real_expenses" => (float)$real_expenses,
    "total_leads" => (int)$leads,
    "total_pax" => $total_adults + $total_children,
    "adults" => $total_adults,
    "children" => $total_children,
    "timeline" => $timeline,
    "destinations" => $destinations,
    "locations" => $locations,
    "tiers" => $tiers,
    "types" => $types,
    "raw_bookings" => $raw_bookings
];

ob_clean(); // Wipe any hidden warnings
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
echo json_encode($output, JSON_INVALID_UTF8_IGNORE); // 🚀 FORCES JSON TO PRINT REGARDLESS OF BAD CHARACTERS
ob_end_flush();
$conn->close();
?>