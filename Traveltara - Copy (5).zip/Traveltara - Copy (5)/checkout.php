<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Checkout | Traveltara</title>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="css/booking.css">
    <link rel="stylesheet" href="css/checkout.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
</head>
<body>

    <header class="compact-hero">
        <h1 class="brand-logo">traveltara</h1>
        <div class="hero-subtitle">Secure Checkout & Final Configuration</div>
    </header>

    <main class="booking-container">
        
        <div style="text-align: right; font-weight: bold; color: #555; margin-bottom: 20px; font-size: 15px;">
            Booking Ref: <span id="checkoutBookingId" style="color: var(--navy);">Generating...</span>
        </div>

        <form id="checkoutForm">
            
            <div class="checkout-form-section">
                <h2 class="checkout-section-title">I. Selected Itinerary</h2>
                <div class="form-grid" style="grid-template-columns: 1fr;">
                    <div class="input-group">
                        <label>Package Name</label>
                        <input type="text" id="chkPackage" readonly class="locked-input">
                    </div>
                    <div class="input-group">
                        <label>Tier / Class</label>
                        <input type="text" id="chkTier" readonly class="locked-input">
                    </div>
                </div>
            </div>

            <div class="checkout-form-section">
                <h2 class="checkout-section-title">II. Party Configuration</h2>
                <div class="party-grid">
                    <div class="input-group">
                        <label>Adults</label>
                        <div class="counter-wrap">
                            <button type="button" class="counter-btn" onclick="updateCount('adults', -1)">-</button>
                            <input type="number" id="adults" class="counter-input" value="2" min="1" onchange="calculatePricing()">
                            <button type="button" class="counter-btn" onclick="updateCount('adults', 1)">+</button>
                        </div>
                    </div>
                    <div class="input-group">
                        <label>Children <span style="font-size: 0.75rem; color: #888;">(< 12 yrs)</span></label>
                        <div class="counter-wrap">
                            <button type="button" class="counter-btn" onclick="updateCount('child', -1)">-</button>
                            <input type="number" id="child" class="counter-input" value="0" min="0" onchange="calculatePricing()">
                            <button type="button" class="counter-btn" onclick="updateCount('child', 1)">+</button>
                        </div>
                    </div>
                    <div class="input-group">
                        <label>Rooms Required</label>
                        <div class="counter-wrap">
                            <button type="button" class="counter-btn" onclick="updateCount('rooms', -1)">-</button>
                            <input type="number" id="rooms" class="counter-input" value="1" min="1" onchange="calculatePricing()">
                            <button type="button" class="counter-btn" onclick="updateCount('rooms', 1)">+</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="discount-container">
                <label>Have a Discount Code?</label>
                <div class="discount-input-row">
                    <input type="text" id="couponInput" placeholder="Enter Code">
                    <button id="applyCouponBtn" type="button">APPLY</button>
                </div>
                <p id="couponMsg"></p>
            </div>

            <div class="checkout-form-section hidden-section" id="pricingSection">
                <h2 class="checkout-section-title">III. Final Pricing Summary</h2>
                <div class="price-box">
                    <div class="price-label">Total Payable Amount</div>
                    <div class="price-value" id="displayTotalCost">₹ 0</div>
                </div>
            </div>

            <div class="tnc-container">
                <input type="checkbox" id="tncCheck" required>
                <label for="tncCheck">I have read and agree to the <span id="openTncText">Terms & Policies</span>.</label>
            </div>
            
            <button type="submit" class="submit-btn" id="proceedPaymentBtn" style="font-size: 1.1rem; padding: 18px; max-width: none;">Confirm & Proceed to Payment</button>

        </form>
    </main>

    <div id="tncModal" class="modal-overlay">
        <div class="modal-content">
            <span class="modal-close" id="closeModalBtn">&times;</span>
            <h2 style="margin-top:0; font-size:24px; color:var(--navy); font-family: var(--serif); border-bottom: 2px solid var(--gold); padding-bottom: 10px;">Legal Agreements</h2>
            
            <div class="modal-scroll-area" id="tncScrollArea">
                <h3>1. Terms and Conditions</h3>
                <p>Welcome to Traveltara. By accessing our platform and booking our services, you agree to be bound by these terms. All itineraries are subject to availability and may change due to unforeseen circumstances. Traveltara acts as an agent for third-party suppliers (hotels, transport, etc.) and is not liable for their defaults.</p>
                <p>Guests must carry valid identification and, where required, passports with sufficient validity. Travel insurance is highly recommended.</p>
                
                <h3>2. Refund Policy</h3>
                <p>Refunds are processed to the original payment method within 7-14 business days. The refundable amount depends entirely on the proximity to the commencement date as outlined in our cancellation policy below. Non-refundable deposits or fees levied by third-party suppliers will be deducted from any eligible refund.</p>

                <h3>3. Privacy Policy</h3>
                <p>Traveltara respects your privacy. We collect personal data strictly for the purpose of securing your reservations and ensuring legal compliance. Your payment data is securely processed via Razorpay.</p>

                <h3>4. Cancellation Policy</h3>
                <p>Cancellations must be requested in writing. The following general schedule applies:</p>
                <ul style="margin-bottom:0;">
                    <li>30+ days prior to departure: 90% Refund</li>
                    <li>15-29 days prior to departure: 50% Refund</li>
                    <li>7-14 days prior to departure: 25% Refund</li>
                    <li>Less than 7 days prior: No Refund</li>
                </ul>
                <br><br><br>
            </div>

            <button type="button" id="agreeBtn" class="agree-btn" disabled>Scroll down to Agree</button>
        </div>
    </div>
    
    <!-- HIDDEN INVOICE TEMPLATE WITH EXACT A4 DIMENSIONS -->
    <div id="invoicePrintContainer" style="display: none;">
        <div id="traveltaraInvoice" style="width: 800px; padding: 40px; background: #ffffff; font-family: 'Lato', Arial, sans-serif; color: #333; box-sizing: border-box; margin: 0; position: relative;">
            
            <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
                <tr>
                    <td style="padding-bottom: 20px; border-bottom: 3px solid #C5A059;" colspan="2">
                        <table style="width: 100%;">
                            <tr>
                                <td style="width: 50%; vertical-align: top;">
                                    <h1 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 32px; margin: 0 0 5px 0; font-weight: 700;">traveltara</h1>
                                    <p style="color: #C5A059; font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; margin: 0;">Bespoke Luxury Journeys</p>
                                </td>
                                <td style="width: 50%; vertical-align: top; text-align: right; font-size: 13px; line-height: 1.4; color: #555;">
                                    <h3 style="color: #0A1128; font-size: 22px; margin: 0 0 8px 0; font-weight: 900; letter-spacing: 1px;">TAX INVOICE</h3>
                                    <p style="margin: 2px 0;"><strong>Traveltara Pvt. Ltd.</strong></p>
                                    <p style="margin: 2px 0;">123 Luxury Avenue, Sector 5, Kolkata, WB 700091</p>
                                    <p style="margin: 2px 0;">Phone: +91 74398 77604 | Email: booking@traveltara.com</p>
                                    <p style="margin: 2px 0;"><strong>GSTIN:</strong> 19AAAAA0000A1Z5 | <strong>PAN:</strong> AAAAA0000A</p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <tr><td colspan="2" style="height: 20px;"></td></tr>

                <tr>
                    <td colspan="2" style="background: #fdfbf7; border: 1px solid #eaeaea; border-radius: 4px; padding: 15px;">
                        <table style="width: 100%;">
                            <tr>
                                <td style="width: 50%; font-size: 13px; color: #444; line-height: 1.6;">
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Invoice No:</strong> <span id="invRealNo">INV-XXXXX</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Booking Ref No:</strong> <span id="invNo">TRV-XXXXX</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Invoice Date:</strong> <span id="invDate">DD-MMM-YYYY</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Transaction ID:</strong> <span id="invPaymentId" style="color: #27ae60; font-family: monospace;">pay_XXXXXX</span></p>
                                </td>
                                <td style="width: 50%; font-size: 13px; color: #444; text-align: right; line-height: 1.6;">
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Due Date:</strong> <span id="invDueDate">DD-MMM-YYYY</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Place of Supply:</strong> <span id="invSupplyPlace">West Bengal (19)</span></p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <tr><td colspan="2" style="height: 20px;"></td></tr>

                <tr>
                    <td style="width: 50%; padding-right: 15px; vertical-align: top;">
                        <div style="font-size: 12px; font-weight: 900; color: #C5A059; border-bottom: 1px solid #C5A059; padding-bottom: 5px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px;">BILL TO</div>
                        <p style="margin: 4px 0; font-size: 14px; color: #0A1128; font-weight: bold;" id="invGuestName">Guest Name</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;" id="invGuestPhone">+91 XXXXXXXXXX</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;" id="invGuestEmail">guest@email.com</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444; word-wrap: break-word;" id="invGuestAddress">Address Not Provided</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;">State: <strong id="invGuestState">West Bengal</strong></p>
                    </td>
                    <td style="width: 50%; padding-left: 15px; vertical-align: top;">
                        <div style="font-size: 12px; font-weight: 900; color: #C5A059; border-bottom: 1px solid #C5A059; padding-bottom: 5px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px;">TRAVEL DETAILS</div>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Destination:</strong> <span id="invPackage">Package Name</span></p>
                        
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Travel Date:</strong> <span id="invTravelDate">TBD</span></p>
                        
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Tier:</strong> <span id="invTier">Super Luxury</span></p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Travelers:</strong> <span id="invPax">2 Adults, 0 Children</span></p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Rooms:</strong> <span id="invRooms">1 Room(s)</span></p>
                    </td>
                </tr>

                <tr><td colspan="2" style="height: 20px;"></td></tr>

                <tr>
                    <td colspan="2">
                        <table style="width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid #0A1128; table-layout: fixed;">
                            <thead>
                                <tr>
                                    <th style="background: #0A1128; color: #ffffff; text-align: left; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 28%;">Description</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: center; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 9%;">HSN/SAC</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: center; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 6%;">Qty</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 11%;">Unit Price</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 12%;">Taxable</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 8%;">CGST</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 8%;">SGST</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 8%;">IGST</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 10%;">Total (₹)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; word-wrap: break-word;" id="invRowDesc">Premium Tour Package</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: center;">9985</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: center;">1</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: right;" id="invRowUnit">0.00</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: right;" id="invRowTaxable">0.00</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: right;" id="invRowCgst">0.00</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: right;" id="invRowSgst">0.00</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: right;" id="invRowIgst">0.00</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: right; font-weight: bold;" id="invRowTotal">0.00</td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>

                <tr><td colspan="2" style="height: 20px;"></td></tr>

                <tr>
                    <td style="width: 55%; padding-right: 15px; vertical-align: top;">
                        <div style="background: #f9f9f9; padding: 15px; border-radius: 4px; border-left: 3px solid #C5A059;">
                            <p style="margin: 0 0 5px 0; font-size: 13px;"><strong>Total Amount in Words:</strong></p>
                            <p id="invWordsText" style="font-style: italic; color: #0A1128; margin: 0; font-size: 13px;">Rupees Zero Only</p>
                        </div>
                    </td>
                    <td style="width: 45%; vertical-align: bottom;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total Taxable Value:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumTaxable">₹ 0.00</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total CGST:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumCgst">₹ 0.00</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total SGST:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumSgst">₹ 0.00</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total IGST:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumIgst">₹ 0.00</td>
                            </tr>
                            <tr>
                                <td style="padding: 10px 0 0 0; font-size: 18px; color: #0A1128; font-weight: 900; border-top: 2px solid #0A1128;">Grand Total:</td>
                                <td style="padding: 10px 0 0 0; font-size: 18px; color: #0A1128; font-weight: 900; text-align: right; border-top: 2px solid #0A1128;" id="invSumGrand">₹ 0.00</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>

            <table style="width: 714px; position: absolute; bottom: 40px; left: 40px; border-top: 1px solid #ddd; padding-top: 20px;">
                <tr>
                    <td style="width: 65%; vertical-align: top;">
                        <h4 style="font-size: 13px; color: #0A1128; margin: 0 0 8px 0; text-transform: uppercase;">Bank & Payment Details</h4>
                        <p style="margin: 2px 0; font-size: 11px; color: #666;"><strong>Bank:</strong> HDFC Bank Ltd. &nbsp;|&nbsp; <strong>A/C Name:</strong> Traveltara Pvt Ltd</p>
                        <p style="margin: 2px 0; font-size: 11px; color: #666;"><strong>A/C No:</strong> 50200012345678 &nbsp;|&nbsp; <strong>IFSC:</strong> HDFC0001234</p>
                        <p style="margin: 2px 0; font-size: 11px; color: #666;"><strong>UPI ID:</strong> traveltara@hdfcbank</p>
                        
                        <h4 style="font-size: 13px; color: #0A1128; margin: 15px 0 8px 0; text-transform: uppercase;">Terms & Conditions</h4>
                        <p style="margin: 2px 0; font-size: 11px; color: #666;">1. 100% payment required prior to trip commencement.</p>
                        <p style="margin: 2px 0; font-size: 11px; color: #666;">2. Cancellations made within 7 days of travel are non-refundable.</p>
                    </td>
                    <td style="width: 35%; vertical-align: bottom; text-align: right;">
                        <div style="border: 2px dashed #C5A059; padding: 15px; border-radius: 4px; background: #fdfbf7; display: inline-block; text-align: center;">
                            <p style="font-weight: 900; color: #0A1128; font-size: 12px; margin: 0; text-transform: uppercase; letter-spacing: 1px;">Automated Invoice</p>
                            <p style="color: #666; font-size: 10px; margin: 5px 0 0 0; line-height: 1.4;">Computer-generated document.<br>No physical signature required.</p>
                        </div>
                    </td>
                </tr>
            </table>

        </div>
    </div>
    <!-- 🚀 ADDED CACHE BUSTER HERE -->
    <script src="js/checkout.js?v=19"></script>

</body>
</html>