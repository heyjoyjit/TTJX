<?php
// Top of package-dubai-6d.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹45,000"; 
$sheet_affordable_price = "₹75,000";
$sheet_super_price = "₹1,20,000";

// EXACT package name from Google Sheet
$target_package = "The Golden Sands & Skyline Expedition 6D/5N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 3-Star Hotels in Bur Dubai / Deira (Close to Metro)</li>
            <li><i class="fa-solid fa-car"></i> Shared AC Coach Transfers for Airport & Sightseeing</li>
            <li><i class="fa-solid fa-ticket"></i> Standard Tickets to Burj Khalifa (124th) & Desert Safari</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast + BBQ Dinner at Desert Camp</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 4-Star Luxury Hotels in Downtown Dubai or Business Bay</li>
            <li><i class="fa-solid fa-car"></i> Private AC Sedan Transfers for Maximum Comfort</li>
            <li><i class="fa-solid fa-ticket"></i> Skip-the-line Tickets & Premium Dhow Cruise Marina</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast + 2 Specialty Buffet Dinners Included</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Ultra-Luxury (e.g., Atlantis The Palm or Address Downtown)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Land Cruiser) or Chauffeur Limousine</li>
            <li><i class="fa-solid fa-crown"></i> VIP Desert Safari & Burj Khalifa At The Top SKY (148th Floor)</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining Experiences & Private Marina Yacht Charter</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Golden Sands & Skyline Expedition 6 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="dubai-itinerary.php">International Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Dubai Skyline Expedition (6D/5N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['dubai hero']) ? $tourImages['dubai hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 6 Days / 5 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Golden Sands & Skyline Expedition</h1>
            <p>From the towering heights of the Burj Khalifa to the endless Arabian desert. Experience the ultimate fusion of heritage, ultra-luxury, and architectural marvels.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Golden Sands & Skyline Expedition 6D/5N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Welcome to the "City of Gold." This 6-day comprehensive expedition is expertly paced to showcase every facet of Dubai. You will sail through the glittering Marina on a traditional wooden dhow, bargain for spices in the ancient souks of Deira, witness the world from the 124th floor of the Burj Khalifa, and embark on an adrenaline-pumping 4x4 safari into the deep Arabian dunes. We have balanced the high-energy sightseeing with ample leisure time for world-class shopping and relaxation.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Dubai & Marina Dhow Cruise</h3>
                <p>Arrive at Dubai International Airport (DXB). After passing through world-class immigration, our representative will receive you and transfer you to your hotel. Spend the afternoon relaxing. In the evening, head to the glamorous Dubai Marina. Board a beautifully illuminated traditional wooden Dhow for a 2-hour cruise. Glide past the stunning skyscrapers of the Marina while enjoying an international buffet dinner and live entertainment under the stars.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Heritage of Old Dubai & The Dubai Frame</h3>
                <p>After breakfast, step back in time. Begin your half-day city tour in the Al Fahidi Historical District. Cross the historic Dubai Creek on a traditional wooden Abra (water taxi) for just one Dirham. Disembark in Deira to explore the vibrant, aromatic Spice Souk and the glittering alleys of the world-famous Gold Souk. In the afternoon, visit the colossal Dubai Frame in Zabeel Park, offering a stunning 360-degree view that perfectly divides "Old Dubai" from "New Dubai."</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Icons: Burj Khalifa, Dubai Mall & Fountains</h3>
                <p>Today is dedicated to world records. Head to the Dubai Mall, one of the largest shopping and entertainment destinations on the planet. Discover the massive Dubai Aquarium (from the outside) and the indoor ice rink. Later, take the high-speed elevator to the 124th and 125th floors of the Burj Khalifa, the tallest building in the world, for breathtaking panoramic views. Conclude your evening by watching the spectacular, synchronized Dubai Fountain Show at the base of the tower.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> A Morning of Leisure & The Arabian Desert Safari</h3>
                <p>Enjoy a relaxed morning. You can spend this time lounging by the hotel pool, exploring local cafes, or doing some independent shopping. Around 3:00 PM, your rugged 4x4 Land Cruiser will pick you up for the ultimate Desert Safari. Experience the adrenaline rush of dune bashing across the red sands. Arrive at a traditional Bedouin-style camp to enjoy camel riding, henna painting, a stunning desert sunset, and a mesmerizing belly dance and fire show, paired with a lavish BBQ dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Palm Jumeirah & The Museum of the Future</h3>
                <p>After breakfast, drive onto the spectacular Palm Jumeirah, the world-famous man-made island. Visit "The View at the Palm" for a stunning vantage point of the island's unique shape and the Arabian Gulf. Drive past the iconic Atlantis hotel. In the afternoon, visit the architectural masterpiece, the Museum of the Future (subject to ticket availability), exploring groundbreaking exhibits on space travel, climate change, and advanced technology. Spend your final night experiencing Dubai's incredible culinary scene.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Departure from Dubai</h3>
                <p>Enjoy your final lavish breakfast in the UAE. Depending on your flight schedule, you may have time for some last-minute duty-free shopping. Check out of your hotel, and your chauffeur will transfer you back to Dubai International Airport (DXB) for your onward journey, leaving you with memories of an unforgettable Arabian adventure.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Premium 3-Star Hotels in Bur Dubai / Deira</li>
                <li><i class="fa-solid fa-car"></i> Shared AC Coach Transfers for Airport & Sightseeing</li>
                <li><i class="fa-solid fa-ticket"></i> Standard Tickets to Burj Khalifa (124th) & Desert Safari</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast + BBQ Dinner at Desert Camp</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/dubai-6d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- DUBAI INSIGHTS HUB (6 GRID CARDS)                         -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Dubai Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for your international Arabian adventure.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-passport"></i></div>
                <h3>Visa & Passport Rules</h3>
                <p>Entry requirements:</p>
                <ul>
                    <li><strong>Processing:</strong> Indian passport holders require a pre-approved UAE Tourist Visa (we handle this). Your passport must be valid for at least 6 months from the date of entry. E-visas usually take 3-4 working days to process.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-wine-glass"></i></div>
                <h3>Liquor License & Alcohol</h3>
                <p>Understanding local laws:</p>
                <ul>
                    <li><strong>Availability:</strong> While the UAE is an Islamic country, Dubai boasts a highly cosmopolitan nightlife. Premium spirits, from Chivas Regal to imported wines, are widely available, but they are strictly sold only at licensed hotel bars, restaurants, and nightclubs, not in regular supermarkets.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-plane-departure"></i></div>
                <h3>DXB Airport Terminals & Lounges</h3>
                <p>Navigating the massive airport:</p>
                <ul>
                    <li><strong>Logistics:</strong> Dubai International Airport (DXB) is massive. Pay close attention to whether your flight departs from Terminal 1, 2, or 3. If you have a priority pass or credit card access, DXB features some of the best executive airport lounges in the world to relax before your flight.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-ticket"></i></div>
                <h3>Monument Tickets</h3>
                <p>Booking in advance:</p>
                <ul>
                    <li><strong>The Museum of the Future:</strong> This is currently the most sought-after ticket in Dubai and often sells out a month in advance. If you wish to visit the inside of the museum, you must confirm your booking well ahead of your travel dates.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-shirt"></i></div>
                <h3>Cultural Dress Codes</h3>
                <p>Respecting local norms:</p>
                <ul>
                    <li><strong>Modesty:</strong> Dubai is very modern, and beachwear is perfectly fine at resort pools and public beaches. However, when visiting malls, souks, or heritage areas, both men and women should dress modestly (shoulders and knees covered) to respect local culture.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-money-bill-transfer"></i></div>
                <h3>Tourism Dirham Tax</h3>
                <p>Mandatory hotel fees:</p>
                <ul>
                    <li><strong>On-Site Payment:</strong> The Dubai government mandates a "Tourism Dirham" fee that must be paid directly by the guest at the hotel reception during check-in or check-out. It ranges from 10 to 20 AED per room, per night, depending on the hotel's star rating.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, Tamil Nadu, Andhra Pradesh, Andaman, Lakshadweep, Dubai, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Dubai Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized Arabian adventure.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="The Golden Sands & Skyline Expedition 6D/5N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>