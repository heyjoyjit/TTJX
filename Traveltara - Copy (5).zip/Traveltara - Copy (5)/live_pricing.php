<?php
// =========================================================================
// UNIVERSAL PRICING ENGINE 
// This file does the heavy lifting for ALL destination pages.
// =========================================================================

// 1. Set default fallbacks in case the database is offline
$sheet_budget_price = "Contact Us"; 
$sheet_affordable_price = "Contact Us";
$sheet_super_price = "Contact Us";

// 2. Only run if the destination page told us which package it is
if (isset($target_package)) {
    
    // Connect to the Hostinger Database
    $db_host = "localhost";
    $db_name = "u505532187_traveltara"; 
    $db_user = "u505532187_admin";      
    $db_pass = "Traveltara@2026";   
    
    // Suppress errors visually so the page doesn't crash for the user if the DB is down
    $pricing_conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);

    if (!$pricing_conn->connect_error) {
        // Fetch Live Pricing for the requested package
        $stmt = $pricing_conn->prepare("SELECT `Budget`, `Affordable Luxury`, `Super Luxury` FROM pricing WHERE `Package Name` = ? LIMIT 1");
        $stmt->bind_param("s", $target_package);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $package_data = $result->fetch_assoc();
            
            // Clean inputs and format with ₹ and commas
            if (!empty($package_data['Budget'])) {
                $clean_val = (float)str_replace(',', '', $package_data['Budget']);
                if ($clean_val > 0) $sheet_budget_price = "₹" . number_format($clean_val);
            }
            if (!empty($package_data['Affordable Luxury'])) {
                $clean_val = (float)str_replace(',', '', $package_data['Affordable Luxury']);
                if ($clean_val > 0) $sheet_affordable_price = "₹" . number_format($clean_val);
            }
            if (!empty($package_data['Super Luxury'])) {
                $clean_val = (float)str_replace(',', '', $package_data['Super Luxury']);
                if ($clean_val > 0) $sheet_super_price = "₹" . number_format($clean_val);
            }
        }
        $stmt->close();
        $pricing_conn->close();
    }
}
?>