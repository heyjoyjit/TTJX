<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tailored Trips | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        
        <div class="menu-toggle" id="mobile-menu">
            <i class="fa-solid fa-bars"></i>
        </div>

        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        
        <div class="nav-contact" id="navContact">
            <i class="fa-solid fa-phone"></i> +91 7439877604
        </div>
    </nav>

    <header class="hero" style="height: 50vh; background: linear-gradient(rgba(10, 17, 40, 0.6), rgba(10, 17, 40, 0.6)), url('images/custom-hero.jpg') center/cover;">
        <div class="hero-content">
            <h1>Design Your Dream Escape</h1>
            <p>Bespoke itineraries crafted exclusively for your taste and pace.</p>
        </div>
    </header>

    <section class="section-padding" style="background: var(--light-bg);">
        <div class="custom-trip-container">
            
            <div class="process-info">
                <h2>The Art of Bespoke Travel</h2>
                <p>At traveltara, we believe your journey should be as unique as you are. If our curated packages don't match your exact vision, our Travel Experts will build one from scratch.</p>
                
                <div class="process-steps">
                    <div class="step">
                        <div class="step-icon"><i class="fa-solid fa-comments"></i></div>
                        <div>
                            <h4>1. Consultation</h4>
                            <p>Tell us your dream destinations, preferred travel style, and specific needs.</p>
                        </div>
                    </div>
                    <div class="step">
                        <div class="step-icon"><i class="fa-solid fa-map-location-dot"></i></div>
                        <div>
                            <h4>2. Curation</h4>
                            <p>Our experts design a personalized itinerary, handpicking premium stays and exclusive experiences.</p>
                        </div>
                    </div>
                    <div class="step">
                        <div class="step-icon"><i class="fa-solid fa-plane-departure"></i></div>
                        <div>
                            <h4>3. Experience</h4>
                            <p>Review your custom brochure, finalize the details, and embark on a seamless luxury journey.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="consultation-form-wrapper">
                <h3>Start Your Journey</h3>
                <p style="margin-bottom: 20px; font-size: 0.9rem; color: var(--text-grey);">Fill out the details below. An expert will reach out within 24 hours.</p>
                
                <form action="https://api.web3forms.com/submit" method="POST" class="bespoke-form">
    
    <input type="hidden" name="access_key" value="9c6e22cb-aa85-4e4b-83b0-603a658c95ea">

    <div class="form-row">
        <div class="form-group">
            <label>Full Name *</label>
            <input type="text" name="Name" class="val-name" required placeholder="Your Full Name *" pattern="[A-Za-z\s]+" title="Alphabets and spaces only">
        </div>
        <div class="form-group">
            <label>WhatsApp / Phone *</label>
            <input type="number" name="Phone" class="val-phone" required placeholder="10-Digit Mobile Number *" pattern="\d{10}" maxlength="10" title="Must be exactly 10 digits">
        </div>
    </div>

    <div class="form-group">
        <label>Email Address *</label>
        <input type="email" name="Email" required placeholder="email@example.com *" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Must be a valid email format like name@domain.com">
    </div>

    <div class="form-group">
        <label>Where do you want to go? *</label>
        <input type="text" name="Destination" required placeholder="e.g., A mix of Darjeeling and Sikkim">
    </div>

    <div class="form-row">
        <div class="form-group">
            <label>Expected Travel Month</label>
            <input type="text" name="Expected_Travel_Date" class="val-date" required placeholder="DD/MM/YYYY" pattern="\d{2}/\d{2}/\d{4}" maxlength="10" title="Format must be DD/MM/YYYY">
        </div>
        <div class="form-group">
            <label>Number of Travelers</label>
            <input type="number" name="Number_of_Travelers" min="1" placeholder="2 Adults, 1 Child">
        </div>
    </div>

    <div class="form-group">
        <label>Preferred Travel Style</label>
        <select name="Travel_Style">
            <option value="luxury">Ultra Luxury (5-Star & Boutique)</option>
            <option value="premium">Premium Comfort (4-Star)</option>
            <option value="adventure">Adventure & Nature Focus</option>
            <option value="heritage">Heritage & Culture</option>
        </select>
    </div>

    <div class="form-group">
        <label>Any special requests or celebrations?</label>
        <textarea name="Special_Requests" rows="4" placeholder="Honeymoon, anniversary, dietary restrictions, etc."></textarea>
    </div>

    <button type="submit" class="btn-primary full-width" style="padding: 15px; font-size: 1.1rem;">Request Custom Itinerary</button>
</form>
            </div>
        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-grid">
            
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a>
                <a href="#">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="#">Career</a>
            </div>
            
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="#">Travel Guidelines</a>
            </div>
            
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
            
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>

    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Speak with a Travel Expert</h3>
            <p>Fill out the details below to receive a custom itinerary and quote.</p>
            <form action="https://api.web3forms.com/submit" method="POST" class="lead-form">
    <input type="hidden" name="access_key" value="9c6e22cb-aa85-4e4b-83b0-603a658c95ea">
    <input type="hidden" name="subject" value="New 20% Off VIP Lead!">

    <div class="form-group">
        <input type="text" name="Name" class="val-name" required placeholder="Your Full Name *">
    </div>
    <div class="form-group">
        <input type="tel" name="Phone" class="val-phone" required placeholder="WhatsApp / Phone *">
    </div>
    <div class="form-group">
        <input type="text" name="Destination" required placeholder="Where do you want to travel? *">
    </div>
    
    <div class="h-captcha" data-captcha="true"></div>
    
    <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
</form>
        </div>
    </div>

    <script src="https://web3forms.com/client/script.js" async defer></script>
    <script src="js/main.js"></script>
</body>
</html>
    <script src="js/main.js"></script>

</body>
</html>