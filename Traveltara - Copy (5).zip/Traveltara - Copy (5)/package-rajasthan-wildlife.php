<?php
// Top of package-rajasthan-wildlife.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 LIVE HOSTINGER DATABASE CONNECTION (UNIVERSAL PRICING ENGINE)
// =========================================================================

// EXACT package name from your Admin Dashboard
$target_package = "Wild Rajasthan 10D/9N"; 

// Call the universal brain file to fetch the live prices!
require_once 'live_pricing.php';

// Build Javascript Array for the dynamic UI
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Wildlife Lodges</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for Intercity Transfers</li>
            <li><i class="fa-solid fa-paw"></i> Shared Canter Safaris in Ranthambore</li>
            <li><i class="fa-solid fa-utensils"></i> All Meals Included During Jungle Stays (AP)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Jungle Resorts & Swiss Tents</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-camera"></i> Exclusive 4x4 Gypsy Safaris in Ranthambore & Jawai</li>
            <li><i class="fa-solid fa-utensils"></i> Authentic Rajasthani & Wilderness Dining</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Ultra-Luxury Camps (e.g., Suján Jawai, Oberoi Vanyavilas)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Expert Private Naturalists & VIP Safari Zones</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Bush Dinners & Bonfire Evenings</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wild Rajasthan 10 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="rajasthan-itinerary.php">Rajasthan</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Wild Rajasthan (10D/9N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['ranthambore hero']) ? $tourImages['ranthambore hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 10 Days / 9 Nights</div>
        <div class="subpage-hero-content">
            <h1>Wild Rajasthan</h1>
            <p>Track majestic tigers, elusive leopards, and desert wildlife across the untamed Aravallis.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Wild Rajasthan 10D/9N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Designed for wildlife enthusiasts and nature photographers, this 10-day circuit takes you far beyond the standard palaces into the untamed heart of Rajasthan. You will track the Royal Bengal Tiger in the ancient ruins of Ranthambore, photograph leopards thriving among the Rabari tribesmen in the dramatic granite hills of Jawai, and witness the unique blackbuck conservation of the Bishnoi villages near Jodhpur.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Jaipur</h3>
                <p>Arrive at Jaipur International Airport or Railway Station. Your luxury chauffeur will transfer you to your hotel. After resting, take a brief evening tour of the city center to see the illuminated Hawa Mahal, preparing your gear and cameras for the jungle safaris ahead.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Jaipur to Ranthambore National Park</h3>
                <p>After an early breakfast, drive to Sawai Madhopur, the gateway to Ranthambore National Park (approx. 3.5 hours). Check into your wilderness lodge. After lunch, embark on your very first afternoon Safari. Ranthambore is famous for its tigers diurnal nature, meaning they are easily spotted during the daytime amidst the spectacular ruins of ancient forts.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Tracking the Bengal Tiger</h3>
                <p>Wake up before dawn for a thrilling morning jeep safari deep into the core zones of the park. Keep your cameras ready for tigers, leopards, sloth bears, and marsh crocodiles. Return to your lodge for a heavy breakfast and rest. In the afternoon, head out for a second safari in a different zone to maximize your tracking chances.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Ranthambore Fort & Departure to Kumbhalgarh</h3>
                <p>Enjoy an optional early morning safari or visit the majestic 10th-century Ranthambore Fort perched high within the park. After breakfast, begin a scenic drive toward the Aravalli hills to Kumbhalgarh (approx. 6 hours). Check into your nature resort nestled in the forested valleys.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Kumbhalgarh Wildlife Sanctuary</h3>
                <p>Spend the morning exploring the Kumbhalgarh Wildlife Sanctuary on a rugged jeep safari, tracking wolves, leopards, and the highly endangered Indian courser. In the afternoon, visit the massive Kumbhalgarh Fort, a UNESCO World Heritage site boasting the second-longest continuous wall in the world.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Into the Leopard Hills (Jawai / Bera)</h3>
                <p>Depart for Jawai (approx. 2.5 hours), a dramatic landscape of granite boulders, winding rivers, and scrubland. Jawai is globally unique for the harmonious coexistence between the wild leopards and the local nomadic Rabari herdsmen. Check into your luxury camp and take your first late-afternoon private leopard tracking safari.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Jawai Leopard Safari & Rabari Culture</h3>
                <p>Embark on morning and evening 4x4 safaris across the granite hills. Because the leopards here do not face poaching threats from the locals, they are remarkably relaxed and frequently sighted sunbathing on the rocks. Spend the mid-day interacting with the Rabari tribe to understand their fascinating pastoral lifestyle.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Jawai to the Blue City (Jodhpur)</h3>
                <p>Take one final morning safari in Jawai before driving to Jodhpur (approx. 3.5 hours). Arrive in the historic capital of Marwar and check into your premium property. Spend the evening exploring the vibrant Sardar Market or relaxing at your hotel.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Bishnoi Village Safari & Desert Wildlife</h3>
                <p>Today features a unique cultural wildlife experience. Visit the Bishnoi villages—a community fiercely dedicated to protecting nature. Take a jeep safari through the desert scrub to photograph massive herds of Blackbucks, Chinkaras, and migratory Demoiselle cranes. In the afternoon, visit the colossal Mehrangarh Fort towering over Jodhpur.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Departure from Jodhpur</h3>
                <p>Enjoy a final, unhurried breakfast. Depending on your flight or train schedule, you may do some last-minute shopping for local spices or handicrafts. Your chauffeur will provide a seamless transfer to the Jodhpur Airport or Railway Station for your journey home.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Wildlife Lodges</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for Intercity Transfers</li>
                <li><i class="fa-solid fa-paw"></i> Shared Canter Safaris in Ranthambore</li>
                <li><i class="fa-solid fa-utensils"></i> All Meals Included During Jungle Stays (AP)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/rajasthan-wildlife-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- WILDLIFE INSIGHTS HUB (6 GRID CARDS)                      -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Safari Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Wilderness Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details and safari protocols to ensure a successful and respectful wildlife tracking experience.</p>
        </div>

        <div class="info-hub-grid">
            
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Park Closures & Timing</h3>
                <p>Wildlife tourism is heavily regulated in Rajasthan:</p>
                <ul>
                    <li><strong>Monsoon Closure:</strong> Ranthambore National Park is completely closed from <strong>July 1st to September 30th</strong> for the animal mating season.</li>
                    <li><strong>Peak Sightings:</strong> The hot summer months (April to June) offer the highest chance of tiger sightings as animals gather around shrinking waterholes.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-ticket"></i></div>
                <h3>Advance Safari Bookings</h3>
                <p>Securing your spot requires advance planning:</p>
                <ul>
                    <li><strong>Ranthambore Quotas:</strong> Government permits for core zones sell out 90 to 120 days in advance. Last-minute "Tatkal" bookings are extremely expensive and not guaranteed.</li>
                    <li><strong>Identification:</strong> Original government IDs (Aadhar, Passport) are mandatory and must match the booking details exactly to enter the park.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-truck-monster"></i></div>
                <h3>Gypsy vs. Canter</h3>
                <p>Understanding your safari vehicle options:</p>
                <ul>
                    <li><strong>Gypsy (Jeep):</strong> An open 6-seater 4x4. Excellent for photography, quieter, and can navigate narrow jungle trails. Highly recommended (included in Affordable/Super Luxury tiers).</li>
                    <li><strong>Canter:</strong> An open 20-seater mini-truck. Louder and less maneuverable, but highly cost-effective for budget travelers.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-camera"></i></div>
                <h3>Jungle Etiquette & Gear</h3>
                <p>Maximize your experience while respecting the animals:</p>
                <ul>
                    <li><strong>Clothing:</strong> Wear muted, earth tones (khaki, olive, brown). Avoid bright colors, white, or strong perfumes.</li>
                    <li><strong>Silence:</strong> Maintain absolute silence during tracking. Listen to the forest alarm calls (monkeys, deer) which signal a predator nearby.</li>
                    <li><strong>Dust Protection:</strong> The jungle tracks are extremely dusty. Bring scarves or bandanas to cover your face and camera gear.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-paw"></i></div>
                <h3>The Jawai Experience</h3>
                <p>Jawai is not a traditional national park:</p>
                <ul>
                    <li><strong>Open Wilderness:</strong> It is an open, rocky landscape shared by humans and leopards. Safaris here are conducted by specialized, privately-owned 4x4 vehicles.</li>
                    <li><strong>Rabari Culture:</strong> The local Rabari tribes consider leopards sacred. This mutual respect is the primary reason for Jawai's booming leopard population.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Weather Preparations</h3>
                <p>Jungle weather is extreme and unpredictable:</p>
                <ul>
                    <li><strong>Winter Mornings:</strong> Open jeep safaris at 6:00 AM in December/January are bone-chillingly cold due to wind chill. Heavy jackets, gloves, and beanies are essential.</li>
                    <li><strong>Summer Heat:</strong> By May, afternoon temperatures exceed 40°C. Hydration and heavy sun protection are critical.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream royal escape to Rajasthan.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Wild Rajasthan 10D/9N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>