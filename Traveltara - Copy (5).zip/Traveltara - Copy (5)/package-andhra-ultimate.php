<?php
// Top of package-andhra-ultimate.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹45,000"; 
$sheet_affordable_price = "₹70,000";
$sheet_super_price = "₹1,10,000";

// EXACT package name from Google Sheet
$target_package = "The Royal Andhra Expedition 15D/14N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hotels / Valley Lodges</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the 15-Day Route</li>
            <li><i class="fa-solid fa-ticket"></i> Standard Monument Entry & River Cruise Tickets Included</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Heritage Resorts, Eco-Camps & Coastal Retreats</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta for Maximum Inter-City Comfort</li>
            <li><i class="fa-solid fa-map-location-dot"></i> Expert Guided Cave Explorations & VIP Temple Darshans</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP) highlighting Andhra Cuisines</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Palaces & Ultra-Luxury Retreats (e.g., Novotel Vizag, Taj Tirupati)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Vistadome Train, Private Boat Charters & Protocol Darshans</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Dining, Royal Telugu Feasts & Coastal Seafood BBQs</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Royal Andhra Expedition 15 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="andhra-pradesh-itinerary.php">Andhra Pradesh Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Royal Expedition (15D/14N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['andhra ultimate hero']) ? $tourImages['andhra ultimate hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 15 Days / 14 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Royal Andhra Expedition</h1>
            <p>A magnificent 15-day grand loop spanning the deep blue Vizag coast, mist-covered coffee estates, mighty river deltas, profound temples, and the Grand Canyon of India.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Royal Andhra Expedition 15D/14N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>To truly understand the depth of Andhra Pradesh, one must traverse its profound contrasts. We have designed this 15-day expedition to be entirely comprehensive, ensuring no region is left unexplored or rushed. You will begin in the "City of Destiny," Visakhapatnam, ascend into the Araku Valley, cruise the Godavari River, trace the Buddhist heritage of Amaravati, witness staggering devotion in Tirupati, and finally explore the rugged, awe-inspiring landscapes of Gandikota and the Belum Caves.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in the City of Destiny (Vizag)</h3>
                <p>Arrive at Visakhapatnam Airport (VTZ). Your private chauffeur will receive you and transfer you to your sea-facing hotel. Spend the afternoon exploring the coastal legacy of Vizag. Visit the INS Kurusura Submarine Museum, a real decommissioned Indian Navy submarine, and the TU 142 Aircraft Museum. In the evening, take a leisurely stroll down the iconic Ramakrishna (RK) Beach and soak in the vibrant atmosphere of the Bay of Bengal.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Rushikonda Coast & Kailasagiri</h3>
                <p>After breakfast, drive along the highly scenic coastal road toward Rushikonda Beach. Enjoy the morning relaxing by the sea. Later, take the picturesque ropeway up to Kailasagiri Hill Park. Standing 360 feet overlooking the ocean, the park features massive statues of Shiva and Parvati and offers breathtaking panoramic views of the entire coastline. Visit the ancient Simhachalam Temple in the late afternoon before returning to your hotel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Glass-Domed Train to Araku Valley</h3>
                <p>Check out early and transfer to the Visakhapatnam Railway Station. Board the Kirandul Passenger train for a spectacular journey into the Eastern Ghats, passing through 58 dark tunnels and over deep, lush ravines. Disembark at Araku Station, where your chauffeur will be waiting. Check into your valley resort. Spend the afternoon visiting the Tribal Museum to understand the indigenous culture of the region and relax in the misty, cool air.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Coffee Plantations, Waterfalls & Borra Caves</h3>
                <p>Begin your day with a guided walk through the sprawling organic coffee plantations, tasting freshly brewed local coffee. Next, visit the cascading Chaparai Waterfalls. In the afternoon, take a short drive to the magnificent Borra Caves. Believed to be 150 million years old, these massive limestone caves feature spectacular stalactite and stalagmite formations. Return to your Araku resort for the evening.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Descent to Rajahmundry & Godavari Harathi</h3>
                <p>Enjoy a final mountain breakfast, then check out and drive down the ghats toward the historic city of Rajahmundry (approx. 5 hours). Check into your riverside hotel. Rajahmundry is one of the oldest cities in the Indian subcontinent. As the evening sets in, head to the Pushkar Ghat to witness the mesmerizing Godavari Harathi, a grand riverside worship ritual set against the backdrop of the massive Godavari Arch Bridge.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Great Papikondalu River Cruise</h3>
                <p>Wake up early and board your cruise for an unforgettable full-day journey on the Godavari. As the river narrows, you will enter the spectacular Papikondalu range, where towering, densely forested hills rise sharply from both sides of the water. The boat stops at the ancient Gandi Pochamma Temple and the tribal village of Perantapalli. Enjoy a freshly prepared bamboo chicken lunch on board. Return to your hotel in Rajahmundry by the evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> The Konaseema Delta & Drive to Vijayawada</h3>
                <p>After breakfast, drive through the Konaseema region, often referred to as the "Kerala of Andhra Pradesh." Visit the highly revered Draksharamam Temple, one of the five Pancharama Kshetras. In the afternoon, continue your drive south along the highway to Vijayawada (approx. 3.5 hours), the bustling commercial capital situated on the banks of the Krishna River. Check into your hotel and relax.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Bhavani Island, Caves & Buddhist Amaravati</h3>
                <p>Start your day with a visit to the Undavalli Caves, a stunning 4th-century monolithic rock-cut cave complex featuring a massive reclining Vishnu. Proceed to the Prakasam Barrage for views over the Krishna River. Take a short boat ride to Bhavani Island, one of the largest river islands in India, for a peaceful afternoon. Later, drive to nearby Amaravati to explore the ancient Buddhist Stupa ruins and the impressive Dhyana Buddha statue.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> The Long Drive to the Sacred Seven Hills</h3>
                <p>Check out and embark on a transition drive from the coastal plains deep into the Rayalaseema region toward Tirupati (approx. 6.5 hours). Watch the landscape change from lush river basins to rugged, rocky terrain. Arrive in Tirupati, the gateway to the sacred Seven Hills, by late afternoon. Check into your hotel, relax, and prepare yourself for the immense spiritual energy of the following day.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> The Vayu Lingam & Tirumala Darshan</h3>
                <p>Start your day with a short drive to Srikalahasti to visit the ancient Vayu Lingam temple, representing the element of Wind. Return to Tirupati and embark on the highly scenic drive up the winding ghat roads to Tirumala. Proceed for the pre-booked Special Entry Darshan of Lord Sri Venkateswara Swamy. Experience the palpable devotion of thousands of pilgrims, receive the world-famous Tirupati Laddu, and descend back to the foothills in the evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Transition into the Rayalaseema Heartland (Kadapa)</h3>
                <p>After breakfast, check out and drive north into the heart of the Rayalaseema region toward Kadapa (approx. 3.5 hours). En route, visit the historic Chandragiri Fort, built in the 11th century. Arrive in Kadapa, check into your hotel, and visit the ancient Devuni Kadapa Temple in the evening. This day serves as a relaxed transition before entering the rugged canyon territories.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> The Grand Canyon of India (Gandikota)</h3>
                <p>Drive to the spectacular Gandikota (approx. 2 hours). Often called the "Grand Canyon of India," this breathtaking gorge is formed by the Pennar River cutting through the Erramala hills. Walk along the massive red sandstone cliffs, explore the ruins of the 13th-century Gandikota Fort, the Madhavaraya Temple, and the Jamia Masjid. Enjoy a sunset over the canyon gorge before checking into your local eco-camp or heritage resort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Into the Depths (Belum Caves)</h3>
                <p>After breakfast, drive to the Belum Caves (approx. 1.5 hours). This is the second-largest cave system on the Indian subcontinent, reaching a depth of 150 feet. Explore the eerie, beautifully illuminated stalactite and stalagmite formations, sinkholes, and the underground stream known as Patalaganga. In the afternoon, continue your drive towards the Anantapur district (approx. 2 hours) and check into your hotel for the night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 14</span> The Monolithic Marvels of Lepakshi</h3>
                <p>Check out and drive to the historic village of Lepakshi. Step into the 16th century at the Veerabhadra Temple, a masterclass of the Vijayanagara Empire's architectural brilliance. Stand beneath the legendary "Hanging Pillar," admire the natural-dye ceiling frescoes, and marvel at the massive Lepakshi Nandi, carved flawlessly from a single granite boulder. Spend your final evening reflecting on the incredible diversity of your journey.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 15</span> Departure from Bengaluru</h3>
                <p>Your ultimate Royal Andhra Expedition comes to a close. Enjoy a final South Indian breakfast. Because Lepakshi is situated right on the border of Andhra Pradesh and Karnataka, it is significantly closer to Bengaluru than any major Andhra city. Your chauffeur will drive you directly to Kempegowda International Airport (BLR) in Bengaluru (approx. 2 hours) for your onward flight, leaving you with memories of a perfectly complete exploration.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hotels / Valley Lodges</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the 15-Day Route</li>
                <li><i class="fa-solid fa-ticket"></i> Standard Monument Entry & River Cruise Tickets Included</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/andhra-ultimate-15d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- EXPEDITION INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The 15-Day Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for this massive, multi-terrain endurance journey across Andhra Pradesh.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-plane-departure"></i></div>
                <h3>Flight Route Optimization</h3>
                <p>Avoiding a 12-hour backtrack:</p>
                <ul>
                    <li><strong>Gateways:</strong> Because this is a massive cross-state expedition, it is absolutely vital to book your arrival flight into Visakhapatnam (VTZ) in the northeast, and your departure flight out of Bengaluru (BLR) in the southwest. Driving from Lepakshi back to Vizag is highly discouraged.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car-side"></i></div>
                <h3>Vehicle Upgrade Recommended</h3>
                <p>Managing the long distances:</p>
                <ul>
                    <li><strong>Road Fatigue:</strong> Over 15 days, you will transition between coasts, river deltas, highways, and rocky canyons. We highly advise upgrading to an Innova Crysta (even for couples) for the superior suspension and legroom over thousands of kilometers.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Tirumala Darshan Logistics</h3>
                <p>Securing your entry:</p>
                <ul>
                    <li><strong>Advance Booking:</strong> Special Entry Darshan tickets for Lord Venkateswara sell out 60-90 days in advance. We require your exact ID proofs early to secure these slots. Furthermore, strict dress codes (Dhotis for men, Sarees/Churidars for women) are relentlessly enforced.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-person-hiking"></i></div>
                <h3>Cave Explorations</h3>
                <p>Physical requirements:</p>
                <ul>
                    <li><strong>Borra & Belum:</strong> Both cave systems involve descending deep underground. Belum Caves, in particular, can get extremely warm and claustrophobic as you reach Patalaganga. Sturdy, anti-slip footwear is mandatory.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-train-tram"></i></div>
                <h3>The Araku Train</h3>
                <p>Securing the glass-roof experience:</p>
                <ul>
                    <li><strong>Vistadome Demand:</strong> The glass-roofed train coaches to Araku Valley are incredibly popular. While included in our premium tiers, they are strictly subject to IRCTC availability. Book your expedition well in advance to guarantee these seats.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-sun"></i></div>
                <h3>Weather Variations</h3>
                <p>Packing for extremes:</p>
                <ul>
                    <li><strong>The Transitions:</strong> Vizag and Rajahmundry are highly humid. Araku Valley is cool and misty (requiring light jackets). Gandikota and Belum Caves are situated in the arid Rayalaseema region, where the sun beats down intensely on the rocky terrain. Pack layers and sun protection.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, Tamil Nadu, Andhra Pradesh, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized 15-day Andhra Grand Loop.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="The Royal Andhra Expedition 15D/14N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>