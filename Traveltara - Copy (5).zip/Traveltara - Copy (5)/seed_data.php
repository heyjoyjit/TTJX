<?php
// ⚠️ WARNING: THIS SCRIPT ADDS 200+ ROWS OF TEST DATA TO YOUR DATABASE.
header("Content-Type: text/html; charset=utf-8");

$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

echo "<h2>🚀 Initializing Traveltara AI Test Data...</h2>";

// 1. RANDOM DATA ARRAYS
$firstNames = ["Rahul", "Priya", "Amit", "Sneha", "Vikram", "Neha", "Rohan", "Pooja", "Karan", "Anjali", "Suresh", "Ritu", "Deepak", "Kavita", "Manoj"];
$lastNames = ["Sharma", "Singh", "Patel", "Kumar", "Gupta", "Das", "Shah", "Reddy", "Verma", "Bose", "Jain", "Mehta", "Chopra"];
$destinations = [
    ["name" => "Wild Rajasthan 10D/9N", "type" => "Domestic", "base" => 45000],
    ["name" => "Swiss Alpine Express 7D/6N", "type" => "International", "base" => 185000],
    ["name" => "Lakshadweep Island Explorer", "type" => "Domestic", "base" => 32000],
    ["name" => "Vietnam Vibes 6D/5N", "type" => "International", "base" => 65000],
    ["name" => "Kerala Backwaters 5D/4N", "type" => "Domestic", "base" => 28000]
];
$tiers = ["Budget", "Affordable Luxury", "Super Luxury"];
$states = ["West Bengal", "Maharashtra", "Delhi", "Karnataka", "Gujarat", "Tamil Nadu", "Uttar Pradesh", "Rajasthan"];

// ==========================================
// 🔴 1. SEED 150 BOOKINGS (Over last 90 days)
// ==========================================
echo "Injecting 150 Bookings...<br>";
$conn->query("TRUNCATE TABLE bookings"); // Optional: Clears old bookings before seeding

for ($i = 0; $i < 150; $i++) {
    $daysAgo = rand(0, 90);
    $timestamp = date('Y-m-d H:i:s', strtotime("-$daysAgo days"));
    
    $fName = $firstNames[array_rand($firstNames)];
    $lName = $lastNames[array_rand($lastNames)];
    $phone = "9" . rand(100000000, 999999999);
    $email = strtolower($fName . "." . $lName . rand(10,99) . "@gmail.com");
    $state = $states[array_rand($states)];
    $address = "123 Test Street, Sample City, $state, 700001";
    
    $dest = $destinations[array_rand($destinations)];
    $tier = $tiers[array_rand($tiers)];
    $adults = rand(1, 4);
    $children = rand(0, 2);
    $rooms = ceil($adults / 2);
    
    // Calculate realistic price
    $multiplier = ($tier == "Budget") ? 1 : (($tier == "Affordable Luxury") ? 1.5 : 2.5);
    $totalPaid = ($dest['base'] * $multiplier * $adults) + ($dest['base'] * $multiplier * 0.5 * $children);
    $formattedPaid = "₹" . number_format($totalPaid, 0, '.', ',');
    
    $bookingId = "TRV-TEST-" . strtoupper(substr(md5(rand()), 0, 5));
    $payRef = "pay_" . substr(md5(rand()), 0, 10);
    $invoice = "INV-" . rand(1000,9999);

    $sql = "INSERT INTO bookings (`Booking ID`, `Timestamp`, `First Name`, `Last Name`, `Primary Phone`, `Email`, `Residential Address`, `Destination`, `Tour Tier`, `Tour Type (Dom/Int)`, `Adults`, `Children`, `Rooms`, `Total Paid`, `Payment Ref ID`, `Invoice No`, `Status`) 
            VALUES ('$bookingId', '$timestamp', '$fName', '$lName', '$phone', '$email', '$address', '{$dest['name']}', '$tier', '{$dest['type']}', $adults, $children, $rooms, '$formattedPaid', '$payRef', '$invoice', 'Payment Complete')";
    $conn->query($sql);
}

// ==========================================
// 🔴 2. SEED 60 EXPENSES (Over last 90 days)
// ==========================================
echo "Injecting 60 Expenses...<br>";
$conn->query("TRUNCATE TABLE expenses"); // Optional: Clears old expenses

$expCats = ["Marketing & Ads", "Software & Hosting", "Office & Admin", "Miscellaneous"];
for ($i = 0; $i < 60; $i++) {
    $daysAgo = rand(0, 90);
    $date = date('Y-m-d', strtotime("-$daysAgo days"));
    $cat = $expCats[array_rand($expCats)];
    $amt = rand(1500, 12000);
    $desc = "Test $cat Expense for Analysis";
    
    $conn->query("INSERT INTO expenses (exp_date, category, description, amount) VALUES ('$date', '$cat', '$desc', $amt)");
}

// ==========================================
// 🔴 3. SEED 80 INTERACTIONS (CRM LEADS)
// ==========================================
echo "Injecting 80 CRM Leads & Interactions...<br>";
$conn->query("TRUNCATE TABLE interactions");
$conn->query("TRUNCATE TABLE master_crm");

$sources = ["WhatsApp Popup", "Website Form", "Direct Call", "Facebook Ad"];
for ($i = 0; $i < 80; $i++) {
    $daysAgo = rand(0, 90);
    $timestamp = date('Y-m-d H:i:s', strtotime("-$daysAgo days"));
    $fName = $firstNames[array_rand($firstNames)];
    $phone = "8" . rand(100000000, 999999999);
    $source = $sources[array_rand($sources)];
    
    $conn->query("INSERT INTO interactions (`Phone Number`, `Source`, `Extracted Name`, `Exact Message / Details`, `Timestamp`) VALUES ('$phone', '$source', '$fName', '💬 Inquiry regarding tour packages.', '$timestamp')");
    $conn->query("INSERT INTO master_crm (`Phone Number`, `Name`, `Client Type`, `Total Interactions`, `Latest Interest`, `Action Status`) VALUES ('$phone', '$fName', 'Lead', 1, '$source', '🟢 New Lead')");
}

echo "<h2 style='color: green;'>✅ Successfully generated 290 rows of Test Data!</h2>";
echo "<p>You can now go back to your Admin Dashboard, refresh the page, and test all your AI Charts, Line Graphs, and Expense Trackers.</p>";
echo "<p><b>CRITICAL:</b> Delete this <code>seed_data.php</code> file from your server after you run it so nobody else can click it!</p>";

$conn->close();
?>