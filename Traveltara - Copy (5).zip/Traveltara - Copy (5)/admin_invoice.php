<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin POS | Traveltara</title>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="css/booking.css">
    <link rel="stylesheet" href="css/checkout.css">
    
    <style>
        /* Admin specific cleanups */
        .admin-hero { background: #0A1128; color: #fff; padding: 30px 20px; text-align: center; }
        .admin-hero h1 { font-family: 'Playfair Display', serif; color: #C5A059; margin: 0; }
        .location-row { background: #fdfbf7; border: 1px solid #ddd; padding: 20px; border-radius: 8px; margin-bottom: 15px; position: relative; }
        .remove-loc-btn { position: absolute; top: 15px; right: 15px; background: #e74c3c; color: #fff; border: none; border-radius: 4px; padding: 5px 10px; cursor: pointer; }
        .add-loc-btn { background: transparent; color: #C5A059; border: 2px dashed #C5A059; padding: 12px; width: 100%; border-radius: 8px; cursor: pointer; font-weight: bold; margin-bottom: 20px; }
        .add-loc-btn:hover { background: rgba(197, 160, 89, 0.1); }
    </style>
</head>
<body style="background: #f4f4f4;">

    <header class="admin-hero">
        <h1>traveltara | POS</h1>
        <div style="font-family: 'Lato', sans-serif; color: #aaa; margin-top: 5px;">Manual Offline Billing & Invoicing System</div>
    </header>

    <main class="booking-container" style="max-width: 900px; margin-top: -20px;">
        <form id="adminInvoiceForm">
            
            <div class="checkout-form-section">
                <h2 class="checkout-section-title">1. Guest Details</h2>
                <div class="form-grid">
                    <div class="input-group"><label>Guest Name *</label><input type="text" id="gName" required></div>
                    <div class="input-group"><label>Phone Number *</label><input type="tel" id="gPhone" maxlength="10" required></div>
                    <div class="input-group"><label>Email Address *</label><input type="email" id="gEmail" required></div>
                    <div class="input-group"><label>State of Residence *</label>
                        <select id="gState" required>
                            <option value="West Bengal">West Bengal</option>
                            <option value="Other">Other (Inter-state)</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="checkout-form-section">
                <h2 class="checkout-section-title">2. Itinerary & Pricing (Taxable Amounts)</h2>
                
                <div id="locationsContainer">
                    <!-- Dynamic locations will be injected here -->
                </div>
                
                <button type="button" class="add-loc-btn" onclick="addLocationRow()"><i class="fa-solid fa-plus"></i> Add Destination / Service</button>
            </div>

            <div class="checkout-form-section">
                <h2 class="checkout-section-title">3. Party Configuration</h2>
                <div class="party-grid">
                    <div class="input-group">
                        <label>Adults</label><input type="number" id="adults" class="counter-input" value="2" min="1">
                    </div>
                    <div class="input-group">
                        <label>Children (< 12)</label><input type="number" id="child" class="counter-input" value="0" min="0">
                    </div>
                    <div class="input-group">
                        <label>Rooms</label><input type="number" id="rooms" class="counter-input" value="1" min="1">
                    </div>
                    <div class="input-group">
                        <label>Tier</label>
                        <select id="tier">
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Budget">Budget</option>
                            <option value="Customised">Customised</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="checkout-form-section" id="pricingSection">
                <h2 class="checkout-section-title">4. Grand Total & Settlement</h2>
                <div class="price-box">
                    <div class="price-label">Total Amount (Incl. 5% GST)</div>
                    <div class="price-value" id="displayTotalCost">₹ 0.00</div>
                </div>
            </div>
            
            <button type="submit" class="submit-btn" id="generateBillBtn" style="font-size: 1.1rem; padding: 18px; max-width: none; background: #27ae60;">
                <i class="fa-solid fa-file-invoice"></i> Mark as Paid (Cash/Offline) & Generate Invoice
            </button>

        </form>
    </main>

    <!-- HIDDEN INVOICE TEMPLATE FOR PDF GENERATION -->
    <div id="invoicePrintContainer" style="display: none;">
        <div id="traveltaraInvoice" style="width: 800px; padding: 40px; background: #ffffff; font-family: 'Lato', Arial, sans-serif; color: #333; box-sizing: border-box; margin: 0; position: relative;">
            
            <!-- Standard Header -->
            <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
                <tr>
                    <td style="padding-bottom: 20px; border-bottom: 3px solid #C5A059;" colspan="2">
                        <table style="width: 100%;">
                            <tr>
                                <td style="width: 50%; vertical-align: top;">
                                    <h1 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 32px; margin: 0 0 5px 0; font-weight: 700;">traveltara</h1>
                                    <p style="color: #C5A059; font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; margin: 0;">Bespoke Luxury Journeys</p>
                                </td>
                                <td style="width: 50%; vertical-align: top; text-align: right; font-size: 13px; line-height: 1.4; color: #555;">
                                    <h3 style="color: #0A1128; font-size: 22px; margin: 0 0 8px 0; font-weight: 900; letter-spacing: 1px;">TAX INVOICE</h3>
                                    <p style="margin: 2px 0;"><strong>Traveltara Pvt. Ltd.</strong></p>
                                    <p style="margin: 2px 0;">Phone: +91 74398 77604 | Email: booking@traveltara.com</p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr><td colspan="2" style="height: 20px;"></td></tr>

                <!-- Invoice Meta -->
                <tr>
                    <td colspan="2" style="background: #fdfbf7; border: 1px solid #eaeaea; border-radius: 4px; padding: 15px;">
                        <table style="width: 100%;">
                            <tr>
                                <td style="width: 50%; font-size: 13px; color: #444; line-height: 1.6;">
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Invoice No:</strong> <span id="invRealNo">INV-XXXXX</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Invoice Date:</strong> <span id="invDate">DD-MMM-YYYY</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Payment Mode:</strong> <span style="color: #27ae60; font-weight: bold;">CASH / OFFLINE SETTLEMENT</span></p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr><td colspan="2" style="height: 20px;"></td></tr>

                <!-- Bill To -->
                <tr>
                    <td style="width: 50%; padding-right: 15px; vertical-align: top;">
                        <div style="font-size: 12px; font-weight: 900; color: #C5A059; border-bottom: 1px solid #C5A059; padding-bottom: 5px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px;">BILL TO</div>
                        <p style="margin: 4px 0; font-size: 14px; color: #0A1128; font-weight: bold;" id="invGuestName">Guest Name</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;" id="invGuestPhone">+91 XXXXXXXXXX</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;" id="invGuestEmail">guest@email.com</p>
                    </td>
                    <td style="width: 50%; padding-left: 15px; vertical-align: top;">
                        <div style="font-size: 12px; font-weight: 900; color: #C5A059; border-bottom: 1px solid #C5A059; padding-bottom: 5px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px;">TRAVEL DETAILS</div>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Tier:</strong> <span id="invTier">Super Luxury</span></p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Travelers:</strong> <span id="invPax">2 Adults, 0 Children</span></p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Rooms:</strong> <span id="invRooms">1 Room(s)</span></p>
                    </td>
                </tr>
                <tr><td colspan="2" style="height: 20px;"></td></tr>

                <!-- DYNAMIC ITEMS TABLE -->
                <tr>
                    <td colspan="2">
                        <table style="width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid #0A1128;">
                            <thead>
                                <tr>
                                    <th style="background: #0A1128; color: #ffffff; text-align: left; padding: 10px; font-weight: 700; border: 1px solid #0A1128;">Destination / Service</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: center; padding: 10px; font-weight: 700; border: 1px solid #0A1128;">Date</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128;">Taxable Base (₹)</th>
                                </tr>
                            </thead>
                            <tbody id="invTableBody">
                                <!-- JS WILL INJECT ROWS HERE -->
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr><td colspan="2" style="height: 20px;"></td></tr>

                <!-- Footer Totals -->
                <tr>
                    <td style="width: 55%; padding-right: 15px; vertical-align: top;">
                        <div style="background: #f9f9f9; padding: 15px; border-radius: 4px; border-left: 3px solid #C5A059;">
                            <p style="margin: 0 0 5px 0; font-size: 13px;"><strong>Total Amount in Words:</strong></p>
                            <p id="invWordsText" style="font-style: italic; color: #0A1128; margin: 0; font-size: 13px;">Rupees Zero Only</p>
                        </div>
                    </td>
                    <td style="width: 45%; vertical-align: bottom;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total Taxable Value:</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumTaxable">₹ 0.00</td>
                            </tr>
                            <tr>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">GST (5%):</td>
                                <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumGst">₹ 0.00</td>
                            </tr>
                            <tr>
                                <td style="padding: 10px 0 0 0; font-size: 18px; color: #0A1128; font-weight: 900; border-top: 2px solid #0A1128;">Grand Total:</td>
                                <td style="padding: 10px 0 0 0; font-size: 18px; color: #0A1128; font-weight: 900; text-align: right; border-top: 2px solid #0A1128;" id="invSumGrand">₹ 0.00</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>

        </div>
    </div>

    <script src="js/admin_invoice.js"></script>
</body>
</html>