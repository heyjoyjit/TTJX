<?php
// Top of package-rajasthan-grand.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹48,000"; 
$sheet_affordable_price = "₹75,000";
$sheet_super_price = "₹1,25,000";

// EXACT package name from Google Sheet
$target_package = "Rajasthan Grand Epic 15D/14N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Heritage Guesthouses</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the 15-Day Route</li>
            <li><i class="fa-solid fa-camera"></i> Standard Fort, Desert & Sightseeing Tours</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Boutique Havelis & Desert Tents</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-paw"></i> Ranthambore Jeep Safari & Thar Desert Excursion</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Grand Palaces (Taj/Oberoi/Leela properties)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive VIP Guides & Private Boat Charters</li>
            <li><i class="fa-solid fa-utensils"></i> Exclusive Fine Dining & Palace Courtyard Dinners</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Grand Rajasthan Epic | 15 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="rajasthan-itinerary.php">Rajasthan</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">The Grand Epic (15D/14N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['rajasthan grand']) ? $tourImages['rajasthan grand'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 15 Days / 14 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Grand Rajasthan Epic</h1>
            <p>The ultimate 15-day royal expedition. Discover palaces, deserts, tigers, and painted havelis.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Rajasthan Grand Epic 15D/14N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>This is the definitive, all-encompassing tour of Rajasthan. Over 15 luxurious days, you will trace the complete historical loop of Rajputana. From the bustling Pink City of Jaipur to the painted frescoes of Mandawa, the camel trails of Bikaner, the golden dunes of Jaisalmer, the blue streets of Jodhpur, the romantic lakes of Udaipur, and the wild tiger jungles of Ranthambore. This perfectly paced journey ensures you experience the absolute best of India's most vibrant state.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in the Pink City (Jaipur)</h3>
                <p>Welcome to Rajasthan! Arrive at Jaipur Airport or Railway Station. Your luxury chauffeur will transfer you to your heritage hotel. Spend the evening visiting the spectacular Albert Hall Museum or enjoying an authentic Rajasthani cultural dinner at Chokhi Dhani.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Grandeur of Amber & Jaipur</h3>
                <p>Ascend the Aravalli hills to explore the magnificent Amber Fort. On your return, photograph the Jal Mahal (Water Palace). Spend the afternoon exploring the City Palace, the astronomical wonders of Jantar Mantar, and the iconic, intricately carved Hawa Mahal.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Jaipur to Mandawa (The Open Art Gallery)</h3>
                <p>Depart Jaipur for the Shekhawati region (approx. 3.5 hours). Arrive in Mandawa, a town globally renowned for its spectacular painted Havelis. Stroll through the streets to witness centuries-old frescoes depicting mythology, British officers, and ancient trades. Overnight in a heritage Haveli.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Mandawa to Bikaner (Camel Country)</h3>
                <p>Drive westward deeper into the desert to Bikaner (approx. 4 hours). In the afternoon, explore the formidable Junagarh Fort, a massive, unassailable fortress featuring beautiful palaces. Later, visit the National Research Centre on Camel to learn about the "Ships of the Desert."</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Bikaner to the Golden City (Jaisalmer)</h3>
                <p>Visit the unique Karni Mata (Rat) Temple in Deshnoke before embarking on a beautiful, arid drive across the Thar Desert to Jaisalmer (approx. 5 hours). Arrive in the late afternoon, check into your hotel, and enjoy a serene evening walk around Gadisar Lake.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Living Fort of Jaisalmer</h3>
                <p>Explore the magnificent Jaisalmer Fort, a UNESCO World Heritage site where a quarter of the city's population still resides. Wander through narrow lanes, visiting the intricately carved Patwon Ki Haveli and Nathmal Ki Haveli, marveling at the golden sandstone architecture.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> The Great Thar Desert Safari</h3>
                <p>Spend a relaxed morning in Jaisalmer. In the afternoon, drive to the Sam Sand Dunes. Embark on a thrilling 4x4 Jeep or camel safari across the sweeping dunes at sunset. Check into your luxury Swiss tent for an unforgettable evening of desert bonfires, Kalbelia folk music, and a starlit dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Desert to the Blue City (Jodhpur)</h3>
                <p>Wake up to a desert sunrise. After breakfast, depart for Jodhpur (approx. 5 hours). Arrive in the "Blue City," the historic capital of Marwar. Check into your premium property and spend the evening exploring the vibrant Sardar Market and the historic Clock Tower.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Mehrangarh Fort & Jaswant Thada</h3>
                <p>Explore the colossal Mehrangarh Fort, towering 400 feet above the city, offering panoramic views of the blue-painted houses. Walk through the Phool Mahal and visit Jaswant Thada, a brilliant white marble cenotaph. Afternoon at leisure.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Jodhpur to Udaipur via Ranakpur</h3>
                <p>Depart for the City of Lakes (approx. 5 hours). En route, stop deep in the Aravalli valleys to visit the Ranakpur Jain Temple, a true architectural wonder with 1,444 unique marble pillars. Arrive in the romantic city of Udaipur by late afternoon and check into your lakeside resort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> The Romantic Palaces of Udaipur</h3>
                <p>Explore the sprawling Udaipur City Palace, overlooking Lake Pichola. Visit the beautiful Saheliyon Ki Bari and the towering Jagdish Temple. Conclude the day with a mesmerizing sunset boat cruise on Lake Pichola, sailing past the iconic Taj Lake Palace.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> Udaipur to Pushkar via Chittorgarh</h3>
                <p>Drive to the holy city of Pushkar. Along the way, explore the legendary Chittorgarh Fort, the largest fort in India, echoing with tales of Rajput valor. Arrive in Pushkar by evening, visit the sacred Pushkar Lake and the rare Brahma Temple. Overnight in Pushkar.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Pushkar to Ranthambore National Park</h3>
                <p>After a peaceful morning in Pushkar, drive to Sawai Madhopur, the gateway to Ranthambore National Park (approx. 5 hours). Check into your wilderness lodge. Enjoy a relaxed evening preparing for tomorrow's exciting jungle safari.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 14</span> Tracking the Royal Bengal Tiger</h3>
                <p>Wake up before dawn for a thrilling morning jeep safari deep into the core zones of Ranthambore. Keep your cameras ready for tigers, leopards, and sloth bears amidst the ancient ruins. Return for lunch, and head out for a second afternoon safari to maximize your tracking chances.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 15</span> Departure from Jaipur / Delhi</h3>
                <p>Enjoy a final breakfast at your jungle lodge. Your chauffeur will drive you back to Jaipur (approx. 3.5 hours) or optionally to New Delhi, providing a seamless transfer to the airport or railway station, concluding your magnificent 15-day Rajasthan Epic.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Heritage Guesthouses</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the 15-Day Route</li>
                <li><i class="fa-solid fa-camera"></i> Standard Fort, Desert & Sightseeing Tours</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/rajasthan-grand-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- RAJASTHAN INSIGHTS HUB (6 GRID CARDS)                     -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Royal Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical insights to ensure your massive 15-day journey is seamless, comfortable, and culturally enriching.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time to Visit</h3>
                <p>The desert and jungle climate dictates the perfect travel window:</p>
                <ul>
                    <li><strong>Winter (Oct - Mar):</strong> The peak and perfect season. Warm, sunny days and cool, comfortable nights. Ideal for all 15 days.</li>
                    <li><strong>Important Note:</strong> Ranthambore National Park is closed during the monsoon (July to September). This itinerary must be modified if traveling during those months.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Temple Etiquette</h3>
                <p>Rajasthan is home to deeply sacred, active pilgrimage sites:</p>
                <ul>
                    <li><strong>Pushkar:</strong> A highly sacred town. The consumption of meat, alcohol, and eggs is strictly prohibited within the city limits.</li>
                    <li><strong>Ranakpur:</strong> This Jain temple has a strict dress code. Leather items (belts, shoes, wallets) must be left in the vehicle.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-camera"></i></div>
                <h3>Pacing & Walking</h3>
                <p>A 15-day trip requires stamina and good pacing:</p>
                <ul>
                    <li><strong>Fort Terrain:</strong> Forts like Mehrangarh and Chittorgarh require significant walking on steep, uneven stone ramps. Wear excellent, supportive footwear.</li>
                    <li><strong>Rest Days:</strong> We have built in lighter days (like in Pushkar and Mandawa) to ensure you do not suffer from "monument fatigue."</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Extensive Highway Travel</h3>
                <p>This massive loop covers over 1,500 kilometers:</p>
                <ul>
                    <li><strong>Vehicle Comfort:</strong> Because you will spend several days driving 4-5 hours, we strongly recommend upgrading to an SUV (Innova Crysta) for superior legroom and shock absorption.</li>
                    <li><strong>The Roads:</strong> The highways connecting the major cities are excellent and highly scenic, ranging from desert dunes to the lush Aravalli hills.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-paw"></i></div>
                <h3>Ranthambore Safari Logistics</h3>
                <p>Tiger tracking requires specific preparation:</p>
                <ul>
                    <li><strong>Advance Booking:</strong> Safari permits sell out months in advance. We must book your core zone tickets early to ensure the best tracking experience.</li>
                    <li><strong>Original IDs:</strong> You must carry the exact original ID (Passport/Aadhar) used for booking to enter the forest gates.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bag-shopping"></i></div>
                <h3>Royal Shopping</h3>
                <p>Pace your shopping across the different artisanal hubs:</p>
                <ul>
                    <li><strong>Jaipur:</strong> Precious gemstones, Kundan jewelry, and block-printed textiles.</li>
                    <li><strong>Jodhpur:</strong> Antiques, spices, and wooden handicrafts.</li>
                    <li><strong>Udaipur:</strong> Miniature Pichwai paintings and leather journals.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream royal escape to Rajasthan.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Rajasthan Grand Epic 15D/14N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>