<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Payments | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Payment Policy</h1>
        <p>100% secure, encrypted transactions.</p>
    </header>

    <main class="info-container">
        <h2>Accepted Methods</h2>
        <p>We utilize an enterprise-grade payment gateway to ensure your financial data is fully encrypted. We accept all major Credit Cards, Debit Cards, Net Banking, and UPI applications for seamless domestic and international transactions.</p>

        <h2>Tax Invoices & GST</h2>
        <p>Traveltara operates with complete financial transparency. Every successful booking instantly generates an official Tax Invoice sent directly to your email. All package prices quoted on our platform include the mandatory 18% Goods and Services Tax (GST).</p>

        <h2>Data Security</h2>
        <p>We do not store your sensitive credit card numbers or banking passwords on our servers. All transactions are routed directly through our secure, PCI-DSS compliant payment processing partners.</p>
    </main>

</body>
</html>