<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') { http_response_code(200); exit(); }
header("Content-Type: application/json");

// YOUR HOSTINGER DATABASE
$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) { die(json_encode(["status" => "error", "message" => "DB Failed"])); }

$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

if (!$data) { echo json_encode(["status" => "error", "message" => "Invalid Request"]); exit; }

$category = $conn->real_escape_string($data['category']);
$itemName = $conn->real_escape_string($data['itemName']);
$tourType = $conn->real_escape_string($data['tourType']);
$imageUrl = $conn->real_escape_string($data['imageUrl']);

// THE ROUTER: DECIDE WHICH TABLE TO USE
if ($category === 'destination_card' || $category === 'sub_destination' || $category === 'tour') {
    $sql = "INSERT INTO tours (place_name, tour_type, image_url) VALUES ('$itemName', '$tourType', '$imageUrl')";
} 
elseif ($category === 'blog_post' || $category === 'blog') {
    $sql = "INSERT INTO blogs (title, image_url) VALUES ('$itemName', '$imageUrl')";
} 
elseif ($category === 'home_banner' || $category === 'general_asset' || $category === 'home') {
    $sql = "INSERT INTO site_settings (setting_name, image_url) VALUES ('$itemName', '$imageUrl')";
} 
else {
    echo json_encode(["status" => "error", "message" => "Unknown Category"]); exit;
}

// EXECUTE THE SAVE
if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "DB Error: " . $conn->error]);
}

$conn->close();
?>