<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms & Conditions | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Terms & Conditions</h1>
        <p>The rules of the road.</p>
    </header>

    <main class="info-container">
        <h2>1. Booking & Agreement</h2>
        <p>By utilizing the Traveltara website and booking engine, you enter into a binding agreement with us. All bookings are subject to availability at the time of processing. The dynamic pricing quoted on our checkout page is estimated and secured only upon the generation of a confirmed Payment ID and Tax Invoice.</p>

        <h2>2. Payments & Pricing</h2>
        <p>All prices are listed in Indian Rupees (INR) and are inclusive of an 18% Goods and Services Tax (GST) unless explicitly stated otherwise. Traveltara reserves the right to amend pricing prior to final payment due to fluctuations in hotel tariffs, transport costs, or government taxes.</p>

        <h2>3. Guest Responsibilities</h2>
        <p>It is the primary responsibility of the guest to ensure all details entered during the booking process (Name, Contact, Aadhaar, Passport) are 100% accurate. Traveltara is not liable for boarding denials, hotel rejections, or itinerary disruptions caused by incorrect identity documentation provided by the guest.</p>

        <h2>4. Force Majeure</h2>
        <p>Traveltara shall not be held liable for any delays, alterations, or cancellations of itineraries caused by natural disasters, severe weather, political unrest, pandemics, or any other circumstances beyond our direct control (Force Majeure).</p>
    </main>

</body>
</html>