<?php
// Top of package-rajasthan-classic.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹28,500"; 
$sheet_affordable_price = "₹42,000";
$sheet_super_price = "₹68,000";

// EXACT package name from Google Sheet
$target_package = "Classic Heritage 10D/9N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Heritage Guesthouses</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Route</li>
            <li><i class="fa-solid fa-camera"></i> Standard Fort & Palace Sightseeing</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Boutique Havelis</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> Guided Pushkar Walk & Lake Pichola Boat Ride</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Grand Palaces (Taj/Oberoi/Leela properties)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive VIP Guide Access at Mehrangarh & Amber</li>
            <li><i class="fa-solid fa-utensils"></i> Exclusive Fine Dining & Palace Courtyard Dinners</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Classic Heritage 10 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="rajasthan-itinerary.php">Rajasthan</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">The Classic Heritage (10D/9N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Height for faster scrolling) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['jaipur hero']) ? $tourImages['jaipur hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 10 Days / 9 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Classic Heritage</h1>
            <p>A beautifully unhurried journey through the Pink, Blue, and White cities of Rajputana.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Classic Heritage 10D/9N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Designed for true immersion rather than rushing, this 10-day Classic Heritage route explores the soul of Rajasthan. You will spend ample time discovering the vibrant bazaars of the Pink City (Jaipur), witness the serene spirituality of Pushkar, explore the colossal Mehrangarh Fort in the Blue City (Jodhpur), marvel at the Great Wall of India (Kumbhalgarh), and conclude with three relaxed days in the romantic City of Lakes (Udaipur).</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in the Pink City (Jaipur)</h3>
                <p>Arrive at Jaipur International Airport or Railway Station. Your luxury chauffeur will warmly welcome you and transfer you to your premium heritage property. Spend a relaxed evening visiting the magnificent Albert Hall Museum, or opt for an authentic Rajasthani dinner experience at a cultural village resort like Chokhi Dhani.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Grandeur of Amber & Jaipur Palaces</h3>
                <p>After a lavish breakfast, take a scenic drive out of the city center to the majestic Amber Fort, nestled in the Aravalli hills. Enjoy an elephant or jeep ride to the courtyard. En route back, photograph the beautiful Jal Mahal (Water Palace) floating in Man Sagar Lake. In the afternoon, explore the City Palace and the intricately carved facade of the Hawa Mahal (Palace of Winds).</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Jaipur Local Flavors & Sunset Vistas</h3>
                <p>Experience Jaipur like a local. Visit the UNESCO-listed Jantar Mantar observatory. Spend the afternoon exploring the vibrant Johari Bazaar and Bapu Bazaar, world-famous for Kundan jewelry and block-printed textiles. In the late afternoon, drive up to Nahargarh Fort for a breathtaking, panoramic sunset view over the entire Pink City.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Jaipur to the Holy City of Pushkar</h3>
                <p>Depart Jaipur for the serene, spiritual town of Pushkar (approx. 3 hours). En route, you may opt to visit the revered Ajmer Sharif Dargah. Upon reaching Pushkar, check into your boutique resort. Walk down to the holy Pushkar Lake, surrounded by 52 bathing ghats, and visit the rare Brahma Temple—one of the only temples in the world dedicated to Lord Brahma.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Pushkar to the Blue City (Jodhpur)</h3>
                <p>After a peaceful morning breakfast, depart for Jodhpur (approx. 4-5 hours). Arrive in the "Blue City," historically the capital of the Marwar kingdom, and check into your hotel. Spend your evening exploring the lively Sardar Market and the historic Ghanta Ghar (Clock Tower), renowned for its authentic spices and textiles.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Mehrangarh Fort & Jaswant Thada</h3>
                <p>Dedicate today to Jodhpur's architectural marvels. Visit the colossal Mehrangarh Fort, towering majestically above the blue-painted houses. Walk through its intricately decorated palaces like the Phool Mahal (Flower Palace). Next, visit Jaswant Thada, a brilliant white marble cenotaph often called the "Taj Mahal of Marwar," built in memory of Maharaja Jaswant Singh II.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Jodhpur to Kumbhalgarh (The Great Wall)</h3>
                <p>Leave the arid plains of Jodhpur and drive toward the lush Aravalli ranges (approx. 4 hours). Arrive at Kumbhalgarh and check into your nature resort. In the afternoon, explore the massive Kumbhalgarh Fort, a UNESCO World Heritage site featuring the second-longest continuous wall in the world (36 km long). Stay for the captivating evening sound and light show.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Kumbhalgarh to Udaipur via Ranakpur</h3>
                <p>Depart for the City of Lakes. En route, stop deep within a forested valley to visit the Ranakpur Jain Temple, a true architectural wonder supported by ,1444 uniquely carved marble pillars. Arrive in the deeply romantic city of Udaipur by late afternoon. Check into your lakeside resort and relax.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> The Romantic City of Lakes</h3>
                <p>Spend a leisurely day exploring Udaipur. Visit the sprawling City Palace complex overlooking Lake Pichola. Wander through the exquisitely landscaped Saheliyon Ki Bari (Garden of the Maidens) and visit the towering Jagdish Temple. Conclude your epic 10-day journey with a mesmerizing sunset boat cruise on Lake Pichola, sailing past the iconic Taj Lake Palace.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Departure from Udaipur</h3>
                <p>Enjoy a final, unhurried royal breakfast. Depending on your flight or train schedule, you may do some last-minute shopping for exquisite miniature paintings. Your chauffeur will provide a seamless transfer to the Maharana Pratap Airport or Udaipur Railway Station for your journey home.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Heritage Guesthouses</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Route</li>
                <li><i class="fa-solid fa-camera"></i> Standard Fort & Palace Sightseeing</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/rajasthan-classic-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- RAJASTHAN INSIGHTS HUB (6 GRID CARDS)                     -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Royal Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical insights to ensure your journey through the land of kings is seamless, comfortable, and culturally enriching.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time to Visit</h3>
                <p>The desert climate dictates the perfect travel window:</p>
                <ul>
                    <li><strong>Winter (Oct - Mar):</strong> The peak and perfect season. Warm, sunny days and cool, comfortable nights.</li>
                    <li><strong>Summer (Apr - Jun):</strong> Searing heat often exceeding 45°C. Sightseeing is severely restricted to early mornings.</li>
                    <li><strong>Monsoon (Jul - Sep):</strong> A beautiful, offbeat time for Udaipur and Kumbhalgarh, which turn wonderfully green and lush.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Temple Etiquette</h3>
                <p>Rajasthan is home to deeply sacred, active pilgrimage sites:</p>
                <ul>
                    <li><strong>Pushkar:</strong> A highly sacred town. The consumption of meat, alcohol, and eggs is strictly prohibited within the city limits.</li>
                    <li><strong>Ranakpur:</strong> This Jain temple has a strict dress code (shoulders and knees covered). Leather items (belts, shoes, wallets) must be left in the vehicle.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-camera"></i></div>
                <h3>Monument Realities</h3>
                <p>Exploring these massive forts requires pacing:</p>
                <ul>
                    <li><strong>Lots of Walking:</strong> Forts like Mehrangarh and Kumbhalgarh require significant walking on steep, uneven stone ramps. Wear comfortable, supportive footwear.</li>
                    <li><strong>Guide Services:</strong> We highly recommend utilizing the official, certified audio guides or human guides at major forts to truly understand the history.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Highway Travel</h3>
                <p>This 10-day itinerary balances city stays with beautiful drives:</p>
                <ul>
                    <li><strong>The Roads:</strong> The highways connecting Jaipur, Ajmer, and Jodhpur are among the best in India, ensuring smooth driving.</li>
                    <li><strong>Aravalli Hills:</strong> The drive from Jodhpur through Kumbhalgarh to Udaipur winds through the Aravalli mountains. Keep motion sickness medication handy if needed.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bag-shopping"></i></div>
                <h3>Royal Shopping</h3>
                <p>Each city in Rajasthan has its own unique artisanal specialty:</p>
                <ul>
                    <li><strong>Jaipur:</strong> The global capital for precious gemstones, Kundan jewelry, and block-printed textiles (block prints).</li>
                    <li><strong>Jodhpur:</strong> Famous for beautifully crafted wooden furniture, antiques, and authentic spices.</li>
                    <li><strong>Udaipur:</strong> Renowned for the finest miniature paintings on silk, paper, and camel bone.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Delights</h3>
                <p>Rajput cuisine is rich, fiery, and deeply flavorful:</p>
                <ul>
                    <li><strong>Dal Baati Churma:</strong> The quintessential Rajasthani vegetarian dish. Hard wheat rolls served with lentil curry and sweet crushed wheat.</li>
                    <li><strong>Laal Maas:</strong> A fiery, smoky mutton curry prepared with special Mathania red chilies—a must-try for non-vegetarians.</li>
                    <li><strong>Ghevar:</strong> A famous local sweet, especially popular in Jaipur.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream royal escape to Rajasthan.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Classic Heritage 10D/9N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>