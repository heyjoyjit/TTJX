<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Full Madhya Pradesh - 14 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="madhya-pradesh-itinerary.php">Madhya Pradesh Packages</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Full Madhya Pradesh (14D/13N)</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/mp-full.jpg') center/cover;">
        <div class="subpage-hero-content">
            <h1>Full Madhya Pradesh</h1>
            <p>14 Days / 13 Nights of the Ultimate Central India Circuit</p>
        </div>
    </header>

    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>The definitive statewide circuit built entirely for the smart traveler. Experience the incredible diversity of Madhya Pradesh—from the carved temples of Khajuraho and the jungles of Bandhavgarh to the street food of Indore—utilizing comfortable, authentic budget homestays and economical guesthouses throughout.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Gwalior</h3>
                <p>Arrive in Gwalior. Check into your clean, economical guesthouse. Spend the afternoon exploring the massive Gwalior Fort and the Sas Bahu Temple. Enjoy local street chaat in the evening.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Gwalior to Orchha</h3>
                <p>Take an affordable shared transport or local train to Orchha. Check into a traditional, budget-friendly homestay near the Betwa River. Explore the Orchha Fort complex and Ram Raja Temple.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Orchha to Khajuraho</h3>
                <p>Travel to the UNESCO World Heritage site of Khajuraho. Check into a backpacker-friendly lodge. Spend the afternoon marveling at the intricate carvings of the Western Group of Temples.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Panna Excursion</h3>
                <p>Take a short budget trip to nearby Panna National Park. Enjoy the cascading Raneh Falls and an affordable jeep safari through the reserve. Return to Khajuraho for the night.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Khajuraho to Bandhavgarh</h3>
                <p>Travel deep into tiger country. Check into a basic but cozy eco-lodge on the outskirts of Bandhavgarh National Park. Relax around the campfire and share stories with fellow travelers.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Bandhavgarh to Jabalpur</h3>
                <p>Enjoy a morning safari to spot Royal Bengal Tigers. After lunch, transfer to Jabalpur. Check into a local guesthouse and visit the stunning Dhuandhar Falls and Marble Rocks at Bhedaghat.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Jabalpur to Pachmarhi</h3>
                <p>Drive winding roads to the hill station of Pachmarhi. Settle into a budget-friendly heritage cottage. Enjoy the cool climate and explore the local market.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Pachmarhi Exploration</h3>
                <p>Spend a full day enjoying nature. Trek to Bee Falls, explore the Pandav Caves, and hike up to Dhoopgarh for a magnificent, cost-free panoramic sunset.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Pachmarhi to Bhopal</h3>
                <p>Travel to the City of Lakes, Bhopal. Stop en route to explore the ancient Buddhist monuments at Sanchi Stupa. Check into a smart city guesthouse in Bhopal.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Bhopal Sightseeing</h3>
                <p>Visit the prehistoric cave paintings at Bhimbetka. In the evening, enjoy a budget-friendly boat ride on the Upper Lake and explore the vibrant Chowk Bazaar.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Bhopal to Ujjain</h3>
                <p>Travel to the holy city of Ujjain. Check into an affordable Dharamshala or guesthouse near the ghats. Witness the mesmerizing evening Aarti on the banks of the Shipra River.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> Ujjain to Indore</h3>
                <p>Attend the early morning Bhasma Aarti at Mahakaleshwar. Travel to Indore in the afternoon. Check into your budget stay and immediately hit Sarafa Bazaar for a legendary, low-cost street food dinner.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Mandu Excursion</h3>
                <p>Take a day trip to the ruined fortress city of Mandu. Explore Jahaz Mahal and the romantic pavilions of Roopmati. Return to Indore for your final night in Madhya Pradesh.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 14</span> Departure</h3>
                <p>Enjoy a local breakfast of hot Poha and Jalebi before heading to the Indore Airport or Railway Station for your journey home.</p>
            </div>
        </div>

        <aside class="itinerary-sidebar">
            <div class="sidebar-price-box">
                <span class="price-label">Starting From</span>
                <div class="price-amount">₹27,500<span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list">
                <li><i class="fa-solid fa-bed"></i> Budget Guesthouses & Homestays</li>
                <li><i class="fa-solid fa-bus"></i> Mix of Private & Shared Transport</li>
                <li><i class="fa-solid fa-utensils"></i> Authentic Local Food & Dhabas</li>
                <li><i class="fa-solid fa-wallet"></i> High-Value Economy Focus</li>
            </ul>
            
            <hr class="sidebar-divider">
            
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/mp-full-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>

     <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, Madhya Pradesh, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">Internation</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/917439877604" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

    <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>
        
    </div>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Speak with a Travel Expert</h3>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Madhya Pradesh Packages" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>