<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Destinations | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        
        <div class="menu-toggle" id="mobile-menu">
            <i class="fa-solid fa-bars"></i>
        </div>

        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        
        <div class="nav-contact" id="navContact">
            <i class="fa-solid fa-phone"></i> +91 9477709755
        </div>
    </nav>

   <section class="utility-bar">
    <div class="utility-container">
        
        <div class="search-row">
            <form id="destPageSearchForm" class="dest-search-form">
                <i class="fa-solid fa-location-dot search-icon"></i>
                <input type="text" id="destSearchInput" placeholder="Search..." autocomplete="off">
                
                <button type="button" id="mobileViewToggle" class="mobile-view-btn" title="Change View">
                    <i class="fa-solid fa-border-all"></i>
                </button>

                <button type="button" id="mobileFilterToggle" class="filter-funnel-btn" title="Toggle Filters">
                    <i class="fa-solid fa-filter"></i>
                </button>

                <button type="submit" class="btn-primary search-btn">
                    <span class="search-btn-text">Search</span>
                    <i class="fa-solid fa-magnifying-glass search-btn-icon"></i>
                </button>

                <div id="destSearchSuggestions" class="search-suggestions"></div>
            </form>
        </div>

        <div id="advancedFiltersContainer" class="advanced-filters">
            
            <div class="filter-header-mobile">
                <span style="font-family: 'Playfair Display', serif; font-weight: bold; font-size: 1.2rem; color: #222;">Filters</span>
                <button id="resetFiltersBtn" class="reset-btn">
                    <i class="fa-solid fa-rotate-right"></i> Reset
                </button>
            </div>

            <div class="filter-group-wrap">
                <div class="filter-group">
                    <span class="filter-label">Vibe:</span>
                    <select id="vibeFilter" class="filter-select">
                        <option value="all">Any Vibe</option>
                        <option value="mountain">Mountains & Snow</option>
                        <option value="heritage">Royalty & Heritage</option>
                        <option value="nature">Nature & Spa</option>
                        <option value="city">City Escapes</option>
                        <option value="coastal">Coastal & Beaches</option>
                    </select>
                </div>

                <div class="filter-group">
                    <span class="filter-label">Budget:</span>
                    <select id="budgetFilter" class="filter-select">
                        <option value="all">Any Budget</option>
                        <option value="under-20">Under ₹20,000</option>
                        <option value="20-40">₹20,000 - ₹40,000</option>
                        <option value="above-40">Above ₹40,000</option>
                    </select>
                </div>

                <div class="filter-group">
                    <span class="filter-label">Sort by:</span>
                    <select id="sortFilter" class="filter-select">
                        <option value="relevance">Relevance</option>
                        <option value="price-low">Cost: Low to High</option>
                        <option value="price-high">Cost: High to Low</option>
                        <option value="az">Name: A to Z</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="toggle-container">
    <div class="toggle-switch">
        <input type="radio" id="toggle-domestic" name="dest-type" value="domestic" checked>
        <label for="toggle-domestic">Domestic</label>

        <input type="radio" id="toggle-international" name="dest-type" value="international">
        <label for="toggle-international">International</label>
        
        <div class="toggle-slider"></div>
    </div>
</div>

    <section class="section-padding" style="padding-top: 0;">
        <div class="grid-container" id="destGrid" style="transition: all 0.3s ease;">
            
           <div class="destination-card dest-item" data-category="city" data-region="domestic" data-name="kashmir" data-price="14000">
                <div class="card-image bg-delhi" style="background: url('<?php echo isset($tourImages['kashmir']) ? $tourImages['kashmir'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Kashmir</h3>
                    <p>Discover the pristine valleys, serene lakes, and snow-capped peaks of Kashmir.</p>
                    <a href="kashmir-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="mountain" data-region="domestic" data-name="himachal pradesh pine valley snow" data-price="28000">
                <div class="card-image bg-himachal" style="background: url('<?php echo isset($tourImages['himachal pradesh']) ? $tourImages['himachal pradesh'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Himachal Pradesh</h3>
                    <p>Cozy pine retreats and majestic snow-capped valleys.</p>
                    <a href="himachal-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>
            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="char dham yatra spiritual kedarnath badrinath luxury helicopter" data-price="55000">
                <div class="card-image bg-chardham" style="background: url('<?php echo isset($tourImages['char dham']) ? $tourImages['char dham'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Char Dham</h3>
                    <p>Embark on a divine journey with exclusive VIP darshans, premium serene stays, and seamless helicopter transfers.</p>
                    <a href="package-chardham.php" class="btn-outline">Explore package</a>
                </div>
            </div>

           <div class="destination-card dest-item" data-category="mountains" data-region="domestic" data-name="uttarakhand himalayas mountains nature" data-price="18000">
                <div class="card-image bg-uttarakhand" style="background: url('<?php echo isset($tourImages['uttarakhand']) ? $tourImages['uttarakhand'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Uttarakhand</h3>
                    <p>Majestic Himalayan peaks, bespoke spiritual retreats, and serene mountain getaways.</p>
                    <a href="uttarakhand-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="golden punjab amritsar luxury royal" data-price="32000">
                <div class="card-image bg-goldenpunjab" style="background: url('<?php echo isset($tourImages['golden punjab']) ? $tourImages['golden punjab'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Golden Punjab</h3>
                    <p>A majestic VIP journey through the Golden Temple, royal palaces, and the ultra-luxurious essence of Punjab.</p>
                    <a href="punjab-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="varanasi spiritual heritage ganges" data-price="12000">
                <div class="card-image bg-varanasi" style="background: url('<?php echo isset($tourImages['varanasi']) ? $tourImages['varanasi'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Varanasi</h3>
                    <p>The spiritual heart of India, ancient ghats, and mesmerizing VIP Ganga Aarti experiences.</p>
                    <a href="package-varanasi.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="rajasthan desert fort palaces" data-price="45000">
                <div class="card-image bg-rajasthan" style="background: url('<?php echo isset($tourImages['rajasthan']) ? $tourImages['rajasthan'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Rajasthan</h3>
                    <p>Live like royalty in heritage forts and desert luxury camps.</p>
                    <a href="rajasthan-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="gujarat heritage desert culture" data-price="16000">
                <div class="card-image bg-gujarat" style="background: url('<?php echo isset($tourImages['gujarat']) ? $tourImages['gujarat'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Gujarat</h3>
                    <p>The magnificent White Desert, private Asiatic lion safaris, and vibrant cultural richness.</p>
                    <a href="gujarat-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="madhya pradesh mp heart of india wildlife budget" data-price="6500">
                <div class="card-image bg-mp" style="background: url('<?php echo isset($tourImages['madhya pradesh']) ? $tourImages['madhya pradesh'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Madhya Pradesh</h3>
                    <p>Explore the Heart of India, featuring thrilling tiger safaris, ancient forts, and vibrant street food.</p>
                    <a href="madhya-pradesh-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="coastal" data-region="domestic" data-name="goa south coastal luxury beach" data-price="25000">
                <div class="card-image bg-goa" style="background: url('<?php echo isset($tourImages['goa']) ? $tourImages['goa'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Goa</h3>
                    <p>Exclusive South Goa luxury resorts, private beaches, and tropical relaxation.</p>
                    <a href="goa-itenary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="mountain" data-region="domestic" data-name="north bengal darjeeling tea toy train" data-price="15000">
                <div class="card-image bg-nbengal" style="background: url('<?php echo isset($tourImages['north bengal']) ? $tourImages['north bengal'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>North Bengal</h3>
                    <p>Tea estates, toy trains, and heritage colonial stays.</p>
                    <a href="north-bengal-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="nature" data-region="domestic" data-name="purulia eco nature red soil chau" data-price="12000">
                <div class="card-image bg-purulia" style="background: url('<?php echo isset($tourImages['purulia']) ? $tourImages['purulia'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Purulia</h3>
                    <p>Experience the rustic luxury of Purulia with bespoke eco-resorts, serene lakes, and vibrant Chau dance performances.</p>
                    <a href="package-purulia.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="bankura bishnupur terracotta heritage" data-price="14000">
                <div class="card-image bg-bankura" style="background: url('<?php echo isset($tourImages['bankura']) ? $tourImages['bankura'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Bankura</h3>
                    <p>Discover terracotta artistry in absolute luxury. Explore ancient Bishnupur temples while staying in premium heritage properties.</p>
                    <a href="package-bankura.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="shanti niketan tagore culture art" data-price="16000">
                <div class="card-image bg-shantiniketan" style="background: url('<?php echo isset($tourImages['shanti niketan']) ? $tourImages['shanti niketan'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Shanti Niketan</h3>
                    <p>Immerse yourself in Tagore's poetic legacy with exclusive boutique stays and personalized cultural tours.</p>
                    <a href="package-shantiniketan.php" class="btn-outline">Explore package</a>
                </div>
            </div>
            <div class="destination-card dest-item" data-category="nature" data-region="domestic" data-name="daringbadi odisha nature hill station luxury" data-price="14000">
                <div class="card-image bg-daringbadi" style="background: url('<?php echo isset($tourImages['daringbadi']) ? $tourImages['daringbadi'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Daringbadi</h3>
                    <p>Discover the 'Kashmir of Odisha' with premium eco-retreats, private pine forest trails, and serene coffee plantations.</p>
                    <a href="package-daringbadi.php" class="btn-outline">Explore package</a>
                </div>
            </div>
            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="odisha heritage temples coastal" data-price="15000">
                <div class="card-image bg-odisha" style="background: url('<?php echo isset($tourImages['odisha']) ? $tourImages['odisha'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Odisha</h3>
                    <p>Ancient sun temples, pristine eastern coastlines, and rich cultural heritage.</p>
                    <a href="odisha-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="madhubani bihar heritage art culture mithila" data-price="12000">
                <div class="card-image bg-madhubani" style="background: url('<?php echo isset($tourImages['madhubani']) ? $tourImages['madhubani'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Madhubani</h3>
                    <p>Immerse yourself in Mithila's vibrant artistic heritage with exclusive cultural tours and boutique artisan stays.</p>
                    <a href="package-madhubani.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="mountain" data-region="domestic" data-name="sikkim himalayan" data-price="25000">
                <div class="card-image bg-sikkim" style="background: url('<?php echo isset($tourImages['sikkim']) ? $tourImages['sikkim'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Sikkim</h3>
                    <p>Alpine lakes, monasteries, and unparalleled Himalayan luxury.</p>
                    <a href="sikkim-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="nature" data-region="domestic" data-name="assam tea wildlife rhino nature" data-price="24000">
                <div class="card-image bg-assam" style="background: url('<?php echo isset($tourImages['assam']) ? $tourImages['assam'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Assam</h3>
                    <p>Bespoke tea estate retreats, private Brahmaputra river cruises, and exclusive one-horned rhino safaris.</p>
                    <a href="assam-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="karnataka explorer mysore hampi wildlife" data-price="35000">
                <div class="card-image bg-karnataka" style="background: url('<?php echo isset($tourImages['karnataka explorer']) ? $tourImages['karnataka explorer'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Karnataka Explorer</h3>
                    <p>From the royal palaces of Mysore to the luxury wilderness of Kabini and ancient ruins of Hampi.</p>
                    <a href="karnataka-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="coastal" data-region="domestic" data-name="kerala backwaters luxury nature" data-price="22000">
                <div class="card-image bg-kerala" style="background: url('<?php echo isset($tourImages['kerala']) ? $tourImages['kerala'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Kerala</h3>
                    <p>Tranquil backwaters, exclusive luxury houseboats, and lush green spice plantations.</p>
                    <a href="kerala-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="nature" data-region="domestic" data-name="munnar kerala nature spa south tea" data-price="22000">
                <div class="card-image bg-munnar" style="background: url('<?php echo isset($tourImages['munnar']) ? $tourImages['munnar'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Munnar</h3>
                    <p>Tranquil southern spice gardens and emerald tea hills.</p>
                    <a href="package-kerala-munnar.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="heritage" data-region="domestic" data-name="tamil heritage temples chettinad culture" data-price="28000">
                <div class="card-image bg-tamil" style="background: url('<?php echo isset($tourImages['tamil heritage']) ? $tourImages['tamil heritage'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Tamil Heritage</h3>
                    <p>A curated journey through magnificent Dravidian temples, rich classical arts, and luxury Chettinad mansions.</p>
                    <a href="tamil-nadu-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="nature" data-region="domestic" data-name="eastghats andhra hills nature araku" data-price="20000">
                <div class="card-image bg-eastghats" style="background: url('<?php echo isset($tourImages['eastghats andhra']) ? $tourImages['eastghats andhra'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Eastghats Andhra</h3>
                    <p>Uncharted luxury in the Eastern Ghats. Pristine valleys, exclusive tribal heritage, and serene coffee plantations.</p>
                    <a href="andhra-pradesh-itinerary.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="coastal" data-region="domestic" data-name="andaman islands luxury beach scuba" data-price="35000">
                <div class="card-image bg-andaman" style="background: url('<?php echo isset($tourImages['andaman']) ? $tourImages['andaman'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Andaman</h3>
                    <p>Pristine white sand beaches, crystal clear waters, and premium island resorts.</p>
                    <a href="package-andaman-complete.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="coastal" data-region="domestic" data-name="lakshadweep islands pristine coral atolls" data-price="38500">
                <div class="card-image bg-lakshadweep" style="background: url('<?php echo isset($tourImages['lakshadweep']) ? $tourImages['lakshadweep'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Lakshadweep</h3>
                    <p>Exclusive coral atolls, turquoise lagoons, and untouched marine sanctuaries.</p>
                    <a href="package-lakshadweep-6d.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="city" data-region="international" data-name="dubai uae desert safari luxury" data-price="55000">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['dubai']) ? $tourImages['dubai'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Dubai</h3>
                    <p>Explore the dunes and modern luxury of the UAE.</p>
                    <a href="package-dubai-6d.ph" class="btn-outline">View Itinerary</a>
                </div>
            </div>
            <div class="destination-card dest-item" data-category="mountain" data-region="international" data-name="switzerland" data-price="125000">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['switzerland']) ? $tourImages['switzerland'] : $fallbackImg; ?>') center/cover;"></div>
                
                <div class="card-content">
                    <h3>Switzerland</h3>
                    <p>Experience the pinnacle of alpine luxury, from snow-capped peaks to serene lakes.</p>
                    <a href="switzerland.php" class="btn-outline">Explore package</a>
                </div>
            </div>
            
            <div class="destination-card dest-item" data-category="culture" data-region="international" data-name="vietnam" data-price="85000">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['vietnam']) ? $tourImages['vietnam'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Vietnam</h3>
                    <p>Sail through Ha Long Bay and explore the rich, lantern-lit history of Hoi An.</p>
                    <a href="package-vietnam-13d.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="beach" data-region="international" data-name="thailand" data-price="75000">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['thailand']) ? $tourImages['thailand'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Thailand</h3>
                    <p>Experience premium island hopping, private beach villas, and vibrant Bangkok nightlife.</p>
                    <a href="thailand.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="nature" data-region="international" data-name="sri lanka" data-price="65000">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['sri lanka']) ? $tourImages['sri lanka'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Sri Lanka</h3>
                    <p>Discover emerald tea plantations, ancient ruins, and exclusive Indian Ocean resorts.</p>
                    <a href="srilanka.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="city" data-region="international" data-name="paris" data-price="135000">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['paris']) ? $tourImages['paris'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Paris</h3>
                    <p>The epitome of romance. Enjoy private Louvre tours and Michelin-star dining by the Seine.</p>
                    <a href="paris.php" class="btn-outline">Explore package</a>
                </div>
            </div>

            <div class="destination-card dest-item" data-category="culture" data-region="international" data-name="italy" data-price="145000">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['italy']) ? $tourImages['italy'] : $fallbackImg; ?>') center/cover;"></div>
                <div class="card-content">
                    <h3>Italy</h3>
                    <p>From the Amalfi Coast to Tuscan vineyards, taste the absolute pinnacle of European luxury.</p>
                    <a href="italy.php" class="btn-outline">Explore package</a>
                </div>
            </div>
            

        </div>
        
        <div id="noDestResults" style="display: none; text-align: center; padding: 60px 20px; color: #666;">
            <i class="fa-regular fa-compass" style="font-size: 3rem; margin-bottom: 15px; color: #ccc;"></i>
            <h3>No matching destinations found.</h3>
            <p>Adjust your filters or let us build a custom trip for you!</p>
            <button class="btn-primary" onclick="openLeadPopup()" style="margin-top: 15px;">Build Custom Trip</button>
        </div>
    </section>

    <section class="stats-banner" style="margin-top: 0;">
        <div style="max-width: 800px; margin: auto;">
            <h2>Looking for something else?</h2>
            <p style="margin-bottom: 20px;">Our experts can build a custom itinerary for anywhere in India.</p>
            <button class="btn-primary" onclick="openLeadPopup()">Request Custom Trip</button>
        </div>
    </section>
    <section class="infinity-ad-section">
    <div class="marquee-wrapper">
        <button class="strip-btn left-btn" id="stripSlideLeft"><i class="fa-solid fa-chevron-left"></i></button>
        
        <div class="marquee-track" id="suggestionTrack">
            
            <a href="kashmir-4-day.php" class="promo-card">
                <div class="strip-img" style="background-image: url('assets/kashmir-main.jpg');">
                    <span class="promo-badge offer-badge">Early Bird - 25% Off</span>
                </div>
                <div class="strip-info">
                    <span class="promo-subtitle">KASHMIR GETAWAY</span>
                    <h3>Heaven on Earth</h3>
                    <div class="promo-footer">
                        <div class="promo-price"><span class="price-label">Starts at</span><span class="price-amount">₹18,500</span></div>
                        <div class="promo-cta">Book Now <i class="fa-solid fa-arrow-right"></i></div>
                    </div>
                </div>
            </a>

            <a href="rajasthan-7-day.php" class="promo-card">
                <div class="strip-img" style="background-image: url('assets/rajasthan-main.jpg');">
                    <span class="promo-badge exclusive-badge">Heritage Luxury</span>
                </div>
                <div class="strip-info">
                    <span class="promo-subtitle">RAJASTHAN</span>
                    <h3>Palaces of Mewar</h3>
                    <div class="promo-footer">
                        <div class="promo-price"><span class="price-label">Starts at</span><span class="price-amount">₹42,000</span></div>
                        <div class="promo-cta">Discover <i class="fa-solid fa-arrow-right"></i></div>
                    </div>
                </div>
            </a>

            <a href="vietnam-6-day.php" class="promo-card">
                <div class="strip-img" style="background-image: url('assets/vietnam-main.jpg');">
                    <span class="promo-badge signature-badge">Trending Overseas</span>
                </div>
                <div class="strip-info">
                    <span class="promo-subtitle">VIETNAM</span>
                    <h3>Golden Hands Bridge</h3>
                    <div class="promo-footer">
                        <div class="promo-price"><span class="price-label">Starts at</span><span class="price-amount">₹65,000</span></div>
                        <div class="promo-cta">Explore <i class="fa-solid fa-arrow-right"></i></div>
                    </div>
                </div>
            </a>

            <a href="kerala-6-day.php" class="promo-card">
                <div class="strip-img" style="background-image: url('assets/kerala-main.jpg');">
                    <span class="promo-badge offer-badge">Monsoon Special</span>
                </div>
                <div class="strip-info">
                    <span class="promo-subtitle">KERALA</span>
                    <h3>Backwaters Retreat</h3>
                    <div class="promo-footer">
                        <div class="promo-price"><span class="price-label">Starts at</span><span class="price-amount">₹24,000</span></div>
                        <div class="promo-cta">Book Now <i class="fa-solid fa-arrow-right"></i></div>
                    </div>
                </div>
            </a>

            <a href="andaman-5-day.php" class="promo-card">
                <div class="strip-img" style="background-image: url('assets/andaman-main.jpg');">
                    <span class="promo-badge exclusive-badge">Bestseller</span>
                </div>
                <div class="strip-info">
                    <span class="promo-subtitle">ANDAMAN ISLANDS</span>
                    <h3>Havelock Escape</h3>
                    <div class="promo-footer">
                        <div class="promo-price"><span class="price-label">Starts at</span><span class="price-amount">₹32,500</span></div>
                        <div class="promo-cta">Discover <i class="fa-solid fa-arrow-right"></i></div>
                    </div>
                </div>
            </a>

            <a href="thailand-5-day.php" class="promo-card">
                <div class="strip-img" style="background-image: url('assets/thailand-main.jpg');">
                    <span class="promo-badge offer-badge">Flash Sale - 15% Off</span>
                </div>
                <div class="strip-info">
                    <span class="promo-subtitle">THAILAND</span>
                    <h3>Phuket Pool Villa</h3>
                    <div class="promo-footer">
                        <div class="promo-price"><span class="price-label">Starts at</span><span class="price-amount">₹55,000</span></div>
                        <div class="promo-cta">Book Now <i class="fa-solid fa-arrow-right"></i></div>
                    </div>
                </div>
            </a>

            <a href="himachal-7-day.php" class="promo-card">
                <div class="strip-img" style="background-image: url('assets/himachal-main.jpg');">
                    <span class="promo-badge signature-badge">Family Favorite</span>
                </div>
                <div class="strip-info">
                    <span class="promo-subtitle">HIMACHAL PRADESH</span>
                    <h3>Shimla & Manali</h3>
                    <div class="promo-footer">
                        <div class="promo-price"><span class="price-label">Starts at</span><span class="price-amount">₹28,000</span></div>
                        <div class="promo-cta">Explore <i class="fa-solid fa-arrow-right"></i></div>
                    </div>
                </div>
            </a>

        </div>

        <button class="strip-btn right-btn" id="stripSlideRight"><i class="fa-solid fa-chevron-right"></i></button>
    </div>
</section>

    <footer class="site-footer">
        <div class="footer-grid">
            
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a>
                <a href="#">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="#">Career</a>
            </div>
            
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="#">Travel Guidelines</a>
            </div>
            
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
            
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>
     <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>
        
    </div>

    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *">
                </div>
                
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <script src="js/main.js"></script>
</body>
</html>