<?php
// db.php - The Master Connection File
$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Database connection failed. Please try again later.");
}

// 🚀 FORCE INDIAN STANDARD TIME (IST) FOR ALL TIMESTAMPS
date_default_timezone_set('Asia/Kolkata');
$conn->query("SET time_zone = '+05:30'");
?>