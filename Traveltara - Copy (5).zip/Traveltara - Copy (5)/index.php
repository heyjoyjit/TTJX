<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>traveltara | Luxury Tailored Journeys</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
    <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
    
    <div class="menu-toggle" id="mobile-menu">
        <i class="fa-solid fa-bars"></i>
    </div>
    
    <div class="nav-links" id="navLinks">
        <a href="index.php" class="nav-item">Home</a>
        <a href="destinations.php" class="nav-item">Destinations</a>
        <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
        <a href="blog.php" class="nav-item">Blog</a>

        <!-- 🚨 NEW: This entire block is strictly for Mobile 🚨 -->
        <div class="mobile-only-links">
            <a href="offers.php"><i class="fa-solid fa-ticket"></i> Claim your coupon</a>
            <a href="contact.php"><i class="fa-solid fa-headset"></i> Customer Support</a>
            <a href="terms.php"><i class="fa-solid fa-shield"></i> Terms & Policies</a>
            <a href="refunds.php"><i class="fa-solid fa-arrow-rotate-left"></i> Refunds & Cancellations</a>
            <a href="admin-dashboard.php" class="admin-link"><i class="fa-solid fa-lock"></i> Admin Login</a>
        </div>
    </div>

    <div class="nav-contact" id="navContact">
        <i class="fa-solid fa-phone"></i> +91 9477709755
    </div>
    </nav>
    

    <header class="hero-carousel-section" style="position: relative; width: 100%; min-height: 80vh; overflow: visible; background: var(--dark-navy);">
        
       <div class="hero-track" id="heroTrack" style="display: flex; width: 100%; height: 100%; overflow-x: auto; scroll-snap-type: x mandatory; scroll-behavior: smooth; scrollbar-width: none; position: absolute; inset: 0;">
            
            <a href="madhya-pradesh-itinerary.php" class="hero-slide" style="min-width: 100%; width: 100%; height: 100%; position: relative; scroll-snap-align: start; flex-shrink: 0; display: block; text-decoration: none; cursor: pointer;">
                
                <video autoplay muted loop playsinline style="width: 100%; height: 100%; object-fit: cover;">
                    <source src="<?php echo isset($tourImages['hero banner 1']) ? $tourImages['hero banner 1'] : $fallbackVideo; ?>" type="video/mp4">
                </video>
                
                <div class="banner-overlay" style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(10, 17, 40, 0.8) 0%, rgba(10, 17, 40, 0.1) 40%, transparent 100%); transition: background 0.3s ease;"></div>
            </a>

            <a href="madhya-pradesh-itinerary.php" class="hero-slide" style="min-width: 100%; width: 100%; height: 100%; position: relative; scroll-snap-align: start; flex-shrink: 0; display: block; text-decoration: none; cursor: pointer;">
                
                <video autoplay muted loop playsinline style="width: 100%; height: 100%; object-fit: cover;">
                    <source src="<?php echo isset($tourImages['hero banner 2']) ? $tourImages['hero banner 2'] : $fallbackVideo; ?>" type="video/mp4">
                </video>
                
                <div class="banner-overlay" style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(10, 17, 40, 0.8) 0%, rgba(10, 17, 40, 0.1) 40%, transparent 100%); transition: background 0.3s ease;"></div>
            </a>

            <a href="custom-trip.php" class="hero-slide" style="min-width: 100%; width: 100%; height: 100%; position: relative; scroll-snap-align: start; flex-shrink: 0; display: block; text-decoration: none; cursor: pointer;">
                <img src="<?php echo isset($tourImages['hero banner 3']) ? $tourImages['hero banner 3'] : $fallbackImg; ?>" alt="Luxury Travel" style="width: 100%; height: 100%; object-fit: cover;">
                <div class="banner-overlay" style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(10, 17, 40, 0.8) 0%, rgba(10, 17, 40, 0.1) 40%, transparent 100%); transition: background 0.3s ease;"></div>
            </a>

            <a href="madhya-pradesh-itinerary.php" class="hero-slide" style="min-width: 100%; width: 100%; height: 100%; position: relative; scroll-snap-align: start; flex-shrink: 0; display: block; text-decoration: none; cursor: pointer;">
                
                <video autoplay muted loop playsinline style="width: 100%; height: 100%; object-fit: cover;">
                    <source src="<?php echo isset($tourImages['hero banner 4']) ? $tourImages['hero banner 4'] : $fallbackVideo; ?>" type="video/mp4">
                </video>
                
                <div class="banner-overlay" style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(10, 17, 40, 0.8) 0%, rgba(10, 17, 40, 0.1) 40%, transparent 100%); transition: background 0.3s ease;"></div>
            </a>

        </div> 
        <button class="slider-btn left-btn hero-nav" onclick="slideHero(-1)" style="z-index: 20; left: 30px;"><i class="fa-solid fa-chevron-left"></i></button>
        <button class="slider-btn right-btn hero-nav" onclick="slideHero(1)" style="z-index: 20; right: 30px;"><i class="fa-solid fa-chevron-right"></i></button>

        <div class="search-bar-wrapper" id="heroSearchWrapper">
            <form class="search-bar" id="mainSearchBar" onsubmit="event.preventDefault();">
                <input type="text" id="destinationSearch" placeholder='Search "Dub"' autocomplete="off">
                <button type="submit" class="btn-primary" id="searchBtn">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </form>
            <div id="searchSuggestions" class="suggestion-box"></div>
        </div>
    </header>
    

    <section class="top-destinations section-padding" style="background: var(--light-bg); margin-top: 50px;">
        
        <div class="section-header text-center" style="margin-bottom: 40px;">
            <h2>Top Destinations</h2>
            <p>Hover to explore starting prices for our most loved getaways.</p>
        </div>
        
        <div class="slider-wrapper">
            <button class="slider-btn left-btn" onclick="window.slideDestinations(-1)"><i class="fa-solid fa-chevron-left"></i></button>
            
            <div class="dest-slider-container" id="destSlider">
                <a href="kashmir-itinerary.php" class="dest-card">
                    <div class="dest-img" style="background-image: url('<?php echo isset($tourImages['card kashmir']) ? $tourImages['card kashmir'] : $fallbackImg; ?>"></div>
                    <div class="dest-info">
                        <h3></h3>
                        <div class="hover-price"><p>Starting at</p><h4>₹18,500</h4></div>
                    </div>
                </a>

                <a href="kerala-itinerary.php" class="dest-card">
                    <div class="dest-img" style="background-image: url('<?php echo isset($tourImages['card kerala']) ? $tourImages['card kerala'] : $fallbackImg; ?>"></div>
                    <div class="dest-info">
                        <h3></h3>
                        <div class="hover-price"><p>Starting at</p><h4>₹14,999</h4></div>
                    </div>
                </a>

                <a href="andaman-itinerary.php" class="dest-card">
                    <div class="dest-img" style="background-image: url('<?php echo isset($tourImages['card andaman']) ? $tourImages['card andaman'] : $fallbackImg; ?>"></div>
                    <div class="dest-info">
                        <h3></h3>
                        <div class="hover-price"><p>Starting at</p><h4>₹22,000</h4></div>
                    </div>
                </a>

                <a href="goa-itinerary.php" class="dest-card">
                    <div class="dest-img" style="background-image: url('<?php echo isset($tourImages['card goa']) ? $tourImages['card goa'] : $fallbackImg; ?>"></div>
                    <div class="dest-info">
                        <h3></h3>
                        <div class="hover-price"><p>Starting at</p><h4>₹35,000</h4></div>
                    </div>
                </a>

                <a href="himachal-itinerary.php" class="dest-card">
                    <div class="dest-img" style="background-image: url('<?php echo isset($tourImages['card himachal']) ? $tourImages['card himachal'] : $fallbackImg; ?>"></div>
                    <div class="dest-info">
                        <h3></h3>
                        <div class="hover-price"><p>Starting at</p><h4>₹45,999</h4></div>
                    </div>
                </a>

                <a href="dubai-itinerary.php" class="dest-card">
                    <div class="dest-img" style="background-image: url('<?php echo isset($tourImages['card dubai']) ? $tourImages['card dubai'] : $fallbackImg; ?>"></div>
                    <div class="dest-info">
                        <h3></h3>
                        <div class="hover-price"><p>Starting at</p><h4>₹45,999</h4></div>
                    </div>
                </a>

                <a href="rajasthan-itinerary.php" class="dest-card">
                    <div class="dest-img" style="background-image: url('<?php echo isset($tourImages['card rajasthan']) ? $tourImages['card rajasthan'] : $fallbackImg; ?>"></div>
                    <div class="dest-info">
                        <h3></h3>
                        <div class="hover-price"><p>Starting at</p><h4>₹12,500</h4></div>
                    </div>
                </a>
            </div>
            
           <button class="slider-btn right-btn" onclick="window.slideDestinations(1)"><i class="fa-solid fa-chevron-right"></i></button>
        </div>
    </section>
    

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const destTrack = document.getElementById('destSlider');
            if (!destTrack) return;

            const cards = Array.from(destTrack.children);
            const count = cards.length;

            // Clone for Infinity Scroll
            cards.forEach(card => destTrack.appendChild(card.cloneNode(true)));
            cards.slice().reverse().forEach(card => destTrack.prepend(card.cloneNode(true)));

            // Center initial position
            setTimeout(() => {
                const cardWidth = destTrack.querySelector('.dest-card').offsetWidth + 25; 
                destTrack.scrollLeft = cardWidth * count;
            }, 100);

            // Smooth Infinity Reset
            destTrack.addEventListener('scroll', () => {
                const cardWidth = destTrack.querySelector('.dest-card').offsetWidth + 25;
                if (destTrack.scrollLeft <= cardWidth) {
                    destTrack.style.scrollBehavior = 'auto'; 
                    destTrack.scrollLeft += cardWidth * count;
                    setTimeout(() => destTrack.style.scrollBehavior = 'smooth', 10);
                } 
                else if (destTrack.scrollLeft >= cardWidth * (count * 2) - destTrack.clientWidth) {
                    destTrack.style.scrollBehavior = 'auto';
                    destTrack.scrollLeft -= cardWidth * count;
                    setTimeout(() => destTrack.style.scrollBehavior = 'smooth', 10);
                }
            }, { passive: true });

            // Arrow controls
            window.slideDestinations = function(direction) {
                const cardWidth = destTrack.querySelector('.dest-card').offsetWidth + 25;
                destTrack.style.scrollBehavior = 'smooth';
                destTrack.scrollBy({ left: cardWidth * direction });
            };
        });
    </script>

    <!-- 🚨 THE LUXURY BENTO MOSAIC HOOK 🚨 -->
    <section class="bento-section section-padding" style="background: var(--light-bg);">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <h2 style="font-family: var(--font-heading); font-size: clamp(2rem, 5vw, 3rem); color: var(--dark-navy);">Curated by Traveltara</h2>
            <p style="font-family: var(--font-body); color: #666;">Step into a world crafted exclusively for the discerning traveler.</p>
        </div>

        <div class="bento-grid">
            
            <!-- Grid Item 1: MASSIVE FEATURE (Takes up half the grid) -->
            <a href="kashmir-itinerary.php" class="bento-item bento-large">
                <div class="bento-bg" style="background-image: url('<?php echo isset($tourImages['card kashmir']) ? $tourImages['card kashmir'] : $fallbackImg; ?>');"></div>
                <div class="bento-overlay"></div>
                <div class="bento-content">
                    <span class="bento-tag">Signature</span>
                    <h3>The Alpine Escape</h3>
                    <p>Discover the untouched beauty of the snow-capped north.</p>
                </div>
            </a>

            <!-- Grid Item 2: WIDE LANDSCAPE -->
            <a href="andaman-itinerary.php" class="bento-item bento-wide">
                <div class="bento-bg" style="background-image: url('<?php echo isset($tourImages['card andaman']) ? $tourImages['card andaman'] : $fallbackImg; ?>');"></div>
                <div class="bento-overlay"></div>
                <div class="bento-content">
                    <span class="bento-tag">Coastal</span>
                    <h3>Oceanic Serenity</h3>
                </div>
            </a>

            <!-- Grid Item 3: SQUARE 1 -->
            <a href="rajasthan-itinerary.php" class="bento-item bento-square">
                <div class="bento-bg" style="background-image: url('<?php echo isset($tourImages['card rajasthan']) ? $tourImages['card rajasthan'] : $fallbackImg; ?>');"></div>
                <div class="bento-overlay"></div>
                <div class="bento-content">
                    <span class="bento-tag">Heritage</span>
                    <h3>Royal India</h3>
                </div>
            </a>

            <!-- Grid Item 4: SQUARE 2 -->
            <a href="custom-trip.php" class="bento-item bento-square">
                <div class="bento-bg" style="background-image: url('<?php echo isset($tourImages['banner forest']) ? $tourImages['banner forest'] : $fallbackImg; ?>');"></div>
                <div class="bento-overlay"></div>
                <div class="bento-content">
                    <span class="bento-tag">Wild</span>
                    <h3>Safaris</h3>
                </div>
            </a>

        </div>
    </section>

    <section class="custom-section section-padding world-map-bg">
        <div class="custom-content">
            <h2>Design Your Own Escape</h2>
            <p>Don't see your dream destination? Our Travel Experts specialize in bespoke, tailored trips. Tell us where you want to go, and we will orchestrate the perfect itinerary.</p>
            <button class="btn-primary" onclick="openLeadPopup()">Consult an Expert</button>
        </div>
    </section>
    <section class="love-for-forests section-padding" style="background: var(--light-bg);">
        <div class="section-header text-center" style="margin-bottom: 40px;">
            <h2>Love for Forests</h2>
            <p>Immerse yourself in the wild. Exclusive jungle safaris and forest retreats.</p>
        </div>

        <div class="forest-banner-wrapper" style="max-width: 1200px; margin: 0 auto;">
            <div class="forest-banner">
                <div class="forest-img" style="background-image: url('<?php echo isset($tourImages['banner forest']) ? $tourImages['banner forest'] : $fallbackImg; ?>');"></div>
                <div class="forest-overlay">
                    <div class="overlay-content">
                        <h4>Coming Soon!</h4>
                        <p>Arranging wild travel plans...</p>
                        <button class="btn-outline-small forest-cta-btn" onclick="openForestPopup()">Show Interest</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="hotel-stays section-padding">
        <div class="section-header text-center">
            <h2>Luxury Hotel Stays</h2>
            <p>Handpicked accommodations for the perfect 5 star needs</p>
        </div>
       <div class="hotel-scroll-container" id="hotelScroll">
    <div class="hotel-card">
    <div class="hotel-img">
            <img src="<?php echo isset($tourImages['taj mahal palace']) ? $tourImages['taj mahal palace'] : $fallbackImg; ?>">
        </div>
        <h4>Taj Mahal Palace</h4>
        <p>Mumbai</p>
    </div>
    <div class="hotel-card">
        <div class="hotel-img">
            <img src="<?php echo isset($tourImages['the oberoi']) ? $tourImages['the oberoi'] : $fallbackImg; ?>">
        </div>
        <h4>The Oberoi</h4>
        <p>New Delhi</p>
    </div>
    <div class="hotel-card">
        <div class="hotel-img">
            <img src="<?php echo isset($tourImages['itc sonar']) ? $tourImages['itc sonar'] : $fallbackImg; ?>">
        </div>
        <h4>ITC Sonar</h4>
        <p>Kolkata</p>
    </div>
    <div class="hotel-card">
        <div class="hotel-img">
           <img src="<?php echo isset($tourImages['leela palace']) ? $tourImages['leela palace'] : $fallbackImg; ?>">
        </div>
        <h4>Leela Palace</h4>
        <p>Bangalore</p>
    </div>
    <div class="hotel-card">
        <div class="hotel-img">
            <img src="<?php echo isset($tourImages['rambagh palace']) ? $tourImages['rambagh palace'] : $fallbackImg; ?>">
        </div>
        <h4>Rambagh Palace</h4>
        <p>Jaipur</p>
    </div>
    <div class="hotel-card">
        <div class="hotel-img">
            <img src="<?php echo isset($tourImages['taj exotica']) ? $tourImages['taj exotica'] : $fallbackImg; ?>">
        </div>
        <h4>Taj Exotica</h4>
        <p>Goa</p>
    </div>
    <div class="hotel-card">
        <div class="hotel-img">
           <img src="<?php echo isset($tourImages['umaid bhawan']) ? $tourImages['umaid bhawan'] : $fallbackImg; ?>">
        </div>
        <h4>Umaid Bhawan</h4>
        <p>Jodhpur</p>
    </div>
</div>
    </section>

    <section class="why-choose-section section-padding">
        <div class="why-banner">
            
            <div class="why-text-content">
                <h2>Why Choose traveltara?</h2>
                <p>We orchestrate bespoke luxury experiences with exclusive VIP access, deep local expertise, and a dedicated 24/7 concierge to ensure your journey is absolutely flawless.</p>
            </div>

            <div class="why-stats-grid">
                <div class="stat-item">
                    <h3>98%</h3>
                    <p>Client Satisfaction</p>
                </div>
                
                <div class="stat-item">
                    <h3>4.9<span style="font-size: 1.5rem; color: #ccc;">/5</span></h3>
                    <p>Average Rating</p>
                </div>
                
                <div class="stat-item">
                    <h3>50+</h3>
                    <p>Destinations</p>
                </div>
            </div>

        </div>
    </section>

    <section class="reviews-section section-padding" style="background: #fdfdfd; position: relative;">
        <div class="section-header text-center">
            <h2>What Our Travelers Say</h2>
            <p>Real stories from unforgettable journeys.</p>
        </div>
        
        <div class="reviews-slider-container" style="position: relative; max-width: 1400px; margin: auto; padding: 0 50px;">
            
            <button class="slider-btn left-btn rev-btn" onclick="slideReviews(-1)"><i class="fa-solid fa-chevron-left"></i></button>
            
            <div class="review-marquee-wrapper">
                <div class="review-track" id="reviewTrack">
                    
                    <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"Absolutely flawless from start to finish. The custom Kashmir itinerary was perfectly paced, and the 5-star hotels were breathtaking."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #c5a059;">S</div>
                        <div class="rev-info">
                            <h4>Sneha Desai</h4>
                            <span>Mumbai, India</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"I’ve used many travel agencies, but the attention to detail here is unmatched. Our Kerala houseboat experience was magical."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #0a1128;">R</div>
                        <div class="rev-info">
                            <h4>Rahul Verma</h4>
                            <span>Delhi, NCR</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"They didn't just book a trip; they curated an experience. The private tours in Rajasthan made us feel like royalty."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #555;">A</div>
                        <div class="rev-info">
                            <h4>Anjali Kapoor</h4>
                            <span>Bangalore</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"Super responsive and incredibly helpful. The smart itinerary they planned for our Sikkim trip saved us so much time and hassle."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #888;">M</div>
                        <div class="rev-info">
                            <h4>Mohit Sharma</h4>
                            <span>Kolkata</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"Our honeymoon in Bali was an absolute dream. From the private pool villa to the candlelit beach dinner, every detail was perfect."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #e67e22;">P</div>
                        <div class="rev-info">
                            <h4>Priya & Aman</h4>
                            <span>Pune, India</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"Planning a trip for 12 family members is a nightmare, but they handled our Andaman trip effortlessly. Scuba diving was incredible!"</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #27ae60;">I</div>
                        <div class="rev-info">
                            <h4>The Iyer Family</h4>
                            <span>Chennai</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"We wanted an offbeat adventure, and the Meghalaya itinerary they built for us blew our minds. Hidden waterfalls and crystal clear rivers!"</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #2980b9;">R</div>
                        <div class="rev-info">
                            <h4>Rohan Das</h4>
                            <span>Guwahati</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"The VIP Desert Safari in Dubai was the highlight of our year. They managed all the visas and transfers perfectly. Zero stress."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #8e44ad;">N</div>
                        <div class="rev-info">
                            <h4>Neha Gupta</h4>
                            <span>Ahmedabad</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"I was nervous about booking a Euro trip, but their guidance through Switzerland and Paris made us feel so safe and well taken care of."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #d35400;">S</div>
                        <div class="rev-info">
                            <h4>Sarah Thomas</h4>
                            <span>Kochi</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"Celebrated our 10th anniversary in a Maldives water villa. The team negotiated a free couples spa upgrade for us! Highly recommended."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #16a085;">A</div>
                        <div class="rev-info">
                            <h4>Amit Patel</h4>
                            <span>Surat</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"A fantastic girls' trip to South Goa. They found us a gorgeous boutique villa away from the crowds with the best local food recommendations."</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #e84393;">V</div>
                        <div class="rev-info">
                            <h4>Vikram & Friends</h4>
                            <span>Chandigarh</span>
                        </div>
                    </div>
                </div>

                <div class="review-card">
                    <div class="stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                    <p class="review-text">"Road tripping through Himachal (Manali to Spiti) requires a tough vehicle and great drivers. They provided the best of both. What a thrill!"</p>
                    <div class="reviewer">
                        <div class="rev-avatar" style="background-color: #c0392b;">K</div>
                        <div class="rev-info">
                            <h4>Kavita Reddy</h4>
                            <span>Hyderabad</span>
                        </div>
                    </div>
                </div>

                </div>
            </div>

            <button class="slider-btn right-btn rev-btn" onclick="slideReviews(1)"><i class="fa-solid fa-chevron-right"></i></button>
        </div>
    </section>
    <section class="video-stories-section section-padding" style="background: var(--dark-navy); color: var(--white);">
        <div class="section-header text-center">
            <h2 style="color: var(--primary-gold);">Traveler Reels</h2>
            <p style="color: #ccc;">Watch our travelers experience the magic of Traveltara.</p>
        </div>

        <div class="slider-wrapper" style="max-width: 3600px;">
            <button class="slider-btn left-btn vid-btn" onclick="window.slideVideos(-1)"><i class="fa-solid fa-chevron-left"></i></button>

            <div class="review-marquee-wrapper"> 
                <div class="video-slider-container" id="videoTrack" style="display: flex; gap: 20px; overflow-x: auto; scroll-behavior: smooth; scrollbar-width: none; padding: 20px 0; scroll-snap-type: x mandatory;">

                    <div class="video-card">
                        <video src="<?php echo isset($tourImages['reel 1']) ? $tourImages['reel 1'] : 'assets/demo.mp4'; ?>" class="story-vid" loop playsinline muted></video>
                        <div class="vid-overlay">
                            <button class="mute-btn"><i class="fa-solid fa-volume-xmark"></i></button>
                            <div class="play-pause-btn"><i class="fa-solid fa-play"></i></div>
                            <div class="vid-info-bottom">
                                <h4>Maldives Escape</h4>
                                <p>@priya_travels</p>
                            </div>
                        </div>
                    </div>

                    <div class="video-card">
                        <video src="<?php echo isset($tourImages['reel 1']) ? $tourImages['reel 1'] : 'assets/demo.mp4'; ?>" class="story-vid" loop playsinline muted></video>
                        <div class="vid-overlay">
                            <button class="mute-btn"><i class="fa-solid fa-volume-xmark"></i></button>
                            <div class="play-pause-btn"><i class="fa-solid fa-play"></i></div>
                            <div class="vid-info-bottom">
                                <h4>Kashmir Winter</h4>
                                <p>@the_sharma_family</p>
                            </div>
                        </div>
                    </div>

                    <div class="video-card">
                        <video src="<?php echo isset($tourImages['reel 1']) ? $tourImages['reel 1'] : 'assets/demo.mp4'; ?>" class="story-vid" loop playsinline muted></video>
                        <div class="vid-overlay">
                            <button class="mute-btn"><i class="fa-solid fa-volume-xmark"></i></button>
                            <div class="play-pause-btn"><i class="fa-solid fa-play"></i></div>
                            <div class="vid-info-bottom">
                                <h4>Bali Villa</h4>
                                <p>@rohan_explores</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="video-card">
                        <video src="<?php echo isset($tourImages['reel 1']) ? $tourImages['reel 1'] : 'assets/demo.mp4'; ?>" class="story-vid" loop playsinline muted></video>
                        <div class="vid-overlay">
                            <button class="mute-btn"><i class="fa-solid fa-volume-xmark"></i></button>
                            <div class="play-pause-btn"><i class="fa-solid fa-play"></i></div>
                            <div class="vid-info-bottom">
                                <h4>Swiss Alps</h4>
                                <p>@neha_gupta</p>
                            </div>
                        </div>
                    </div>
                    <div class="video-card">
                        <video src="<?php echo isset($tourImages['reel 1']) ? $tourImages['reel 1'] : 'assets/demo.mp4'; ?>" class="story-vid" loop playsinline muted></video>
                        <div class="vid-overlay">
                            <button class="mute-btn"><i class="fa-solid fa-volume-xmark"></i></button>
                            <div class="play-pause-btn"><i class="fa-solid fa-play"></i></div>
                            <div class="vid-info-bottom">
                                <h4>Swiss Alps</h4>
                                <p>@neha_gupta</p>
                            </div>
                        </div>
                    </div>
                    <div class="video-card">
                        <video src="<?php echo isset($tourImages['reel 1']) ? $tourImages['reel 1'] : 'assets/demo.mp4'; ?>" class="story-vid" loop playsinline muted></video>
                        <div class="vid-overlay">
                            <button class="mute-btn"><i class="fa-solid fa-volume-xmark"></i></button>
                            <div class="play-pause-btn"><i class="fa-solid fa-play"></i></div>
                            <div class="vid-info-bottom">
                                <h4>Swiss Alps</h4>
                                <p>@neha_gupta</p>
                            </div>
                        </div>
                    </div>
                    <div class="video-card">
                        <video src="<?php echo isset($tourImages['reel 1']) ? $tourImages['reel 1'] : 'assets/demo.mp4'; ?>" class="story-vid" loop playsinline muted></video>
                        <div class="vid-overlay">
                            <button class="mute-btn"><i class="fa-solid fa-volume-xmark"></i></button>
                            <div class="play-pause-btn"><i class="fa-solid fa-play"></i></div>
                            <div class="vid-info-bottom">
                                <h4>Swiss Alps</h4>
                                <p>@neha_gupta</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <button class="slider-btn right-btn vid-btn" onclick="window.slideVideos(1)"><i class="fa-solid fa-chevron-right"></i></button>
        </div>
    </section>
    <section class="traveller-gallery section-padding" style="background: var(--light-bg);">
        <div class="section-header text-center" style="margin-bottom: 40px;">
            <h2 style="font-family: 'DM Sans', sans-serif; letter-spacing: 2px; text-transform: uppercase;">Our Gallery</h2>
        </div>
        
        <div class="gallery-slider-wrapper" style="width: 100%; overflow: hidden;">
            <div class="gallery-track" id="galleryTrack">
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['1']) ? $tourImages['1'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['2']) ? $tourImages['2'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['3']) ? $tourImages['3'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['4']) ? $tourImages['4'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['5']) ? $tourImages['5'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['6']) ? $tourImages['6'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['7']) ? $tourImages['7'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['8']) ? $tourImages['8'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['9']) ? $tourImages['9'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['10']) ? $tourImages['10'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['11']) ? $tourImages['11'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['12']) ? $tourImages['12'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['13']) ? $tourImages['13'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['14']) ? $tourImages['14'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['15']) ? $tourImages['15'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['16']) ? $tourImages['16'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['17']) ? $tourImages['17'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['18']) ? $tourImages['18'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['19']) ? $tourImages['19'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['20']) ? $tourImages['20'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['21']) ? $tourImages['21'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['22']) ? $tourImages['22'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['23']) ? $tourImages['23'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['24']) ? $tourImages['24'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['25']) ? $tourImages['25'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['26']) ? $tourImages['26'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['27']) ? $tourImages['27'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['28']) ? $tourImages['28'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['29']) ? $tourImages['29'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['30']) ? $tourImages['30'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['31']) ? $tourImages['31'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['32']) ? $tourImages['32'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['33']) ? $tourImages['33'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['34']) ? $tourImages['34'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['35']) ? $tourImages['35'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['36']) ? $tourImages['36'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['37']) ? $tourImages['37'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['38']) ? $tourImages['38'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['39']) ? $tourImages['39'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['40']) ? $tourImages['40'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['41']) ? $tourImages['41'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['42']) ? $tourImages['42'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['43']) ? $tourImages['43'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['44']) ? $tourImages['44'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['45']) ? $tourImages['45'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['46']) ? $tourImages['46'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['47']) ? $tourImages['47'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['48']) ? $tourImages['48'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['49']) ? $tourImages['49'] : $fallbackImg; ?>" alt="Gallery"></div>
                <div class="gallery-item" onclick="openLightbox(this)"><img src="<?php echo isset($tourImages['50']) ? $tourImages['50'] : $fallbackImg; ?>" alt="Gallery"></div>
            </div>
        </div>

        <div class="gallery-controls" style="display: flex; justify-content: center; gap: 15px; margin-top: 25px;">
            <button class="gallery-arrow" onclick="slideGallery(-1)"><i class="fa-solid fa-chevron-left"></i></button>
            <button class="gallery-arrow" onclick="slideGallery(1)"><i class="fa-solid fa-chevron-right"></i></button>
        </div>
    </section>

    <section class="faq-section section-padding" style="background: #fdfdfd;">
        <div class="section-header text-center">
            <h2>Frequently Asked Questions</h2>
            <p>Everything you need to know before you pack your bags.</p>
        </div>
        
        <div class="faq-container" style="max-width: 800px; margin: auto; padding: 0 20px;">
            
            <div class="faq-item">
                <button class="faq-question">
                    <span>How do I customize a travel package?</span>
                    <i class="fa-solid fa-chevron-down arrow-icon"></i>
                </button>
                <div class="faq-answer">
                    <div class="answer-content">
                        <p>You can easily customize any package by clicking the "Inquire Now" button and specifying your preferences. Our travel experts will tailor the itinerary, hotels, and activities exactly to your liking!</p>
                    </div>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">
                    <span>Are flights included in the package price?</span>
                    <i class="fa-solid fa-chevron-down arrow-icon"></i>
                </button>
                <div class="faq-answer">
                    <div class="answer-content">
                        <p>Our standard packages generally cover hotels, transfers, and activities. Flight inclusions depend on the specific package. Please check the "Inclusions" tab on the specific destination page or ask our agents to bundle flights for you!</p>
                    </div>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">
                    <span>What is your cancellation policy?</span>
                    <i class="fa-solid fa-chevron-down arrow-icon"></i>
                </button>
                <div class="faq-answer">
                    <div class="answer-content">
                        <p>We offer flexible booking! Cancellations made 30 days prior to departure receive a full refund. Cancellations within 15-30 days incur a 25% fee. Please refer to our Terms & Conditions for peak-season specifics.</p>
                    </div>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">
                    <span>Do you provide visa assistance for international trips?</span>
                    <i class="fa-solid fa-chevron-down arrow-icon"></i>
                </button>
                <div class="faq-answer">
                    <div class="answer-content">
                        <p>Absolutely! We have a dedicated Visa Desk that handles all documentation, interview scheduling, and application submissions for our international travelers at no extra service charge.</p>
                    </div>
                </div>
            </div>

            <div class="more-faqs-wrapper" id="moreFaqsWrapper">
                <div class="more-faqs-inner">
                    
                    <div class="faq-item">
                        <button class="faq-question">
                            <span>What payment methods do you accept?</span>
                            <i class="fa-solid fa-chevron-down arrow-icon"></i>
                        </button>
                        <div class="faq-answer">
                            <div class="answer-content">
                                <p>We accept all major credit cards, debit cards, bank transfers, and UPI. All transactions processed through the Traveltara portal are fully encrypted and 100% secure.</p>
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <button class="faq-question">
                            <span>Are the local tour guides certified?</span>
                            <i class="fa-solid fa-chevron-down arrow-icon"></i>
                        </button>
                        <div class="faq-answer">
                            <div class="answer-content">
                                <p>Yes! We only partner with highly experienced, government-certified local guides who are fluent in English and possess deep knowledge of the local history and culture.</p>
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <button class="faq-question">
                            <span>Is travel insurance included?</span>
                            <i class="fa-solid fa-chevron-down arrow-icon"></i>
                        </button>
                        <div class="faq-answer">
                            <div class="answer-content">
                                <p>Basic coverage is included in some of our premium packages. However, we highly recommend adding a comprehensive protection plan to any itinerary to cover unexpected medical emergencies or trip interruptions.</p>
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <button class="faq-question">
                            <span>Can I make changes after booking?</span>
                            <i class="fa-solid fa-chevron-down arrow-icon"></i>
                        </button>
                        <div class="faq-answer">
                            <div class="answer-content">
                                <p>Yes, minor adjustments can usually be made up to 15 days before departure, subject to availability. Significant date changes may incur hotel or airline rescheduling fees.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="text-center" style="margin-top: 30px;">
                <button id="toggleFaqsBtn" class="btn-outline-small" style="padding: 10px 25px; font-size: 1rem; border-radius: 30px; cursor: pointer; background: transparent; color: var(--primary-gold); border: 2px solid var(--primary-gold);">
                    Show More <i class="fa-solid fa-angle-down" style="margin-left: 5px;"></i>
                </button>
            </div>

        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-grid">
            
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
            
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

   <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>
        
    </div>

    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *">
                </div>
                
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <div class="popup-overlay" id="forestPopup">
        <div class="popup-box premium-popup forest-popup-box">
            <span class="close-btn" onclick="closeForestPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #2d6a4f;">Wild Escapes</span>
                <h3>Love for Forests</h3>
                <p class="popup-subtitle">Leave your details below. We will notify you when our exclusive forest itineraries launch!</p>
            </div>
            
            <form id="forestInterestForm" class="lead-form" onsubmit="submitForestForm(event)">
                <div class="form-group">
                    <input type="text" id="forestName" name="Name" autocomplete="name" required placeholder="Your Full Name (Letters Only) *" pattern="[A-Za-z\s]+" title="Please use alphabetical characters only">
                </div>
                <div class="form-group">
                    <input type="tel" id="forestPhone" name="Phone" autocomplete="tel" required placeholder="Phone Number (10 Digits) *" pattern="\d{10}" maxlength="10" title="Please enter exactly 10 numeric digits">
                </div>
                <div class="form-group">
                    <input type="email" id="forestEmail" name="Email" autocomplete="email" placeholder="Email Address (Optional)">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn" style="background: #2d6a4f; box-shadow: 0 10px 20px rgba(45, 106, 79, 0.3) !important;">Register Interest</button>
            </form>
        </div>
    </div>
    <div class="lightbox-overlay" id="lightboxOverlay" onclick="closeLightbox(event)">
        <span class="lightbox-close" title="Close">&times;</span>
        
        <button class="lightbox-arrow left" onclick="changeLightboxImage(-1, event)"><i class="fa-solid fa-chevron-left"></i></button>
        <button class="lightbox-arrow right" onclick="changeLightboxImage(1, event)"><i class="fa-solid fa-chevron-right"></i></button>
        
        <img class="lightbox-img" id="lightboxImg" src="" alt="Expanded View">
    </div>
   <script src="js/main.js?v=2.0"></script>
</body>
</html>