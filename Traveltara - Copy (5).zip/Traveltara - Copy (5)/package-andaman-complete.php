<?php
// Top of package-andaman-complete.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹28,500"; 
$sheet_affordable_price = "₹42,000";
$sheet_super_price = "₹65,000";

// EXACT package name from Google Sheet
$target_package = "The Complete Andaman Marine Expedition 8D/7N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star AC Hotels across Islands</li>
            <li><i class="fa-solid fa-ship"></i> Government/Standard AC Ferry Tickets for Inter-Island Transfers</li>
            <li><i class="fa-solid fa-car"></i> Dedicated AC Private Cabs for Sightseeing</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Beach Resorts & Sea-Facing Properties</li>
            <li><i class="fa-solid fa-ship"></i> Premium Class Tickets on Luxury Catamarans (Makruzz/Green Ocean)</li>
            <li><i class="fa-solid fa-mask-snorkel"></i> Complimentary Snorkeling Session at Elephant Beach</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP) with Island Seafood</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Ultra-Luxury (e.g., Taj Exotica, Sea Shell Resort)</li>
            <li><i class="fa-solid fa-ship"></i> Royal/VIP Class Catamaran Tickets & Optional Private Yacht Charter</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Scuba Diving Experience & Private Beach Dinners</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Dining, Private Bonfires & Premium Seafood BBQs</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Complete Andaman Marine Expedition 8 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="andaman-itinerary.php">Andaman Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Complete Expedition (8D/7N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['andaman ultimate hero']) ? $tourImages['andaman ultimate hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 8 Days / 7 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Complete Andaman Expedition</h1>
            <p>An unforgettable 8-day island-hopping journey blending historic Port Blair, the white sands of Havelock, and the pristine reefs of Neil Island via luxury catamaran.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Complete Andaman Marine Expedition 8D/7N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Immerse yourself in India's ultimate tropical paradise. This comprehensive 8-day marine expedition ensures you experience the absolute best of the Andaman archipelago. The journey is seamlessly connected by high-speed luxury catamarans, cutting through the turquoise waters of the Bay of Bengal. You will explore the profound history of the Cellular Jail in Port Blair, relax on Radhanagar Beach (consistently ranked among Asia's best), dive into vibrant coral reefs at Elephant Beach, and witness the geological wonders of Neil Island.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Port Blair & The Cellular Jail</h3>
                <p>Arrive at Veer Savarkar International Airport (IXZ) in Port Blair. Your private chauffeur will receive you and transfer you to your hotel. After a brief rest and lunch, begin your Andaman journey with a visit to the historic Cellular Jail (Kala Pani), a profound symbol of India's freedom struggle. Walk through the solitary confinement corridors. In the evening, take your seat in the open-air amphitheater for the highly moving Light and Sound Show that brings the history of the jail to life.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Luxury Cruise to Swaraj Dweep (Havelock)</h3>
                <p>After an early breakfast, check out and transfer to the Haddo Jetty. Board your high-speed luxury catamaran (Makruzz, Green Ocean, or Nautika) for a spectacular 1.5 to 2-hour cruise across the deep blue sea to Swaraj Dweep (Havelock Island). Upon arrival, check into your beachside resort. In the late afternoon, head to the world-renowned Radhanagar Beach (Beach No. 7). Walk along the powdery white sands, swim in the crystal-clear waters, and witness a spectacular tropical sunset.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Marine Wonders at Elephant Beach</h3>
                <p>After breakfast, embark on a short motorized boat ride to Elephant Beach, famous for its incredibly clear water and vibrant, shallow coral reefs. This is the ultimate destination for water sports. Enjoy complimentary snorkeling to witness the marine life. For thrill-seekers, optional activities like Sea Walking, Jet Skiing, Glass Bottom Boat rides, and Scuba Diving are available. Return to your resort by lunchtime and spend the rest of the afternoon relaxing at leisure.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Cruise to Shaheed Dweep (Neil Island)</h3>
                <p>Check out of your Havelock resort and transfer to the jetty. Board another scenic catamaran cruise to Shaheed Dweep (Neil Island). Known as the "Vegetable Bowl of Andaman," Neil is significantly quieter and more rustic than Havelock. Check into your resort. In the afternoon, visit Laxmanpur Beach, known for its vast expanse of white sand and shallow waters, making it the perfect spot to hunt for unique seashells and watch a brilliant, uninterrupted sunset.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Natural Bridge & Bharatpur Beach</h3>
                <p>Start your day with a visit to the Natural Rock Bridge (Howrah Bridge), an incredible geological formation created by centuries of ocean erosion. The walk to the bridge during low tide reveals small tidal pools filled with starfish, sea cucumbers, and small crabs. Later, proceed to Bharatpur Beach, the only beach in Neil Island suitable for swimming and water sports. The coral reefs here are stunningly vibrant. Return to your resort for a peaceful evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Return Cruise to Port Blair</h3>
                <p>Enjoy a relaxed morning on the quiet shores of Neil Island. Check out of your hotel and transfer to the jetty for your afternoon luxury cruise back to Port Blair. Upon arrival, check into your hotel. Spend the late afternoon shopping at the Aberdeen Bazaar or Sagarika Government Emporium for authentic Andaman souvenirs, including pearl jewelry, seashell crafts, and bamboo artifacts.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Netaji Subhash Chandra Bose Island & North Bay</h3>
                <p>After breakfast, take a short boat ride from the Water Sports Complex to Netaji Subhash Chandra Bose Island (formerly Ross Island). Once the administrative headquarters of the British, it is now a fascinating "jungle-reclaimed" island featuring colonial ruins draped in massive Banyan roots, and free-roaming deer and peacocks. Continue your boat trip to North Bay (Coral Island), the landscape featured on the back of the Indian 20-rupee note, for a final round of snorkeling or submarine rides.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Departure from Port Blair</h3>
                <p>Your ultimate Andaman expedition comes to an end. Enjoy a final tropical breakfast at your hotel. Check out and transfer to Veer Savarkar International Airport (IXZ) for your onward flight, taking back sun-drenched memories of India's most beautiful archipelago.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star AC Hotels across Islands</li>
                <li><i class="fa-solid fa-ship"></i> Government/Standard AC Ferry Tickets for Inter-Island Transfers</li>
                <li><i class="fa-solid fa-car"></i> Dedicated AC Private Cabs for Sightseeing</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/andaman-complete-8d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- EXPEDITION INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Island Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Archipelago Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for this multi-island cruise expedition.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-ship"></i></div>
                <h3>Ferry Logistics & Weather</h3>
                <p>Island connectivity:</p>
                <ul>
                    <li><strong>Schedule Changes:</strong> All inter-island transfers (Port Blair ↔ Havelock ↔ Neil) depend entirely on ocean weather conditions and clearance from the Directorate of Shipping Services. Ferry timings may be delayed, pre-poned, or canceled due to high winds or cyclones, requiring flexible itinerary adjustments.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-signal"></i></div>
                <h3>Digital Detox</h3>
                <p>Internet connectivity:</p>
                <ul>
                    <li><strong>Limited Network:</strong> The Andaman Islands suffer from notoriously poor internet and cellular connectivity. BSNL and Airtel work decently in Port Blair, but in Havelock and Neil, expect minimal to zero 4G/Wi-Fi. Download important documents, movies, and music offline before arriving.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-sun"></i></div>
                <h3>Tropical Climate & Timing</h3>
                <p>Beating the heat:</p>
                <ul>
                    <li><strong>Early Sunsets:</strong> The Andaman Islands follow IST but are geographically much further east. The sun rises very early (around 5:00 AM) and sets by 5:30 PM. Your days must start early to maximize daylight. Sunscreen (coral-safe), sunglasses, and hats are mandatory.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-mask-snorkel"></i></div>
                <h3>Scuba & Medical Fitness</h3>
                <p>Diving regulations:</p>
                <ul>
                    <li><strong>Health Checks:</strong> You do not need to know how to swim to participate in beginner scuba diving (Discover Scuba) or Sea Walking. However, you will be required to sign a medical declaration. Persons with severe asthma, heart conditions, or pregnant women are generally prohibited from diving.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-id-card-clip"></i></div>
                <h3>Permits & Restrictions</h3>
                <p>Protecting the islands:</p>
                <ul>
                    <li><strong>Restricted Areas:</strong> Certain islands and tribal reserves (like the Jarawa Reserve) are strictly protected by the Government of India. Photography of tribal people is a severe criminal offense. Always carry a valid government-issued ID (Passport/Aadhaar) for ferry boardings and hotel check-ins.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-fish"></i></div>
                <h3>Island Gastronomy</h3>
                <p>What to eat:</p>
                <ul>
                    <li><strong>Seafood Paradise:</strong> The islands offer some of the freshest seafood in India. Expect amazing crab, lobster, and tiger prawns. Vegetarians have ample options, primarily South Indian and North Indian thalis, though high-end luxury resorts cater to all international palates.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, Tamil Nadu, Andhra Pradesh, Andaman, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with an Island Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized Andaman cruise expedition.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="The Complete Andaman Marine Expedition 8D/7N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>