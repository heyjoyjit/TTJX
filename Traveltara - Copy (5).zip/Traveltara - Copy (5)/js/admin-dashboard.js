/**
 * ==========================================================================
 * TRAVELTARA ADMIN DASHBOARD - ENTERPRISE UNIFIED JAVASCRIPT ENGINE
 * 100% CRASH-PROOF, ULTRA-SENSITIVE FORECASTING & ISOLATED LOGIC
 * ==========================================================================
 */

// --- 1. UI CONTROLS & SIDEBAR LOGIC ---
function toggleDropdown(menuId, btnId) {
    const menu = document.getElementById(menuId);
    const btn = document.getElementById(btnId);
    if(menu) menu.classList.toggle('show');
    if(btn) btn.classList.toggle('dropdown-active');
}

function switchTab(tabId, element) {
    localStorage.setItem('activeAdminTab', tabId);
    document.querySelectorAll('.tab-panel').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    
    const targetTab = document.getElementById(tabId);
    if(targetTab) targetTab.classList.add('active');
    if(element) element.classList.add('active');
    
    if (element && element.classList.contains('sub-link')) {
        const parentDropdown = element.closest('.dropdown-container');
        if (parentDropdown) {
            parentDropdown.classList.add('show');
            const parentBtn = parentDropdown.previousElementSibling;
            if (parentBtn) parentBtn.classList.add('dropdown-active');
        }
    }
    if (window.innerWidth <= 768) closeMobileMenu();
}

function toggleMobileMenu() {
    const sidebar = document.getElementById('adminSidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if(sidebar) sidebar.classList.toggle('mobile-open');
    if(overlay) overlay.classList.toggle('active');
}

function closeMobileMenu() {
    const sidebar = document.getElementById('adminSidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if(sidebar) sidebar.classList.remove('mobile-open');
    if(overlay) overlay.classList.remove('active');
}

// --- 2. GLOBAL LIVE TABLE SEARCH (DEEP SCAN LOGIC) ---
function filterTable(inputEl, tbodyId) {
    if (!inputEl) return;
    let filter = inputEl.value.toLowerCase().trim();
    let tbody = document.getElementById(tbodyId);
    if(!tbody) return;
    
    let rows = tbody.querySelectorAll('tr');
    rows.forEach(row => {
        if (row.cells.length <= 1) return; // Skip empty rows
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
}

// --- 3. MODAL & CRUD API LOGIC ---
function closeModal(id) { 
    const modal = document.getElementById(id);
    if(modal) modal.classList.remove('active'); 
}

async function sendUpdate(payload, btnSelector) {
    const btn = document.querySelector(btnSelector);
    if(btn) { btn.innerText = "Saving..."; btn.disabled = true; }

    try {
        const response = await fetch('admin_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (result.status === 'success') {
            location.reload(); 
        } else {
            alert('Error: ' + result.message);
            if(btn) { btn.innerText = "Save"; btn.disabled = false; }
        }
    } catch (error) {
        console.error("CRUD Error:", error);
        alert('Server communication error. Check console.');
        if(btn) { btn.innerText = "Save"; btn.disabled = false; }
    }
}

async function deleteRecord(tableName, id) {
    if (!confirm(`Are you sure you want to PERMANENTLY delete this record from ${tableName}?`)) return;
    try {
        const response = await fetch('admin_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'delete_record', table: tableName, id: id })
        });
        const result = await response.json();
        if (result.status === 'success') location.reload();
        else alert('Error: ' + result.message);
    } catch (error) { alert('Server communication error.'); }
}

// Pricing Logic
function openPricingModal(btn = null) {
    if (btn) {
        document.getElementById('priceId').value = btn.dataset.id;
        document.getElementById('pricePackage').value = btn.dataset.package;
        document.getElementById('priceBudget').value = btn.dataset.budget;
        document.getElementById('priceAffordable').value = btn.dataset.affordable;
        document.getElementById('priceSuper').value = btn.dataset.super;
        document.getElementById('pricingModalTitle').innerText = "Edit Pricing";
    } else {
        document.getElementById('priceId').value = ''; document.getElementById('pricePackage').value = '';
        document.getElementById('priceBudget').value = ''; document.getElementById('priceAffordable').value = '';
        document.getElementById('priceSuper').value = ''; document.getElementById('pricingModalTitle').innerText = "Add New Package";
    }
    document.getElementById('pricingModalOverlay').classList.add('active');
}
async function savePricing() {
    await sendUpdate({
        action: 'save_pricing', id: document.getElementById('priceId').value, package: document.getElementById('pricePackage').value,
        budget: document.getElementById('priceBudget').value, affordable: document.getElementById('priceAffordable').value, super: document.getElementById('priceSuper').value
    }, '#pricingModalOverlay .btn-save');
}

// Coupon Logic
function openCouponModal(btn = null) {
    if (btn) {
        document.getElementById('couponId').value = btn.dataset.id; document.getElementById('couponCode').value = btn.dataset.code;
        document.getElementById('couponDiscount').value = btn.dataset.discount; document.getElementById('couponStatus').value = btn.dataset.status;
        document.getElementById('couponUsedBy').value = btn.dataset.usedby; document.getElementById('couponModalTitle').innerText = "Edit Coupon";
    } else {
        document.getElementById('couponId').value = ''; document.getElementById('couponCode').value = ''; document.getElementById('couponDiscount').value = '';
        document.getElementById('couponStatus').value = 'Active'; document.getElementById('couponUsedBy').value = ''; document.getElementById('couponModalTitle').innerText = "Create New Coupon";
    }
    document.getElementById('couponModalOverlay').classList.add('active');
}
async function saveCoupon() {
    await sendUpdate({
        action: 'save_coupon', id: document.getElementById('couponId').value, code: document.getElementById('couponCode').value,
        discount: document.getElementById('couponDiscount').value, status: document.getElementById('couponStatus').value, usedBy: document.getElementById('couponUsedBy').value
    }, '#couponModalOverlay .btn-save');
}
function openBulkCouponModal() {
    document.getElementById('bulkCouponCount').value = '10'; document.getElementById('bulkCouponDiscount').value = '20';
    document.getElementById('bulkCouponModalOverlay').classList.add('active');
}
async function generateBulkCoupons() {
    const count = document.getElementById('bulkCouponCount').value;
    const discount = document.getElementById('bulkCouponDiscount').value;
    if(!count || count <= 0) return alert("Please enter a valid number of coupons.");
    if(!discount) return alert("Please enter a discount value.");
    await sendUpdate({ action: 'generate_coupons', count: count, discount: discount }, '#bulkCouponModalOverlay .btn-save');
}
async function deleteAllCoupons() {
    if (!confirm(`🚨 WARNING: Are you absolutely sure you want to delete ALL coupons? This cannot be undone.`)) return;
    if (!confirm(`FINAL WARNING: Click OK to permanently wipe your entire coupon database.`)) return;
    try {
        const response = await fetch('admin_api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'delete_all_coupons' }) });
        const result = await response.json();
        if (result.status === 'success') location.reload();
        else alert('Error: ' + result.message);
    } catch (error) { alert('Server communication error.'); }
}

// CRM Logic
function openCrmModal(btn) {
    document.getElementById('crmPhoneId').value = btn.dataset.phone; document.getElementById('crmName').value = btn.dataset.name;
    document.getElementById('crmEmail').value = btn.dataset.email; document.getElementById('crmStatus').value = btn.dataset.status;
    document.getElementById('crmClientType').value = btn.dataset.ctype; document.getElementById('crmInterest').value = btn.dataset.interest;
    document.getElementById('crmModalOverlay').classList.add('active');
}
async function saveCrmEdits() {
    await sendUpdate({
        action: 'update_crm', phone: document.getElementById('crmPhoneId').value, name: document.getElementById('crmName').value,
        email: document.getElementById('crmEmail').value, status: document.getElementById('crmStatus').value,
        clientType: document.getElementById('crmClientType').value, interest: document.getElementById('crmInterest').value
    }, '#crmModalOverlay .btn-save');
}

// Booking Logic
function openBookingModal(btn) {
    document.getElementById('bookId').value = btn.dataset.id || ''; document.getElementById('bookStatus').value = btn.dataset.status || '';
    document.getElementById('bookTier').value = btn.dataset.tier || ''; document.getElementById('bookPrefix').value = btn.dataset.prefix || '';
    document.getElementById('bookFName').value = btn.dataset.fname || ''; document.getElementById('bookMName').value = btn.dataset.mname || '';
    document.getElementById('bookLName').value = btn.dataset.lname || ''; document.getElementById('bookPhone').value = btn.dataset.phone || '';
    document.getElementById('bookAltPhone').value = btn.dataset.altphone || ''; document.getElementById('bookEmail').value = btn.dataset.email || '';
    document.getElementById('bookAadhaar').value = btn.dataset.aadhaar || ''; document.getElementById('bookPassport').value = btn.dataset.passport || '';
    document.getElementById('bookDest').value = btn.dataset.dest || ''; document.getElementById('bookCommDate').value = btn.dataset.commdate || '';
    document.getElementById('bookTourType').value = btn.dataset.tourtype || ''; document.getElementById('bookAdults').value = btn.dataset.adults || '0';
    document.getElementById('bookChildren').value = btn.dataset.children || '0'; document.getElementById('bookRooms').value = btn.dataset.rooms || '0';
    document.getElementById('bookTotalPaid').value = btn.dataset.totalpaid || ''; document.getElementById('bookPayRef').value = btn.dataset.payref || '';
    document.getElementById('bookInvoice').value = btn.dataset.invoice || ''; document.getElementById('bookCoupon').value = btn.dataset.coupon || '';
    document.getElementById('bookResAddr').value = btn.dataset.resaddr || ''; document.getElementById('bookPermAddr').value = btn.dataset.permaddr || '';
    document.getElementById('bookOffAddr').value = btn.dataset.offaddr || ''; document.getElementById('bookDelAddr').value = btn.dataset.deladdr || '';
    document.getElementById('bookingModalOverlay').classList.add('active');
}
async function saveBookingEdits() {
    await sendUpdate({
        action: 'update_booking', bookingId: document.getElementById('bookId').value, prefix: document.getElementById('bookPrefix').value,
        fName: document.getElementById('bookFName').value, mName: document.getElementById('bookMName').value, lName: document.getElementById('bookLName').value,
        phone: document.getElementById('bookPhone').value, altPhone: document.getElementById('bookAltPhone').value, email: document.getElementById('bookEmail').value,
        resAddress: document.getElementById('bookResAddr').value, permAddress: document.getElementById('bookPermAddr').value, offAddress: document.getElementById('bookOffAddr').value,
        delAddress: document.getElementById('bookDelAddr').value, aadhaar: document.getElementById('bookAadhaar').value, tourType: document.getElementById('bookTourType').value,
        passport: document.getElementById('bookPassport').value, dest: document.getElementById('bookDest').value, commDate: document.getElementById('bookCommDate').value,
        tier: document.getElementById('bookTier').value, adults: document.getElementById('bookAdults').value, children: document.getElementById('bookChildren').value,
        rooms: document.getElementById('bookRooms').value, totalPaid: document.getElementById('bookTotalPaid').value, paymentRef: document.getElementById('bookPayRef').value,
        invoiceNo: document.getElementById('bookInvoice').value, couponUsed: document.getElementById('bookCoupon').value, status: document.getElementById('bookStatus').value
    }, '#bookingModalOverlay .btn-save');
}

// Interaction Logic
function openInteractionModal(btn) {
    document.getElementById('intId').value = btn.dataset.id; document.getElementById('intPhone').value = btn.dataset.phone;
    document.getElementById('intSource').value = btn.dataset.source; document.getElementById('intName').value = btn.dataset.name;
    document.getElementById('intEmail').value = btn.dataset.email; document.getElementById('intTranscript').value = btn.dataset.transcript;
    document.getElementById('interactionModalOverlay').classList.add('active');
}
async function saveInteractionEdits() {
    await sendUpdate({
        action: 'update_interaction', id: document.getElementById('intId').value, phone: document.getElementById('intPhone').value,
        source: document.getElementById('intSource').value, extName: document.getElementById('intName').value, extEmail: document.getElementById('intEmail').value,
        transcript: document.getElementById('intTranscript').value
    }, '#interactionModalOverlay .btn-save');
}

// Data Import/Export
function exportData(tableName) { window.location.href = `admin_api.php?action=export&table=${tableName}`; }
async function importData(inputElement, tableName) {
    const file = inputElement.files[0];
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.csv')) {
        alert("❌ ERROR: Incorrect File Type!\n\nUpload a '.csv' (Comma Delimited) file.");
        inputElement.value = ''; return;
    }
    if (!confirm(`Are you sure you want to upload data into ${tableName}?`)) { inputElement.value = ''; return; }
    
    const formData = new FormData();
    formData.append('action', 'import'); formData.append('table', tableName); formData.append('file', file);
    document.body.style.cursor = 'wait';
    try {
        const response = await fetch('admin_api.php', { method: 'POST', body: formData });
        const result = await response.json();
        document.body.style.cursor = 'default';
        if (result.status === 'success') { alert(`✅ Success`); location.reload(); } 
        else { alert(`⚠️ Error: ${result.message}`); }
    } catch (error) {
        document.body.style.cursor = 'default';
        alert("An error occurred during import.");
    }
    inputElement.value = ''; 
}

// --- 4. OMNI DASHBOARD LOGIC (CHART CONTROLS & PDF GENERATION) ---
function changeChartType(chartInstance, newType) {
    if (chartInstance && chartInstance.config) {
        chartInstance.config.type = newType;
        chartInstance.update();
    }
}

function downloadExecutiveReport() {
    const execTextEl = document.getElementById('execReportText');
    const forecastEl = document.getElementById('aiForecastContainer');
    
    if (!execTextEl || !forecastEl) {
        alert("Report data is still loading. Please wait a moment.");
        return;
    }
    
    let printWin = window.open('', '', 'width=900,height=800');
    printWin.document.write(`
        <html><head><title>Traveltara Executive Report</title>
        <style>
            body{font-family: Arial, sans-serif; padding:40px; line-height:1.6; color:#333;} 
            h1{color:#0A1128; border-bottom:2px solid #C5A059; padding-bottom:10px;} 
            h2{color:#2980b9; margin-top:0;} 
            .box{border:1px solid #ddd; padding:20px; border-radius:8px; margin-bottom:20px; background:#fdfdfd;}
            b{color:#0A1128;}
        </style></head><body>
    `);
    printWin.document.write('<h1>Traveltara Intelligence Report</h1>');
    printWin.document.write('<p><b>Generated on:</b> ' + new Date().toLocaleString() + '</p>');
    printWin.document.write('<div class="box"><h2>Performance Summary</h2>' + execTextEl.innerHTML + '</div>');
    let cleanForecast = forecastEl.innerHTML.replace(/<i.*?<\/i>/g, '');
    printWin.document.write('<div class="box"><h2>AI Forecast & Alerts</h2>' + cleanForecast + '</div>');
    printWin.document.write('</body></html>');
    printWin.document.close();
    
    setTimeout(() => { printWin.print(); printWin.close(); }, 800);
}

// Global Dashboard Variables
let revChart, locChart, tierChart, typeChart, destChart, customRelChart;
let globalRawBookings = []; 
let currentDataCore = null; 
const API_URL = "admin_analytics.php"; 
const EXP_API_URL = "admin_expenses.php";

const fmt = (num) => "₹ " + num.toLocaleString('en-IN', { maximumFractionDigits: 0 });

// --- 5. DATA AI CHAT NLP PROCESSOR (HYBRID ENGINE) ---
async function processAIQuery() {
    const inputEl = document.getElementById('aiQueryInput');
    const chatBox = document.getElementById('aiChatBox');
    if(!inputEl || !chatBox) return;
    
    const query = inputEl.value.trim();
    if (!query) return;
    
    chatBox.innerHTML += `<div class="user-msg">${query}</div>`;
    inputEl.value = '';
    
    const typingId = 'typing-' + Date.now();
    chatBox.innerHTML += `<div class="ai-msg" id="${typingId}"><i><i class="fa-solid fa-spinner fa-spin"></i> Searching live database...</i></div>`;
    chatBox.scrollTop = chatBox.scrollHeight; 
    
    try {
        const backendResponse = await fetch('admin_ai_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query })
        });
        
        const backendData = await backendResponse.json();
        
        if(backendData.answer === "FALLBACK_TO_LOCAL" || !backendData.answer) {
            let localResponse = "I'm sorry, I couldn't understand that query. Try asking about revenue, profit, leads, destinations, or specific timeframes like 'last 1 hour' or 'today'.";
            
            if (!currentDataCore) {
                localResponse = "System data is currently loading or unavailable. Please try again in a moment.";
            } else {
                const d = currentDataCore;
                let tempRaw = globalRawBookings;
                let isTimeFiltered = false;
                
                const qLower = query.toLowerCase();
                if(qLower.includes('hour')) {
                    const oneHourAgo = new Date(new Date().getTime() - 60*60*1000);
                    tempRaw = tempRaw.filter(b => new Date(b.Timestamp.replace(/-/g, '/')) >= oneHourAgo);
                    isTimeFiltered = true;
                } else if(qLower.includes('today')) {
                    const startOfDay = new Date(); startOfDay.setHours(0,0,0,0);
                    tempRaw = tempRaw.filter(b => new Date(b.Timestamp.replace(/-/g, '/')) >= startOfDay);
                    isTimeFiltered = true;
                }

                if(isTimeFiltered) {
                    let tempRev = 0;
                    tempRaw.forEach(b => tempRev += parseFloat(b.Revenue || 0));
                    let timeContext = qLower.includes('hour') ? "the last 1 hour" : "today";
                    localResponse = `Scanning database... Found it. In ${timeContext}, you received exactly <b>${tempRaw.length} bookings</b> generating <b>${fmt(tempRev)}</b> in revenue.`;
                } else {
                    const gross = parseFloat(d.gross_revenue) || 0;
                    const exp = parseFloat(d.real_expenses) || 0;
                    const profit = gross - exp;
                    const leads = parseInt(d.total_leads) || 1; 
                    const totalBookings = d.raw_bookings ? d.raw_bookings.length : 0;
                    const conversion = ((totalBookings / leads) * 100).toFixed(1);
                    
                    if (qLower.includes('profit') || qLower.includes('net')) {
                        localResponse = `Based on your selected timeframe, your Real Net Profit is <b>${fmt(profit)}</b>. (Revenue: ${fmt(gross)} minus Expenses: ${fmt(exp)}).`;
                    } else if (qLower.includes('revenue') || qLower.includes('sales') || qLower.includes('gross')) {
                        localResponse = `Your Gross Revenue for this period is <b>${fmt(gross)}</b>.`;
                    } else if (qLower.includes('expense') || qLower.includes('cost')) {
                        localResponse = `Your logged Real Expenses currently stand at <b>${fmt(exp)}</b>.`;
                    } else if (qLower.includes('lead') || qLower.includes('enquir')) {
                        localResponse = `You have captured exactly <b>${leads}</b> unique leads in this timeframe.`;
                    } else if (qLower.includes('conversion') || qLower.includes('rate')) {
                        localResponse = `Your Lead-to-Booking Conversion Rate is currently <b>${conversion}%</b> based on ${totalBookings} successful bookings from ${leads} leads.`;
                    } else if (qLower.includes('pax') || qLower.includes('passenger') || qLower.includes('travel')) {
                        localResponse = `You have a total of <b>${d.total_pax} passengers</b> booked (${d.adults} Adults and ${d.children} Children).`;
                    } else if (qLower.includes('destination') || qLower.includes('top') || qLower.includes('best')) {
                        if (d.destinations && d.destinations.length > 0) {
                            localResponse = `Your top-selling destination is <b>${d.destinations[0].Destination}</b> with ${d.destinations[0].Count} packages sold.`;
                        } else {
                            localResponse = `I cannot find any destination data for this timeframe.`;
                        }
                    } else if (qLower.includes('aov') || qLower.includes('average')) {
                        const aov = totalBookings > 0 ? (gross / totalBookings) : 0;
                        localResponse = `Your Average Order Value (AOV) per booking is <b>${fmt(aov)}</b>.`;
                    }
                }
            }
            document.getElementById(typingId).innerHTML = localResponse;
        } else {
            document.getElementById(typingId).innerHTML = backendData.answer;
        }
    } catch(err) {
        console.warn("Backend AI not found. Engaging local NLP engine.", err);
        let localResponse = "I'm sorry, I couldn't understand that query. Try asking about revenue, profit, leads, destinations, or specific timeframes like 'last 1 hour' or 'today'.";
        if (currentDataCore) {
            const d = currentDataCore;
            const gross = parseFloat(d.gross_revenue) || 0;
            const exp = parseFloat(d.real_expenses) || 0;
            const profit = gross - exp;
            const qLower = query.toLowerCase();
            if (qLower.includes('profit') || qLower.includes('net')) {
                localResponse = `Based on your selected timeframe, your Real Net Profit is <b>${fmt(profit)}</b>. (Revenue: ${fmt(gross)} minus Expenses: ${fmt(exp)}).`;
            } else if (qLower.includes('revenue') || qLower.includes('sales') || qLower.includes('gross')) {
                localResponse = `Your Gross Revenue for this period is <b>${fmt(gross)}</b>.`;
            }
        }
        document.getElementById(typingId).innerHTML = localResponse;
    }
    chatBox.scrollTop = chatBox.scrollHeight; 
}

// --- 6. LIVE REFRESH DATA SYNC ---
async function refreshAllData() {
    const btn = document.getElementById('liveRefreshBtn');
    if(!btn) return;
    const originalText = '<i class="fa-solid fa-rotate-right"></i> Live Refresh';
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Syncing...';
    btn.disabled = true;
    
    await loadDashboardData();
    await loadExpenseData();
    
    btn.innerHTML = '<i class="fa-solid fa-check"></i> Updated!';
    setTimeout(() => {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }, 2000);
}

// --- 7. CORE DASHBOARD ENGINE (FETCH, RENDER, & SENSITIVE FORECASTING) ---
async function loadDashboardData() {
    const rangeElement = document.getElementById('timeRangeFilter');
    if (!rangeElement) return; 
    
    const range = rangeElement.value;
    try {
        const response = await fetch(`${API_URL}?range=${range}`);
        const data = await response.json();
        
        currentDataCore = data; 
        globalRawBookings = data.raw_bookings || [];
        
        // RENDER 1: TOP METRIC CARDS
        try {
            const gross = parseFloat(data.gross_revenue) || 0;
            const expenses = parseFloat(data.real_expenses) || 0;
            const profit = gross - expenses;   
            const leads = parseInt(data.total_leads) || 0;
            
            if(document.getElementById('valRevenue')) document.getElementById('valRevenue').innerText = fmt(gross);
            if(document.getElementById('valExpenses')) document.getElementById('valExpenses').innerText = fmt(expenses);
            if(document.getElementById('valProfit')) document.getElementById('valProfit').innerText = fmt(profit);
            if(document.getElementById('valLeads')) document.getElementById('valLeads').innerText = leads.toLocaleString();
            if(document.getElementById('valPax')) document.getElementById('valPax').innerText = parseInt(data.total_pax || 0).toLocaleString();
            if(document.getElementById('valPaxSub')) document.getElementById('valPaxSub').innerText = `Adults: ${data.adults || 0} | Children: ${data.children || 0}`;
        } catch(e) { console.error("Error drawing top cards", e); }
        
        // RENDER 2: SENSITIVE EXECUTIVE REPORT
        try {
            const execReportEl = document.getElementById('execReportText');
            if(execReportEl) {
                const gross = parseFloat(data.gross_revenue) || 0;
                const expenses = parseFloat(data.real_expenses) || 0;
                const profit = gross - expenses;   
                const leads = parseInt(data.total_leads) || 0;
                const totalBookingsCount = globalRawBookings.length;
                
                const profitMargin = gross > 0 ? ((profit / gross) * 100).toFixed(1) : 0;
                const convRate = leads > 0 ? ((totalBookingsCount / leads) * 100).toFixed(1) : 0;
                const aov = totalBookingsCount > 0 ? (gross / totalBookingsCount) : 0;
                const cac = totalBookingsCount > 0 ? (expenses / totalBookingsCount) : 0; 
                
                const topDestName = (data.destinations && data.destinations.length > 0) ? data.destinations[0].Destination : 'None Tracked';
                const topLocName = (data.locations && data.locations.length > 0) ? data.locations[0].State : 'None Tracked';
                
                let topTierName = 'None Tracked';
                if(data.tiers && data.tiers.length > 0) {
                    topTierName = data.tiers.reduce((prev, curr) => (parseInt(prev.Count) > parseInt(curr.Count)) ? prev : curr).Tier;
                }
                
                let topTypeName = 'None Tracked';
                if(data.types && data.types.length > 0) {
                    topTypeName = data.types.reduce((prev, curr) => (parseInt(prev.Count) > parseInt(curr.Count)) ? prev : curr).Type;
                }
                
                let reportHTML = `<p><b>1. Financial Health & Profitability:</b><br>`;
                reportHTML += `In this timeframe, Traveltara secured <b>${totalBookingsCount} confirmed bookings</b>, facilitating travel for <b>${parseInt(data.total_pax || 0)} passengers</b>. `;
                reportHTML += `This generated a total gross revenue of <b>${fmt(gross)}</b>. With real-world operational expenses logged at <b>${fmt(expenses)}</b>, the net profit stands at <b>${fmt(profit)}</b>. `;
                
                if (totalBookingsCount > 0) {
                    reportHTML += `This represents an effective profit margin of <b>${profitMargin}%</b>. It costs an average of <b>${fmt(cac)}</b> in expenses to acquire a single booking (CAC).</p>`;
                } else {
                    reportHTML += `Because there are 0 bookings, you are currently experiencing a 100% loss relative to your operational expenses.</p>`;
                }

                reportHTML += `<p><b>2. Sales & Acquisition Metrics:</b><br>`;
                reportHTML += `Your marketing efforts captured <b>${leads} unique leads</b>. Based on successful closures, your Lead-to-Booking conversion rate is <b>${convRate}%</b>. `;
                reportHTML += `Furthermore, your Average Order Value (AOV) currently sits at <b>${fmt(aov)} per booking</b>.</p>`;

                reportHTML += `<p><b>3. Customer Demographic & Preferences:</b><br>`;
                reportHTML += `Geographically, your highest converting customer base originates from <b>${topLocName}</b>. `;
                reportHTML += `When booking, the majority of your clients demonstrate a preference for <b>${topTierName}</b> tier packages, showing a distinct inclination towards <b>${topTypeName}</b> travel. `;
                reportHTML += `Currently, the highest market demand is focused on <b>${topDestName}</b>.</p>`;

                execReportEl.innerHTML = reportHTML;
            }
        } catch(e) { 
            console.error("Executive Report Crash isolated:", e); 
            const execReportEl = document.getElementById('execReportText');
            if(execReportEl) execReportEl.innerHTML = "Not enough relational data to generate full text report.";
        }
        
        // RENDER 3: CHARTS
        try {
            if(data.timeline && data.timeline.length > 0) {
                const labels = data.timeline.map(item => item.Date);
                const amounts = data.timeline.map(item => item.DailyTotal);
                const ctxRev = document.getElementById('revenueChart');
                if(ctxRev) {
                    if(revChart) revChart.destroy();
                    revChart = new Chart(ctxRev.getContext('2d'), {
                        type: 'line', data: { labels: labels, datasets: [{ label: 'Daily Revenue', data: amounts, borderColor: '#C5A059', backgroundColor: 'rgba(197, 160, 89, 0.1)', borderWidth: 3, fill: true, tension: 0.4 }] },
                        options: { responsive: true, maintainAspectRatio: false, scales: { y: { ticks: { callback: function(value) { return '₹ ' + value.toLocaleString('en-IN'); } } } }, plugins: { tooltip: { callbacks: { label: function(context) { return '₹ ' + context.parsed.y.toLocaleString('en-IN'); } } } } }
                    });
                }
            }
        } catch(e) { console.error("Rev Chart Error", e); }
        
        try {
            if(data.locations && data.locations.length > 0) {
                const locLabels = data.locations.map(item => item.State.trim() || "Unknown");
                const locCounts = data.locations.map(item => item.Count);
                const ctxLoc = document.getElementById('locationChart');
                if(ctxLoc) {
                    if(locChart) locChart.destroy();
                    locChart = new Chart(ctxLoc.getContext('2d'), {
                        type: 'doughnut', data: { labels: locLabels, datasets: [{ data: locCounts, backgroundColor: ['#0A1128', '#C5A059', '#27ae60', '#e74c3c', '#8e44ad', '#f39c12'], borderWidth: 0 }] },
                        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right' } } }
                    });
                }
            }
        } catch(e) { console.error("Loc Chart Error", e); }

        try {
            if(data.tiers && data.tiers.length > 0) {
                const tierLabels = data.tiers.map(item => item.Tier);
                const tierCounts = data.tiers.map(item => item.Count);
                const ctxTier = document.getElementById('tierChart');
                if(ctxTier) {
                    if(tierChart) tierChart.destroy();
                    tierChart = new Chart(ctxTier.getContext('2d'), {
                        type: 'bar', data: { labels: tierLabels, datasets: [{ label: 'Bookings', data: tierCounts, backgroundColor: ['#C5A059', '#2980b9', '#27ae60', '#e74c3c', '#8e44ad', '#f39c12'], borderRadius: 4 }] },
                        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
                    });
                }
            }
        } catch(e) { console.error("Tier Chart Error", e); }

        try {
            if(data.types && data.types.length > 0) {
                const typeLabels = data.types.map(item => item.Type);
                const typeCounts = data.types.map(item => item.Count);
                const ctxType = document.getElementById('typeChart');
                if(ctxType) {
                    if(typeChart) typeChart.destroy();
                    typeChart = new Chart(ctxType.getContext('2d'), {
                        type: 'pie', data: { labels: typeLabels, datasets: [{ data: typeCounts, backgroundColor: ['#2980b9', '#16a085', '#34495e'], borderWidth: 0 }] },
                        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
                    });
                }
            }
        } catch(e) { console.error("Type Chart Error", e); }

        try {
            if(data.destinations && data.destinations.length > 0) {
                const destLabels = data.destinations.slice(0, 5).map(item => item.Destination);
                const destCounts = data.destinations.slice(0, 5).map(item => item.Count);
                const ctxDest = document.getElementById('destChart');
                if(ctxDest) {
                    if(destChart) destChart.destroy();
                    destChart = new Chart(ctxDest.getContext('2d'), {
                        type: 'bar', data: { labels: destLabels, datasets: [{ label: 'Packages Sold', data: destCounts, backgroundColor: ['#0A1128', '#C5A059', '#27ae60', '#e74c3c', '#8e44ad', '#f39c12'], borderRadius: 4 }] },
                        options: { responsive: true, maintainAspectRatio: false, indexAxis: 'y', plugins: { legend: { display: false } }, scales: { x: { ticks: { callback: function(value) { return value + ' Pkgs'; } } } } }
                    });
                }
            }
        } catch(e) { console.error("Dest Chart Error", e); }

        try { generateForecast(data); } catch(e) { console.error("Forecast Error", e); }
        try { renderCustomChart(); } catch(e) { console.error("Explorer Error", e); }

    } catch (err) { console.error("Fatal Dashboard Network Error:", err); }
}

function renderCustomChart() {
    if (!globalRawBookings || globalRawBookings.length === 0) return;
    const xAxisEl = document.getElementById('customX');
    const yAxisEl = document.getElementById('customY');
    const chartCanvas = document.getElementById('customRelationalChart');
    if(!xAxisEl || !yAxisEl || !chartCanvas) return;
    
    const xAxisKey = xAxisEl.value; 
    const yAxisKey = yAxisEl.value; 
    
    const grouped = {};
    globalRawBookings.forEach(row => {
        let xVal = row[xAxisKey] || 'Unknown/Blank';
        if (!grouped[xVal]) grouped[xVal] = 0;
        if (yAxisKey === 'Count') { grouped[xVal] += 1; } else { grouped[xVal] += parseFloat(row[yAxisKey]) || 0; }
    });
    
    const labels = Object.keys(grouped); const values = Object.values(grouped);
    if(customRelChart) customRelChart.destroy();
    
    let yPrefix = yAxisKey === 'Revenue' ? '₹ ' : '';
    let ySuffix = yAxisKey === 'Pax' ? ' Pax' : (yAxisKey === 'Count' ? ' Bookings' : '');

    customRelChart = new Chart(chartCanvas.getContext('2d'), {
        type: 'bar', 
        data: { labels: labels, datasets: [{ label: yAxisKey === 'Count' ? 'Total Bookings' : (yAxisKey === 'Pax' ? 'Total Passengers' : 'Revenue'), data: values, backgroundColor: ['#8e44ad', '#2980b9', '#27ae60', '#e74c3c', '#C5A059', '#f39c12', '#16a085', '#d35400', '#c0392b', '#34495e'], borderRadius: 4 }] },
        options: { 
            responsive: true, maintainAspectRatio: false,
            scales: { y: { ticks: { callback: function(value) { return yPrefix + value.toLocaleString('en-IN') + ySuffix; } } } },
            plugins: { tooltip: { callbacks: { label: function(context) { return yPrefix + context.parsed.y.toLocaleString('en-IN') + ySuffix; } } } }
        }
    });
}

// --- 8. SENSITIVE AI FORECASTING (REALISTIC PRECISION MODEL) ---
function generateForecast(data) {
    const container = document.getElementById('aiForecastContainer');
    if(!container) return;
    
    const timeline = data.timeline || [];
    const expenses = parseFloat(data.real_expenses) || 0;
    const gross = parseFloat(data.gross_revenue) || 0;
    const leads = parseInt(data.total_leads) || 0;
    const totalBookings = globalRawBookings ? globalRawBookings.length : 0;
    
    let html = '';
    
    // Extrapolation & Trajectory Logic
    let projected30Days = 0;
    let growthRate = 0;
    let isGrowing = true;

    if (timeline.length === 0) {
        html += `<div class="tip-item warning"><h4 style="margin:0 0 5px 0; color:#e74c3c;"><i class="fa-solid fa-triangle-exclamation"></i> Zero Bookings Detected</h4><p style="margin: 0; font-size: 13px;">No completed transactions found in this period. Mathematical projections are paused.</p></div>`;
    } else {
        const midPoint = Math.floor(timeline.length / 2);
        let firstHalfSum = 0, secondHalfSum = 0;
        for(let i = 0; i < midPoint; i++) firstHalfSum += parseFloat(timeline[i].DailyTotal);
        for(let i = midPoint; i < timeline.length; i++) secondHalfSum += parseFloat(timeline[i].DailyTotal);
        
        isGrowing = secondHalfSum >= firstHalfSum;
        growthRate = firstHalfSum === 0 ? (secondHalfSum > 0 ? 0.1 : 0) : ((secondHalfSum - firstHalfSum) / firstHalfSum);
        
        // 🚀 REALISTIC CALCULATION FIX: Use actual calendar context days, not just days with sales
        const filterSelect = document.getElementById('timeRangeFilter');
        let contextDays = 30; // Default fallback
        if (filterSelect) {
            const val = filterSelect.value;
            if (val === 'mtd') contextDays = Math.max(1, new Date().getDate());
            else if (val === 'last_month' || val === '30days') contextDays = 30;
            else if (val === 'last_year' || val === 'prev_fy') contextDays = 365;
        }
        
        // Calculate true daily run rate over the entire calendar period
        const trueDailyRunRate = gross / contextDays;

        // Cap extreme mathematical growth spikes (e.g. 1 sale to 5 sales) to a realistic +/- 15% maximum swing
        let safeGrowth = growthRate;
        if (safeGrowth > 0.15) safeGrowth = 0.15;
        if (safeGrowth < -0.15) safeGrowth = -0.15;

        // Project 30 days accurately
        projected30Days = (trueDailyRunRate * 30) * (1 + safeGrowth);

        if (timeline.length === 1) {
            html += `<div class="tip-item"><h4 style="margin:0 0 5px 0; color:#C5A059;"><i class="fa-solid fa-chart-line"></i> Early Trajectory</h4><div style="font-size: 20px; font-weight: bold;">${fmt(Math.max(0, projected30Days))}</div><p style="margin: 5px 0 0 0; font-size: 13px;">Based on sparse data, realistically extrapolated to a 30-day run rate.</p></div>`;
        } else {
            html += `<div class="tip-item"><h4 style="margin:0 0 5px 0; color:#C5A059;"><i class="fa-solid fa-chart-line"></i> Projected Revenue (30 Days)</h4><div style="font-size: 20px; font-weight: bold;">${fmt(Math.max(0, projected30Days))}</div><p style="margin: 5px 0 0 0; font-size: 13px;">Precision forecast based on exact daily run-rate and momentum damping.</p></div>`;
        }
    }

    // Expense ROI & Customer Acquisition Cost (CAC)
    const cac = totalBookings > 0 ? (expenses / totalBookings) : 0;
    const roi = expenses > 0 ? (((gross - expenses) / expenses) * 100).toFixed(1) : (gross > 0 ? 'Infinity' : 0);

    if (expenses > 0 && totalBookings > 0) {
         html += `<div class="tip-item"><h4 style="margin:0 0 5px 0; color:#2980b9;"><i class="fa-solid fa-scale-balanced"></i> Expense & Acquisition (CAC)</h4><p style="margin: 0; font-size: 13px;">You spend an average of <b>${fmt(cac)}</b> to acquire 1 booking. Return on Spend (ROAS) is highly positive at <b>${roi}%</b>.</p></div>`;
    } else if (expenses > 0 && totalBookings === 0) {
         html += `<div class="tip-item warning"><h4 style="margin:0 0 5px 0; color:#e74c3c;"><i class="fa-solid fa-fire"></i> High Cash Burn Alert</h4><p style="margin: 0; font-size: 13px;">You have spent <b>${fmt(expenses)}</b> with 0 resulting bookings. Assess your marketing funnel immediately.</p></div>`;
    }

    // Booking Velocity & Gaps
    let bookingGapText = "Insufficient data to calculate frequency.";
    if (timeline.length > 1) {
        const firstDate = new Date(timeline[0].Date);
        const lastDate = new Date(timeline[timeline.length-1].Date);
        const diffDays = Math.ceil(Math.abs(lastDate - firstDate) / (1000 * 60 * 60 * 24));
        const safeTimelineLength = Math.max(1, timeline.length - 1);
        const gap = diffDays / safeTimelineLength;
        if (gap <= 1) {
            bookingGapText = `Incredible momentum. You are securing bookings at a rate of <b>1 or more per day</b>.`;
        } else {
            bookingGapText = `You are experiencing an average gap of <b>${gap.toFixed(1)} days</b> between successful bookings.`;
        }
    } else if (timeline.length === 1) {
        bookingGapText = `Only 1 active booking day recorded in this timeframe. Velocity is stalled.`;
    }
    html += `<div class="tip-item"><h4 style="margin:0 0 5px 0; color:#8e44ad;"><i class="fa-solid fa-bolt"></i> Booking Velocity & Gaps</h4><p style="margin: 0; font-size: 13px;">${bookingGapText}</p></div>`;

    // Conversion & AOV
    const conversion = leads > 0 ? ((totalBookings / leads) * 100).toFixed(1) : 0;
    if(conversion > 0 && conversion < 5) {
        html += `<div class="tip-item warning"><h4 style="margin:0 0 5px 0; color:#e74c3c;"><i class="fa-solid fa-filter"></i> Low Conversion Alert</h4><p style="margin: 0; font-size: 13px;">Your Lead-to-Booking rate is <b>${conversion}%</b>. You are getting leads, but not closing them.</p></div>`;
    } else if (conversion >= 5) {
        html += `<div class="tip-item"><h4 style="margin:0 0 5px 0; color:#27ae60;"><i class="fa-solid fa-filter"></i> Healthy Conversions</h4><p style="margin: 0; font-size: 13px;">Your Lead-to-Booking rate is strong at <b>${conversion}%</b>.</p></div>`;
    }

    // Final Render
    container.innerHTML = html;
}

// --- 9. EXPENSE TRACKER LOGIC ---
async function loadExpenseData() {
    const rangeElement = document.getElementById('expenseTimeFilter');
    if(!rangeElement) return;
    const range = rangeElement.value;
    try {
        const response = await fetch(`${EXP_API_URL}?action=GET_DATA&range=${range}`);
        const data = await response.json();
        if(document.getElementById('expRevValue')) document.getElementById('expRevValue').innerText = fmt(data.revenue);
        if(document.getElementById('expTotalValue')) document.getElementById('expTotalValue').innerText = fmt(data.expenses_total);
        const pnlCard = document.getElementById('expPnLCard');
        const pnlText = document.getElementById('expPnLValue');
        if(pnlText) pnlText.innerText = fmt(data.profit_loss);
        if(pnlCard && pnlText) {
            if (data.profit_loss >= 0) { pnlText.style.color = "#27ae60"; pnlCard.style.borderTopColor = "#27ae60"; } 
            else { pnlText.style.color = "#e74c3c"; pnlCard.style.borderTopColor = "#e74c3c"; }
        }
        const tbody = document.getElementById('expenseTableBody');
        if(tbody) {
            tbody.innerHTML = '';
            if (data.expense_list.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;">No expenses logged for this timeframe.</td></tr>'; return;
            }
            data.expense_list.forEach(exp => {
                tbody.innerHTML += `<tr><td><button class="btn-delete" onclick="deleteExpense(${exp.id})" style="padding: 5px 10px; font-size: 12px;"><i class="fa-solid fa-trash"></i></button></td><td><strong>${exp.exp_date}</strong></td><td><span class="status-badge" style="background:#fdfbf7; color:#0A1128; border:1px solid #ddd;">${exp.category}</span></td><td>${exp.description}</td><td style="color:#e74c3c; font-weight:bold;">${fmt(exp.amount)}</td></tr>`;
            });
        }
    } catch (err) { console.error("Failed to load expenses", err); }
}

function openExpenseModal() {
    document.getElementById('expDate').value = new Date().toISOString().split('T')[0];
    document.getElementById('expDesc').value = ''; document.getElementById('expAmount').value = '';
    document.getElementById('expenseModalOverlay').style.display = 'flex';
}

async function saveExpense() {
    const payload = { action: 'ADD_EXPENSE', date: document.getElementById('expDate').value, category: document.getElementById('expCategory').value, description: document.getElementById('expDesc').value, amount: document.getElementById('expAmount').value };
    if(!payload.date || !payload.description || !payload.amount) return alert("Please fill all fields.");
    const btn = document.querySelector('#expenseModalOverlay .btn-save');
    if(btn) { btn.innerText = "Saving..."; btn.disabled = true; }
    try {
        await fetch(EXP_API_URL, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
        document.getElementById('expenseModalOverlay').style.display = 'none'; 
        loadExpenseData(); loadDashboardData(); 
    } catch (e) { alert("Failed to save expense."); }
    if(btn) { btn.innerText = "Save Expense"; btn.disabled = false; }
}

async function deleteExpense(id) {
    if(!confirm("Are you sure you want to delete this expense? This will recalculate your Profit/Loss instantly.")) return;
    try {
        await fetch(EXP_API_URL, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({action: 'DELETE_EXPENSE', id: id}) });
        loadExpenseData(); loadDashboardData(); 
    } catch (e) { alert("Failed to delete."); }
}

// --- 10. MASTER INITIALIZATION ---
window.addEventListener('load', () => { 
    const lastTab = localStorage.getItem('activeAdminTab');
    if (lastTab) {
        const targetLink = document.querySelector(`[onclick*="'${lastTab}'"]`);
        if (targetLink) targetLink.click();
    }
    
    const overlay = document.getElementById('sidebarOverlay');
    if (overlay) overlay.addEventListener('click', closeMobileMenu);

    if(document.getElementById('finance-tab')) {
        loadDashboardData(); 
        loadExpenseData(); 
    }
    
    const aiInput = document.getElementById("aiQueryInput");
    if (aiInput) {
        aiInput.addEventListener("keypress", function(event) {
            if (event.key === "Enter") { event.preventDefault(); processAIQuery(); }
        });
    }
});