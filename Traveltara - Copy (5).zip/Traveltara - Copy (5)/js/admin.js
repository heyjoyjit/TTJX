// =======================================================
// MASTER ADMIN POS & INVOICE GENERATOR (FULL DATA SYNC)
// =======================================================

// 🚀 ROUTE DIRECTLY TO HOSTINGER MYSQL DATABASE
const HOSTINGER_API_URL = "process_leads.php";
const HOSTINGER_MAILER_URL = "process_checkout.php"; 

let locationCount = 0;
const fmt = (num) => num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

window.fetchPincodeData = async function(pincode, prefix) {
    const pinInput = document.getElementById(prefix + 'Pin');
    if (pinInput) pinInput.value = pincode.replace(/[^0-9]/g, '');
    if(pincode.length === 6) {
        try {
            let response = await fetch(`https://api.postalpincode.in/pincode/${pincode}`);
            let data = await response.json();
            if(data[0].Status === "Success") {
                document.getElementById(prefix+'City').value = data[0].PostOffice[0].Block || data[0].PostOffice[0].Name;
                document.getElementById(prefix+'State').value = data[0].PostOffice[0].State;
            }
        } catch(e) {}
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const sameAsRes = document.getElementById('sameAsResCheck');
    const permBlock = document.getElementById('permAddressBlock');
    if(sameAsRes) sameAsRes.addEventListener('change', (e) => e.target.checked ? permBlock.classList.add('hidden-section') : permBlock.classList.remove('hidden-section'));
    addLocationRow(); 
});

window.addLocationRow = function() {
    locationCount++;
    const container = document.getElementById('locationsContainer');
    const row = document.createElement('div');
    row.className = 'location-row'; row.id = `locRow_${locationCount}`;
    row.innerHTML = `
        <button type="button" class="remove-loc-btn" onclick="removeLocationRow(${locationCount})"><i class="fa-solid fa-xmark"></i></button>
        <div class="form-grid" style="grid-template-columns: 2fr 1fr 1fr;">
            <div class="input-group"><label>Destination Name</label><input type="text" class="loc-name editable-highlight" required></div>
            <div class="input-group"><label>Date / Duration</label><input type="text" class="loc-date editable-highlight" required></div>
            <div class="input-group"><label>Taxable Amount (₹)</label><input type="number" class="loc-amt editable-highlight" required min="0" value="0" oninput="calculateAdminTotal()"></div>
        </div>
    `;
    container.appendChild(row);
};

window.removeLocationRow = function(id) { document.getElementById(`locRow_${id}`).remove(); calculateAdminTotal(); };

window.calculateAdminTotal = function() {
    let totalTaxable = 0;
    document.querySelectorAll('.loc-amt').forEach(input => totalTaxable += parseFloat(input.value) || 0);
    const gst = totalTaxable * 0.05;
    document.getElementById('displayTotalCost').innerText = `₹ ${fmt(totalTaxable + gst)}`;
    return { taxable: totalTaxable, gst: gst, total: totalTaxable + gst };
};

window.updatePosSubmitBtn = function() {
    const mode = document.querySelector('input[name="posPaymentMode"]:checked').value;
    const btn = document.getElementById('generateBillBtn');
    if (mode === 'cash') {
        btn.innerHTML = '<i class="fa-solid fa-file-invoice"></i> Record Cash Payment & Generate Invoice'; btn.style.background = '#27ae60';
    } else {
        btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Generate Order & Send Payment Link'; btn.style.background = '#154b9b';
    }
};

document.getElementById('adminPosForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    if(document.getElementById('primaryPhone').value.length !== 10) return alert("Primary Phone must be exactly 10 digits.");
    
    const btn = document.getElementById('generateBillBtn');
    const originalBtnText = btn.innerHTML;
    const paymentMode = document.querySelector('input[name="posPaymentMode"]:checked').value;
    
    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Processing...'; 
    btn.style.pointerEvents = 'none';

    try {
        const getVal = (id) => { const el = document.getElementById(id); return el ? el.value.trim() : ""; };
        
        const math = calculateAdminTotal();
        const timePart = Date.now().toString(36).toUpperCase().slice(-5);
        const bookingId = `TRV-POS-${timePart}`;

        let destArray = [];
        document.querySelectorAll('.loc-name').forEach(input => { if (input.value.trim() !== '') destArray.push(input.value.trim()); });
        const combinedDestinations = destArray.join(' + ');

        // Gather base details
        const guestName = `${getVal('prefix')} ${getVal('fName')} ${getVal('lName')}`.trim();
        const phone = getVal('primaryPhone');
        const email = getVal('email');
        const adults = getVal('adults') || '2';
        const children = getVal('child') || '0';
        const rooms = getVal('rooms') || '1';

        // The Initial CRM Payload (Creates the row in Hostinger)
        const masterPayload = {
            action: 'LEAD_CAPTURE',
            bookingId: bookingId,
            prefix: getVal('prefix'),
            fName: getVal('fName'),
            mName: getVal('mName'),
            lName: getVal('lName'),
            primaryPhone: phone,
            altPhone: getVal('altPhone'),
            email: email,
            resAddress: `${getVal('resLine1')}, ${getVal('resLandmark')}, ${getVal('resCity')}, ${getVal('resState')} - ${getVal('resPin')}`,
            aadhaar: getVal('aadhaar'),
            passport: getVal('passport'),
            tourType: getVal('tourType'),
            destination: combinedDestinations,
            startDate: getVal('startDate'),
            tier: getVal('tier'),
            adults: adults,
            children: children,
            rooms: rooms,
            totalAmount: math.total
        };

        if (paymentMode === 'cash') {
            const invoiceBase64 = await buildAndDownloadPDF(bookingId, `INV-${timePart}POS`, guestName, phone, email, getVal('resState'), getVal('tier'), adults, children, rooms, getVal('startDate'), math);
            
            // 1. Create the Lead/Row in Hostinger
            masterPayload.paymentId = "OFFLINE_POS";
            await fetch(HOSTINGER_API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(masterPayload) }).catch(e=>{});
            
            // 2. Immediately fire MARK_PAID to finalize the row with counts
            const markPaidPayload = {
                action: 'MARK_PAID',
                bookingId: bookingId,
                adults: adults,
                children: children,
                rooms: rooms,
                totalPaid: math.total,
                paymentRef: "OFFLINE_POS_CASH",
                couponUsed: "N/A",
                status: "Payment Complete"
            };
            await fetch(HOSTINGER_API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(markPaidPayload) }).catch(e=>{});

            // 3. Send Email
            var xhr = new XMLHttpRequest(); xhr.open("POST", HOSTINGER_MAILER_URL, true); xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = function() {
                window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(`Hi ${getVal('fName')},\n\nWe have successfully received your offline payment of ₹${fmt(math.total)} for Ref: *${bookingId}*.\n\nYour official Tax Invoice has been generated and sent to your email (${email}).\n\n- Traveltara`)}`, '_blank');
                btn.innerHTML = `<i class="fa-solid fa-check-double"></i> Done!`; setTimeout(() => window.location.reload(), 1500); 
            };
            xhr.send(JSON.stringify({ action: 'HOSTINGER_EMAIL', bookingId: bookingId, email: email, phone: phone, guestName: guestName, totalAmount: math.total, paymentId: "OFFLINE_CASH_POS", invoicePdf: invoiceBase64 }));
        
        } else {
            const posPayload = { tier: getVal('tier') || 'Customised', a: adults, c: children, r: rooms, date: getVal('startDate') || '', addr: getVal('resLine1') || '', city: getVal('resCity') || '', state: getVal('resState') || 'West Bengal', pin: getVal('resPin') || '' };
            const b64Data = btoa(encodeURIComponent(JSON.stringify(posPayload)));
            const payLink = `https://traveltara.com/checkout.php?ref=${bookingId}&dest=${encodeURIComponent(combinedDestinations)}&p=${b64Data}`;

            masterPayload.paymentId = "PENDING_LINK_SENT";
            await fetch(HOSTINGER_API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(masterPayload) }).catch(e=>{});
            
            var xhr = new XMLHttpRequest(); xhr.open("POST", HOSTINGER_MAILER_URL, true); xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = function() {
                window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(`Hi ${getVal('fName')},\n\nYour bespoke itinerary is ready!\n\nRef: *${bookingId}*\nTotal: *₹${fmt(math.total)}*\n\nTo secure your reservation, please pay via our secure gateway here:\n🔗 ${payLink}\n\nOnce paid, your Tax Invoice will be generated automatically.\n\n- Traveltara`)}`, '_blank');
                btn.innerHTML = `<i class="fa-solid fa-check-double"></i> Link Sent!`; setTimeout(() => window.location.reload(), 1500); 
            };
            xhr.send(JSON.stringify({ action: 'SEND_PAYMENT_LINK', bookingId: bookingId, email: email, phone: phone, guestName: guestName, totalAmount: math.total, destination: combinedDestinations, payloadStr: b64Data }));
        }
    } catch (error) {
        alert("Server error. Please try again."); btn.innerHTML = originalBtnText; btn.style.pointerEvents = 'auto'; 
    }
});

async function buildAndDownloadPDF(bookingId, invoiceNo, gName, gPhone, gEmail, state, tier, adults, children, rooms, sDate, math) {
    return new Promise((resolve) => {
        const d = new Date(); const formattedDate = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
        let formattedTripDate = sDate ? new Date(sDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : 'TBD';

        document.getElementById('invRealNo').innerText = invoiceNo; document.getElementById('invNo').innerText = bookingId;
        document.getElementById('invDate').innerText = formattedDate; document.getElementById('invDueDate').innerText = formattedDate;
        document.getElementById('invSupplyPlace').innerText = state; document.getElementById('invGuestName').innerText = gName;
        document.getElementById('invGuestPhone').innerText = gPhone; document.getElementById('invGuestEmail').innerText = gEmail;
        document.getElementById('invGuestAddress').innerText = document.getElementById('resLine1') ? document.getElementById('resLine1').value : "Address on File";
        document.getElementById('invGuestState').innerText = state; document.getElementById('invTravelDate').innerText = formattedTripDate;
        document.getElementById('invTier').innerText = tier; document.getElementById('invPax').innerText = `${adults} Adults, ${children} Children`;
        document.getElementById('invRooms').innerText = `${rooms} Room(s)`;

        const isLocal = state.toLowerCase().includes('west bengal') || state.toLowerCase().includes('wb');
        let totalCgst = 0, totalSgst = 0, totalIgst = 0;
        const tbody = document.getElementById('invTableBody'); tbody.innerHTML = ''; 
        let firstPkgName = "Custom Package";
        document.querySelectorAll('.location-row').forEach((row, index) => {
            const name = row.querySelector('.loc-name').value || 'Service'; const taxableAmt = parseFloat(row.querySelector('.loc-amt').value) || 0;
            if (index === 0) firstPkgName = name;
            let rowCgst = 0, rowSgst = 0, rowIgst = 0;
            if (isLocal) { rowCgst = taxableAmt * 0.025; rowSgst = taxableAmt * 0.025; totalCgst += rowCgst; totalSgst += rowSgst; } else { rowIgst = taxableAmt * 0.05; totalIgst += rowIgst; }
            const tr = document.createElement('tr');
            tr.innerHTML = `<td style="padding: 10px; border: 1px solid #ddd;">${name}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: center;">9985</td><td style="padding: 10px; border: 1px solid #ddd; text-align: center;">1</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${fmt(taxableAmt)}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${fmt(taxableAmt)}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${isLocal ? fmt(rowCgst) : "0.00"}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${isLocal ? fmt(rowSgst) : "0.00"}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${!isLocal ? fmt(rowIgst) : "0.00"}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right; font-weight: bold;">${fmt(taxableAmt + rowCgst + rowSgst + rowIgst)}</td>`;
            tbody.appendChild(tr);
        });

        document.getElementById('invPackage').innerText = document.querySelectorAll('.location-row').length > 1 ? `${firstPkgName} (+${document.querySelectorAll('.location-row').length - 1} more)` : firstPkgName;
        document.getElementById('invSumTaxable').innerText = "₹ " + fmt(math.taxable); document.getElementById('invSumCgst').innerText = isLocal ? "₹ " + fmt(totalCgst) : "₹ 0.00";
        document.getElementById('invSumSgst').innerText = isLocal ? "₹ " + fmt(totalSgst) : "₹ 0.00"; document.getElementById('invSumIgst').innerText = !isLocal ? "₹ " + fmt(totalIgst) : "₹ 0.00";
        document.getElementById('invSumGrand').innerText = "₹ " + fmt(math.total);
        
        function numberToWords(num) {
            const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
            const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
            if ((num = num.toString()).length > 9) return 'Overflow';
            const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
            if (!n) return ''; let str = '';
            str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : ''; str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
            str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : ''; str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
            str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'Only' : 'Only'; return str;
        }
        document.getElementById('invWordsText').innerText = "Rupees " + numberToWords(Math.round(math.total));

        const element = document.getElementById('traveltaraInvoice');
        const container = document.getElementById('invoicePrintContainer');
        
        container.style.display = 'block'; 
        container.style.position = 'absolute'; 
        container.style.top = '0'; 
        container.style.left = '0'; 
        container.style.zIndex = '-9999';

        setTimeout(() => {
            const opt = { 
                margin: 0, 
                filename: `${invoiceNo}.pdf`, 
                image: { type: 'jpeg', quality: 1 }, 
                html2canvas: { scale: 3, useCORS: true, windowWidth: 800, x: 0, y: 0, scrollY: 0 }, 
                jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait', compress: true } 
            };

            if (window.html2pdf) {
                const worker = html2pdf().set(opt).from(element);
                worker.save().then(() => {
                    worker.outputPdf('datauristring').then(function(pdfAsString) {
                        container.style.display = 'none'; 
                        resolve(pdfAsString.split(',')[1]);
                    });
                }).catch((err) => { container.style.display = 'none'; resolve(""); });
            } else { container.style.display = 'none'; resolve(""); }
        }, 150); 
    });
}