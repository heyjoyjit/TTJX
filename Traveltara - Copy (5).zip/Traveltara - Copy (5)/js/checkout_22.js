// =======================================================
// MASTER CHECKOUT.JS (SPLIT-BRAIN ROUTING - HIGH SPEED)
// =======================================================

// 🟢 1. GOOGLE (For Prices, Coupons, Razorpay & CRM Logging)
const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec";

// 🔴 2. HOSTINGER (For Heavy PDF handling & Emails)
const HOSTINGER_MAILER_URL = "https://traveltara.com/process_checkout_3.php"; 

let packageBasePrices = { "Budget": 0, "Affordable Luxury": 0, "Super Luxury": 0 };
let appliedDiscountPercent = 0;
let activeCouponCode = "";

function numberToWords(num) {
    const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
    const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
    if ((num = num.toString()).length > 9) return 'Overflow';
    const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return ''; 
    let str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'Only' : 'Only';
    return str;
}

window.calculatePricing = function() {
    const savedTier = sessionStorage.getItem('tara_tour_tier');
    const pricingSection = document.getElementById('pricingSection');
    const displayTotal = document.getElementById('displayTotalCost');
    
    if (!savedTier || savedTier === "Customised") {
        if(pricingSection) pricingSection.classList.add('hidden-section'); return;
    }

    const ppa = packageBasePrices[savedTier] || 0;
    if (ppa === 0) return;
    if(pricingSection) pricingSection.classList.remove('hidden-section');

    const adults = parseInt(document.getElementById('adults').value) || 1;
    const children = parseInt(document.getElementById('child').value) || 0;
    const minRooms = Math.ceil((adults + (children / 4)) / 2) || 1;

    document.getElementById('rooms').setAttribute('min', minRooms);
    let currentRooms = parseInt(document.getElementById('rooms').value) || 1;
    if (currentRooms < minRooms) { currentRooms = minRooms; document.getElementById('rooms').value = currentRooms; }

    const grandTotal = (adults * ppa) + (children * (ppa * 0.75)) + ((currentRooms - minRooms) * (ppa * 0.25));
    const discountAmount = grandTotal * (appliedDiscountPercent / 100);
    const finalPayable = grandTotal - discountAmount;

    if (displayTotal) {
        if (appliedDiscountPercent > 0) {
            displayTotal.innerHTML = `<span style="text-decoration:line-through; font-size: 14px; color: #888;">₹ ${grandTotal.toLocaleString('en-IN')}</span> <br> ₹ ${finalPayable.toLocaleString('en-IN')}`;
        } else { displayTotal.innerText = "₹ " + finalPayable.toLocaleString('en-IN'); }
    }
    sessionStorage.setItem('tara_total_price', finalPayable);
};

window.updateCount = function(id, delta) {
    const input = document.getElementById(id);
    if(!input) return;
    let currentVal = parseInt(input.value) || 0;
    let minVal = parseInt(input.getAttribute('min')) || 0;
    if(currentVal + delta >= minVal) { input.value = currentVal + delta; calculatePricing(); }
};

document.addEventListener('DOMContentLoaded', async () => {
    
    // 🚨 SECURE PAYMENT LOCK LOGIC 🚨
    const urlParams = new URLSearchParams(window.location.search);
    const payRef = urlParams.get('ref');
    const payDest = urlParams.get('dest') || "Bespoke Itinerary";

    if (payRef) {
        if(document.getElementById('checkoutBookingId')) document.getElementById('checkoutBookingId').innerText = payRef;
        if(document.getElementById('chkPackage')) document.getElementById('chkPackage').value = payDest;
        if(document.getElementById('chkTier')) document.getElementById('chkTier').value = "Customised VIP";

        // Lock the UI
        const partyGrid = document.querySelector('.party-grid');
        if(partyGrid) { partyGrid.style.pointerEvents = 'none'; partyGrid.style.opacity = '0.5'; }
        const discountBox = document.querySelector('.discount-container');
        if(discountBox) discountBox.style.display = 'none';

        const proceedBtn = document.getElementById('proceedPaymentBtn');
        if (proceedBtn) {
            proceedBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Verifying Secure Link...';
            proceedBtn.style.pointerEvents = 'none';
        }

        // Securely fetch exact price and status from Hostinger DB
        try {
            let res = await fetch(HOSTINGER_MAILER_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'VERIFY_PAYMENT_LINK', bookingId: payRef })
            });
            let data = await res.json();

            if (data.status === 'success' && proceedBtn) {
                if (data.payment_id !== 'PENDING_LINK_SENT') {
                    // LINK IS INVALID / ALREADY PAID
                    proceedBtn.innerHTML = '<i class="fa-solid fa-shield-check"></i> Payment Already Completed';
                    proceedBtn.style.background = '#27ae60';
                    proceedBtn.style.color = '#fff';
                    setTimeout(() => { window.location.href = 'success.php'; }, 2500);
                } else {
                    // LINK IS VALID - UNLOCK PAYMENT BUTTON
                    sessionStorage.setItem('tara_booking_id', payRef);
                    sessionStorage.setItem('tara_total_price', data.amount);
                    sessionStorage.setItem('tara_guest_name', data.guestName);
                    sessionStorage.setItem('tara_guest_email', data.email);
                    sessionStorage.setItem('tara_package_name', payDest);

                    const pricingSec = document.getElementById('pricingSection');
                    if (pricingSec) pricingSec.classList.remove('hidden-section');
                    
                    const displayTotal = document.getElementById('displayTotalCost');
                    if (displayTotal) displayTotal.innerText = `₹ ${parseInt(data.amount).toLocaleString('en-IN')}`;
                    
                    proceedBtn.innerHTML = `Pay Securely: ₹ ${parseInt(data.amount).toLocaleString('en-IN')}`;
                    proceedBtn.style.pointerEvents = 'auto';
                }
            } else if (proceedBtn) {
                proceedBtn.innerHTML = '<i class="fa-solid fa-link-slash"></i> Link Invalid or Expired';
            }
        } catch (e) {
            if (proceedBtn) proceedBtn.innerHTML = '<i class="fa-solid fa-wifi"></i> Connection Error';
        }
        
        // Prevent normal pricing logic from running
        window.calculatePricing = function() {}; 
        initCheckoutFormListeners(); // Initialize buttons but skip auto-fill
        return; 
    }

    // --- REGULAR CHECKOUT LOGIC (If no ?ref= in URL) ---
    const savedPackageName = sessionStorage.getItem('tara_package_name') || "Custom Trip";
    if(document.getElementById('checkoutBookingId')) document.getElementById('checkoutBookingId').innerText = sessionStorage.getItem('tara_booking_id') || "TRV-XXXXXX";
    if(document.getElementById('chkPackage')) document.getElementById('chkPackage').value = savedPackageName;
    if(document.getElementById('chkTier')) document.getElementById('chkTier').value = sessionStorage.getItem('tara_tour_tier') || "Standard";

    // FETCH PRICES FROM GOOGLE
    try {
        let response = await fetch(`${GOOGLE_SCRIPT_URL}?action=getPricing`);
        let masterPricingList = await response.json();
        if (masterPricingList[savedPackageName]) packageBasePrices = masterPricingList[savedPackageName];
    } catch (e) { console.error("Pricing Fetch Failed"); }

    calculatePricing();

    const couponBtn = document.getElementById('applyCouponBtn');
    if (couponBtn) {
        couponBtn.addEventListener('click', async () => {
            const code = document.getElementById('couponInput').value.trim().toUpperCase();
            if (!code) return; 
            couponBtn.innerText = "Wait..."; couponBtn.style.pointerEvents = "none";
            
            // FETCH COUPONS FROM GOOGLE
            try {
                let response = await fetch(`${GOOGLE_SCRIPT_URL}?action=verifyCoupon&code=${code}`);
                let result = await response.json();
                if (result.valid) {
                    appliedDiscountPercent = result.discount; activeCouponCode = code;
                    document.getElementById('couponMsg').innerText = `Congratulations! ${result.discount}% Discount Applied.`;
                    document.getElementById('couponMsg').style.color = "#27ae60";
                } else {
                    appliedDiscountPercent = 0; activeCouponCode = "";
                    document.getElementById('couponMsg').innerText = "Invalid Coupon Code or Expired";
                    document.getElementById('couponMsg').style.color = "#e74c3c";
                }
                calculatePricing(); 
            } catch (e) {}
            couponBtn.innerText = "APPLY"; couponBtn.style.pointerEvents = "auto";
        });
    }

    initCheckoutFormListeners();
});

function initCheckoutFormListeners() {
    const tncCheck = document.getElementById('tncCheck');
    const openTncText = document.getElementById('openTncText');
    const tncModal = document.getElementById('tncModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const agreeBtn = document.getElementById('agreeBtn');
    const scrollArea = document.getElementById('tncScrollArea');

    if(tncCheck && tncModal) {
        function openLegalModal(e) {
            if (!tncCheck.checked) {
                e.preventDefault(); tncModal.style.display = 'flex'; scrollArea.scrollTop = 0;
                if (agreeBtn) {
                    agreeBtn.classList.remove('unlocked'); agreeBtn.disabled = true; agreeBtn.innerText = "Scroll down to Agree";
                }
            }
        }
        tncCheck.addEventListener('click', openLegalModal);
        if (openTncText) openTncText.addEventListener('click', openLegalModal);
        if (closeModalBtn) closeModalBtn.addEventListener('click', () => { tncModal.style.display = 'none'; });
        if (scrollArea && agreeBtn) {
            scrollArea.addEventListener('scroll', () => {
                if (scrollArea.scrollTop + scrollArea.clientHeight >= scrollArea.scrollHeight - 10) {
                    agreeBtn.classList.add('unlocked'); agreeBtn.disabled = false; agreeBtn.innerHTML = '<i class="fa-solid fa-check"></i> I Agree to All Policies';
                }
            });
            agreeBtn.addEventListener('click', () => { tncCheck.checked = true; tncModal.style.display = 'none'; });
        }
    }

    const checkoutForm = document.getElementById('checkoutForm');
    const proceedBtn = document.getElementById('proceedPaymentBtn');

    if (checkoutForm && proceedBtn) {
       checkoutForm.addEventListener('submit', async (e) => {
            e.preventDefault(); 
            if (tncCheck && !tncCheck.checked) return alert("Please agree to the Terms & Policies first.");
            
            proceedBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Initializing Gateway...';
            proceedBtn.style.pointerEvents = 'none'; 
            
            const finalAmt = parseInt(sessionStorage.getItem('tara_total_price'));
            if (isNaN(finalAmt) || finalAmt < 1) return alert("Invalid amount. Check pricing.");
            
            const amountInPaise = finalAmt * 100; 
            const bookingId = sessionStorage.getItem('tara_booking_id') || 'TRV-XXXXXX';
            const guestName = sessionStorage.getItem('tara_guest_name') || 'Valued Guest';
            const guestEmail = sessionStorage.getItem('tara_guest_email') || '';
            const phone = sessionStorage.getItem('tara_guest_phone') || '';

            // INITIALIZE RAZORPAY VIA GOOGLE
            let orderData;
            try {
                const orderResponse = await fetch(`${GOOGLE_SCRIPT_URL}?action=createOrder&amount=${amountInPaise}`);
                orderData = await orderResponse.json();
                if(orderData.error) throw new Error(orderData.error);
            } catch (err) {
                alert("Failed to initialize gateway.");
                proceedBtn.innerHTML = 'Confirm & Proceed to Payment'; proceedBtn.style.pointerEvents = 'auto'; return;
            }

            var options = {
                "key": "rzp_live_SfkS8TnfvHiudv", 
                "amount": amountInPaise, 
                "currency": "INR",
                "name": "Traveltara",
                "description": "Secure Tour Booking: " + bookingId,
                "order_id": orderData.id, 
                "prefill": { "name": guestName, "email": guestEmail, "contact": phone },
                "theme": { "color": "#0A1128" },
                "handler": async function (response) {
                    proceedBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Securing Booking & Sending Email...';
                    const realPaymentId = response.razorpay_payment_id;

                    try {
                        const invoiceBase64 = await generateInvoicePDF(finalAmt, realPaymentId);

                        // 🔴 PAYLOAD 1: Sends heavy PDF to Hostinger for Emails
                        const hostingerPayload = {
                            action: 'HOSTINGER_EMAIL',
                            bookingId: bookingId,
                            email: guestEmail,
                            guestName: guestName,
                            totalAmount: finalAmt,
                            paymentId: realPaymentId,
                            invoicePdf: invoiceBase64         
                        };

                        // 🟢 PAYLOAD 2: Sends lightweight text to Google Sheets CRM (No PDF!)
                        const googlePayload = {
                            action: 'MARK_PAID',
                            bookingId: bookingId,
                            adults: document.getElementById('adults') ? document.getElementById('adults').value : '2',
                            children: document.getElementById('child') ? document.getElementById('child').value : '0',
                            rooms: document.getElementById('rooms') ? document.getElementById('rooms').value : '1',
                            totalAmount: finalAmt,
                            paymentId: realPaymentId,
                            couponUsed: activeCouponCode
                        };

                        // 1. Fire AJAX to Hostinger
                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", HOSTINGER_MAILER_URL, true);
                        xhr.setRequestHeader("Content-Type", "application/json;charset=utf-8");
                        
                        xhr.onload = function() {
                            try {
                                let serverResponse = JSON.parse(xhr.responseText);
                                if (serverResponse.status === "error") {
                                    alert("SERVER CRASH: " + serverResponse.message);
                                    proceedBtn.innerHTML = 'Confirm & Proceed to Payment';
                                    proceedBtn.style.pointerEvents = 'auto';
                                    return; 
                                }
                            } catch (e) {}

                            proceedBtn.style.background = '#27ae60'; 
                            proceedBtn.style.color = '#fff';
                            proceedBtn.innerHTML = `<i class="fa-solid fa-shield-check"></i> Booking Confirmed!`;
                            setTimeout(() => { window.location.href = "success.php"; }, 1500);
                        };

                        xhr.onerror = function() {
                            console.error("AJAX Transmission Failed");
                            window.location.href = "success.php";
                        };
                        
                        xhr.send(JSON.stringify(hostingerPayload));

                        // 2. Fire Fetch to Google simultaneously
                        fetch(GOOGLE_SCRIPT_URL, {
                            method: 'POST',
                            mode: 'no-cors',
                            headers: { 'Content-Type': 'text/plain' },
                            body: JSON.stringify(googlePayload)
                        }).catch(e => console.error("Google sync failed silently", e));

                    } catch (err) { window.location.href = "success.php"; }
                }
            };
            
            if (window.Razorpay) {
                var rzp1 = new window.Razorpay(options);
                rzp1.on('payment.failed', function (res){ alert("Payment Failed"); proceedBtn.innerHTML = 'Confirm & Proceed to Payment'; proceedBtn.style.pointerEvents = 'auto'; });
                rzp1.open();
            } else {
                alert("Payment Gateway Failed to Load. Please check your internet connection.");
                proceedBtn.innerHTML = 'Confirm & Proceed to Payment'; proceedBtn.style.pointerEvents = 'auto';
            }
        });
    }
}

// --- GENERATE INVOICE PDF (HIGH SPEED & HIGH RESOLUTION) ---
async function generateInvoicePDF(finalGrandTotal, razorpayPaymentId) {
    return new Promise((resolve, reject) => {
        const getSessionData = (keysArray) => {
            for(let key of keysArray) {
                let val = sessionStorage.getItem(key);
                if (val && val.trim() !== '') return val.trim();
            }
            return '';
        };

        const bookingId = sessionStorage.getItem('tara_booking_id') || 'TRV-XXXXX';
        const pkgName = sessionStorage.getItem('tara_package_name') || 'Custom Journey';
        const tier = sessionStorage.getItem('tara_tour_tier') || 'Standard';
        const guestName = getSessionData(['tara_guest_name', 'guest_name', 'name']) || 'Valued Guest';
        const guestPhone = getSessionData(['tara_guest_phone', 'tara_phone', 'phone']) || 'N/A';
        const guestEmail = getSessionData(['tara_guest_email', 'tara_email', 'email']) || 'N/A';

        const adults = document.getElementById('adults') ? document.getElementById('adults').value : '2';
        const kids = document.getElementById('child') ? document.getElementById('child').value : '0';
        const rooms = document.getElementById('rooms') ? document.getElementById('rooms').value : '1';

        const rawResAddr = getSessionData(['tara_res_address', 'tara_resAddress', 'resAddress', 'address', 'tara_guest_address']);
        const rawCity = getSessionData(['tara_city', 'tara_guest_city', 'city']);
        const guestState = getSessionData(['tara_state', 'tara_guest_state', 'state']) || 'West Bengal';
        const rawZip = getSessionData(['tara_pincode', 'tara_guest_pincode', 'pincode', 'zip', 'tara_zip']);

        const addressParts = [rawResAddr, rawCity, guestState, rawZip].filter(item => item !== '');
        const finalGuestAddress = addressParts.length > 0 ? addressParts.join(', ') : 'Address Not Provided';

        const invTimePart = Date.now().toString(36).toUpperCase().slice(-5);
        const invRandPart = Math.random().toString(36).toUpperCase().slice(2, 5);
        const generatedInvoiceNo = `INV-${invTimePart}${invRandPart}`;

        const grandTotal = parseFloat(finalGrandTotal);
        const taxableValue = grandTotal / 1.05; 
        
        let cgst = 0, sgst = 0, igst = 0;
        const isLocal = guestState.toLowerCase().includes('west bengal') || guestState.toLowerCase().includes('wb');
        
        if (isLocal) { cgst = taxableValue * 0.025; sgst = taxableValue * 0.025; } 
        else { igst = taxableValue * 0.05; }

        const today = new Date();
        const formattedDate = today.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

        // 🚀 Grab and format the Commencement Date from Memory
        const rawTripDate = sessionStorage.getItem('tara_start_date');
        let formattedTripDate = 'Not Selected';
        if (rawTripDate && rawTripDate.trim() !== '') {
            const d = new Date(rawTripDate);
            formattedTripDate = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
        }

        if(document.getElementById('invRealNo')) document.getElementById('invRealNo').innerText = generatedInvoiceNo;
        if(document.getElementById('invNo')) document.getElementById('invNo').innerText = bookingId;
        if(document.getElementById('invDate')) document.getElementById('invDate').innerText = formattedDate;
        if(document.getElementById('invDueDate')) document.getElementById('invDueDate').innerText = formattedDate; 
        if(document.getElementById('invPaymentId')) document.getElementById('invPaymentId').innerText = razorpayPaymentId || "Awaiting Gateway";
        if(document.getElementById('invSupplyPlace')) document.getElementById('invSupplyPlace').innerText = guestState;
        if(document.getElementById('invGuestName')) document.getElementById('invGuestName').innerText = guestName;
        if(document.getElementById('invGuestPhone')) document.getElementById('invGuestPhone').innerText = guestPhone;
        if(document.getElementById('invGuestEmail')) document.getElementById('invGuestEmail').innerText = guestEmail;
        if(document.getElementById('invGuestAddress')) document.getElementById('invGuestAddress').innerText = finalGuestAddress;
        if(document.getElementById('invGuestState')) document.getElementById('invGuestState').innerText = guestState;
        
        if(document.getElementById('invPackage')) document.getElementById('invPackage').innerText = pkgName;
        
        // Push the new date into the PDF
        if(document.getElementById('invTravelDate')) document.getElementById('invTravelDate').innerText = formattedTripDate;
        
        if(document.getElementById('invTier')) document.getElementById('invTier').innerText = tier;
        if(document.getElementById('invPax')) document.getElementById('invPax').innerText = `${adults} Adults, ${kids} Children`;
        if(document.getElementById('invRooms')) document.getElementById('invRooms').innerText = `${rooms} Room(s)`;
        if(document.getElementById('invRowDesc')) document.getElementById('invRowDesc').innerText = `${pkgName} - ${tier} Tier`;

        const fmt = (num) => num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        if(document.getElementById('invRowUnit')) document.getElementById('invRowUnit').innerText = fmt(taxableValue);
        if(document.getElementById('invRowTaxable')) document.getElementById('invRowTaxable').innerText = fmt(taxableValue);
        if(document.getElementById('invRowTotal')) document.getElementById('invRowTotal').innerText = fmt(grandTotal);
        if(document.getElementById('invSumTaxable')) document.getElementById('invSumTaxable').innerText = "₹ " + fmt(taxableValue);
        if(document.getElementById('invSumGrand')) document.getElementById('invSumGrand').innerText = "₹ " + fmt(grandTotal);
        if(document.getElementById('invRowCgst')) document.getElementById('invRowCgst').innerText = isLocal ? fmt(cgst) : "0.00";
        if(document.getElementById('invRowSgst')) document.getElementById('invRowSgst').innerText = isLocal ? fmt(sgst) : "0.00";
        if(document.getElementById('invRowIgst')) document.getElementById('invRowIgst').innerText = !isLocal ? fmt(igst) : "0.00";
        if(document.getElementById('invSumCgst')) document.getElementById('invSumCgst').innerText = isLocal ? "₹ " + fmt(cgst) : "₹ 0.00";
        if(document.getElementById('invSumSgst')) document.getElementById('invSumSgst').innerText = isLocal ? "₹ " + fmt(sgst) : "₹ 0.00";
        if(document.getElementById('invSumIgst')) document.getElementById('invSumIgst').innerText = !isLocal ? "₹ " + fmt(igst) : "₹ 0.00";
        if(document.getElementById('invWordsText')) document.getElementById('invWordsText').innerText = "Rupees " + numberToWords(Math.round(grandTotal));

        const element = document.getElementById('traveltaraInvoice');
        const container = document.getElementById('invoicePrintContainer');
        if (!element || !container) return resolve(""); 

        container.style.display = 'block';
        container.style.position = 'absolute';
        container.style.top = '0';
        container.style.left = '0';
        container.style.zIndex = '-9999';

        const opt = {
            margin: 0, 
            filename: `${generatedInvoiceNo}.pdf`,
            image: { type: 'jpeg', quality: 0.85 }, // Reduced to 85% to drastically cut file weight
            html2canvas: { scale: 1.2, useCORS: true, windowWidth: 800, scrollY: 0, x: 0, y: 0 }, // Optimized scale
            jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' } 
        };

        if (window.html2pdf) {
            const pdfWorker = html2pdf().set(opt).from(element);
            
            // 🔥 THE FIX: Generate ONCE, Download to Device, and Send to Hostinger
            pdfWorker.outputPdf('datauristring').then(function (pdfAsString) {
                container.style.display = 'none'; 
                
                // 1. Instantly trigger the local download on the customer's device
                const downloadLink = document.createElement('a');
                downloadLink.href = pdfAsString;
                downloadLink.download = `${generatedInvoiceNo}.pdf`;
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);

                // 2. Pass the EXACT SAME Base64 data to Hostinger for the email
                const cleanBase64 = pdfAsString.split(',')[1];
                resolve(cleanBase64); 

            }).catch((err) => { 
                console.error("PDF Engine Error:", err);
                container.style.display = 'none'; 
                resolve(""); 
            });
        } else {
            console.error("html2pdf library not loaded");
            container.style.display = 'none';
            resolve("");
        }
    });
}