// =======================================================
// SUCCESS.JS (FINAL DISPLAY & WHATSAPP GENERATOR)
// =======================================================

document.addEventListener('DOMContentLoaded', () => {
    // 1. Pull data from memory
    const savedId = sessionStorage.getItem('tara_booking_id') || 'N/A';
    const savedName = sessionStorage.getItem('tara_guest_name') || 'Guest';
    const savedPkg = sessionStorage.getItem('tara_package_name') || 'Custom Trip';
    
    // 2. Display the ID on the screen
    if(savedId !== 'N/A') {
        document.getElementById('finalRefId').innerText = savedId;
    }
    
    // 3. BUILD THE STRICTLY FORMATTED WHATSAPP MESSAGE
    const waBtn = document.getElementById('waButton');
    if (waBtn) {
        // Encode the variables so spaces/special characters don't break the link
        const encName = encodeURIComponent(savedName);
        const encId = encodeURIComponent(savedId);
        const encPkg = encodeURIComponent(savedPkg);
        
        // Using %0A to force strict line breaks in WhatsApp Web
        const finalMsg = `Hi%20Traveltara!%20I%20just%20completed%20my%20booking%20and%20need%20some%20assistance.%0A%0A*My%20Details:*%0AName:%20${encName}%0ARef%20ID:%20${encId}%0APackage:%20${encPkg}`;
        
        waBtn.href = `https://wa.me/919477709755?text=${finalMsg}`;
    }
    
    // NOTE: The 2-second automatic sessionStorage.clear() has been removed 
    // so you can refresh and test this page safely!
});