/**
 * ==========================================================================
 * TRAVELTARA LUXURY PORTAL - CORE APPLICATION ENGINE
 * ==========================================================================
 */
// =======================================================
// GLOBAL NAVBAR: AUTO-ACTIVE STATE DETECTOR
// =======================================================
document.addEventListener("DOMContentLoaded", () => {
    // 1. Get the current page URL (e.g., "destinations.php")
    let currentPath = window.location.pathname.split('/').pop();
    
    // 2. If it's empty (like just visiting your domain.com), assume it's the home page
    if (currentPath === '') {
        currentPath = 'index.php';
    }

    // 3. Find all your navigation links using your exact class
    const navLinks = document.querySelectorAll('.nav-item');

    // 4. Loop through them and find the one that matches the current page
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        
        if (linkHref === currentPath) {
            link.classList.add('active'); // Activates the CSS we just wrote!
        } else {
            link.classList.remove('active');
        }
    });
});

"use strict"; 

// =========================================
// 1. GLOBAL API (UI BINDINGS)
// These MUST sit at the top so your buttons can always find them!
// =========================================

// Hero Banner Buttons (Fixed scroll-snap math)
window.slideHero = function(direction) {
    const track = document.getElementById('heroTrack');
    if (!track) return;
    // Uses clientWidth and adds 5px to force it past the CSS snap point
    const slideWidth = track.clientWidth; 
    track.scrollBy({ left: (slideWidth + 5) * direction, behavior: 'smooth' });
};

window.slideDestinations = function(direction) {
    const track = document.getElementById('destSlider');
    if (!track) return;
    const cardWidth = track.querySelector('.dest-card').offsetWidth + 25; 
    track.scrollBy({ left: cardWidth * direction, behavior: 'smooth' });
};

window.slideReviews = function(direction) {
    const track = document.getElementById('reviewTrack');
    if (!track) return;
    const cardWidth = track.querySelector('.review-card').offsetWidth + 30; 
    track.scrollBy({ left: cardWidth * direction, behavior: 'smooth' });
};

window.slideVideos = function(direction) {
    const track = document.getElementById('videoTrack');
    if (!track) return;
    const cardWidth = track.querySelector('.video-card').offsetWidth + 20; 
    track.scrollBy({ left: cardWidth * direction, behavior: 'smooth' });
};

window.openLeadPopup = function() { 
    const popup = document.getElementById('leadPopup');
    if (popup) popup.style.display = 'flex'; 
};

window.closeLeadPopup = function() { 
    const popup = document.getElementById('leadPopup');
    if (popup) popup.style.display = 'none'; 
};


// =========================================
// 2. CORE APPLICATION INITIALIZATION
// =========================================
document.addEventListener("DOMContentLoaded", () => {

    /* --- A. MOBILE NAVIGATION --- */
    const mobileMenu = document.getElementById('mobile-menu');
    const navLinksContainer = document.getElementById('navLinks');
    
    if (mobileMenu && navLinksContainer) {
        mobileMenu.addEventListener('click', (e) => {
            e.preventDefault(); 
            navLinksContainer.classList.toggle('active');
            const icon = mobileMenu.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-xmark');
            }
        });
    }

    /* --- B. SMART LEAD POPUP (UPGRADED FOR WHATSAPP CONFLICT) --- */
    const popup = document.getElementById('leadPopup');
    if (popup) {
        
        // NEW LOGIC: Checks if chat is open before showing the popup
        const tryShowPopup = () => {
            if (!sessionStorage.getItem('vipPopupShown')) {
                // If WhatsApp chat is currently active, wait 10 seconds and try again!
                if (typeof isChatOpen !== 'undefined' && isChatOpen) {
                    setTimeout(tryShowPopup, 100); 
                    return;
                }
                
                window.openLeadPopup();
                sessionStorage.setItem('vipPopupShown', 'true');
            }
        };

        // Triggers the smart check after 12 seconds
        setTimeout(tryShowPopup, 12000);

        window.addEventListener('click', (e) => {
            if (e.target === popup) window.closeLeadPopup();
        });
    }

    /* --- C. HERO BANNER INFINITY SCROLL (Fixed Auto-Play) --- */
    const heroTrack = document.getElementById('heroTrack');
    if (heroTrack && !heroTrack.dataset.initialized) {
        heroTrack.dataset.initialized = "true";
        const heroSlides = Array.from(heroTrack.children);
        const slideCount = heroSlides.length;
        
        heroSlides.forEach(slide => heroTrack.appendChild(slide.cloneNode(true)));
        heroSlides.slice().reverse().forEach(slide => heroTrack.prepend(slide.cloneNode(true)));

        setTimeout(() => { heroTrack.scrollLeft = heroTrack.clientWidth * slideCount; }, 100);

        // Run timer unconditionally every 5 seconds
        let heroTimer = setInterval(() => { window.slideHero(1); }, 5000);
        const resetHeroTimer = () => { 
            clearInterval(heroTimer); 
            heroTimer = setInterval(() => window.slideHero(1), 5000); 
        };

        // REMOVED mouse hover pause! It now only pauses if you are physically dragging it on mobile
        heroTrack.addEventListener('touchstart', () => clearInterval(heroTimer), { passive: true });
        heroTrack.addEventListener('touchend', resetHeroTimer);

        const originalSlideHero = window.slideHero;
        window.slideHero = function(direction) {
            originalSlideHero(direction);
            resetHeroTimer();
        };

        heroTrack.addEventListener('scroll', () => {
            const w = heroTrack.clientWidth;
            if (heroTrack.scrollLeft <= 5) {
                heroTrack.style.scrollBehavior = 'auto'; 
                heroTrack.scrollLeft += w * slideCount;
            } else if (heroTrack.scrollLeft >= w * (slideCount * 2) - 5) {
                heroTrack.style.scrollBehavior = 'auto'; 
                heroTrack.scrollLeft -= w * slideCount;
            }
        }, { passive: true });
    }

    

    /* --- E. TEXT REVIEWS INFINITY SCROLL --- */
    const reviewTrack = document.getElementById('reviewTrack');
    if (reviewTrack && !reviewTrack.dataset.initialized) {
        reviewTrack.dataset.initialized = "true";
        const revCards = Array.from(reviewTrack.children);
        const revCount = revCards.length;
        
        revCards.forEach(card => reviewTrack.appendChild(card.cloneNode(true)));
        revCards.slice().reverse().forEach(card => reviewTrack.prepend(card.cloneNode(true)));

        setTimeout(() => { reviewTrack.scrollLeft = (reviewTrack.querySelector('.review-card').offsetWidth + 30) * revCount; }, 100);

        let revTimer = setInterval(() => { window.slideReviews(1); }, 5000);
        const resetRevTimer = () => { 
            clearInterval(revTimer); 
            revTimer = setInterval(() => window.slideReviews(1), 5000); 
        };

        reviewTrack.addEventListener('mouseenter', () => clearInterval(revTimer));
        reviewTrack.addEventListener('mouseleave', resetRevTimer);
        reviewTrack.addEventListener('touchstart', () => clearInterval(revTimer), { passive: true });
        reviewTrack.addEventListener('touchend', resetRevTimer);

        const originalSlideReviews = window.slideReviews;
        window.slideReviews = function(direction) {
            originalSlideReviews(direction);
            resetRevTimer();
        };

        reviewTrack.addEventListener('scroll', () => {
            const w = reviewTrack.querySelector('.review-card').offsetWidth + 30;
            if (reviewTrack.scrollLeft <= w) {
                reviewTrack.style.scrollBehavior = 'auto'; 
                reviewTrack.scrollLeft += w * revCount;
            } else if (reviewTrack.scrollLeft >= w * (revCount * 2) - reviewTrack.clientWidth) {
                reviewTrack.style.scrollBehavior = 'auto'; 
                reviewTrack.scrollLeft -= w * revCount;
            }
        }, { passive: true });
    }

    // --- 6. TRAVELER REELS (VIEWPORT SENSITIVE & EXCLUSIVE PLAY) ---
    const videoTrack = document.getElementById('videoTrack');
    if (videoTrack) {
        const cards = videoTrack.querySelectorAll('.video-card');
        let activeCard = null; // Tracks the currently unmuted/focused video

        // 1. Set up the Viewport Observer (The "Security Camera")
        const observerOptions = {
            root: null, // Watches the main browser screen
            threshold: 0.2 // Triggers as soon as the video is less than 20% visible
        };

        const videoObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                const card = entry.target;
                const vid = card.querySelector('video');

                if (!entry.isIntersecting) {
                    // --- SCROLLED OUT OF VIEW ---
                    vid.pause(); // Instantly pause to save battery
                    
                    // If they scrolled away from the active unmuted video, reset it!
                    if (activeCard === card) {
                        activeCard = null;
                        vid.muted = true;
                        card.classList.remove('is-playing');
                        card.querySelector('.play-pause-btn i').className = 'fa-solid fa-play';
                        card.querySelector('.mute-btn i').className = 'fa-solid fa-volume-xmark';
                        card.querySelector('.mute-btn').style.background = 'rgba(0, 0, 0, 0.5)';
                        
                        // Wake up any OTHER videos that are currently on the screen
                        resumeBackgroundVideos();
                    }
                } else {
                    // --- SCROLLED INTO VIEW ---
                    // Only start playing if no one is currently focused on an active video
                    if (activeCard === null) {
                        vid.muted = true; // Guarantee it is silent
                        vid.play().catch(e => console.log("Autoplay prevented:", e));
                    }
                }
            });
        }, observerOptions);

        // Helper: Scans the screen and wakes up visible background videos
        const resumeBackgroundVideos = () => {
            cards.forEach(c => {
                const rect = c.getBoundingClientRect();
                // Math to check if the card is currently inside the screen boundaries
                const isVisible = (rect.top < window.innerHeight && rect.bottom >= 0 && rect.left < window.innerWidth && rect.right >= 0);
                
                if (isVisible) {
                    const v = c.querySelector('video');
                    v.muted = true;
                    v.play().catch(() => {});
                    c.classList.remove('is-playing');
                    c.querySelector('.play-pause-btn i').className = 'fa-solid fa-play';
                }
            });
        };

        // 2. Attach Listeners to Each Card
        cards.forEach(card => {
            // Tell the observer to start watching this specific card
            videoObserver.observe(card); 

            const vid = card.querySelector('video');
            const muteBtn = card.querySelector('.mute-btn');
            const playIcon = card.querySelector('.play-pause-btn i');

            // --- CLICKING THE VIDEO CARD ---
            card.addEventListener('click', (e) => {
                if (e.target.closest('.mute-btn') || e.target.closest('.slider-btn')) return; 

                if (activeCard === card) {
                    // Clicking the active video resets everything to silent background mode
                    activeCard = null;
                    resumeBackgroundVideos(); 
                } else {
                    // Clicking a new video makes it Exclusive
                    activeCard = card;
                    
                    cards.forEach(otherCard => {
                        if (otherCard !== card) {
                            const otherVid = otherCard.querySelector('video');
                            otherVid.pause(); // Freeze all others
                            otherVid.muted = true; 
                            otherCard.classList.remove('is-playing');
                            otherCard.querySelector('.play-pause-btn i').className = 'fa-solid fa-play';
                        }
                    });

                    vid.play();
                    card.classList.add('is-playing');
                    playIcon.className = 'fa-solid fa-pause';
                }
            });

            // --- CLICKING THE MUTE BUTTON ---
            muteBtn.addEventListener('click', (e) => {
                e.stopPropagation(); 
                
                // Security Rule: Unmuting an inactive video makes it the active one
                if (activeCard !== card) {
                    card.click(); 
                }

                vid.muted = !vid.muted;
                muteBtn.querySelector('i').className = vid.muted ? 'fa-solid fa-volume-xmark' : 'fa-solid fa-volume-high';
                muteBtn.style.background = vid.muted ? 'rgba(0, 0, 0, 0.5)' : 'var(--primary-gold)';
            });
        });
    }

    // --- 7. FAQ ACCORDION & SHOW MORE LOGIC ---
    
    // Part A: Individual Question Clicking
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const questionBtn = item.querySelector('.faq-question');
        if(questionBtn) {
            questionBtn.addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                
                // Close all other FAQs first for a clean accordion effect
                faqItems.forEach(otherItem => otherItem.classList.remove('active'));
                
                // If the clicked one wasn't already open, open it now
                if (!isActive) item.classList.add('active');
            });
        }
    });

    // Part B: Show More / Show Less Button
    const toggleBtn = document.getElementById('toggleFaqsBtn');
    const moreFaqsWrapper = document.getElementById('moreFaqsWrapper');

    if (toggleBtn && moreFaqsWrapper) {
        toggleBtn.addEventListener('click', function() {
            const isExpanded = moreFaqsWrapper.classList.contains('expanded');

            if (!isExpanded) {
                // Expand the section
                moreFaqsWrapper.classList.add('expanded');
                this.innerHTML = 'Show Less <i class="fa-solid fa-angle-up" style="margin-left: 5px;"></i>';
            } else {
                // Collapse the section
                moreFaqsWrapper.classList.remove('expanded');
                this.innerHTML = 'Show More <i class="fa-solid fa-angle-down" style="margin-left: 5px;"></i>';
                
                // Clean up: Auto-close any open questions inside the hidden block
                moreFaqsWrapper.querySelectorAll('.faq-item').forEach(item => {
                    item.classList.remove('active');
                });
            }
        });
    }
    /* --- I. STRICT FORM VALIDATION --- */
    document.querySelectorAll('.val-name').forEach(input => {
        input.addEventListener('input', e => e.target.value = e.target.value.replace(/[^A-Za-z\s]/g, ''));
    });
    document.querySelectorAll('.val-phone').forEach(input => {
        input.addEventListener('input', e => {
            e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10);
        });
    });
    document.querySelectorAll('.val-date').forEach(input => {
        input.addEventListener('input', e => {
            if (e.inputType === 'deleteContentBackward') return;
            let v = e.target.value.replace(/\D/g, '').substring(0, 8); 
            if (v.length >= 5) e.target.value = `${v.substring(0, 2)}/${v.substring(2, 4)}/${v.substring(4, 8)}`;
            else if (v.length >= 3) e.target.value = `${v.substring(0, 2)}/${v.substring(2)}`;
            else e.target.value = v;
        });
    });

    /* --- J. SMART SEARCH AUTOCOMPLETE --- */
    const searchInputHero = document.getElementById('destinationSearch');
    const searchSuggestions = document.getElementById('searchSuggestions');
    const searchForm = document.getElementById('mainSearchBar');
    
    if (searchInputHero && searchSuggestions) {
        const destData = [
            { name: "Kolkata, West Bengal", url: "city-kolkata.php", type: "City Escape" },
            { name: "Mumbai, Maharashtra", url: "city-mumbai.php", type: "City Escape" },
            { name: "Bangalore, Karnataka", url: "city-bangalore.php", type: "City Escape" },
            { name: "Delhi, NCR", url: "city-delhi.php", type: "City Escape" },
            { name: "Jaipur, Rajasthan", url: "city-jaipur.php", type: "Heritage City" },
            { name: "Goa (South Goa)", url: "city-goa.php", type: "Coastal Luxury" },
            { name: "Sikkim", url: "sikkim-itinerary.php", type: "Mountain Itinerary" },
            { name: "Rajasthan", url: "rajasthan-itinerary.php", type: "Heritage Itinerary" },
            { name: "Darjeeling", url: "north-bengal-itinerary.php", type: "Heritage Itinerary" },
            { name: "Himachal Pradesh", url: "himachal-itinerary.php", type: "Mountain Itinerary" },
            { name: "Munnar, Kerala", url: "munnar-itinerary.php", type: "Nature & Spa" }
        ];

        searchInputHero.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase().trim();
            searchSuggestions.innerHTML = ''; 
            if (query.length === 0) {
                searchSuggestions.style.cssText = "display: none !important;";
                return;
            }
            const filtered = destData.filter(d => d.name.toLowerCase().includes(query) || d.type.toLowerCase().includes(query));
            if (filtered.length > 0) {
                filtered.forEach(dest => {
                    const a = document.createElement('a');
                    a.href = dest.url;
                    a.className = 'suggestion-item';
                    a.innerHTML = `<i class="fa-solid fa-location-dot"></i><div class="suggestion-text"><strong>${dest.name}</strong><span>${dest.type}</span></div>`;
                    searchSuggestions.appendChild(a);
                });
            } else {
                searchSuggestions.innerHTML = `<div style="padding: 15px 25px; color: #888; font-style: italic;">No destinations found. Try "Jaipur".</div>`;
            }
            searchSuggestions.style.cssText = "display: flex !important; flex-direction: column !important;";
        });

        document.addEventListener('click', (e) => {
            if (!searchInputHero.contains(e.target) && !searchSuggestions.contains(e.target)) {
                searchSuggestions.style.cssText = "display: none !important;";
            }
        });

        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const query = searchInputHero.value.toLowerCase().trim();
                const match = destData.find(d => d.name.toLowerCase().includes(query));
                window.location.href = match ? match.url : "destinations.php";
            });
        }
    }

    /* --- K. BLOG PAGE FILTERING --- */
    const blogSearchInput = document.getElementById('searchInput');
    if (blogSearchInput) {
        blogSearchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            let found = false;
            document.querySelectorAll('.featured-post, .blog-card').forEach(post => {
                const isMatch = post.textContent.toLowerCase().includes(query);
                post.style.display = isMatch ? (post.classList.contains('featured-post') ? 'flex' : 'block') : 'none';
                if (isMatch) found = true;
            });
            let noMsg = document.getElementById('no-results-msg');
            if (!found) {
                if (!noMsg) {
                    const grid = document.querySelector('.blog-grid');
                    if(grid) grid.insertAdjacentHTML('beforeend', '<p id="no-results-msg" style="text-align:center; padding:40px; width:100%; color:#555;">No articles found.</p>');
                } else noMsg.style.display = 'block';
            } else if (noMsg) noMsg.style.display = 'none';
        });
    }

    document.querySelectorAll('.category-filter').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.category-filter').forEach(b => b.style.color = 'var(--dark-navy)');
            e.target.style.color = 'var(--primary-gold)';
            const targetCat = e.target.getAttribute('data-target');
            document.querySelectorAll('.featured-post, .blog-card').forEach(post => {
                const match = (targetCat === 'all' || post.getAttribute('data-category') === targetCat);
                post.style.display = match ? (post.classList.contains('featured-post') ? 'flex' : 'block') : 'none';
            });
        });
    });
    

}); // End DOMContentLoaded

// =========================================
// TRENDING CITIES: FILTERS & SHOW MORE (MAX 4)
// =========================================
document.addEventListener("DOMContentLoaded", () => {
    const cityPills = document.querySelectorAll('.city-pill');
    const cityCards = document.querySelectorAll('.city-wrapper');
    const showMoreBtn = document.getElementById('showMoreCitiesBtn');
    
    let currentFilter = 'urbans'; // Default category
    let isExpanded = false;

    // Core function to calculate and show/hide the correct cards
    function applyCityFilter() {
        let matchCount = 0;

        cityCards.forEach(card => {
            if (card.getAttribute('data-category') === currentFilter) {
                matchCount++;
                card.classList.remove('hidden-city'); 
                
                if (!isExpanded && matchCount > 4) {
                    card.classList.add('hidden-extra');
                } else {
                    card.classList.remove('hidden-extra');
                    card.style.animation = 'none';
                    card.offsetHeight; 
                    card.style.animation = 'cityFadeIn 0.4s ease forwards';
                }
            } else {
                card.classList.add('hidden-city');
                card.classList.remove('hidden-extra');
            }
        });

        // Show or Hide the Text Button based on math
        if (showMoreBtn) {
            if (matchCount > 4) {
                showMoreBtn.style.display = 'inline-block';
                // UPDATED: Now toggles the text between "See Less" and "See More"
                showMoreBtn.innerHTML = isExpanded 
                    ? 'See Less <i class="fa-solid fa-angle-up" style="margin-left: 5px;"></i>' 
                    : 'See More <i class="fa-solid fa-angle-down" style="margin-left: 5px;"></i>';
            } else {
                showMoreBtn.style.display = 'none'; 
            }
        }
    }

    if (cityPills.length > 0 && cityCards.length > 0) {
        
        // 1. Run the math immediately when the page loads
        applyCityFilter();

        // 2. What happens when a user clicks a Tab
        cityPills.forEach(pill => {
            pill.addEventListener('click', (e) => {
                // Update active gold button style
                cityPills.forEach(p => p.classList.remove('active'));
                e.target.classList.add('active');
                
                // Set the new filter, reset expansion, and run math
                currentFilter = e.target.getAttribute('data-filter');
                isExpanded = false; 
                applyCityFilter();
            });
        });

        // 3. What happens when a user clicks the Arrow
        if (showMoreBtn) {
            showMoreBtn.addEventListener('click', () => {
                isExpanded = !isExpanded; // Toggle true/false
                applyCityFilter();
            });
        }
    }
});

// ==========================================================================
// SMART WHATSAPP LIVE CHAT LOGIC (WITH DESTINATION MENU)
// ==========================================================================

let chatStep = 0;
let chatData = { name: '', phone: '', email: '', message: '' };
let isChatOpen = false;

function playNotificationSound() {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = 'sine'; osc.frequency.setValueAtTime(880, ctx.currentTime); 
        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.3);
    } catch (e) { }
}

window.toggleWaPopup = function() {
    const popup = document.getElementById('waPopup');
    if (!popup) return;
    
    // Instantly hide the tooltip if they click the button while it's auto-showing!
    const tooltip = document.querySelector('.wa-tooltip');
    if (tooltip) tooltip.classList.remove('auto-show');

    popup.classList.toggle('active');
    isChatOpen = popup.classList.contains('active');

    if (isChatOpen && chatStep === 0) {
        document.getElementById('waChatCanvas').innerHTML = ''; 
        playNotificationSound();
        showTypingIndicator();
        
        setTimeout(() => {
            removeTypingIndicator();
            appendBotMessage("Hi there! 👋 Welcome to Traveltara. To get started, what is your name?");
            chatStep = 1; 
        }, 1500);
    }
}

window.handleWaEnter = function(event) {
    if (event.key === 'Enter') processUserMessage();
}

window.processUserMessage = function() {
    const inputField = document.getElementById('waInputField');
    const text = inputField.value.trim();
    if (!text) return; 

    appendUserMessage(text);
    inputField.value = '';
    showTypingIndicator();

    setTimeout(() => {
        removeTypingIndicator();

        // STEP 1: Name -> Phone
        if (chatStep === 1) {
            chatData.name = text;
            appendBotMessage(`Nice to meet you, ${chatData.name}! Could you share your 10-digit WhatsApp number so we can easily reach you?`);
            chatStep = 2;
        } 
        
        // STEP 2: Phone -> Email
        else if (chatStep === 2) {
            if (!/^\d{10}$/.test(text)) {
                appendBotMessage("Invalid input. Please provide a valid 10-digit numeric phone number.");
                return; 
            }
            chatData.phone = text;
            
            const canvas = document.getElementById('waChatCanvas');
            const msgHTML = `
                <div class="wa-chat-bubble incoming fade-in-chat" id="emailStepBubble">
                    <span class="wa-sender">Traveltara Concierge</span>
                    <p>Got it, thanks! Please provide your email address to receive our exclusive luxury deals.</p>
                    <button class="wa-quick-reply-btn" onclick="skipEmailStep()">No thanks, I'll miss the chance</button>
                    <span class="wa-time">Just now</span>
                </div>
            `;
            canvas.insertAdjacentHTML('beforeend', msgHTML);
            playNotificationSound();
            scrollToBottom();
            chatStep = 3;
        } 
        
        // STEP 3: Email -> Query Options
        else if (chatStep === 3) {
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text)) {
                appendBotMessage("Invalid format. Please provide a valid email (e.g., name@example.com) or tap the button above to miss the chance.");
                return; 
            }
            chatData.email = text;
            removeElementById('emailStepBubble'); 
            triggerQueryOptions("Perfect! Now, how can we help you today?");
        }

        // STEP 4: User Typed Custom Text instead of clicking "Exploring", "Specific", or "Associate"
        else if (chatStep === 4) {
            removeElementById('queryStepBubble'); 
            chatData.message = text;
            finalizeChat();
        }

        // STEP 5: User Typed Custom Text instead of clicking a Destination Button
        else if (chatStep === 5) {
            removeElementById('destListBubble');
            chatData.message = `Destination Requested: ${text}`;
            finalizeChat();
        }

        // STEP 6: User Typed their destination AFTER clicking "Others"
        else if (chatStep === 6) {
            chatData.message = `Destination Requested: ${text}`;
            finalizeChat();
        }

    }, 1200); 
}

// --- OPTION BUTTON HANDLERS ---

window.skipEmailStep = function() {
    appendUserMessage("I'll miss the chance"); 
    chatData.email = "Skipped";
    removeElementById('emailStepBubble');
    
    showTypingIndicator();
    setTimeout(() => {
        removeTypingIndicator();
        triggerQueryOptions("Perfect! Now, how can we help you today?");
    }, 1200);
}

// Shows: Exploring vs Specific vs Associate
function triggerQueryOptions(introText) {
    const canvas = document.getElementById('waChatCanvas');
    const msgHTML = `
        <div class="wa-chat-bubble incoming fade-in-chat" id="queryStepBubble">
            <span class="wa-sender">Traveltara Concierge</span>
            <p>${introText}</p>
            <div class="wa-quick-reply-group">
                <button class="wa-quick-reply-btn" onclick="chooseQuery('Just exploring options')">Just exploring options</button>
                <button class="wa-quick-reply-btn" onclick="chooseQuery('Specific destination')">Specific destination</button>
                <button class="wa-quick-reply-btn" onclick="chooseQuery('Need an associate')">Need an associate</button>
            </div>
            <span class="wa-time">Just now</span>
        </div>
    `;
    canvas.insertAdjacentHTML('beforeend', msgHTML);
    playNotificationSound();
    scrollToBottom();
    chatStep = 4; 
}

window.chooseQuery = function(choice) {
    removeElementById('queryStepBubble'); 
    appendUserMessage(choice);
    
    showTypingIndicator();
    setTimeout(() => {
        removeTypingIndicator();
        
        if (choice === 'Just exploring options') {
            chatData.message = "Just exploring options.";
            finalizeChat();
        } else if (choice === 'Need an associate') {
            chatData.message = "I need to speak with an associate.";
            finalizeChat();
        } else {
            // They chose Specific Destination -> Show the list!
            triggerDestinationList("Awesome! Choose your destination from the list below or type it in:");
        }
    }, 1000);
}

// Shows: Destination List
function triggerDestinationList(introText) {
    const canvas = document.getElementById('waChatCanvas');
    const msgHTML = `
        <div class="wa-chat-bubble incoming fade-in-chat" id="destListBubble">
            <span class="wa-sender">Traveltara Concierge</span>
            <p>${introText}</p>
            <div class="wa-quick-reply-group">
                <button class="wa-quick-reply-btn" onclick="chooseDestination('Kashmir')">Kashmir</button>
                <button class="wa-quick-reply-btn" onclick="chooseDestination('Kerala')">Kerala</button>
                <button class="wa-quick-reply-btn" onclick="chooseDestination('Bali')">Bali</button>
                <button class="wa-quick-reply-btn" onclick="chooseDestination('Dubai')">Dubai</button>
                <button class="wa-quick-reply-btn" onclick="chooseDestination('Others')">Others</button>
            </div>
            <span class="wa-time">Just now</span>
        </div>
    `;
    canvas.insertAdjacentHTML('beforeend', msgHTML);
    playNotificationSound();
    scrollToBottom();
    chatStep = 5; 
}

window.chooseDestination = function(dest) {
    removeElementById('destListBubble'); 
    appendUserMessage(dest);
    
    showTypingIndicator();
    setTimeout(() => {
        removeTypingIndicator();
        
        if (dest === 'Others') {
            appendBotMessage("Got it! Please type the specific place name below.");
            chatStep = 6; // Moves to Step 6 to wait for their typed destination
        } else {
            chatData.message = `Destination Requested: ${dest}`;
            finalizeChat();
        }
    }, 1000);
}

// --- DOM HELPERS & SUBMISSION ---

// --- DOM HELPERS & SUBMISSION ---

function finalizeChat() {
    appendBotMessage("Perfect! I'm connecting you to our luxury travel expert right now... ✈️");
    setTimeout(() => { submitAndRedirect(); }, 1200);
}

function removeElementById(id) {
    const el = document.getElementById(id);
    if (el) {
        const buttons = el.querySelectorAll('.wa-quick-reply-btn, .wa-quick-reply-group');
        buttons.forEach(btn => btn.remove()); 
    }
}

function appendBotMessage(text) {
    const canvas = document.getElementById('waChatCanvas');
    canvas.insertAdjacentHTML('beforeend', `<div class="wa-chat-bubble incoming fade-in-chat"><span class="wa-sender">Traveltara Concierge</span><p>${text}</p><span class="wa-time">Just now</span></div>`);
    playNotificationSound();
    scrollToBottom();
}

function appendUserMessage(text) {
    const canvas = document.getElementById('waChatCanvas');
    canvas.insertAdjacentHTML('beforeend', `<div class="wa-chat-bubble outgoing fade-in-chat"><p>${text}</p><span class="wa-time">Just now</span></div>`);
    scrollToBottom();
}

function showTypingIndicator() {
    const canvas = document.getElementById('waChatCanvas');
    canvas.insertAdjacentHTML('beforeend', `<div class="wa-chat-bubble incoming" id="waActiveTyping" style="width: 60px; padding: 12px 15px;"><div class="typing-indicator"><span></span><span></span><span></span></div></div>`);
    scrollToBottom();
}

function removeTypingIndicator() {
    const typing = document.getElementById('waActiveTyping');
    if (typing) typing.remove();
}

function scrollToBottom() {
    const canvas = document.getElementById('waChatCanvas');
    canvas.scrollTop = canvas.scrollHeight;
}

// --- API SUBMISSION ---
function submitAndRedirect() {
    const waText = encodeURIComponent(`Hi Traveltara! My name is ${chatData.name}.\nEmail: ${chatData.email}\n\nMy Query: ${chatData.message}`);
    const waNumber = "917439877604"; 
    
    const formData = new FormData();
    formData.append("access_key", "9c6e22cb-aa85-4e4b-83b0-603a658c95ea");
    formData.append("subject", "New Live Chat Lead!");
    formData.append("Name", chatData.name);
    formData.append("Phone", chatData.phone);
    formData.append("Email", chatData.email); 
    formData.append("Message", chatData.message);
    
    fetch('https://api.web3forms.com/submit', { method: 'POST', body: formData }).catch(e => console.log(e));

    chatStep = 0;
    chatData = { name: '', phone: '', email: '', message: '' };
    toggleWaPopup(); 
    
    window.open(`https://wa.me/${waNumber}?text=${waText}`, '_blank');
}

// --- 7. AUTO-NUDGE TOOLTIP (ONE-TIME AT 50 SECONDS) ---
document.addEventListener("DOMContentLoaded", () => {
    const tooltip = document.querySelector('.wa-tooltip');
    
    // Check if we've already nudged them this session
    const hasTooltipShown = sessionStorage.getItem('waTooltipShown');
    
    if (tooltip && !hasTooltipShown) {
        setTimeout(() => {
            const popup = document.getElementById('waPopup');
            
            // STRICT CHECK: Only show if the popup does NOT have the 'active' class
            if (popup && !popup.classList.contains('active')) {
                tooltip.classList.add('auto-show');
                
                // Hide it after 7 seconds
                setTimeout(() => {
                    tooltip.classList.remove('auto-show');
                }, 7000); 

                // Lock the auto-tooltip for the rest of the session
                sessionStorage.setItem('waTooltipShown', 'true');
            }
        }, 50000); // 50 seconds
    }
});

// --- 8. AUTO-OPEN CHATBOX (ONE-TIME AT 55 SECONDS) ---
document.addEventListener("DOMContentLoaded", () => {
    // Check if we've already auto-opened the chat this session
    const hasChatAutoOpened = sessionStorage.getItem('waChatAutoOpened');

    if (!hasChatAutoOpened) {
        setTimeout(() => {
            const leadPopup = document.getElementById('leadPopup');
            const isLeadOpen = leadPopup && (leadPopup.style.display === 'flex' || leadPopup.style.display === 'block');
            
            // Only auto-open if the chat isn't already open, user hasn't interacted, and the VIP popup isn't visible
            if (!isChatOpen && chatStep === 0 && !isLeadOpen) {
                if (typeof window.toggleWaPopup === 'function') {
                    window.toggleWaPopup();
                    
                    // Lock the auto-open for the rest of the session
                    sessionStorage.setItem('waChatAutoOpened', 'true');
                }
            }
        }, 55000); // 55 seconds
    }
});

// =========================================
// MOBILE LEFT-SIDE NAVIGATION LOGIC
// =========================================
document.addEventListener("DOMContentLoaded", () => {
    // Using your exact html IDs
    const openBtn = document.getElementById('mobile-menu');
    const closeBtn = document.getElementById('menuCloseBtn');
    const sideNav = document.getElementById('navLinks');
    const overlay = document.getElementById('navOverlay');

    if (openBtn && closeBtn && sideNav && overlay) {
        
        // 1. Open the Menu
        openBtn.addEventListener('click', () => {
            sideNav.classList.add('active');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden'; // Stop background scrolling
        });

        // 2. Helper to close the menu
        const closeMenu = () => {
            sideNav.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = ''; // Restore scrolling
        };

        // 3. Close Triggers
        closeBtn.addEventListener('click', closeMenu); // Click the 'X'
        overlay.addEventListener('click', closeMenu);  // Click the dark background
        
        // Close menu if a user clicks a link (useful for one-page scrolling sites)
        const navItems = sideNav.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('click', closeMenu);
        });
    }
});
// --- 6. TRAVELER REELS (SMOOTH INFINITY & SMART AUDIO PLAYBACK) ---
const videoTrack = document.getElementById('videoTrack');
if (videoTrack && !videoTrack.dataset.initialized) {
    videoTrack.dataset.initialized = "true";
    const originalCards = Array.from(videoTrack.querySelectorAll('.video-card'));
    const vidCount = originalCards.length;
    let activeCard = null;

    // Helper to reset the UI of a muted/paused card
    const resetCardUI = (card, vid) => {
        vid.muted = true;
        card.classList.remove('is-playing');
        
        const playBtn = card.querySelector('.play-pause-btn i');
        if (playBtn) playBtn.className = 'fa-solid fa-play';
        
        const muteBtn = card.querySelector('.mute-btn');
        if (muteBtn) {
            muteBtn.querySelector('i').className = 'fa-solid fa-volume-xmark';
            muteBtn.style.background = 'rgba(0, 0, 0, 0.5)';
        }
    };

    // 1. Observer: Plays muted by default, mutes/pauses when scrolled away
    const videoObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            const card = entry.target;
            const vid = card.querySelector('video');

            if (!entry.isIntersecting) {
                // Video scrolled out of view -> Pause & Force Mute
                vid.pause();
                resetCardUI(card, vid);
                
                if (activeCard === card) {
                    activeCard = null;
                    resumeBackgroundVideos();
                }
            } else if (activeCard === null) {
                // Video scrolled into view -> Autoplay MUTED
                vid.muted = true;
                vid.play().catch(() => {});
            }
        });
    }, { threshold: 0.2 });

    const resumeBackgroundVideos = () => {
        videoTrack.querySelectorAll('.video-card').forEach(c => {
            const rect = c.getBoundingClientRect();
            const isVisible = (rect.top < window.innerHeight && rect.bottom >= 0 && rect.left < window.innerWidth && rect.right >= 0);
            if (isVisible) {
                const v = c.querySelector('video');
                v.muted = true; 
                v.play().catch(() => {});
                resetCardUI(c, v);
            }
        });
    };

    // 2. Click Events: Tap anywhere (Video OR Mute Button) to toggle sound!
    const bindCardEvents = (card) => {
        videoObserver.observe(card);
        const vid = card.querySelector('video');
        const muteBtn = card.querySelector('.mute-btn');
        const playIcon = card.querySelector('.play-pause-btn i');

        // Clicking ANYWHERE on the card handles the logic
        card.addEventListener('click', (e) => {
            // Ignore clicks on slider navigation arrows
            if (e.target.closest('.slider-btn')) return;
            
            if (activeCard !== card) {
                // Turn ON this video (Make it active & Unmute)
                activeCard = card;
                
                // Pause and mute all other videos
                videoTrack.querySelectorAll('.video-card').forEach(otherCard => {
                    if (otherCard !== card) {
                        const otherVid = otherCard.querySelector('video');
                        otherVid.pause();
                        resetCardUI(otherCard, otherVid);
                    }
                });
                
                // Unmute & Play clicked video
                vid.muted = false; 
                vid.play().catch(() => {});
                card.classList.add('is-playing');
                if (playIcon) playIcon.className = 'fa-solid fa-pause';
                
                if (muteBtn) {
                    muteBtn.querySelector('i').className = 'fa-solid fa-volume-high';
                    muteBtn.style.background = 'var(--primary-gold)';
                }
            } else {
                // If the video IS already active, tapping it or the mute button just toggles the sound!
                vid.muted = !vid.muted;
                
                if (muteBtn) {
                    muteBtn.querySelector('i').className = vid.muted ? 'fa-solid fa-volume-xmark' : 'fa-solid fa-volume-high';
                    muteBtn.style.background = vid.muted ? 'rgba(0, 0, 0, 0.5)' : 'var(--primary-gold)';
                }
            }
        });
    };

    // 3. Clone for Infinity Scroll
    originalCards.forEach(card => {
        const clone = card.cloneNode(true);
        videoTrack.appendChild(clone);
        bindCardEvents(clone);
    });
    originalCards.slice().reverse().forEach(card => {
        const clone = card.cloneNode(true);
        videoTrack.prepend(clone);
        bindCardEvents(clone);
    });
    originalCards.forEach(card => bindCardEvents(card));

    // 4. Center starting position
    setTimeout(() => {
        const cardWidth = videoTrack.querySelector('.video-card').offsetWidth + 20; 
        videoTrack.scrollLeft = cardWidth * vidCount;
    }, 100);

    // 5. SMOOTH TELEPORT LOGIC
    let isVidScrolling;
    videoTrack.addEventListener('scroll', () => {
        window.clearTimeout(isVidScrolling);
        isVidScrolling = setTimeout(() => {
            const cardWidth = videoTrack.querySelector('.video-card').offsetWidth + 20;
            
            if (videoTrack.scrollLeft <= cardWidth) {
                videoTrack.style.scrollSnapType = 'none';
                videoTrack.style.scrollBehavior = 'auto';
                videoTrack.scrollLeft += cardWidth * vidCount;
                setTimeout(() => {
                    videoTrack.style.scrollBehavior = 'smooth';
                    videoTrack.style.scrollSnapType = 'x mandatory';
                }, 50);
            } else if (videoTrack.scrollLeft >= cardWidth * (vidCount * 2) - videoTrack.clientWidth) {
                videoTrack.style.scrollSnapType = 'none';
                videoTrack.style.scrollBehavior = 'auto';
                videoTrack.scrollLeft -= cardWidth * vidCount;
                setTimeout(() => {
                    videoTrack.style.scrollBehavior = 'smooth';
                    videoTrack.style.scrollSnapType = 'x mandatory';
                }, 50);
            }
        }, 50); 
    }, { passive: true });
}
// =========================================
//7 SEARCH BAR DYNAMIC TYPING EFFECT
// =========================================
document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById('destinationSearch');
    if (!searchInput || searchInput.dataset.typingInit) return;
    searchInput.dataset.typingInit = "true";

    const typingWords = ["Traveltara", "Rajasthan", "Kashmir", "Bali"];
    let wordIndex = 0;
    let charIndex = 0;
    let isDeleting = false;

    function typeEffect() {
        const currentWord = typingWords[wordIndex];
        
        // Update the placeholder text
        if (isDeleting) {
            searchInput.setAttribute('placeholder', `Search "${currentWord.substring(0, charIndex - 1)}"`);
            charIndex--;
        } else {
            searchInput.setAttribute('placeholder', `Search "${currentWord.substring(0, charIndex + 1)}"`);
            charIndex++;
        }

        // Set typing speeds (typing is slower, deleting is faster)
        let typeSpeed = isDeleting ? 50 : 120;

        // If word is fully typed, pause before deleting
        if (!isDeleting && charIndex === currentWord.length) {
            typeSpeed = 2000; // Wait 2 seconds
            isDeleting = true;
        } 
        // If word is fully deleted, move to next word and pause before typing
        else if (isDeleting && charIndex === 0) {
            isDeleting = false;
            wordIndex = (wordIndex + 1) % typingWords.length; // Loop back to start
            typeSpeed = 500; // Wait half a second before typing new word
        }

        // Run the loop
        setTimeout(typeEffect, typeSpeed);
    }

    // Start the effect after 1 second
    setTimeout(typeEffect, 1000);
});
// =========================================
// LOVE FOR FORESTS POPUP & VALIDATION
// =========================================
window.openForestPopup = function() {
    const popup = document.getElementById('forestPopup');
    if (popup) popup.style.display = 'flex';
};

window.closeForestPopup = function() {
    const popup = document.getElementById('forestPopup');
    if (popup) popup.style.display = 'none';
};

// Strict Form Submission Logic
window.submitForestForm = function(event) {
    event.preventDefault();
    
    const nameInput = document.getElementById('forestName').value;
    const phoneInput = document.getElementById('forestPhone').value;

    // JavaScript regex check (Backup to html5 pattern)
    const nameRegex = /^[A-Za-z\s]+$/;
    const phoneRegex = /^\d{10}$/;

    if (!nameRegex.test(nameInput)) {
        alert("Please enter a valid name using only letters.");
        return;
    }
    if (!phoneRegex.test(phoneInput)) {
        alert("Please enter exactly 10 numeric digits for the phone number.");
        return;
    }

    alert("Thank you! Your interest in our Forest Escapes has been securely registered.");
    
    closeForestPopup();
    document.getElementById('forestInterestForm').reset();
};

// Allow closing by clicking the dark overlay outside the box
document.addEventListener("DOMContentLoaded", () => {
    const forestPopup = document.getElementById('forestPopup');
    if (forestPopup) {
        window.addEventListener('click', (e) => {
            if (e.target === forestPopup) window.closeForestPopup();
        });
    }
});
// =========================================
// TRAVELLER GALLERY: 2-ROW INFINITY SCROLL
// =========================================
document.addEventListener("DOMContentLoaded", () => {
    const galleryTrack = document.getElementById('galleryTrack');
    if (!galleryTrack || galleryTrack.dataset.galleryInit) return;
    galleryTrack.dataset.galleryInit = "true";

    const items = Array.from(galleryTrack.children);
    const count = items.length;
    if (count === 0) return;

    // 1. Clone items for seamless infinity
    items.forEach(item => galleryTrack.appendChild(item.cloneNode(true)));
    items.slice().reverse().forEach(item => galleryTrack.prepend(item.cloneNode(true)));

    // 2. Center Starting Position
    setTimeout(() => {
        const colWidth = galleryTrack.querySelector('.gallery-item').offsetWidth + 10; // 10px gap
        // (count / 2) because there are 2 rows
        galleryTrack.scrollLeft = colWidth * (count / 2);
    }, 100);

    // 3. Auto Smooth Scroll
    let isAutoScrolling = true;
    let animationId;

    function smoothAutoScroll() {
        if (!isAutoScrolling) return;
        galleryTrack.scrollLeft += 1; // 1 pixel per frame (buttery smooth)
        
        const colWidth = galleryTrack.querySelector('.gallery-item').offsetWidth + 10;
        const originalSetWidth = colWidth * (count / 2);
        
        if (galleryTrack.scrollLeft >= originalSetWidth * 2) {
            galleryTrack.scrollLeft -= originalSetWidth;
        }
        animationId = requestAnimationFrame(smoothAutoScroll);
    }
    
    setTimeout(() => { animationId = requestAnimationFrame(smoothAutoScroll); }, 500);

    // 4. The Kill Switch (Stops auto-scroll on interaction)
    const stopAutoScroll = () => {
        if (isAutoScrolling) {
            isAutoScrolling = false;
            cancelAnimationFrame(animationId);
            galleryTrack.style.scrollSnapType = "x mandatory"; // Turns on snapping for manual
        }
    };

    galleryTrack.addEventListener('touchstart', stopAutoScroll, { passive: true });
    galleryTrack.addEventListener('mousedown', stopAutoScroll, { passive: true });
    galleryTrack.addEventListener('wheel', stopAutoScroll, { passive: true });

    // 5. Arrow Button Logic (With Seamless Math)
    window.slideGallery = function(direction) {
        stopAutoScroll();
        const colWidth = galleryTrack.querySelector('.gallery-item').offsetWidth + 10;
        const originalSetWidth = colWidth * (count / 2);

        // Teleport if at edges before sliding
        if (galleryTrack.scrollLeft <= colWidth && direction === -1) {
            galleryTrack.style.scrollSnapType = 'none';
            galleryTrack.style.scrollBehavior = 'auto';
            galleryTrack.scrollLeft += originalSetWidth;
            setTimeout(() => {
                galleryTrack.style.scrollBehavior = 'smooth';
                galleryTrack.scrollBy({ left: colWidth * direction });
                galleryTrack.style.scrollSnapType = 'x mandatory';
            }, 10);
        } else if (galleryTrack.scrollLeft >= (originalSetWidth * 2) - galleryTrack.clientWidth && direction === 1) {
            galleryTrack.style.scrollSnapType = 'none';
            galleryTrack.style.scrollBehavior = 'auto';
            galleryTrack.scrollLeft -= originalSetWidth;
            setTimeout(() => {
                galleryTrack.style.scrollBehavior = 'smooth';
                galleryTrack.scrollBy({ left: colWidth * direction });
                galleryTrack.style.scrollSnapType = 'x mandatory';
            }, 10);
        } else {
            galleryTrack.style.scrollBehavior = 'smooth';
            galleryTrack.scrollBy({ left: colWidth * direction });
        }
    };
});
// =========================================
// TRAVELLER GALLERY: LIGHTBOX WITH NAVIGATION
// =========================================
let currentLightboxIndex = 0;
let lightboxImagesArray = [];

window.openLightbox = function(element) {
    const lightbox = document.getElementById('lightboxOverlay');
    const lightboxImg = document.getElementById('lightboxImg');
    
    // 1. Gather all unique images to prevent duplicate clicking from clones
    lightboxImagesArray = [];
    const allImages = document.querySelectorAll('#galleryTrack .gallery-item img');
    allImages.forEach(img => {
        if (!lightboxImagesArray.includes(img.src)) {
            lightboxImagesArray.push(img.src);
        }
    });

    // 2. Find which image we clicked on
    const clickedSrc = element.querySelector('img').src;
    currentLightboxIndex = lightboxImagesArray.indexOf(clickedSrc);
    
    // 3. Show the image
    lightboxImg.src = clickedSrc;
    lightbox.classList.add('active');
    document.body.style.overflow = 'hidden'; 
};

window.changeLightboxImage = function(direction, event) {
    // Prevent the click from bleeding through to the background and closing the lightbox
    if (event) event.stopPropagation(); 
    
    currentLightboxIndex += direction;
    
    // Infinity loop the clicks!
    if (currentLightboxIndex >= lightboxImagesArray.length) {
        currentLightboxIndex = 0;
    } else if (currentLightboxIndex < 0) {
        currentLightboxIndex = lightboxImagesArray.length - 1;
    }
    
    const lightboxImg = document.getElementById('lightboxImg');
    
    // Quick fade out/in effect for the transition
    lightboxImg.style.opacity = '0.3';
    lightboxImg.style.transform = 'scale(0.95)';
    
    setTimeout(() => {
        lightboxImg.src = lightboxImagesArray[currentLightboxIndex];
        lightboxImg.style.opacity = '1';
        lightboxImg.style.transform = 'scale(1)';
    }, 150);
};

window.closeLightbox = function(event) {
    const lightbox = document.getElementById('lightboxOverlay');
    const lightboxImg = document.getElementById('lightboxImg');
    
    // Close only if clicking the background or the close button
    if (event.target === lightbox || event.target.classList.contains('lightbox-close')) {
        lightbox.classList.remove('active');
        document.body.style.overflow = ''; 
        setTimeout(() => { lightboxImg.src = ''; }, 300); 
    }
};

// Bonus: Allow keyboard arrows to switch images!
document.addEventListener('keydown', function(event) {
    const lightbox = document.getElementById('lightboxOverlay');
    if (lightbox && lightbox.classList.contains('active')) {
        if (event.key === 'ArrowLeft') {
            changeLightboxImage(-1, null);
        } else if (event.key === 'ArrowRight') {
            changeLightboxImage(1, null);
        } else if (event.key === 'Escape') {
            closeLightbox({ target: lightbox });
        }
    }
});
// ==========================================================================
// TRAVELTARA MASTER CRM INTEGRATION (THE WATCHER BYPASS)
// ==========================================================================

// 🔥 PASTE YOUR HOSTINGER LEADS API URL HERE 🔥
const GOOGLE_URL = "https://traveltara.com/process_leads.php";

// --- 1. THE BULLETPROOF SENDER (GLOBAL) ---
window.sendToCRM = function(name, phone, email, details, source) {
    const params = new URLSearchParams();
    params.append("Name", name || "Unknown");
    params.append("Phone", phone || "No Number");
    params.append("Email", email || "");
    params.append("Details", details || "");
    params.append("Source", source || "");

    fetch(GOOGLE_URL, { 
        method: 'POST', 
        body: params, 
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        mode: 'no-cors' 
    }).then(() => console.log(`[CRM Success] Sent ${source}`))
      .catch(err => console.error("[CRM Error] Sync failed.", err));
};

// --- 2. VIP FORM (SUBMIT + INSTANT CAPTURE) ---
window.submitVipForm = function(event) {
    event.preventDefault(); 
    const name = document.getElementById('vipName').value;
    const phone = document.getElementById('vipPhone').value;
    const dest = document.getElementById('vipDest').value;

    window.sendToCRM(name, phone, "", "Wants to visit: " + dest, "VIP 20% Offer (Completed)");
    
    alert("Your 20% discount has been secured!");
    if(typeof closeLeadPopup === 'function') closeLeadPopup();
    document.getElementById('vipForm').reset();
    sessionStorage.removeItem('vipPartial'); 
};

// --- 3. FOREST FORM (SUBMIT + INSTANT CAPTURE) ---
window.submitForestForm = function(event) {
    event.preventDefault();
    const name = document.getElementById('forestName').value;
    const phone = document.getElementById('forestPhone').value;
    const email = document.getElementById('forestEmail').value;

    window.sendToCRM(name, phone, email, "Interested in Forest Escapes", "Forest Form (Completed)");
    
    alert("Thank you! Your interest is registered.");
    if(typeof closeForestPopup === 'function') closeForestPopup();
    document.getElementById('forestInterestForm').reset();
    sessionStorage.removeItem('forestPartial'); 
};

// --- 4. THE WATCHER BYPASS, MAGIC LINKS & WHATSAPP CAPTURE ---
document.addEventListener("DOMContentLoaded", () => {
    
    // 1. VIP Abandoned Capture (The Watcher + Safety Net)
    const vipPhone = document.getElementById('vipPhone');
    const vipName = document.getElementById('vipName');

    if (vipPhone) {
        const vipWatcher = setInterval(() => {
            const pureNumbers = vipPhone.value.replace(/\D/g, ''); 
            if (pureNumbers.length >= 10 && !sessionStorage.getItem('vipPartial')) {
                sessionStorage.setItem('vipPartial', 'true');
                clearInterval(vipWatcher); // Stop scanning phone
                
                // SOLUTION 1: Wait 600ms to let the phone finish pasting the Name
                setTimeout(() => {
                    const nameVal = (vipName && vipName.value.trim()) ? vipName.value.trim() : "Unknown Guest";
                    window.sendToCRM(nameVal, vipPhone.value, "", "Started typing VIP Form", "VIP Popup (Partial)");
                }, 600);
            }
        }, 500);

        // SOLUTION 2: The Safety Net (If they type Name AFTER the Phone)
        if (vipName) {
            vipName.addEventListener('blur', () => {
                if (sessionStorage.getItem('vipPartial') && vipName.value.trim() !== "") {
                    // This tells Google to update the existing row with their real name
                    window.sendToCRM(vipName.value.trim(), vipPhone.value, "", "Added Name Later", "VIP Popup (Update)");
                }
            });
        }
    }

    // 2. Forest Abandoned Capture (The Watcher + Safety Net)
    const forestPhone = document.getElementById('forestPhone');
    const forestName = document.getElementById('forestName');

    if (forestPhone) {
        const forestWatcher = setInterval(() => {
            const pureNumbers = forestPhone.value.replace(/\D/g, ''); 
            if (pureNumbers.length >= 10 && !sessionStorage.getItem('forestPartial')) {
                sessionStorage.setItem('forestPartial', 'true');
                clearInterval(forestWatcher); 

                setTimeout(() => {
                    const nameVal = (forestName && forestName.value.trim()) ? forestName.value.trim() : "Unknown Guest";
                    window.sendToCRM(nameVal, forestPhone.value, "", "Started typing Forest Form", "Forest Interest (Partial)");
                }, 600);
            }
        }, 500);

        if (forestName) {
            forestName.addEventListener('blur', () => {
                if (sessionStorage.getItem('forestPartial') && forestName.value.trim() !== "") {
                    window.sendToCRM(forestName.value.trim(), forestPhone.value, "", "Added Name Later", "Forest Interest (Update)");
                }
            });
        }
    }

    // =======================================================
    // 3. BOOKING MODAL ABANDONED CAPTURE (NEW)
    // =======================================================
    const regPhone = document.getElementById('regPhone');
    const regName = document.getElementById('regName');
    const regPackage = document.getElementById('regPackageName'); // Grabs the destination

    if (regPhone) {
        const regWatcher = setInterval(() => {
            const pureNumbers = regPhone.value.replace(/\D/g, ''); 
            if (pureNumbers.length >= 10 && !sessionStorage.getItem('regPartial')) {
                sessionStorage.setItem('regPartial', 'true');
                clearInterval(regWatcher); 

                setTimeout(() => {
                    const nameVal = (regName && regName.value.trim()) ? regName.value.trim() : "Unknown Guest";
                    const pkgVal = (regPackage && regPackage.value.trim()) ? regPackage.value.trim() : "Custom Trip";
                    window.sendToCRM(nameVal, regPhone.value, "", "Abandoned Step 1 for: " + pkgVal, "Booking Modal (Partial)");
                }, 600);
            }
        }, 500);

        if (regName) {
            regName.addEventListener('blur', () => {
                if (sessionStorage.getItem('regPartial') && regName.value.trim() !== "") {
                    const pkgVal = (regPackage && regPackage.value.trim()) ? regPackage.value.trim() : "Custom Trip";
                    window.sendToCRM(regName.value.trim(), regPhone.value, "", "Added Name Later for: " + pkgVal, "Booking Modal (Update)");
                }
            });
        }
    }

    // 4. TRAVELTARA ULTIMATE AUTO-FILL (Magic Links & Memory)
    const urlParams = new URLSearchParams(window.location.search);
    const magicName = urlParams.get('name') || urlParams.get('first_name');
    const magicPhone = urlParams.get('phone') || urlParams.get('whatsapp');
    const magicEmail = urlParams.get('email');

    const savedName = localStorage.getItem('tt_userName');
    const savedPhone = localStorage.getItem('tt_userPhone');
    const savedEmail = localStorage.getItem('tt_userEmail');

    const finalName = magicName || savedName;
    const finalPhone = magicPhone || savedPhone;
    const finalEmail = magicEmail || savedEmail;

    // Fills all 3 popups instantly if data exists
    if (finalName) {
        if (document.getElementById('vipName')) document.getElementById('vipName').value = finalName;
        if (document.getElementById('forestName')) document.getElementById('forestName').value = finalName;
        if (document.getElementById('regName')) document.getElementById('regName').value = finalName;
        localStorage.setItem('tt_userName', finalName); 
    }
    if (finalPhone) {
        if (document.getElementById('vipPhone')) document.getElementById('vipPhone').value = finalPhone;
        if (document.getElementById('forestPhone')) document.getElementById('forestPhone').value = finalPhone;
        if (document.getElementById('regPhone')) document.getElementById('regPhone').value = finalPhone;
        localStorage.setItem('tt_userPhone', finalPhone);
    }
    if (finalEmail) {
        if (document.getElementById('forestEmail')) document.getElementById('forestEmail').value = finalEmail;
        localStorage.setItem('tt_userEmail', finalEmail);
    }

    // Scans all 3 popups to save data as the user types
    const saveToMemory = () => {
        const currentName = document.getElementById('vipName')?.value || document.getElementById('forestName')?.value || document.getElementById('regName')?.value;
        const currentPhone = document.getElementById('vipPhone')?.value || document.getElementById('forestPhone')?.value || document.getElementById('regPhone')?.value;
        const currentEmail = document.getElementById('forestEmail')?.value;

        if (currentName) localStorage.setItem('tt_userName', currentName);
        if (currentPhone && currentPhone.length >= 10) localStorage.setItem('tt_userPhone', currentPhone);
        if (currentEmail) localStorage.setItem('tt_userEmail', currentEmail);
    };
    document.addEventListener('input', saveToMemory);

    // 5. WhatsApp Silent Chat Capture
    const chatInput = document.getElementById('waInputField');
    const sendBtn = document.getElementById('waSendBtn');

    const captureChat = () => {
        if (!chatInput) return;
        const fullMessage = chatInput.value.trim();
        if (fullMessage === "") return;

        const phoneMatch = fullMessage.replace(/\D/g, '').substring(0, 10);
        const emailMatch = fullMessage.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);

        if (phoneMatch.length === 10) sessionStorage.setItem('chatPhone', phoneMatch);
        if (emailMatch) sessionStorage.setItem('chatEmail', emailMatch[0]);

        const phoneToSend = sessionStorage.getItem('chatPhone') || "No Number";
        const emailToSend = sessionStorage.getItem('chatEmail') || "";

        window.sendToCRM("Chat User", phoneToSend, emailToSend, fullMessage, "WhatsApp Chat");
    };

    if (sendBtn) sendBtn.addEventListener('click', captureChat, true);
    if (chatInput) chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') captureChat();
    }, true);
});

///////////////////////////////////////
// STARTING OF THE DESTINATION PAGE //
///////////////////////////////////////
// =======================================================
// DESTINATIONS PAGE: ADVANCED MULTI-FILTER, SORT & DROPDOWN (MERGED WITH TOGGLE ENGINE)
// =======================================================
document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById('destSearchInput');
    const searchForm = document.getElementById('destPageSearchForm');
    const suggestionsBox = document.getElementById('destSearchSuggestions');
    
    // The new Toggle Switches instead of the region dropdown
    const domesticRadio = document.getElementById("toggle-domestic");
    const internationalRadio = document.getElementById("toggle-international");
    
    const vibeFilter = document.getElementById('vibeFilter');
    const budgetFilter = document.getElementById('budgetFilter');
    const sortFilter = document.getElementById('sortFilter');
    const resetBtn = document.getElementById('resetFiltersBtn');
    
    const gridContainer = document.getElementById('destGrid');
    const noResults = document.getElementById('noDestResults');
    
    const filterToggleBtn = document.getElementById('mobileFilterToggle');
    const filterContainer = document.getElementById('advancedFiltersContainer');
    const mobileViewToggle = document.getElementById('mobileViewToggle');

    if (gridContainer && searchInput && domesticRadio) {
        let destItems = Array.from(document.querySelectorAll('.dest-item'));
        destItems.forEach((item, index) => item.setAttribute('data-original-index', index));

        const destDataList = destItems.map(item => ({
            name: item.querySelector('h3').innerText,
            vibe: item.getAttribute('data-category'),
            region: item.getAttribute('data-region'),
            searchTags: (item.querySelector('h3').innerText + " " + item.getAttribute('data-name') + " " + item.getAttribute('data-category') + " " + item.getAttribute('data-region')).toLowerCase()
        }));

        // --- 1. DYNAMIC TYPING EFFECT ---
        const typeWords = ["traveltara", "Rajasthan", "Sikkim", "Munnar", "Goa", "Kolkata", "Mumbai"];
        let wordIdx = 0;
        let charIdx = 0;
        let isDeleting = false;
        let typingTimer;
        let isFocused = false;

        function playTypingEffect() {
            if (isFocused || searchInput.value !== '') return; 

            const currentWord = typeWords[wordIdx];
            
            if (isDeleting) {
                searchInput.setAttribute('placeholder', `Search "${currentWord.substring(0, charIdx - 1)}"`);
                charIdx--;
            } else {
                searchInput.setAttribute('placeholder', `Search "${currentWord.substring(0, charIdx + 1)}"`);
                charIdx++;
            }

            let typeSpeed = isDeleting ? 40 : 100;

            if (!isDeleting && charIdx === currentWord.length) {
                typeSpeed = 2000; 
                isDeleting = true;
            } else if (isDeleting && charIdx === 0) {
                isDeleting = false;
                wordIdx = (wordIdx + 1) % typeWords.length;
                typeSpeed = 500; 
            }

            typingTimer = setTimeout(playTypingEffect, typeSpeed);
        }

        setTimeout(playTypingEffect, 1000);

        searchInput.addEventListener('focus', () => {
            isFocused = true;
            clearTimeout(typingTimer);
            searchInput.setAttribute('placeholder', 'Search...');
        });

        searchInput.addEventListener('blur', () => {
            isFocused = false;
            if (searchInput.value === '') {
                charIdx = 0;
                isDeleting = false;
                playTypingEffect();
            }
        });

        // --- 2. THE MASTER FILTERING ENGINE ---
        function applyAllFilters() {
            let searchQuery = searchInput.value.toLowerCase().trim();
            
            // Strictly read the active toggle
            let activeRegion = domesticRadio.checked ? 'domestic' : 'international';
            let activeVibe = vibeFilter ? vibeFilter.value : 'all';
            let activeBudget = budgetFilter ? budgetFilter.value : 'all';
            let activeSort = sortFilter ? sortFilter.value : 'relevance';
            
            let visibleCount = 0;

            destItems.forEach(item => {
                let category = item.getAttribute('data-category');
                let region = item.getAttribute('data-region');
                let price = parseInt(item.getAttribute('data-price') || "0");
                
                let searchableText = (item.querySelector('h3').innerText + " " + item.getAttribute('data-name') + " " + category + " " + region).toLowerCase();
                
                let matchesSearch = (searchQuery === '' || searchableText.includes(searchQuery));
                
                // RULE A: Must match the Toggle Switch strictly
                let matchesRegion = (region === activeRegion);
                let matchesVibe = (activeVibe === 'all' || category === activeVibe);
                
                let matchesBudget = true;
                if (activeBudget === 'under-20') matchesBudget = price < 20000;
                else if (activeBudget === '20-40') matchesBudget = price >= 20000 && price <= 40000;
                else if (activeBudget === 'above-40') matchesBudget = price > 40000;

                if (matchesSearch && matchesRegion && matchesVibe && matchesBudget) {
                    item.style.display = 'block'; 
                    item.style.animation = "fadeIn 0.5s ease forwards";
                    visibleCount++;
                } else {
                    item.style.display = 'none';
                }
            });

            let visibleItems = destItems.filter(item => item.style.display !== 'none');
            
            visibleItems.sort((a, b) => {
                let priceA = parseInt(a.getAttribute('data-price') || "0");
                let priceB = parseInt(b.getAttribute('data-price') || "0");
                let nameA = a.querySelector('h3').innerText.toLowerCase();
                let nameB = b.querySelector('h3').innerText.toLowerCase();
                
                if (activeSort === 'relevance') return parseInt(a.getAttribute('data-original-index')) - parseInt(b.getAttribute('data-original-index'));
                else if (activeSort === 'price-low') return priceA - priceB;
                else if (activeSort === 'price-high') return priceB - priceA;
                else if (activeSort === 'az') return nameA.localeCompare(nameB);
            });

            visibleItems.forEach(item => gridContainer.appendChild(item));
            if (noResults) noResults.style.display = (visibleCount === 0) ? 'block' : 'none';
        }

        // --- 3. AUTO-SUGGEST & SMART TOGGLE SYNC ---
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase().trim();
            if(suggestionsBox) suggestionsBox.innerHTML = '';

            if (query.length === 0) {
                if(suggestionsBox) suggestionsBox.style.display = 'none';
                applyAllFilters();
                return;
            }

            // --- SMART FLIP: Check if the typed search requires flipping the toggle ---
            let foundRegion = null;
            destDataList.forEach(d => {
                if (!foundRegion && d.searchTags.includes(query)) {
                    foundRegion = d.region; 
                }
            });

            if (foundRegion === "domestic" && !domesticRadio.checked) domesticRadio.checked = true;
            else if (foundRegion === "international" && !internationalRadio.checked) internationalRadio.checked = true;


            // --- Auto-Suggest Drawing ---
            const matches = destDataList.filter(d => d.searchTags.includes(query));

            if (matches.length > 0 && suggestionsBox) {
                matches.slice(0, 5).forEach(dest => {
                    const div = document.createElement('div');
                    div.className = 'suggestion-item';

                    const vibeFormat = dest.vibe ? dest.vibe.charAt(0).toUpperCase() + dest.vibe.slice(1) : '';
                    const regionFormat = dest.region === 'domestic' ? 'India' : 'International';

                    div.innerHTML = `
                        <i class="fa-solid fa-location-dot" style="color: #D4AF37; font-size: 1.2rem;"></i>
                        <div style="display: flex; flex-direction: column;">
                            <strong style="font-family: 'Playfair Display', serif; font-size: 1.1rem; color: #222;">${dest.name}</strong>
                            <span style="font-size: 0.8rem; color: #777; font-family: 'Lato', sans-serif;">${vibeFormat} • ${regionFormat}</span>
                        </div>
                    `;

                    div.addEventListener('click', () => {
                        searchInput.value = dest.name;
                        
                        // Ensure toggle is perfectly synced when they click a suggestion
                        if (dest.region === "domestic") domesticRadio.checked = true;
                        if (dest.region === "international") internationalRadio.checked = true;

                        suggestionsBox.style.display = 'none';
                        applyAllFilters(); 
                    });

                    suggestionsBox.appendChild(div);
                });
            } else if (suggestionsBox) {
                suggestionsBox.innerHTML = `<div style="padding: 15px 20px; color: #888; font-family: 'Lato', sans-serif; font-style: italic;">No destinations found matching "${query}".</div>`;
            }

            if(suggestionsBox) suggestionsBox.style.display = 'flex';
            applyAllFilters();
        });

        document.addEventListener('click', (e) => {
            if (searchForm && !searchForm.contains(e.target)) {
                if (suggestionsBox) suggestionsBox.style.display = 'none';
            }
        });

        // --- 4. RESET BUTTON LOGIC ---
        if (resetBtn) {
            resetBtn.addEventListener('click', (e) => {
                e.preventDefault();
                searchInput.value = '';
                domesticRadio.checked = true; // Default back to domestic
                if(vibeFilter) vibeFilter.value = 'all';
                if(budgetFilter) budgetFilter.value = 'all';
                if(sortFilter) sortFilter.value = 'relevance';
                if (suggestionsBox) suggestionsBox.style.display = 'none';
                applyAllFilters();
                
                isFocused = false;
                charIdx = 0;
                isDeleting = false;
                playTypingEffect();
            });
        }

        // --- 5. ATTACH THE EVENT LISTENERS ---
        domesticRadio.addEventListener('change', () => { searchInput.value = ""; applyAllFilters(); });
        internationalRadio.addEventListener('change', () => { searchInput.value = ""; applyAllFilters(); });
        
        if (vibeFilter) vibeFilter.addEventListener('change', applyAllFilters);
        if (budgetFilter) budgetFilter.addEventListener('change', applyAllFilters);
        if (sortFilter) sortFilter.addEventListener('change', applyAllFilters);
        
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => { 
                e.preventDefault(); 
                if (suggestionsBox) suggestionsBox.style.display = 'none';
                applyAllFilters(); 
            });
        }

        // --- 6. SMART SINGLE VIEW TOGGLE (Mobile Only) ---
        let isGridMode = true; 

        if (mobileViewToggle) {
            if (window.innerWidth <= 768) {
                gridContainer.classList.add('mobile-grid-view');
            }

            mobileViewToggle.addEventListener('click', (e) => {
                e.preventDefault();
                isGridMode = !isGridMode;

                if (isGridMode) {
                    gridContainer.style.display = ''; 
                    gridContainer.classList.add('mobile-grid-view'); 
                    mobileViewToggle.innerHTML = '<i class="fa-solid fa-border-all"></i>';
                } else {
                    gridContainer.style.display = 'flex';
                    gridContainer.style.flexDirection = 'column';
                    gridContainer.style.gap = '20px';
                    gridContainer.classList.remove('mobile-grid-view'); 
                    mobileViewToggle.innerHTML = '<i class="fa-solid fa-list"></i>';
                }
            });
        }

        // --- 7. MOBILE FUNNEL TOGGLE ---
        if (filterToggleBtn && filterContainer) {
            filterToggleBtn.addEventListener('click', (e) => {
                e.preventDefault(); 
                filterContainer.classList.toggle('show-mobile-filters');
                filterToggleBtn.classList.toggle('active');
            });
        }

        // Run once on load to establish baseline
        applyAllFilters();
    }
});
// =======================================================
// DYNAMIC SUGGESTION ENGINE (SMART AUTO-MAPPING VERSION)
// =======================================================

// 1. YOUR MASTER DATABASE 
// You only type the ID, Title, Category, and Price. 
// The engine handles the image paths and html links automatically!
const globalPackageDatabase = [
    { id: "sikkim6D5N", title: "Sikkim Mystique", category: "hills", price: "₹28,000" },
    { id: "northBengal5D4N", title: "North Bengal Heritage", category: "heritage", price: "₹24,500" },
    { id: "rajasthan6D5N", title: "Royal Heritage Circuit", category: "heritage", price: "₹26,500" },
    { id: "himachal4D3N", title: "Shimla Pine Retreat", category: "hills", price: "₹16,500" },
    { id: "himachal6D5N", title: "Grand Himachal Odyssey", category: "hills", price: "₹24,000" },
    { id: "kashmir8D7N", title: "Kashmir Grandeur", category: "hills", price: "₹42,000" }
];

// 2. THE RENDER FUNCTION
document.addEventListener("DOMContentLoaded", () => {
    const suggestionBox = document.getElementById("dynamicSuggestionBox");
    
    // Check if the suggestion strip html actually exists on this page
    if (suggestionBox) {
        
        // Find the category (Defaults to 'hills' if you forgot to add the tag)
        const currentCategory = document.body.getAttribute("data-page-category") || "hills";
        
        // Find matching packages
        let relatedPackages = globalPackageDatabase.filter(pkg => pkg.category === currentCategory);
        
        // If we don't have enough matches, fall back to showing all packages
        if (relatedPackages.length < 2) {
            relatedPackages = globalPackageDatabase;
        }

        suggestionBox.innerHTML = ""; // Clear out the loading space
        
        // Loop through the first 5 packages and draw the HTML cards
        relatedPackages.slice(0, 5).forEach(pkg => {
            
            // 🔥 THE AUTO-MAPPER MAGIC 🔥
            // If the ID is "himachal4D3N", it instantly builds:
            // Image: "assets/himachal4D3N.jpg"
            // Link: "himachal4D3N.php"
            const autoImagePath = `assets/${pkg.id}.jpg`;
            const autoPageLink = `${pkg.id}.php`;

            const cardHTML = `
                <a href="${autoPageLink}" class="suggest-card">
                    <div class="suggest-img">
                        <img src="${autoImagePath}" alt="${pkg.title}" onerror="this.src='assets/default-package.jpg'">
                    </div>
                    <div class="suggest-info">
                        <h4>${pkg.title}</h4>
                        <p>Explore this high-value experience</p>
                        <div class="suggest-price">From ${pkg.price}</div>
                    </div>
                </a>
            `;
            suggestionBox.innerHTML += cardHTML;
        });
    }
});

/// =======================================================
// SMART DESTINATION SEARCH & TOGGLE (PLANE ANIMATION ONLY)
// =======================================================
document.addEventListener("DOMContentLoaded", () => {
    const domesticRadio = document.getElementById("toggle-domestic");
    const internationalRadio = document.getElementById("toggle-international");
    const searchInput = document.getElementById("destSearchInput");
    const allCards = document.querySelectorAll("#destGrid .destination-card");
    
    // Select the Plane element only
    const plane = document.getElementById('traveltaraPlane');

    if (!domesticRadio || !internationalRadio || !searchInput) return;

    /**
     * Filters the grid based on region
     */
    function filterDestinations(region) {
        allCards.forEach(card => {
            if (card.getAttribute("data-region") === region) {
                card.style.display = "block"; 
                card.style.animation = "fadeIn 0.5s ease forwards";
            } else {
                card.style.display = "none";
            }
        });
    }

    // Baseline state
    filterDestinations("domestic");

    /**
     * Triggers the cinematic plane flight
     */
    function triggerFlightEffect() {
        if (plane) {
            // Reset and restart the flight animation
            plane.classList.remove('takeoff');
            void plane.offsetWidth; 
            plane.classList.add('takeoff');

            // Switch content as the plane passes the center
            setTimeout(() => {
                filterDestinations("international");
            }, 600); 
        } else {
            filterDestinations("international");
        }
    }

    // --- EVENT LISTENERS ---

    domesticRadio.addEventListener("change", () => {
        searchInput.value = ""; 
        if (plane) plane.classList.remove('takeoff');
        filterDestinations("domestic");
    });
    
    internationalRadio.addEventListener("change", () => {
        searchInput.value = ""; 
        triggerFlightEffect();
    });

    searchInput.addEventListener("keyup", (e) => {
        const query = e.target.value.toLowerCase().trim();

        if (query === "") {
            const activeRegion = domesticRadio.checked ? "domestic" : "international";
            filterDestinations(activeRegion);
            return;
        }

        let foundRegion = null;
        allCards.forEach(card => {
            const nameData = (card.getAttribute("data-name") || "").toLowerCase();
            const title = card.querySelector("h3").innerText.toLowerCase();
            const desc = card.querySelector("p").innerText.toLowerCase();

            if (nameData.includes(query) || title.includes(query) || desc.includes(query)) {
                card.style.display = "block";
                card.style.animation = "fadeIn 0.5s ease forwards";
                if (!foundRegion) foundRegion = card.getAttribute("data-region");
            } else {
                card.style.display = "none";
            }
        });

        if (foundRegion === "domestic" && !domesticRadio.checked) {
            domesticRadio.checked = true;
            if (plane) plane.classList.remove('takeoff');
        } else if (foundRegion === "international" && !internationalRadio.checked) {
            internationalRadio.checked = true;
            triggerFlightEffect();
        }
    });
});
// =======================================================
// BOOKING BAR LOGIC (Suggestions, Guests, Submission)
// =======================================================
document.addEventListener('DOMContentLoaded', () => {
    // Selectors
    const bookDestInput = document.getElementById('bookDest');
    const bookSuggestions = document.getElementById('bookSuggestions');
    const bookingForm = document.getElementById('homeBookingForm');
    const guestTrigger = document.getElementById('guestTrigger');
    const guestDropdown = document.getElementById('guestDropdown');
    const guestDisplay = document.getElementById('guestCountDisplay');

   // 1. THE MASTER TRAVEL DATABASE
    // Add ALL your destinations and specific 3N/4D packages here.
    const travelDatabase = [
        // --- GENERAL REGIONS ---
        { name: "Kashmir", type: "Region", url: "kashmir.php" },
        { name: "Sikkim", type: "Region", url: "sikkim.php" },
        { name: "Rajasthan", type: "Region", url: "rajasthan.php" },
        { name: "Dubai", type: "Region", url: "dubai.php" },

        // --- SPECIFIC PACKAGES ---
        { name: "Kashmir Paradise (3N/4D)", type: "Package", url: "kashmir-3n4d.php", searchTags: "kashmir 3 days 4 days short" },
        { name: "Sikkim Explorer (5N/6D)", type: "Package", url: "sikkim-5n6d.php", searchTags: "sikkim long week" },
        { name: "Royal Rajasthan (4N/5D)", type: "Package", url: "rajasthan-4n5d.php", searchTags: "rajasthan desert palaces" },
        { name: "Dubai Luxury Luxury (5N/6D)", type: "Package", url: "dubai-6-day.php", searchTags: "dubai uae international" }
    ];

    // 2. SMART SUGGESTION LOGIC
    if (bookDestInput) {
        bookDestInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase().trim();
            bookSuggestions.innerHTML = ''; 

            if (query.length > 0) {
                // Filter the database: Check the name OR the hidden searchTags
                const matches = travelDatabase.filter(item => 
                    item.name.toLowerCase().includes(query) || 
                    (item.searchTags && item.searchTags.includes(query))
                );

                // Populate matches
                matches.forEach(match => {
                    const div = document.createElement('div');
                    div.className = 'suggestion-item';
                    
                    // Determine badge style based on type
                    const badgeClass = match.type === 'Package' ? 'badge-package' : 'badge-region';
                    
                    div.innerHTML = `
                        <i class="fa-solid ${match.type === 'Package' ? 'fa-suitcase-rolling' : 'fa-location-dot'}"></i> 
                        <span>${match.name}</span>
                        <span class="suggest-badge ${badgeClass}">${match.type}</span>
                    `;
                    
                    div.onclick = () => {
                        bookDestInput.value = match.name;
                        bookSuggestions.style.display = 'none';
                    };
                    bookSuggestions.appendChild(div);
                });

                // ALWAYS append Custom Trip option at the bottom
                const customDiv = document.createElement('div');
                customDiv.className = 'suggestion-item custom-option-item';
                customDiv.innerHTML = `
                    <i class="fa-solid fa-wand-magic-sparkles"></i> 
                    <span>Customize trip to "${e.target.value}"</span>
                `;
                customDiv.onclick = () => {
                    bookDestInput.value = e.target.value;
                    bookSuggestions.style.display = 'none';
                };
                bookSuggestions.appendChild(customDiv);

                bookSuggestions.style.display = 'block';
            } else {
                bookSuggestions.style.display = 'none';
            }
        });
    }

    // 5. FORM SUBMISSION (Updated to check the new database)
    if (bookingForm) {
        bookingForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const destination = bookDestInput.value.trim();
            const date = document.getElementById('bookDate').value;
            const adults = document.getElementById('adultCount').value;
            const children = document.getElementById('childCount').value;

            // Check against the master database
            const found = travelDatabase.find(i => i.name.toLowerCase() === destination.toLowerCase());

            if (found) {
                // Route to the specific region or package page with data
                window.location.href = `${found.url}?date=${date}&adults=${adults}&child=${children}`;
            } else {
                // Lead Capture Route (Custom Trip)
                window.location.href = `custom-trip.php?dest=${encodeURIComponent(destination)}&date=${date}&adults=${adults}&child=${children}`;
            }
        });
    }

    // 3. TRAVELERS DROPDOWN LOGIC
    if (guestTrigger && guestDropdown) {
        guestTrigger.addEventListener('click', (e) => {
            e.stopPropagation(); 
            guestDropdown.classList.toggle('active');
        });

        guestDropdown.addEventListener('click', (e) => {
            e.stopPropagation(); // Keep menu open when interacting inside it
        });
    }

    // Close dropdowns if clicking outside
    document.addEventListener('click', (e) => {
        if (guestDropdown && guestDropdown.classList.contains('active')) {
            guestDropdown.classList.remove('active');
        }
        if (bookDestInput && bookSuggestions && !bookDestInput.contains(e.target)) {
            bookSuggestions.style.display = 'none';
        }
    });

    // 4. COUNTER FUNCTION
    window.changeGuest = (type, amt) => {
        const input = document.getElementById(`${type}Count`);
        let newVal = parseInt(input.value) + amt;
        
        // Limits
        if (newVal < 0) newVal = 0;
        if (type === 'adult' && newVal < 1) newVal = 1;
        
        input.value = newVal;

        const adults = document.getElementById('adultCount').value;
        const children = document.getElementById('childCount').value;
        
        let adultText = adults > 1 ? 'Adults' : 'Adult';
        let childText = children == 1 ? 'Child' : 'Children';
        
        if (guestDisplay) {
            guestDisplay.innerText = `${adults} ${adultText}, ${children} ${childText}`;
        }
    };

    // 5. FORM SUBMISSION (Lead Routing)
    if (bookingForm) {
        bookingForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const destination = bookDestInput.value.trim();
            const date = document.getElementById('bookDate').value;
            const adults = document.getElementById('adultCount').value;
            const children = document.getElementById('childCount').value;

            // Check against database
            const found = itineraries.find(i => i.name.toLowerCase() === destination.toLowerCase());

            if (found) {
                // Route to package page with data
                window.location.href = `${found.url}?date=${date}&adults=${adults}&child=${children}`;
            } else {
                // Lead Capture Route
                window.location.href = `custom-trip.php?dest=${encodeURIComponent(destination)}&date=${date}&adults=${adults}&child=${children}`;
            }
        });
    }
});
// =======================================================
// SUGGESTION STRIP CAROUSEL LOGIC
// =======================================================
document.addEventListener('DOMContentLoaded', () => {
    const track = document.getElementById('suggestionTrack');
    const btnLeft = document.getElementById('stripSlideLeft');
    const btnRight = document.getElementById('stripSlideRight');

    if (track && btnLeft && btnRight) {
        const slideAmount = 300; // Scrolls one card at a time

        btnLeft.addEventListener('click', () => {
            track.scrollBy({ left: -slideAmount, behavior: 'smooth' });
        });

        btnRight.addEventListener('click', () => {
            track.scrollBy({ left: slideAmount, behavior: 'smooth' });
        });
    }
});
// =======================================================
    // TRAVELTARA MASTER DATABASE (Standardized URLs)
    // =======================================================
    const travelDatabase = [
        // --- DOMESTIC REGIONS (Expanded) ---
        { name: "Kashmir", type: "Region", url: "kashmir.php" },
        { name: "Sikkim", type: "Region", url: "sikkim.php" },
        { name: "Rajasthan", type: "Region", url: "rajasthan.php" },
        { name: "Himachal Pradesh", type: "Region", url: "himachal.php" },
        { name: "Munnar & Kerala", type: "Region", url: "kerala.php" },
        { name: "North Bengal", type: "Region", url: "north-bengal.php" },
        { name: "Ladakh", type: "Region", url: "ladakh.php" },
        { name: "Andaman Islands", type: "Region", url: "andaman.php" },
        { name: "Goa", type: "Region", url: "goa.php" },

        // --- INTERNATIONAL REGIONS (Restricted) ---
        { name: "Vietnam", type: "Region", url: "vietnam.php" },
        { name: "Thailand", type: "Region", url: "thailand.php" },

        // =======================================================
        // DOMESTIC PACKAGES
        // =======================================================
        
        // --- KASHMIR PACKAGES ---
        { name: "Kashmir Paradise (3N/4D)", type: "Package", url: "kashmir-4-day.php", searchTags: "kashmir short snow gulmarg" },
        { name: "The Crown of India (5N/6D)", type: "Package", url: "kashmir-6-day.php", searchTags: "kashmir dal lake pahalgam premium" },

        // --- SIKKIM PACKAGES ---
        { name: "The Short Getaway (3N/4D)", type: "Package", url: "sikkim-4-day.php", searchTags: "sikkim short gangtok tsomgo" },
        { name: "Sikkim Mystique (5N/6D)", type: "Package", url: "sikkim-6-day.php", searchTags: "sikkim lachung valley popular" },
        { name: "Himalayan Explorer (7N/8D)", type: "Package", url: "sikkim-8-day.php", searchTags: "sikkim deep dive gurudongmar lachen" },

        // --- RAJASTHAN PACKAGES ---
        { name: "Royal Desert Safari (4N/5D)", type: "Package", url: "rajasthan-5-day.php", searchTags: "rajasthan desert jaisalmer camel" },
        { name: "Palaces of Mewar (6N/7D)", type: "Package", url: "rajasthan-7-day.php", searchTags: "rajasthan udaipur jaipur heritage luxury" },

        // --- HIMACHAL PACKAGES ---
        { name: "Shimla & Manali Premium (6N/7D)", type: "Package", url: "himachal-7-day.php", searchTags: "himachal snow mountains family" },
        { name: "Spiti Valley Expedition (8N/9D)", type: "Package", url: "himachal-9-day.php", searchTags: "himachal adventure offbeat road trip" },

        // --- KERALA / MUNNAR PACKAGES ---
        { name: "Munnar Tea Trails (3N/4D)", type: "Package", url: "kerala-4-day.php", searchTags: "kerala munnar short nature green" },
        { name: "Backwaters & Beach Retreat (5N/6D)", type: "Package", url: "kerala-6-day.php", searchTags: "kerala alleppey houseboat relaxing" },

        // --- NORTH BENGAL PACKAGES ---
        { name: "Darjeeling Heritage (3N/4D)", type: "Package", url: "north-bengal-4-day.php", searchTags: "bengal darjeeling tea toy train" },
        { name: "Dooars Wildlife Safari (4N/5D)", type: "Package", url: "north-bengal-5-day.php", searchTags: "bengal dooars jungle forest wildlife" },

        // --- LADAKH PACKAGES ---
        { name: "Leh & Pangong Short (4N/5D)", type: "Package", url: "ladakh-5-day.php", searchTags: "ladakh short lake mountains" },
        { name: "Nubra Valley & Beyond (6N/7D)", type: "Package", url: "ladakh-7-day.php", searchTags: "ladakh desert camel adventure" },

        // --- ANDAMAN PACKAGES ---
        { name: "Havelock Island Escape (4N/5D)", type: "Package", url: "andaman-5-day.php", searchTags: "andaman beach scuba tropical ocean" },

        // --- GOA PACKAGES ---
        { name: "South Goa Villa Retreat (3N/4D)", type: "Package", url: "goa-4-day.php", searchTags: "goa beach luxury relaxing private" },

        // =======================================================
        // INTERNATIONAL PACKAGES
        // =======================================================

        // --- VIETNAM PACKAGES ---
        { name: "Ha Long Bay Cruise (3N/4D)", type: "Package", url: "vietnam-4-day.php", searchTags: "vietnam short cruise boat luxury" },
        { name: "Mekong Delta Retreat (4N/5D)", type: "Package", url: "vietnam-5-day.php", searchTags: "vietnam nature river relaxing" },
        { name: "Golden Hands Bridge & Hoi An (5N/6D)", type: "Package", url: "vietnam-6-day.php", searchTags: "vietnam culture lanterns danang" },
        { name: "Vietnam North to South (8N/9D)", type: "Package", url: "vietnam-9-day.php", searchTags: "vietnam hanoi saigon grand tour" },
        { name: "Ultimate Vietnam Luxury (10N/11D)", type: "Package", url: "vietnam-11-day.php", searchTags: "vietnam premium private resorts" },

        // --- THAILAND PACKAGES ---
        { name: "Phuket Pool Villa Escape (4N/5D)", type: "Package", url: "thailand-5-day.php", searchTags: "thailand beach relax private pool" },
        { name: "Bangkok & Beyond (5N/6D)", type: "Package", url: "thailand-6-day.php", searchTags: "thailand city shopping temples" },
        { name: "Koh Samui Romance (6N/7D)", type: "Package", url: "thailand-7-day.php", searchTags: "thailand couple honeymoon sunset" },
        { name: "The Royal Thai Experience (9N/10D)", type: "Package", url: "thailand-10-day.php", searchTags: "thailand premium grand 5-star" }
    ];

    // =======================================================
// SMART 5-SECOND TRUE INFINITY CAROUSEL (LEFT BUTTON FIXED)
// =======================================================
document.addEventListener('DOMContentLoaded', () => {
    const track = document.getElementById('suggestionTrack');
    const btnLeft = document.getElementById('stripSlideLeft');
    const btnRight = document.getElementById('stripSlideRight');

    if (track && btnLeft && btnRight) {
        
        // 1. THE CLONING ENGINE (Creates the infinite illusion)
        const cards = Array.from(track.children);
        cards.forEach(card => {
            const clone = card.cloneNode(true);
            track.appendChild(clone);
        });

        let autoScrollInterval;
        let idleTimeout;
        const scrollAmount = 300; // Width of one card + gap

        // 2. THE SILENT JUMP (Handles infinite wrap-around)
        const handleInfiniteScroll = () => {
            const halfWidth = track.scrollWidth / 2;

            if (track.scrollLeft >= halfWidth) {
                track.style.scrollBehavior = 'auto'; 
                track.scrollLeft = track.scrollLeft - halfWidth; 
                setTimeout(() => { track.style.scrollBehavior = 'smooth'; }, 10);
            } 
        };

        track.addEventListener('scroll', handleInfiniteScroll, { passive: true });

        // 3. THE MOVEMENT ENGINE
        const executeScroll = () => {
            track.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        };

        const startAutoScroll = () => {
            clearInterval(autoScrollInterval);
            autoScrollInterval = setInterval(executeScroll, 2500); 
        };

        // 4. THE 5-SECOND IDLE TIMER
        const triggerIdleTimer = () => {
            clearInterval(autoScrollInterval); 
            clearTimeout(idleTimeout);         
            idleTimeout = setTimeout(startAutoScroll, 5000);
        };

        // --- EVENT LISTENERS ---

        // THE FIX: Bulletproof Left Button Logic
        btnLeft.addEventListener('click', () => {
            // If we are at the very beginning (<= 10px covers screen scaling quirks)
            if (track.scrollLeft <= 10) {
                track.style.scrollBehavior = 'auto'; // 1. Turn off animation
                track.scrollLeft = (track.scrollWidth / 2); // 2. Silent jump to the cloned middle

                // 3. Wait 20 milliseconds for the browser to register the jump, then slide!
                setTimeout(() => {
                    track.style.scrollBehavior = 'smooth'; 
                    track.scrollBy({ left: -scrollAmount, behavior: 'smooth' }); 
                }, 20);
            } else {
                // If we aren't at the edge, just slide left normally
                track.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
            }
            triggerIdleTimer();
        });

        btnRight.addEventListener('click', () => {
            track.scrollBy({ left: scrollAmount, behavior: 'smooth' });
            triggerIdleTimer();
        });

        // Mobile Touch & Swipes
        track.addEventListener('touchstart', triggerIdleTimer, { passive: true });
        track.addEventListener('touchend', triggerIdleTimer, { passive: true });
        
        // Mouse Hover (Pause while reading)
        track.addEventListener('mouseenter', () => {
            clearInterval(autoScrollInterval);
            clearTimeout(idleTimeout);
        });
        track.addEventListener('mouseleave', triggerIdleTimer);

        // Start the engine on load
        startAutoScroll();
    }
});

// =======================================================
// LEAD CAPTURE MODAL LOGIC (TWO-STEP W/ DYNAMIC PRICING)
// =======================================================

// ⚠️ THIS IS YOUR PRICING URL (Same as the one in checkout.js)
const PRICING_SCRIPT_URL = "https://traveltara.com/process_checkout.php";

document.addEventListener('DOMContentLoaded', () => {
    
    // UI Elements
    const taraOpenBtn = document.getElementById('openBookingModal');
    const taraModal = document.getElementById('taraGatewayModal');
    const taraCancelBtn = document.getElementById('cancelRegBtn');
    const taraBackBtn = document.getElementById('backStepBtn');
    
    // Steps
    const step1 = document.getElementById('gatewayStep1');
    const step2 = document.getElementById('gatewayStep2');
    const step3 = document.getElementById('gatewaySuccessStep');
    
    // Forms
    const form1 = document.getElementById('taraRegFormStep1');
    const form2 = document.getElementById('taraRegFormStep2');
    
    // Inputs Step 1
    const taraNameInput = document.getElementById('regName');
    const taraPhoneInput = document.getElementById('regPhone');
    const taraPhoneErr = document.getElementById('phoneError');
    
    // Inputs Step 2
    const packageNameInput = document.getElementById('regPackageName');
    const tourTierSelect = document.getElementById('regTourTier');
    const priceWrapper = document.getElementById('priceDisplayWrapper');
    const priceInput = document.getElementById('regPrice');
    
    // Timer
    const taraCountdownText = document.getElementById('redirectCountdown');
    const taraInstantRedirectBtn = document.getElementById('instantRedirectBtn');
    let taraCountdownInterval;

    // --- DYNAMIC PRICING ENGINE --- 
    // (Now pulls instantly from the PHP-injected 'tourTierData' variable instead of Google Sheets)
    let currentPackageName = "Custom Trip Request";

    // 1. OPEN MODAL & AUTO-FILL PACKAGE NAME
    if (taraOpenBtn && taraModal) {
        taraOpenBtn.addEventListener('click', function() {
            taraModal.classList.add('active');
            document.body.style.overflow = 'hidden'; 

            if (form1) form1.reset();
            if (form2) form2.reset();

            const btnPackage = this.getAttribute('data-package');
            const urlParams = new URLSearchParams(window.location.search);
            const packageParam = urlParams.get('package');

            if (btnPackage) {
                currentPackageName = btnPackage;
            } else if (packageParam) {
                currentPackageName = packageParam.replace(/-/g, ' ').replace(/\b\w/g, char => char.toUpperCase());
            } else {
                currentPackageName = "Custom Trip Request";
            }

            if (packageNameInput) packageNameInput.value = currentPackageName;

            // Reset Steps & Price Display
            if (step1) step1.classList.remove('hidden-step');
            if (step2) step2.classList.add('hidden-step');
            if (step3) step3.classList.add('hidden-step');
            if (priceWrapper) priceWrapper.style.display = 'none';
        });
    }

    // 2. NAVIGATION (Cancel & Back)
    if (taraCancelBtn && taraModal) {
        taraCancelBtn.addEventListener('click', () => {
            taraModal.classList.remove('active');
            document.body.style.overflow = 'auto'; 
        });
    }
    
    if (taraBackBtn) {
        taraBackBtn.addEventListener('click', () => {
            step2.classList.add('hidden-step');
            step1.classList.remove('hidden-step');
        });
    }

    // 3. INPUT VALIDATION
    if (taraNameInput) taraNameInput.addEventListener('input', function() { this.value = this.value.replace(/[^a-zA-Z\s]/g, ''); });
    if (taraPhoneInput) taraPhoneInput.addEventListener('input', function() { this.value = this.value.replace(/[^0-9]/g, ''); });

    // 4. SUBMIT STEP 1 (Move to Step 2)
    if (form1) {
        form1.addEventListener('submit', (e) => {
            e.preventDefault();
            if (taraPhoneInput && taraPhoneInput.value.length !== 10) {
                if (taraPhoneErr) taraPhoneErr.style.display = 'block';
                taraPhoneInput.style.borderColor = 'red';
                return;
            }
            if (taraPhoneErr) taraPhoneErr.style.display = 'none';
            if (taraPhoneInput) taraPhoneInput.style.borderColor = '#ccc';

            // Transition to Step 2
            step1.classList.add('hidden-step');
            step2.classList.remove('hidden-step');
        });
    }

    // 5. DYNAMIC PRICING LOGIC (Step 2)
    if (tourTierSelect) {
        tourTierSelect.addEventListener('change', function() {
            const selectedTier = this.value;
            
            if (selectedTier === "Customised") {
                priceWrapper.style.display = 'none'; 
                priceInput.value = "";
            } else {
                priceWrapper.style.display = 'block';
                
                let finalPrice = "Price Unavailable";
                
                // LOOK UP EXACT PRICE IN LOCAL PHP DATA
                if (typeof tourTierData !== 'undefined') {
                    if (selectedTier === "Budget" && tourTierData.budget) {
                        finalPrice = tourTierData.budget.price;
                    } else if (selectedTier === "Affordable Luxury" && tourTierData.affordable) {
                        finalPrice = tourTierData.affordable.price;
                    } else if (selectedTier === "Super Luxury" && tourTierData.super) {
                        finalPrice = tourTierData.super.price;
                    }
                }
                
                priceInput.value = finalPrice; 
            }
        });
    }

    // 6. SUBMIT STEP 2 (SPLIT LOGIC: NORMAL VS CUSTOMISED)
    if (form2) {
        form2.addEventListener('submit', async (e) => {
            e.preventDefault();

            const selectedTier = tourTierSelect ? tourTierSelect.value : "Standard";
            const phoneVal = taraPhoneInput ? taraPhoneInput.value : "N/A";
            const nameVal = taraNameInput ? taraNameInput.value : "Guest";
            const packageVal = packageNameInput ? packageNameInput.value : "Custom Trip";

            // GENERATE ID & SAVE SESSION DATA
            const timePart = Date.now().toString(36).toUpperCase().slice(-4); 
            const randomPart = Math.random().toString(36).toUpperCase().slice(2, 5); 
            const uniqueBookingId = `TRV-${timePart}${randomPart}`; 
            
            sessionStorage.setItem('tara_guest_phone', phoneVal);
            sessionStorage.setItem('tara_guest_name', nameVal);
            sessionStorage.setItem('tara_package_name', packageVal);
            sessionStorage.setItem('tara_tour_tier', selectedTier);
            sessionStorage.setItem('tara_booking_id', uniqueBookingId);

            // =======================================================
            // 🔥 THE NEW "CUSTOMISED" WHATSAPP & CRM LOGIC 🔥
            // =======================================================
            if (selectedTier === "Customised") {
                const submitBtn = form2.querySelector('button[type="submit"]');
                submitBtn.innerText = "Connecting to Agent...";
                submitBtn.style.pointerEvents = "none";

                // 1. Silently send the data to Google Sheets
                const payload = {
                    action: 'CUSTOM_REQUEST',
                    bookingId: uniqueBookingId,
                    name: nameVal,
                    phone: phoneVal,
                    package: packageVal,
                    tier: selectedTier
                };

                try {
                    await fetch(PRICING_SCRIPT_URL, {
                        method: 'POST',
                        mode: 'no-cors', // Bypasses CORS blocks
                        headers: { 'Content-Type': 'text/plain' },
                        body: JSON.stringify(payload)
                    });
                } catch (err) {
                    console.error("Sheet sync failed, but proceeding to WhatsApp...", err);
                }

                // 2. Redirect the user to WhatsApp instantly
                const waMsg = encodeURIComponent(`Hi Traveltara! My name is ${nameVal}. I am interested in customizing the "${packageVal}" itinerary. My Ref ID is ${uniqueBookingId}. Please help me plan this!`);
                window.location.href = `https://wa.me/917439877604?text=${waMsg}`;
                
                return; // STOPS the rest of the function from running!
            }
            // =======================================================

            // IF REGULAR TIER (Budget, Luxury, etc.) -> Proceed to Step 3 Countdown
            if (step2) step2.classList.add('hidden-step');
            if (step3) step3.classList.remove('hidden-step');

            let timeLeft = 3;
            if (taraCountdownText) taraCountdownText.innerText = timeLeft;

            taraCountdownInterval = setInterval(() => {
                timeLeft--;
                if (taraCountdownText) taraCountdownText.innerText = timeLeft;

                if (timeLeft <= 0) {
                    clearInterval(taraCountdownInterval);
                    const finalPackageName = document.getElementById('regPackageName').value;
                    sessionStorage.setItem('tara_package_name', finalPackageName);
                    window.location.href = "booking.php"; // Auto Redirect
                }
            }, 1000);
        });
    }

    // 7. MANUAL REDIRECT
    if (taraInstantRedirectBtn) {
        taraInstantRedirectBtn.addEventListener('click', () => {
            clearInterval(taraCountdownInterval); 
            const finalPackageName = document.getElementById('regPackageName').value;
            sessionStorage.setItem('tara_package_name', finalPackageName);
            window.location.href = "booking.php"; 
        });
    }
});
/* =========================================
   DYNAMIC TIER TOGGLE (UNIVERSAL)
   ========================================= */
function updateTier(tierKey, btnElement) {
    // 1. Safety check: Ensure the PHP page actually provided the data
    if (typeof tourTierData === 'undefined') {
        console.error("Tour tier data is missing from the database.");
        return;
    }

    // 2. Remove active state from all buttons, add to the clicked one
    document.querySelectorAll('.tier-pill').forEach(btn => btn.classList.remove('active'));
    btnElement.classList.add('active');

    // 3. Get the dynamic data for the clicked tier
    const data = tourTierData[tierKey];
    if (!data) return;
    
    // 4. Smoothly swap the content
    const highlightsList = document.getElementById('tierHighlights');
    highlightsList.style.opacity = '0'; // Quick fade out
    
    setTimeout(() => {
        document.getElementById('tierLabel').innerText = data.label;
        document.getElementById('tierPrice').innerHTML = data.price + '<span class="price-person">/pp</span>';
        highlightsList.innerHTML = data.highlights;
        highlightsList.style.opacity = '1'; // Fade back in
    }, 200);
}
/* ==========================================================================
   HOMEPAGE FAQ ACCORDION LOGIC (BULLETPROOF)
   ========================================================================== */
document.addEventListener("DOMContentLoaded", function() {
    
    // 1. Force the individual questions and arrows to work
    const allQuestions = document.querySelectorAll('.faq-question');
    
    allQuestions.forEach(function(questionBtn) {
        questionBtn.onclick = function(e) {
            e.preventDefault();
            
            const faqItem = this.closest('.faq-item');
            const answerBox = faqItem.querySelector('.faq-answer');
            const arrow = this.querySelector('.arrow-icon');
            
            // Force the box to open and arrow to spin
            if (answerBox.style.display === 'block') {
                answerBox.style.display = 'none';
                arrow.style.transform = 'rotate(0deg)';
                faqItem.style.borderColor = '#eee';
                faqItem.style.boxShadow = '0 4px 15px rgba(0,0,0,0.03)';
            } else {
                answerBox.style.display = 'block';
                arrow.style.transform = 'rotate(180deg)';
                faqItem.style.borderColor = '#C5A059';
                faqItem.style.boxShadow = '0 10px 25px rgba(197, 160, 89, 0.15)';
            }
        };
    });

    // 2. Keep the "Show More / Show Less" button working perfectly
    const toggleBtn = document.getElementById('toggleFaqsBtn');
    const hiddenWrapper = document.getElementById('moreFaqsWrapper');
    
    if (toggleBtn && hiddenWrapper) {
        hiddenWrapper.style.display = 'none'; 
        
        toggleBtn.onclick = function(e) {
            e.preventDefault();
            if (hiddenWrapper.style.display === 'none') {
                hiddenWrapper.style.display = 'block';
                this.innerHTML = 'Show Less <i class="fa-solid fa-angle-up" style="margin-left: 5px;"></i>';
            } else {
                hiddenWrapper.style.display = 'none';
                this.innerHTML = 'Show More <i class="fa-solid fa-angle-down" style="margin-left: 5px;"></i>';
            }
        };
    }
});
/* ==========================================================================
   PC MOUSE DRAG-TO-SCROLL (WITH PHYSICS-BASED MOMENTUM GLIDE)
   ========================================================================== */
document.addEventListener("DOMContentLoaded", function() {
    
    const sliders = document.querySelectorAll(`
        .hero-track, 
        .dest-slider-container, 
        .hotel-scroll-container, 
        .review-track, 
        .video-slider-container, 
        .gallery-track, 
        .marquee-track,
        .city-toggle-container
    `);

    sliders.forEach(slider => {
        let isDown = false;
        let startX;
        let scrollLeft;
        let startScrollLeft; 
        let hasDragged = false;

        // Physics/Momentum variables
        let velX = 0;
        let prevX = 0;
        let momentumID;

        slider.classList.add('grab-enabled');

        // 1. MOUSE DOWN
        slider.addEventListener('mousedown', (e) => {
            isDown = true;
            hasDragged = false;
            slider.classList.add('is-dragging');
            
            // Kill any active momentum if they grab it while it's still gliding
            cancelAnimationFrame(momentumID);

            slider.style.scrollBehavior = 'auto'; 
            slider.style.scrollSnapType = 'none'; 

            startX = e.pageX - slider.offsetLeft;
            scrollLeft = slider.scrollLeft;
            startScrollLeft = slider.scrollLeft; 
            
            prevX = startX;
            velX = 0;
        });

        // 2. MOUSE LEAVE & MOUSE UP
        const handleMouseUp = () => {
            if (!isDown) return;
            isDown = false;
            slider.classList.remove('is-dragging');
            
            // 🚨 HYચ્BRID LOGIC WITH GLIDE PHYSICS 🚨
            if (slider.classList.contains('dest-slider-container')) {
                // Top Destinations: Activate Buttery Smooth Glide
                slider.style.scrollSnapType = 'none'; 
                velX = velX * 1.5; // Boost the "throw" strength slightly
                beginMomentum();
            } else {
                // Snapping Sliders (Hero, etc): Factor in the "throw speed" to predict snap
                const dragDistance = (startScrollLeft - slider.scrollLeft) - (velX * 5); 
                snapToPerfectPosition(slider, dragDistance);
            }
        };

        slider.addEventListener('mouseleave', handleMouseUp);
        slider.addEventListener('mouseup', handleMouseUp);

        // 3. MOUSE MOVE (Calculates Velocity)
        slider.addEventListener('mousemove', (e) => {
            if (!isDown) return; 
            e.preventDefault();
            
            const x = e.pageX - slider.offsetLeft;
            const walk = (x - startX) * 1.3; 
            
            // Track how fast the mouse is moving (Velocity)
            velX = x - prevX;
            prevX = x;
            
            if (Math.abs(walk) > 5) {
                hasDragged = true; 
            }
            
            slider.scrollLeft = scrollLeft - walk; 
        });

        // 4. THE MOMENTUM GLIDE ENGINE 
        function beginMomentum() {
            slider.scrollLeft -= velX; // Apply the momentum
            velX *= 0.95; // Apply Friction (0.95 = long smooth glide)

            // Keep the animation running until the speed dies down to near-zero
            if (Math.abs(velX) > 0.5) {
                momentumID = requestAnimationFrame(beginMomentum);
            }
        }

        // 5. PREVENT ACCIDENTAL CLICKS
        const links = slider.querySelectorAll('a, button, .city-wrapper, .dest-card, .video-card');
        links.forEach(link => {
            link.addEventListener('click', (e) => {
                if (hasDragged) {
                    e.preventDefault(); 
                }
            });
        });
    });

    // 🚨 THE MAGIC SNAP FUNCTION FOR HERO BANNER/ETC 🚨
    function snapToPerfectPosition(slider, dragDistance) {
        slider.style.scrollBehavior = 'smooth';

        const firstChild = slider.firstElementChild;
        if (!firstChild) return;

        const itemWidth = firstChild.getBoundingClientRect().width;
        const gap = parseFloat(window.getComputedStyle(slider).gap) || 0;
        const totalStep = itemWidth + gap;
        const currentScroll = slider.scrollLeft;
        
        let targetIndex;

        if (slider.classList.contains('hero-track')) {
            const startIndex = Math.round((currentScroll + dragDistance) / totalStep);
            
            if (dragDistance < -30) {
                targetIndex = startIndex + 1;
            } else if (dragDistance > 30) {
                targetIndex = startIndex - 1;
            } else {
                targetIndex = startIndex;
            }
        } else {
            targetIndex = Math.round((currentScroll + dragDistance) / totalStep);
        }

        targetIndex = Math.max(0, targetIndex);
        slider.scrollLeft = targetIndex * totalStep;

        setTimeout(() => {
            slider.style.scrollSnapType = 'x mandatory';
        }, 400); 
    }
});
/* ==========================================================================
   TOP DESTINATIONS: SUB-PIXEL INFINITE SCROLL LOOP
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
    const destTrack = document.getElementById('destSlider');
    if (!destTrack) return;

    const cards = Array.from(destTrack.children);
    const count = cards.length;

    // 1. Clone the cards perfectly
    cards.forEach(card => destTrack.appendChild(card.cloneNode(true)));
    cards.slice().reverse().forEach(card => destTrack.prepend(card.cloneNode(true)));

    let cardWidth = 0;
    let totalOriginalWidth = 0;

    function updateMeasurements() {
        // Use getBoundingClientRect for exact sub-pixel decimals (kills the stutter!)
        const gap = parseFloat(window.getComputedStyle(destTrack).gap) || 0;
        const firstCard = destTrack.querySelector('.dest-card');
        if (firstCard) {
            cardWidth = firstCard.getBoundingClientRect().width + gap;
            totalOriginalWidth = cardWidth * count;
        }
    }

    // 2. Center the initial position securely
    setTimeout(() => {
        updateMeasurements();
        destTrack.scrollLeft = totalOriginalWidth;
    }, 100);

    // Update measurements if the user rotates their phone or resizes window
    window.addEventListener('resize', updateMeasurements);

    // 3. The Zero-Lag Wrap Listener
    destTrack.addEventListener('scroll', () => {
        if (cardWidth === 0) return;

        // Left boundary wrap
        if (destTrack.scrollLeft <= cardWidth - 5) {
            destTrack.style.scrollBehavior = 'auto'; // Instant snap invisible to the eye
            destTrack.scrollLeft += totalOriginalWidth; 
        } 
        // Right boundary wrap
        else if (destTrack.scrollLeft >= (totalOriginalWidth * 2) - cardWidth + 5) {
            destTrack.style.scrollBehavior = 'auto'; // Instant snap invisible to the eye
            destTrack.scrollLeft -= totalOriginalWidth;
        }
    }, { passive: true }); // passive: true ensures the browser prioritizes smooth scrolling

    // 4. Arrow Controls (Attach to window so inline onclick="" buttons still work)
    window.slideDestinations = function(direction) {
        updateMeasurements();
        destTrack.style.scrollBehavior = 'smooth'; 
        destTrack.scrollBy({ left: cardWidth * direction });
    };
});
/* ==========================================================================
   IMMERSIVE SPOTLIGHT MENU LOGIC
   ========================================================================== */
document.addEventListener("DOMContentLoaded", function() {
    const spotlightItems = document.querySelectorAll('.spotlight-menu li');
    const spotlightBgs = document.querySelectorAll('.spotlight-bg');

    spotlightItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            // Get the ID of the background this item triggers
            const targetId = this.getAttribute('data-target');
            
            // Remove 'active' from all backgrounds
            spotlightBgs.forEach(bg => bg.classList.remove('active'));
            
            // Add 'active' to the target background
            const activeBg = document.getElementById(targetId);
            if (activeBg) {
                activeBg.classList.add('active');
            }
        });
    });

    // Optional: Return to the default dark background when the mouse leaves the whole menu
    const spotlightMenu = document.querySelector('.spotlight-menu');
    if(spotlightMenu) {
        spotlightMenu.addEventListener('mouseleave', function() {
            spotlightBgs.forEach(bg => bg.classList.remove('active'));
            document.getElementById('bg-default').classList.add('active');
        });
    }
});
/* ==========================================================================
   TOP DESTINATIONS: SUB-PIXEL INFINITE SCROLL LOOP + MOBILE HOVER FIX
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
    const destTrack = document.getElementById('destSlider');
    if (!destTrack) return;

    // 1. THE MOBILE FOCUS OBSERVER (Restored for Hover Effects)
    // Watches the cards and adds '.focused' when they hit the center of the screen
    const destObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('focused');
            } else {
                entry.target.classList.remove('focused');
            }
        });
    }, { 
        root: destTrack, 
        threshold: 0.6 // Triggers when 60% of the card is visible in the scroll track
    });

    const cards = Array.from(destTrack.children);
    const count = cards.length;

    // 2. CLONE CARDS & ATTACH OBSERVER
    // We must observe the originals AND the clones!
    cards.forEach(card => destObserver.observe(card));

    cards.forEach(card => {
        const clone = card.cloneNode(true);
        destTrack.appendChild(clone);
        destObserver.observe(clone); // Watch the clone
    });
    
    cards.slice().reverse().forEach(card => {
        const clone = card.cloneNode(true);
        destTrack.prepend(clone);
        destObserver.observe(clone); // Watch the clone
    });

    let cardWidth = 0;
    let totalOriginalWidth = 0;

    function updateMeasurements() {
        const gap = parseFloat(window.getComputedStyle(destTrack).gap) || 0;
        const firstCard = destTrack.querySelector('.dest-card');
        if (firstCard) {
            cardWidth = firstCard.getBoundingClientRect().width + gap;
            totalOriginalWidth = cardWidth * count;
        }
    }

    // 3. CENTER STARTING POSITION
    setTimeout(() => {
        updateMeasurements();
        destTrack.scrollLeft = totalOriginalWidth;
    }, 100);

    window.addEventListener('resize', updateMeasurements);

    // 4. THE ZERO-LAG WRAP LISTENER
    destTrack.addEventListener('scroll', () => {
        if (cardWidth === 0) return;

        if (destTrack.scrollLeft <= cardWidth - 5) {
            destTrack.style.scrollBehavior = 'auto'; // Instant snap invisible to the eye
            destTrack.scrollLeft += totalOriginalWidth; 
        } 
        else if (destTrack.scrollLeft >= (totalOriginalWidth * 2) - cardWidth + 5) {
            destTrack.style.scrollBehavior = 'auto'; // Instant snap invisible to the eye
            destTrack.scrollLeft -= totalOriginalWidth;
        }
    }, { passive: true });

    // 5. ARROW CONTROLS 
    window.slideDestinations = function(direction) {
        updateMeasurements();
        destTrack.style.scrollBehavior = 'smooth'; 
        destTrack.scrollBy({ left: cardWidth * direction });
    };
});