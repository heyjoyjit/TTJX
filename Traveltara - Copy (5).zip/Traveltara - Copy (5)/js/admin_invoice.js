// =======================================================
// ADMIN POS & MANUAL INVOICE GENERATOR
// =======================================================

// 🚀 ROUTE DIRECTLY TO HOSTINGER MYSQL DATABASE (NO MORE GOOGLE)
const HOSTINGER_API_URL = "process_leads.php";
const HOSTINGER_MAILER_URL = "https://traveltara.com/process_checkout.php"; 

let locationCount = 0;

// Number to words converter for the invoice
function numberToWords(num) {
    const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
    const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
    if ((num = num.toString()).length > 9) return 'Overflow';
    const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return ''; 
    let str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'Only' : 'Only';
    return str;
}

// Format numbers as Indian Rupees
const fmt = (num) => num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// 1. Dynamic Location Builder
function addLocationRow() {
    locationCount++;
    const container = document.getElementById('locationsContainer');
    
    const row = document.createElement('div');
    row.className = 'location-row';
    row.id = `locRow_${locationCount}`;
    
    row.innerHTML = `
        <button type="button" class="remove-loc-btn" onclick="removeLocationRow(${locationCount})"><i class="fa-solid fa-xmark"></i></button>
        <div class="form-grid" style="grid-template-columns: 2fr 1fr 1fr;">
            <div class="input-group">
                <label>Destination / Service Name</label>
                <input type="text" class="loc-name" required placeholder="e.g. Royal Rajasthan Tour">
            </div>
            <div class="input-group">
                <label>Date</label>
                <input type="date" class="loc-date" required>
            </div>
            <div class="input-group">
                <label>Taxable Amount (₹)</label>
                <input type="number" class="loc-amt" required min="0" value="0" oninput="calculateAdminTotal()">
            </div>
        </div>
    `;
    container.appendChild(row);
}

function removeLocationRow(id) {
    const row = document.getElementById(`locRow_${id}`);
    if (row) row.remove();
    calculateAdminTotal();
}

// Initialize with one empty row
document.addEventListener('DOMContentLoaded', () => {
    addLocationRow();
});

// 2. Real-Time Math Calculator
function calculateAdminTotal() {
    const amountInputs = document.querySelectorAll('.loc-amt');
    let totalTaxable = 0;
    
    amountInputs.forEach(input => {
        totalTaxable += parseFloat(input.value) || 0;
    });

    const gst = totalTaxable * 0.05; // Standard 5% Tour GST
    const grandTotal = totalTaxable + gst;

    document.getElementById('displayTotalCost').innerText = `₹ ${fmt(grandTotal)}`;
    return { taxable: totalTaxable, gst: gst, total: grandTotal };
}

// 3. Form Submission & Bypass Logic
document.getElementById('adminInvoiceForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const btn = document.getElementById('generateBillBtn');
    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Generating Invoice & Routing Emails...';
    btn.style.pointerEvents = 'none';

    // Collect Form Data
    const guestName = document.getElementById('gName').value;
    const guestPhone = document.getElementById('gPhone').value;
    const guestEmail = document.getElementById('gEmail').value;
    const tier = document.getElementById('tier').value;
    const adults = document.getElementById('adults').value;
    const children = document.getElementById('child').value;
    const rooms = document.getElementById('rooms').value;
    
    const math = calculateAdminTotal();
    const invTimePart = Date.now().toString(36).toUpperCase().slice(-5);
    const bookingId = `TRV-POS-${invTimePart}`;
    const generatedInvoiceNo = `INV-${invTimePart}POS`;

    // Extract destinations for the DB
    let destArray = [];
    document.querySelectorAll('.loc-name').forEach(input => { if (input.value.trim() !== '') destArray.push(input.value.trim()); });
    const combinedDestinations = destArray.join(' + ');
    const firstDate = document.querySelector('.loc-date').value || 'TBD';

    // Split name for DB
    const nameParts = guestName.trim().split(' ');
    const fName = nameParts[0] || '';
    const lName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : '';

    // 4. Generate the PDF and trigger local download
    const invoiceBase64 = await buildAndDownloadPDF(bookingId, generatedInvoiceNo, guestName, guestPhone, guestEmail, tier, adults, children, rooms, math);

    try {
        // 5. Fire to Hostinger Database (Create Lead Row)
        const masterPayload = {
            action: 'LEAD_CAPTURE',
            bookingId: bookingId,
            prefix: '',
            fName: fName,
            mName: '',
            lName: lName,
            primaryPhone: guestPhone,
            altPhone: '',
            email: guestEmail,
            resAddress: 'Address on File',
            aadhaar: '',
            passport: '',
            tourType: 'Domestic',
            destination: combinedDestinations,
            startDate: firstDate,
            tier: tier,
            adults: adults,
            children: children,
            rooms: rooms,
            totalAmount: math.total
        };

        await fetch(HOSTINGER_API_URL, { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify(masterPayload) 
        });

        // 6. Fire to Hostinger Database (Mark as Paid)
        const markPaidPayload = {
            action: 'MARK_PAID',
            bookingId: bookingId,
            adults: adults,
            children: children,
            rooms: rooms,
            totalPaid: math.total,
            paymentRef: "OFFLINE_CASH_POS",
            couponUsed: "MANUAL_ENTRY",
            status: "Payment Complete"
        };

        await fetch(HOSTINGER_API_URL, { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify(markPaidPayload) 
        });

        // 7. Fire to Hostinger Mailer (Sends the Email)
        const hostingerPayload = {
            action: 'HOSTINGER_EMAIL',
            bookingId: bookingId,
            email: guestEmail,
            guestName: guestName,
            totalAmount: math.total,
            paymentId: "OFFLINE_CASH_POS", 
            invoicePdf: invoiceBase64         
        };

        var xhr = new XMLHttpRequest();
        xhr.open("POST", HOSTINGER_MAILER_URL, true);
        xhr.setRequestHeader("Content-Type", "application/json;charset=utf-8");
        
        xhr.onload = function() {
            btn.style.background = '#27ae60'; 
            btn.innerHTML = `<i class="fa-solid fa-check"></i> Success! Invoice Sent & Downloaded.`;
            setTimeout(() => { window.location.reload(); }, 2500); // Reset for next customer
        };
        xhr.send(JSON.stringify(hostingerPayload));

    } catch (err) {
        console.error("Database or Email Sync Error: ", err);
        btn.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> Error communicating with server`;
        btn.style.pointerEvents = 'auto';
    }
});

// =======================================================
// DYNAMIC PDF GENERATOR (Inbuilds rows into the table)
// =======================================================
async function buildAndDownloadPDF(bookingId, invoiceNo, gName, gPhone, gEmail, tier, adults, children, rooms, math) {
    return new Promise((resolve) => {
        
        // 1. Populate standard meta data
        document.getElementById('invRealNo').innerText = invoiceNo;
        document.getElementById('invDate').innerText = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
        
        document.getElementById('invGuestName').innerText = gName;
        document.getElementById('invGuestPhone').innerText = gPhone;
        document.getElementById('invGuestEmail').innerText = gEmail;
        
        document.getElementById('invTier').innerText = tier;
        document.getElementById('invPax').innerText = `${adults} Adults, ${children} Children`;
        document.getElementById('invRooms').innerText = `${rooms} Room(s)`;

        // 2. Clear and populate the Dynamic Table Rows
        const tbody = document.getElementById('invTableBody');
        tbody.innerHTML = ''; // Clear old rows
        
        const locRows = document.querySelectorAll('.location-row');
        let pkgNamesForTitle = [];

        locRows.forEach(row => {
            const name = row.querySelector('.loc-name').value || 'Service';
            let date = row.querySelector('.loc-date').value;
            const amt = parseFloat(row.querySelector('.loc-amt').value) || 0;
            
            pkgNamesForTitle.push(name);
            
            if (date) {
                const d = new Date(date);
                date = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
            } else { date = "TBD"; }

            // Inject the HTML row into the invoice
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="padding: 10px; border: 1px solid #ddd; color: #444;">${name}</td>
                <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: center;">${date}</td>
                <td style="padding: 10px; border: 1px solid #ddd; color: #444; text-align: right;">${fmt(amt)}</td>
            `;
            tbody.appendChild(tr);
        });

        // 3. Populate Totals
        document.getElementById('invSumTaxable').innerText = "₹ " + fmt(math.taxable);
        document.getElementById('invSumGst').innerText = "₹ " + fmt(math.gst);
        document.getElementById('invSumGrand').innerText = "₹ " + fmt(math.total);
        document.getElementById('invWordsText').innerText = "Rupees " + numberToWords(Math.round(math.total));

        // 4. Generate & Download
        const element = document.getElementById('traveltaraInvoice');
        const container = document.getElementById('invoicePrintContainer');
        container.style.display = 'block';
        container.style.position = 'absolute';
        container.style.top = '0';
        container.style.left = '0';
        container.style.zIndex = '-9999';

        const opt = {
            margin: 0, 
            filename: `${invoiceNo}.pdf`,
            image: { type: 'jpeg', quality: 0.85 },
            html2canvas: { scale: 1.2, useCORS: true, windowWidth: 800, scrollY: 0, x: 0, y: 0 },
            jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' } 
        };

        html2pdf().set(opt).from(element).outputPdf('datauristring').then(function (pdfAsString) {
            container.style.display = 'none'; 
            
            // Auto Download on Admin PC
            const downloadLink = document.createElement('a');
            downloadLink.href = pdfAsString;
            downloadLink.download = `${invoiceNo}.pdf`;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);

            // Pass Base64 for Hostinger Email
            const cleanBase64 = pdfAsString.split(',')[1];
            resolve(cleanBase64); 
        });
    });
}