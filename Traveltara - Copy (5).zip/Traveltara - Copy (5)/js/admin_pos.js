// =======================================================
// MASTER ADMIN POS & INVOICE GENERATOR (FULL DATA SYNC)
// =======================================================
const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec";
const HOSTINGER_MAILER_URL = "https://traveltara.com/process_checkout.php"; 

let locationCount = 0;
const fmt = (num) => num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

window.fetchPincodeData = async function(pincode, prefix) {
    const pinInput = document.getElementById(prefix + 'Pin');
    if (pinInput) pinInput.value = pincode.replace(/[^0-9]/g, '');
    if(pincode.length === 6) {
        try {
            let response = await fetch(`https://api.postalpincode.in/pincode/${pincode}`);
            let data = await response.json();
            if(data[0].Status === "Success") {
                document.getElementById(prefix+'City').value = data[0].PostOffice[0].Block || data[0].PostOffice[0].Name;
                document.getElementById(prefix+'State').value = data[0].PostOffice[0].State;
            }
        } catch(e) {}
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const sameAsRes = document.getElementById('sameAsResCheck');
    const permBlock = document.getElementById('permAddressBlock');
    if(sameAsRes) sameAsRes.addEventListener('change', (e) => e.target.checked ? permBlock.classList.add('hidden-section') : permBlock.classList.remove('hidden-section'));
    addLocationRow(); 

    // 🚀 AUTO-FETCH INVOICE DATA ON BLUR
    const invoiceInput = document.querySelector('input[name="invoice"]');
    if (invoiceInput) {
        invoiceInput.addEventListener('blur', async function() {
            const inv = this.value.trim();
            if(!inv) return;
            
            try {
                this.style.transition = '0.3s'; this.style.borderColor = '#2980b9';
                const res = await fetch(`admin_pos.php?fetch_invoice=${encodeURIComponent(inv)}`);
                const json = await res.json();
                
                if(json.status === 'success') {
                    const d = json.data;
                    if(document.getElementById('prefix') && d['Prefix']) document.getElementById('prefix').value = d['Prefix'];
                    if(document.getElementById('fName')) document.getElementById('fName').value = d['First Name'] || '';
                    if(document.getElementById('mName')) document.getElementById('mName').value = d['Middle Name'] || '';
                    if(document.getElementById('lName')) document.getElementById('lName').value = d['Last Name'] || '';
                    if(document.getElementById('primaryPhone')) document.getElementById('primaryPhone').value = d['Primary Phone'] || '';
                    if(document.getElementById('altPhone')) document.getElementById('altPhone').value = d['Alt Phone'] || '';
                    if(document.getElementById('email')) document.getElementById('email').value = d['Email'] || '';
                    if(document.getElementById('aadhaar')) document.getElementById('aadhaar').value = d['Aadhaar Number'] || '';
                    if(document.getElementById('passport')) document.getElementById('passport').value = d['Passport No'] || '';
                    if(document.getElementById('dest')) document.getElementById('dest').value = d['Destination'] || '';
                    if(document.getElementById('startDate')) document.getElementById('startDate').value = d['Commencement Date'] || '';
                    if(document.getElementById('tier') && d['Tour Tier']) document.getElementById('tier').value = d['Tour Tier'];
                    if(document.getElementById('tourType') && d['Tour Type (Dom/Int)']) document.getElementById('tourType').value = d['Tour Type (Dom/Int)'];
                    if(document.getElementById('adults')) document.getElementById('adults').value = d['Adults'] || '2';
                    if(document.getElementById('child')) document.getElementById('child').value = d['Children'] || '0';
                    if(document.getElementById('rooms')) document.getElementById('rooms').value = d['Rooms'] || '1';
                    if(document.getElementById('resLine1')) document.getElementById('resLine1').value = d['Residential Address'] || '';
                    const permLine1 = document.querySelector('input[name="permLine1"]');
                    if(permLine1) permLine1.value = d['Permanent Address'] || '';
                    const manualTotal = document.querySelector('input[name="manualTotalPaid"]');
                    if(manualTotal) manualTotal.value = d['Total Paid'] || '';
                    const payRef = document.querySelector('input[name="payRef"]');
                    if(payRef) payRef.value = d['Payment Ref ID'] || '';
                    const coupon = document.querySelector('input[name="coupon"]');
                    if(coupon) coupon.value = d['Coupon Used'] || '';
                    const paymentCompleteRadio = document.querySelector('input[name="status"][value="Payment Complete"]');
                    const pendingPaymentRadio = document.querySelector('input[name="status"][value="Pending Payment"]');
                    if (d['Status'] === 'Payment Complete' && paymentCompleteRadio) paymentCompleteRadio.checked = true;
                    else if (d['Status'] === 'Pending Payment' && pendingPaymentRadio) pendingPaymentRadio.checked = true;
                    if(window.updatePosSubmitBtn) window.updatePosSubmitBtn();
                    this.style.borderColor = '#27ae60'; this.style.backgroundColor = '#e8f8f5';
                } else {
                    this.style.borderColor = '#e74c3c'; this.style.backgroundColor = '#fdedec';
                }
            } catch(e) { console.error("Auto-fetch invoice failed:", e); }
        });
    }
});

window.addLocationRow = function() {
    locationCount++;
    const container = document.getElementById('locationsContainer');
    const row = document.createElement('div');
    row.className = 'location-row'; row.id = `locRow_${locationCount}`;
    row.innerHTML = `
        <button type="button" class="remove-loc-btn" onclick="removeLocationRow(${locationCount})"><i class="fa-solid fa-xmark"></i></button>
        <div class="form-grid" style="grid-template-columns: 2fr 1fr 1fr;">
            <div class="input-group"><label>Destination Name</label><input type="text" class="loc-name editable-highlight" required></div>
            <div class="input-group"><label>Date / Duration</label><input type="text" class="loc-date editable-highlight" required></div>
            <div class="input-group"><label>Taxable Amount (₹)</label><input type="number" class="loc-amt editable-highlight" required min="0" value="0" oninput="calculateAdminTotal()"></div>
        </div>
    `;
    container.appendChild(row);
};

window.removeLocationRow = function(id) { document.getElementById(`locRow_${id}`).remove(); calculateAdminTotal(); };

window.calculateAdminTotal = function() {
    let totalTaxable = 0;
    document.querySelectorAll('.loc-amt').forEach(input => totalTaxable += parseFloat(input.value) || 0);
    const gst = totalTaxable * 0.05;
    document.getElementById('displayTotalCost').innerText = `₹ ${fmt(totalTaxable + gst)}`;
    return { taxable: totalTaxable, gst: gst, total: totalTaxable + gst };
};

// 🚀 DYNAMIC TOGGLE: Removes "Required" lock if Pending Payment is selected
window.updatePosSubmitBtn = function() {
    const modeInput = document.querySelector('input[name="status"]:checked') || document.querySelector('input[name="posPaymentMode"]:checked');
    if(!modeInput) return;
    const mode = modeInput.value;
    const btn = document.getElementById('generateBillBtn');
    const payRefInput = document.querySelector('input[name="payRef"]');
    
    if (mode === 'Payment Complete' || mode === 'cash') {
        btn.innerHTML = '<i class="fa-solid fa-file-invoice"></i> Record Cash Payment & Generate Invoice'; 
        btn.style.background = '#27ae60';
        if(payRefInput) payRefInput.required = true;
    } else {
        btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Generate Order & Send Payment Link'; 
        btn.style.background = '#154b9b';
        if(payRefInput) { payRefInput.required = false; payRefInput.value = ''; }
    }
};

document.getElementById('adminPosForm').addEventListener('submit', async (e) => {
    e.preventDefault(); 
    
    if(document.getElementById('hiddenTotalPaid')) {
        document.getElementById('hiddenTotalPaid').value = document.getElementById('displayTotalCost').innerText;
    }

    if(document.getElementById('primaryPhone').value.length !== 10) return alert("Primary Phone must be exactly 10 digits.");
    
    const modeInput = document.querySelector('input[name="status"]:checked') || document.querySelector('input[name="posPaymentMode"]:checked');
    const paymentMode = modeInput ? modeInput.value : 'Payment Complete';
    
    const payRefInput = document.querySelector('input[name="payRef"]');
    
    // 🚀 VALIDATION: Only strictly enforce Payment Ref ID if it is a completed Cash payment
    if ((paymentMode === 'Payment Complete' || paymentMode === 'cash') && payRefInput && payRefInput.value.trim() === "") {
        return alert("Payment Ref ID is strictly required for Cash/Completed payments. Please enter a valid reference.");
    }
    
    const btn = document.getElementById('generateBillBtn');
    const originalBtnText = btn.innerHTML;
    
    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Processing...'; 
    btn.style.pointerEvents = 'none';

    try {
        const getVal = (id) => { const el = document.getElementById(id); return el ? el.value.trim() : ""; };
        
        const math = calculateAdminTotal();
        const timePart = Date.now().toString(36).toUpperCase().slice(-5);
        
        const bookingId = `TRV-POS-${timePart}`; 

        // 🚀 CRITICAL FIX: Sync exact keyword 'PENDING_LINK_SENT' to database so checkout.php unlocks the payment gateway
        let payRefVal = payRefInput ? payRefInput.value.trim() : "";
        if (paymentMode === 'Payment Complete' || paymentMode === 'cash') {
            if (payRefVal === "") {
                payRefVal = "POS-CASH-" + timePart; 
                if(payRefInput) payRefInput.value = payRefVal; 
            }
        } else {
            payRefVal = "PENDING_LINK_SENT"; 
            if(payRefInput) payRefInput.value = ""; 
        }

        const customInvoiceInput = document.querySelector('input[name="invoice"]');
        const customInvoiceVal = customInvoiceInput ? customInvoiceInput.value.trim() : "";
        const finalInvoiceNo = customInvoiceVal !== "" ? customInvoiceVal : `INV-${timePart}POS`;

        let destArray = [];
        document.querySelectorAll('.loc-name').forEach(input => { if (input.value.trim() !== '') destArray.push(input.value.trim()); });
        const combinedDestinations = destArray.join(' + ');

        const guestName = `${getVal('prefix')} ${getVal('fName')} ${getVal('lName')}`.trim();
        const phone = getVal('primaryPhone');
        const email = getVal('email');
        const adults = getVal('adults') || '2';
        const children = getVal('child') || '0';
        const rooms = getVal('rooms') || '1';
        
        const resAddressStr = `${getVal('resLine1')}, ${getVal('resLandmark')}, ${getVal('resCity')}, ${getVal('resState')} - ${getVal('resPin')}`.replace(/,\s*,/g, ',');
        const isSameAsRes = document.getElementById('sameAsResCheck') ? document.getElementById('sameAsResCheck').checked : true;
        const permAddressStr = isSameAsRes ? resAddressStr : `${getVal('permLine1')}, ${getVal('permCity')}, ${getVal('permState')} - ${getVal('permPin')}`;

        const masterPayload = {
            action: 'LEAD_CAPTURE',
            bookingId: bookingId,
            prefix: getVal('prefix'), fName: getVal('fName'), mName: getVal('mName'), lName: getVal('lName'),
            primaryPhone: phone, altPhone: getVal('altPhone'), email: email,
            resAddress: resAddressStr, permAddress: permAddressStr, aadhaar: getVal('aadhaar'),
            passport: getVal('passport'), tourType: getVal('tourType'), destination: combinedDestinations,
            startDate: getVal('startDate'), tier: getVal('tier'), adults: adults, children: children, rooms: rooms, totalAmount: math.total,
            paymentId: payRefVal 
        };

        const fullBackendPayload = {
            bookingId: bookingId,
            prefix: getVal('prefix'), fName: getVal('fName'), mName: getVal('mName'), lName: getVal('lName'), guestName: guestName,
            phone: phone, primaryPhone: phone, altPhone: getVal('altPhone'), email: email,
            aadhaar: getVal('aadhaar'), passport: getVal('passport'), tourType: getVal('tourType'),
            destination: combinedDestinations, startDate: getVal('startDate'), commDate: getVal('startDate'), 
            tier: getVal('tier'), adults: adults, children: children, rooms: rooms, totalAmount: math.total,
            resAddress: resAddressStr, permAddress: permAddressStr,
            paymentId: payRefVal, 
            payRef: payRefVal     
        };

        const triggerPHPBackend = () => {
            const form = document.getElementById('adminPosForm');
            const hiddenPHPTrigger = document.createElement('input');
            hiddenPHPTrigger.type = 'hidden'; hiddenPHPTrigger.name = 'create_pos_booking'; hiddenPHPTrigger.value = '1';
            form.appendChild(hiddenPHPTrigger);

            const hiddenId = document.createElement('input');
            hiddenId.type = 'hidden'; hiddenId.name = 'js_booking_id'; hiddenId.value = bookingId;
            form.appendChild(hiddenId);

            const hiddenPayRef = document.createElement('input');
            hiddenPayRef.type = 'hidden'; hiddenPayRef.name = 'js_pay_ref'; hiddenPayRef.value = payRefVal;
            form.appendChild(hiddenPayRef);

            if (customInvoiceInput && customInvoiceInput.value.trim() === "") {
                customInvoiceInput.value = finalInvoiceNo;
            }
            form.submit(); 
        };

        if (paymentMode === 'Payment Complete' || paymentMode === 'cash') {
            const invoiceBase64 = await buildAndDownloadPDF(bookingId, finalInvoiceNo, guestName, phone, email, getVal('resState'), getVal('tier'), adults, children, rooms, getVal('startDate'), math, payRefVal);
            
            fetch(GOOGLE_SCRIPT_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify(masterPayload) }).then(() => {
                const couponInput = document.querySelector('input[name="coupon"]');
                const markPaidPayload = { action: 'MARK_PAID', bookingId: bookingId, adults: adults, children: children, rooms: rooms, totalAmount: math.total, paymentId: payRefVal, couponUsed: (couponInput ? couponInput.value.trim() : "N/A") };
                fetch(GOOGLE_SCRIPT_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify(markPaidPayload) }).catch(e=>{});
            }).catch(e=>{});

            var xhr = new XMLHttpRequest(); xhr.open("POST", HOSTINGER_MAILER_URL, true); xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = function() {
                window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(`Hi ${getVal('fName')},\n\nWe have successfully received your offline payment of ₹${fmt(math.total)} for Ref: *${bookingId}*.\n\nYour official Tax Invoice has been generated and sent to your email (${email}).\n\n- Traveltara`)}`, '_blank');
                btn.innerHTML = `<i class="fa-solid fa-check-double"></i> Done! Finalizing SQL...`; 
                setTimeout(() => triggerPHPBackend(), 200); 
            };
            
            const finalCashPayload = Object.assign({}, fullBackendPayload, { action: 'HOSTINGER_EMAIL', paymentId: payRefVal, invoicePdf: invoiceBase64 });
            xhr.send(JSON.stringify(finalCashPayload));
        
        } else {
            // 🚀 INJECTED FULL GUEST DATA, EXACT AMOUNT, AND LOCK FLAGS INTO THE PAYLOAD
            const posPayload = { 
                tier: getVal('tier') || 'Customised', a: adults, c: children, r: rooms, 
                date: getVal('startDate') || '', addr: getVal('resLine1') || '', 
                city: getVal('resCity') || '', state: getVal('resState') || 'West Bengal', 
                pin: getVal('resPin') || '',
                fname: getVal('fName') || '', lname: getVal('lName') || '',
                email: getVal('email') || '', phone: getVal('primaryPhone') || '',
                amount: math.total, locked: true 
            };
            const b64Data = btoa(encodeURIComponent(JSON.stringify(posPayload)));
            
            // 🚀 APPENDED EXPLICIT AMOUNT AND LOCK=1 DIRECTLY TO THE URL SO THE CHECKOUT PAGE CATCHES IT
            const payLink = `https://traveltara.com/checkout.php?ref=${bookingId}&dest=${encodeURIComponent(combinedDestinations)}&amt=${math.total}&lock=1&p=${b64Data}`;

            // 🚀 SILENT URL SHORTENER EXCLUSIVELY FOR WHATSAPP
            let shortPayLink = payLink;
            try {
                const shortRes = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(payLink)}`);
                if (shortRes.ok) {
                    shortPayLink = await shortRes.text();
                }
            } catch (e) {
                console.warn("Shortener API failed, falling back to full link.");
            }

            masterPayload.paymentId = "PENDING_LINK_SENT";
            fetch(GOOGLE_SCRIPT_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify(masterPayload) }).catch(e=>{});
            
            var xhr = new XMLHttpRequest(); xhr.open("POST", HOSTINGER_MAILER_URL, true); xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = function() {
                window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(`Hi ${getVal('fName')},\n\nYour bespoke itinerary is ready!\n\nRef: *${bookingId}*\nTotal: *₹${fmt(math.total)}*\n\nTo secure your reservation, please pay via our secure gateway here:\n ${shortPayLink}\n\nOnce paid, your Tax Invoice will be generated automatically.\n\n- Traveltara`)}`, '_blank');
                btn.innerHTML = `<i class="fa-solid fa-check-double"></i> Link Sent! Finalizing SQL...`; 
                setTimeout(() => triggerPHPBackend(), 200); 
            };
            
            const finalLinkPayload = Object.assign({}, fullBackendPayload, { action: 'SEND_PAYMENT_LINK', paymentId: "PENDING_LINK_SENT", payloadStr: b64Data });
            xhr.send(JSON.stringify(finalLinkPayload));
        }
    } catch (error) {
        alert("Server error. Please try again."); btn.innerHTML = originalBtnText; btn.style.pointerEvents = 'auto'; 
    }
});

// PDF Generator Engine (100% UNTOUCHED)
async function buildAndDownloadPDF(bookingId, invoiceNo, gName, gPhone, gEmail, state, tier, adults, children, rooms, sDate, math, payRef) {
    return new Promise((resolve) => {
        const d = new Date(); const formattedDate = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
        let formattedTripDate = sDate ? new Date(sDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : 'TBD';

        document.getElementById('invRealNo').innerText = invoiceNo; document.getElementById('invNo').innerText = bookingId;
        document.getElementById('invDate').innerText = formattedDate; document.getElementById('invDueDate').innerText = formattedDate;
        document.getElementById('invSupplyPlace').innerText = state; document.getElementById('invGuestName').innerText = gName;
        document.getElementById('invGuestPhone').innerText = gPhone; document.getElementById('invGuestEmail').innerText = gEmail;
        document.getElementById('invGuestAddress').innerText = document.getElementById('resLine1') ? document.getElementById('resLine1').value : "Address on File";
        document.getElementById('invGuestState').innerText = state; document.getElementById('invTravelDate').innerText = formattedTripDate;
        document.getElementById('invTier').innerText = tier; document.getElementById('invPax').innerText = `${adults} Adults, ${children} Children`;
        document.getElementById('invRooms').innerText = `${rooms} Room(s)`;
        
        document.getElementById('invPaymentId').innerText = payRef || "OFFLINE_POS";

        const isLocal = state.toLowerCase().includes('west bengal') || state.toLowerCase().includes('wb');
        let totalCgst = 0, totalSgst = 0, totalIgst = 0;
        const tbody = document.getElementById('invTableBody'); tbody.innerHTML = ''; 
        let firstPkgName = "Custom Package";
        document.querySelectorAll('.location-row').forEach((row, index) => {
            const name = row.querySelector('.loc-name').value || 'Service'; const taxableAmt = parseFloat(row.querySelector('.loc-amt').value) || 0;
            if (index === 0) firstPkgName = name;
            let rowCgst = 0, rowSgst = 0, rowIgst = 0;
            if (isLocal) { rowCgst = taxableAmt * 0.025; rowSgst = taxableAmt * 0.025; totalCgst += rowCgst; totalSgst += rowSgst; } else { rowIgst = taxableAmt * 0.05; totalIgst += rowIgst; }
            const tr = document.createElement('tr');
            tr.innerHTML = `<td style="padding: 10px; border: 1px solid #ddd;">${name}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: center;">9985</td><td style="padding: 10px; border: 1px solid #ddd; text-align: center;">1</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${fmt(taxableAmt)}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${fmt(taxableAmt)}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${isLocal ? fmt(rowCgst) : "0.00"}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${isLocal ? fmt(rowSgst) : "0.00"}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${!isLocal ? fmt(rowIgst) : "0.00"}</td><td style="padding: 10px; border: 1px solid #ddd; text-align: right; font-weight: bold;">${fmt(taxableAmt + rowCgst + rowSgst + rowIgst)}</td>`;
            tbody.appendChild(tr);
        });

        document.getElementById('invPackage').innerText = document.querySelectorAll('.location-row').length > 1 ? `${firstPkgName} (+${document.querySelectorAll('.location-row').length - 1} more)` : firstPkgName;
        document.getElementById('invSumTaxable').innerText = "₹ " + fmt(math.taxable); document.getElementById('invSumCgst').innerText = isLocal ? "₹ " + fmt(totalCgst) : "₹ 0.00";
        document.getElementById('invSumSgst').innerText = isLocal ? "₹ " + fmt(totalSgst) : "₹ 0.00"; document.getElementById('invSumIgst').innerText = !isLocal ? "₹ " + fmt(totalIgst) : "₹ 0.00";
        document.getElementById('invSumGrand').innerText = "₹ " + fmt(math.total);
        
        function numberToWords(num) {
            const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
            const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
            if ((num = num.toString()).length > 9) return 'Overflow';
            const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
            if (!n) return ''; let str = '';
            str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : ''; str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
            str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : ''; str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
            str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'Only' : 'Only'; return str;
        }
        document.getElementById('invWordsText').innerText = "Rupees " + numberToWords(Math.round(math.total));

        const element = document.getElementById('traveltaraInvoice');
        const container = document.getElementById('invoicePrintContainer');
        
        container.style.display = 'block'; container.style.position = 'absolute'; container.style.top = '0'; container.style.left = '0'; container.style.zIndex = '-9999';

        setTimeout(() => {
            const opt = { margin: 0, filename: `${invoiceNo}.pdf`, image: { type: 'jpeg', quality: 1 }, html2canvas: { scale: 3, useCORS: true, windowWidth: 800, x: 0, y: 0, scrollY: 0 }, jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait', compress: true } };
            if (window.html2pdf) {
                const worker = html2pdf().set(opt).from(element);
                worker.save().then(() => {
                    worker.outputPdf('datauristring').then(function(pdfAsString) { container.style.display = 'none'; resolve(pdfAsString.split(',')[1]); });
                }).catch((err) => { container.style.display = 'none'; resolve(""); });
            } else { container.style.display = 'none'; resolve(""); }
        }, 150); 
    });
}