// =======================================================
// MASTER CHECKOUT.JS (AGGRESSIVE MATCHING ENGINE - HIGH SPEED)
// =======================================================

const HOSTINGER_API_URL = "process_leads.php";
const HOSTINGER_MAILER_URL = "process_checkout.php"; 

let packageBasePrices = { "Budget": 0, "Affordable Luxury": 0, "Super Luxury": 0 };
let appliedDiscountPercent = 0; 
let activeCouponCode = "";

window.calculatePricing = function() {
    let savedTier = sessionStorage.getItem('tara_tour_tier') || "";
    savedTier = savedTier.trim(); // 🔥 Strip invisible spaces
    
    const pricingSection = document.getElementById('pricingSection');
    const displayTotal = document.getElementById('displayTotalCost');
    
    if (sessionStorage.getItem('tara_is_locked_link') === 'true' || sessionStorage.getItem('tara_payment_complete') === 'true') return;

    if (!savedTier || savedTier.toLowerCase() === "customised") { 
        if(pricingSection) pricingSection.classList.add('hidden-section'); 
        return; 
    }

    // 🔥 Force an exact tier match regardless of spacing/capitalization
    let ppa = 0;
    for (let key in packageBasePrices) {
        if (key.trim().toLowerCase() === savedTier.toLowerCase()) {
            ppa = parseFloat(packageBasePrices[key]) || 0;
        }
    }
    
    if (ppa === 0) return; 
    
    if(pricingSection) pricingSection.classList.remove('hidden-section');

    const adults = parseInt(document.getElementById('adults').value) || 1;
    const children = parseInt(document.getElementById('child').value) || 0;
    
    const minRooms = Math.ceil((adults + (children / 4)) / 2) || 1;
    document.getElementById('rooms').setAttribute('min', minRooms);
    
    let currentRooms = parseInt(document.getElementById('rooms').value) || 1;
    if (currentRooms < minRooms) { 
        currentRooms = minRooms; 
        document.getElementById('rooms').value = currentRooms; 
    }

    const grandTotal = (adults * ppa) + (children * (ppa * 0.75)) + ((currentRooms - minRooms) * (ppa * 0.25));
    const finalPayable = grandTotal - (grandTotal * (appliedDiscountPercent / 100));

    if (displayTotal) {
        if (appliedDiscountPercent > 0) {
            displayTotal.innerHTML = `<span style="text-decoration:line-through; font-size: 14px; color: #888;">₹ ${grandTotal.toLocaleString('en-IN')}</span> <br> ₹ ${finalPayable.toLocaleString('en-IN')}`;
        } else {
            displayTotal.innerText = "₹ " + finalPayable.toLocaleString('en-IN');
        }
    }
    sessionStorage.setItem('tara_total_price', finalPayable);
};

window.updateCount = function(id, delta) {
    const input = document.getElementById(id); 
    if(!input) return;
    let currentVal = parseInt(input.value) || 0; 
    let minVal = parseInt(input.getAttribute('min')) || 0;
    if(currentVal + delta >= minVal) { 
        input.value = currentVal + delta; 
        calculatePricing(); 
    }
};

document.addEventListener('DOMContentLoaded', async () => {
    
    const urlParams = new URLSearchParams(window.location.search);
    const payRef = urlParams.get('ref');
    const payDest = urlParams.get('dest') || "Bespoke Itinerary";
    const payloadStr = urlParams.get('p');

    // ==========================================================
    // SCENARIO A: SECURE PAYMENT LOCK LOGIC
    // ==========================================================
    if (payRef) {
        sessionStorage.setItem('tara_is_locked_link', 'true');
        
        let pData = { tier: 'Customised', a: '2', c: '0', r: '1', date: 'TBD', addr: '', city: '', state: 'West Bengal', pin: '' };
        if (payloadStr) { 
            try { pData = JSON.parse(decodeURIComponent(atob(payloadStr))); } catch(e) {} 
        }

        if(document.getElementById('checkoutBookingId')) document.getElementById('checkoutBookingId').innerText = payRef;
        if(document.getElementById('chkPackage')) document.getElementById('chkPackage').value = payDest;
        if(document.getElementById('chkTier')) document.getElementById('chkTier').value = pData.tier;
        if(document.getElementById('adults')) document.getElementById('adults').value = pData.a;
        if(document.getElementById('child')) document.getElementById('child').value = pData.c;
        if(document.getElementById('rooms')) document.getElementById('rooms').value = pData.r;

        const partyGrid = document.querySelector('.party-grid');
        if(partyGrid) { partyGrid.style.pointerEvents = 'none'; partyGrid.style.opacity = '0.7'; }
        document.querySelectorAll('.counter-btn').forEach(btn => btn.style.display = 'none');
        const discountBox = document.querySelector('.discount-container');
        if(discountBox) discountBox.style.display = 'none';

        const proceedBtn = document.getElementById('proceedPaymentBtn');
        if (proceedBtn) { 
            proceedBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Verifying Secure Link...'; 
            proceedBtn.style.pointerEvents = 'none'; 
        }

        try {
            let res = await fetch(HOSTINGER_MAILER_URL, { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' }, 
                body: JSON.stringify({ action: 'VERIFY_PAYMENT_LINK', bookingId: payRef }) 
            });
            let data = await res.json();

            if (data.status === 'success' && proceedBtn) {
                if (data.payment_id !== 'PENDING_LINK_SENT') {
                    proceedBtn.innerHTML = '<i class="fa-solid fa-lock"></i> Link Expired / Already Paid';
                    proceedBtn.style.background = '#888'; 
                    proceedBtn.style.color = '#fff';
                } else {
                    // 🚀 CRITICAL FIX: Clean the amount from the database (removes ₹ and commas) to prevent NaN math errors
                    const urlAmt = new URLSearchParams(window.location.search).get('amt');
                    const cleanAmount = urlAmt ? parseFloat(urlAmt) : parseFloat(String(data.amount).replace(/[^0-9.]/g, ''));

                    sessionStorage.setItem('tara_booking_id', payRef);
                    sessionStorage.setItem('tara_total_price', cleanAmount);
                    sessionStorage.setItem('tara_guest_name', data.guestName);
                    sessionStorage.setItem('tara_guest_email', data.email);
                    sessionStorage.setItem('tara_guest_phone', data.phone);
                    sessionStorage.setItem('tara_package_name', payDest);
                    sessionStorage.setItem('tara_tour_tier', pData.tier);
                    sessionStorage.setItem('tara_start_date', pData.date);
                    sessionStorage.setItem('tara_res_address', pData.addr);
                    sessionStorage.setItem('tara_guest_city', pData.city);
                    sessionStorage.setItem('tara_state', pData.state);
                    sessionStorage.setItem('tara_pincode', pData.pin);

                    const formStart = document.getElementById('checkoutForm');
                    const summaryDiv = document.createElement('div');
                    summaryDiv.className = 'checkout-form-section';
                    summaryDiv.style.background = '#fdfbf7';
                    summaryDiv.style.border = '1px solid #C5A059';
                    summaryDiv.innerHTML = `
                        <h2 class="checkout-section-title" style="color: #0A1128;"><i class="fa-solid fa-user-shield"></i> Verified Guest Details</h2>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; font-size: 14px; color: #444;">
                            <div><strong>Name:</strong> ${data.guestName}</div>
                            <div><strong>Phone:</strong> ${data.phone}</div>
                            <div><strong>Email:</strong> ${data.email}</div>
                            <div><strong>Travel Date:</strong> ${pData.date || 'TBD'}</div>
                            <div style="grid-column: 1 / -1;"><strong>Address:</strong> ${pData.addr}, ${pData.city}, ${pData.state} - ${pData.pin}</div>
                        </div>
                        <div style="margin-top: 15px; padding-top: 10px; border-top: 1px dashed #ccc; font-size: 13px; color: #27ae60; font-weight: bold;">
                            <i class="fa-solid fa-lock"></i> Details Locked by Admin. Please agree to the terms below to pay.
                        </div>
                    `;
                    formStart.insertBefore(summaryDiv, formStart.firstChild);

                    const pricingSec = document.getElementById('pricingSection'); 
                    if (pricingSec) pricingSec.classList.remove('hidden-section');
                    const displayTotal = document.getElementById('displayTotalCost'); 
                    if (displayTotal) displayTotal.innerText = `₹ ${cleanAmount.toLocaleString('en-IN')}`;
                    
                    proceedBtn.innerHTML = `Pay Securely: ₹ ${cleanAmount.toLocaleString('en-IN')}`;
                    proceedBtn.style.pointerEvents = 'auto'; 
                }
            } else if (proceedBtn) {
                proceedBtn.innerHTML = '<i class="fa-solid fa-link-slash"></i> Link Invalid or Not Found';
            }
        } catch (e) {
            if (proceedBtn) proceedBtn.innerHTML = '<i class="fa-solid fa-wifi"></i> Verification Failed. Please reload.';
        }
        
        window.calculatePricing = function() {}; 
        initCheckoutFormListeners(); 
        return; 
    }

    // ==========================================================
    // SCENARIO B: REGULAR CHECKOUT LOGIC
    // ==========================================================
    sessionStorage.setItem('tara_is_locked_link', 'false'); 

    const savedPackageName = sessionStorage.getItem('tara_package_name') || "Custom Trip";
    const savedBookingId = sessionStorage.getItem('tara_booking_id');
    const savedTier = sessionStorage.getItem('tara_tour_tier') || "Customised";
    
    const displayId = savedBookingId || "TRV-" + Math.random().toString(36).substr(2, 6).toUpperCase();

    if(document.getElementById('checkoutBookingId')) document.getElementById('checkoutBookingId').innerText = displayId;
    if(document.getElementById('chkPackage')) document.getElementById('chkPackage').value = savedPackageName;
    if(document.getElementById('chkTier')) document.getElementById('chkTier').value = savedTier;

    const proceedBtn = document.getElementById('proceedPaymentBtn');

    if (savedBookingId && proceedBtn) {
        try {
            let verifyRes = await fetch(HOSTINGER_MAILER_URL, { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' }, 
                body: JSON.stringify({ action: 'VERIFY_PAYMENT_LINK', bookingId: savedBookingId }) 
            });
            let verifyData = await verifyRes.json();
            
            const pId = verifyData.payment_id ? String(verifyData.payment_id).trim() : '';
            if (verifyData.status === 'success' && pId !== '' && pId !== 'PENDING' && pId !== 'PENDING_LINK_SENT' && pId !== 'null') {
                proceedBtn.innerHTML = '<i class="fa-solid fa-lock"></i> Session Paid / Completed';
                proceedBtn.style.background = '#888'; 
                proceedBtn.style.color = '#fff';
                proceedBtn.style.pointerEvents = 'none';
                sessionStorage.setItem('tara_payment_complete', 'true');
                
                const partyGrid = document.querySelector('.party-grid');
                if(partyGrid) { partyGrid.style.pointerEvents = 'none'; partyGrid.style.opacity = '0.7'; }
                document.querySelectorAll('.counter-btn').forEach(btn => btn.style.display = 'none');
                const discountBox = document.querySelector('.discount-container');
                if(discountBox) discountBox.style.display = 'none';
                
                window.calculatePricing = function() {}; 
                return; 
            }
        } catch (e) {
            console.warn("Could not verify past payment status.");
        }
    }

    // 🚀 PULL PRICING FROM HOSTINGER (AGGRESSIVE MATCHING)
    try {
        let response = await fetch(`${HOSTINGER_API_URL}?action=getPricing`);
        let masterPricingList = await response.json();
        
        // Clean the session name
        let cleanSessionName = savedPackageName.trim().toLowerCase();
        
        // Loop through the database keys and look for a normalized match
        for (let dbPackageName in masterPricingList) {
            if (dbPackageName.trim().toLowerCase() === cleanSessionName) {
                packageBasePrices = masterPricingList[dbPackageName];
                break;
            }
        }
    } catch (e) {
        console.warn("Could not fetch pricing data.");
    }

    calculatePricing();

    const couponBtn = document.getElementById('applyCouponBtn');
    if (couponBtn) {
        couponBtn.addEventListener('click', async () => {
            const code = document.getElementById('couponInput').value.trim().toUpperCase();
            if (!code) return; 
            couponBtn.innerText = "Wait..."; 
            couponBtn.style.pointerEvents = "none";
            
            try {
                let response = await fetch(`${HOSTINGER_API_URL}?action=verifyCoupon&code=${code}`);
                let result = await response.json();
                if (result.valid) {
                    appliedDiscountPercent = result.discount; 
                    activeCouponCode = code;
                    document.getElementById('couponMsg').innerText = `Congratulations! ${result.discount}% Discount Applied.`;
                    document.getElementById('couponMsg').style.color = "#27ae60";
                } else {
                    appliedDiscountPercent = 0; 
                    activeCouponCode = "";
                    document.getElementById('couponMsg').innerText = "Invalid Coupon Code or Expired";
                    document.getElementById('couponMsg').style.color = "#e74c3c";
                }
                calculatePricing(); 
            } catch (e) {
                 document.getElementById('couponMsg').innerText = "Validation failed. Please try again.";
            }
            couponBtn.innerText = "APPLY"; 
            couponBtn.style.pointerEvents = "auto";
        });
    }

    initCheckoutFormListeners();
});

function initCheckoutFormListeners() {
    const tncCheck = document.getElementById('tncCheck');
    const tncModal = document.getElementById('tncModal');
    const agreeBtn = document.getElementById('agreeBtn');
    const scrollArea = document.getElementById('tncScrollArea');
    const openTncText = document.getElementById('openTncText');
    const closeModalBtn = document.getElementById('closeModalBtn');

    if(tncCheck && tncModal) {
        function openLegalModal(e) {
            if (!tncCheck.checked) {
                e.preventDefault(); 
                tncModal.style.display = 'flex'; 
                if(scrollArea) scrollArea.scrollTop = 0;
                if (agreeBtn) { 
                    agreeBtn.classList.remove('unlocked'); 
                    agreeBtn.disabled = true; 
                    agreeBtn.innerText = "Scroll down to Agree"; 
                }
            }
        }
        tncCheck.addEventListener('click', openLegalModal);
        if (openTncText) openTncText.addEventListener('click', openLegalModal);
        if (closeModalBtn) closeModalBtn.addEventListener('click', () => { tncModal.style.display = 'none'; });
        if (scrollArea && agreeBtn) {
            scrollArea.addEventListener('scroll', () => {
                if (scrollArea.scrollTop + scrollArea.clientHeight >= scrollArea.scrollHeight - 10) {
                    agreeBtn.classList.add('unlocked'); 
                    agreeBtn.disabled = false; 
                    agreeBtn.innerHTML = '<i class="fa-solid fa-check"></i> I Agree to All Policies';
                }
            });
            agreeBtn.addEventListener('click', () => { 
                tncCheck.checked = true; 
                tncModal.style.display = 'none'; 
            });
        }
    }

    const checkoutForm = document.getElementById('checkoutForm');
    const proceedBtn = document.getElementById('proceedPaymentBtn');

    if (checkoutForm && proceedBtn) {
       checkoutForm.addEventListener('submit', async (e) => {
            e.preventDefault(); 
            if (tncCheck && !tncCheck.checked) {
                return alert("Please agree to the Terms & Policies first.");
            }
            
            const originalBtnText = proceedBtn.innerHTML;
            proceedBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Initializing Gateway...';
            proceedBtn.style.pointerEvents = 'none'; 
            
            const finalAmt = parseInt(sessionStorage.getItem('tara_total_price'));
            if (isNaN(finalAmt) || finalAmt < 1) {
                alert("Invalid amount. Session expired or pricing error. Please try booking again.");
                proceedBtn.innerHTML = originalBtnText; 
                proceedBtn.style.pointerEvents = 'auto'; 
                return;
            }
            
            const amountInPaise = finalAmt * 100; 
            const bookingId = sessionStorage.getItem('tara_booking_id') || 'TRV-XXXXXX';
            const guestName = sessionStorage.getItem('tara_guest_name') || 'Valued Guest';
            const guestEmail = sessionStorage.getItem('tara_guest_email') || '';
            const phone = sessionStorage.getItem('tara_guest_phone') || '';

            let orderData;
            try {
                const orderResponse = await fetch(`${HOSTINGER_API_URL}?action=createOrder&amount=${amountInPaise}`);
                orderData = await orderResponse.json();
                if(orderData.error) throw new Error(orderData.error.description || "Razorpay API Error");
                if(!orderData.id) throw new Error("Invalid Razorpay Keys in process_leads.php");
            } catch (err) {
                alert("Gateway Error: " + err.message);
                proceedBtn.innerHTML = originalBtnText; 
                proceedBtn.style.pointerEvents = 'auto'; 
                return;
            }

            var options = {
                "key": "rzp_live_SfkS8TnfvHiudv", 
                "amount": amountInPaise, 
                "currency": "INR", 
                "name": "Traveltara", 
                "description": "Secure Tour Booking: " + bookingId, 
                "order_id": orderData.id, 
                "prefill": { "name": guestName, "email": guestEmail, "contact": phone }, 
                "theme": { "color": "#0A1128" },
                "handler": async function (response) {
                    proceedBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Securing Booking & Generating Invoice...';
                    try {
                        const invTimePart = Date.now().toString(36).toUpperCase().slice(-5);
                        const invRandPart = Math.random().toString(36).toUpperCase().slice(2, 5);
                        const generatedInvoiceNo = `INV-${invTimePart}${invRandPart}`;
                        
                        const realPaymentId = response.razorpay_payment_id;
                        const invoiceBase64 = await generateInvoicePDF(finalAmt, realPaymentId, generatedInvoiceNo);
                        
                        sessionStorage.setItem('tara_payment_complete', 'true');
                        
                        try {
                            await fetch(HOSTINGER_API_URL, { 
                                method: 'POST', 
                                headers: { 'Content-Type': 'application/json' }, 
                                body: JSON.stringify({ 
                                    action: 'MARK_PAID', 
                                    bookingId: bookingId, 
                                    adults: document.getElementById('adults') ? document.getElementById('adults').value : '2',
                                    children: document.getElementById('child') ? document.getElementById('child').value : '0',
                                    rooms: document.getElementById('rooms') ? document.getElementById('rooms').value : '1',
                                    totalPaid: finalAmt, 
                                    paymentRef: realPaymentId,
                                    invoiceNo: generatedInvoiceNo,
                                    couponUsed: activeCouponCode,
                                    status: 'Payment Complete'
                                }) 
                            });
                        } catch(e) {
                            console.warn("Database Sync delayed.");
                        }

                        var xhr = new XMLHttpRequest(); 
                        xhr.open("POST", HOSTINGER_MAILER_URL, true); 
                        xhr.setRequestHeader("Content-Type", "application/json");
                        xhr.onload = function() {
                            proceedBtn.style.background = '#27ae60'; 
                            proceedBtn.style.color = '#fff'; 
                            proceedBtn.innerHTML = `<i class="fa-solid fa-shield-check"></i> Booking Confirmed!`;
                            // 🔥 SPEED FIX: Reduced from 1500ms to 400ms for a snappy transition
                            setTimeout(() => { window.location.href = "success.php"; }, 400);
                        };
                        xhr.onerror = function() { window.location.href = "success.php"; };
                        xhr.send(JSON.stringify({ 
                            action: 'HOSTINGER_EMAIL', 
                            bookingId: bookingId, 
                            email: guestEmail, 
                            guestName: guestName, 
                            phone: phone, 
                            totalAmount: finalAmt, 
                            paymentId: realPaymentId, 
                            invoicePdf: invoiceBase64 
                        }));

                    } catch (err) { 
                        window.location.href = "success.php"; 
                    }
                }
            };
            
            if (window.Razorpay) {
                var rzp1 = new window.Razorpay(options);
                rzp1.on('payment.failed', function (res){ 
                    alert("Payment Failed or Cancelled"); 
                    proceedBtn.innerHTML = originalBtnText; 
                    proceedBtn.style.pointerEvents = 'auto'; 
                });
                rzp1.open();
            } else {
                alert("Payment Gateway Failed to Load. Check connection.");
                proceedBtn.innerHTML = originalBtnText; 
                proceedBtn.style.pointerEvents = 'auto';
            }
        });
    }
}

// --- GENERATE INVOICE PDF ---
async function generateInvoicePDF(finalGrandTotal, razorpayPaymentId, generatedInvoiceNo) {
    return new Promise((resolve) => {
        const getSessionData = (keysArray) => { 
            for(let key of keysArray) { 
                let val = sessionStorage.getItem(key); 
                if (val && val.trim() !== '') return val.trim(); 
            } 
            return ''; 
        };
        
        const bookingId = sessionStorage.getItem('tara_booking_id') || 'TRV-XXXXX';
        const pkgName = sessionStorage.getItem('tara_package_name') || 'Custom Journey';
        const tier = sessionStorage.getItem('tara_tour_tier') || 'Standard';
        const guestName = getSessionData(['tara_guest_name', 'guest_name', 'name']) || 'Valued Guest';
        const guestPhone = getSessionData(['tara_guest_phone', 'tara_phone', 'phone']) || 'N/A';
        const guestEmail = getSessionData(['tara_guest_email', 'tara_email', 'email']) || 'N/A';

        const adults = document.getElementById('adults') ? document.getElementById('adults').value : '2';
        const kids = document.getElementById('child') ? document.getElementById('child').value : '0';
        const rooms = document.getElementById('rooms') ? document.getElementById('rooms').value : '1';

        const rawResAddr = getSessionData(['tara_res_address', 'tara_resAddress', 'resAddress', 'address', 'tara_guest_address']);
        const rawCity = getSessionData(['tara_city', 'tara_guest_city', 'city']);
        const guestState = getSessionData(['tara_state', 'tara_guest_state', 'state']) || 'West Bengal';
        const rawZip = getSessionData(['tara_pincode', 'tara_guest_pincode', 'pincode', 'zip', 'tara_zip']);

        const addressParts = [rawResAddr, rawCity, guestState, rawZip].filter(item => item !== '');
        const finalGuestAddress = addressParts.length > 0 ? addressParts.join(', ') : 'Address Not Provided';

        const grandTotal = parseFloat(finalGrandTotal);
        const taxableValue = grandTotal / 1.05; 
        
        let cgst = 0, sgst = 0, igst = 0;
        const isLocal = guestState.toLowerCase().includes('west bengal') || guestState.toLowerCase().includes('wb');
        if (isLocal) { 
            cgst = taxableValue * 0.025; 
            sgst = taxableValue * 0.025; 
        } else { 
            igst = taxableValue * 0.05; 
        }

        const today = new Date();
        const formattedDate = today.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
        const rawTripDate = sessionStorage.getItem('tara_start_date');
        let formattedTripDate = 'Not Selected';
        if (rawTripDate && rawTripDate.trim() !== '') {
            formattedTripDate = new Date(rawTripDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
        }

        if(document.getElementById('invRealNo')) document.getElementById('invRealNo').innerText = generatedInvoiceNo;
        if(document.getElementById('invNo')) document.getElementById('invNo').innerText = bookingId;
        if(document.getElementById('invDate')) document.getElementById('invDate').innerText = formattedDate;
        if(document.getElementById('invDueDate')) document.getElementById('invDueDate').innerText = formattedDate; 
        if(document.getElementById('invPaymentId')) document.getElementById('invPaymentId').innerText = razorpayPaymentId;
        if(document.getElementById('invSupplyPlace')) document.getElementById('invSupplyPlace').innerText = guestState;
        if(document.getElementById('invGuestName')) document.getElementById('invGuestName').innerText = guestName;
        if(document.getElementById('invGuestPhone')) document.getElementById('invGuestPhone').innerText = guestPhone;
        if(document.getElementById('invGuestEmail')) document.getElementById('invGuestEmail').innerText = guestEmail;
        if(document.getElementById('invGuestAddress')) document.getElementById('invGuestAddress').innerText = finalGuestAddress;
        if(document.getElementById('invGuestState')) document.getElementById('invGuestState').innerText = guestState;
        if(document.getElementById('invPackage')) document.getElementById('invPackage').innerText = pkgName;
        if(document.getElementById('invTravelDate')) document.getElementById('invTravelDate').innerText = formattedTripDate;
        if(document.getElementById('invTier')) document.getElementById('invTier').innerText = tier;
        if(document.getElementById('invPax')) document.getElementById('invPax').innerText = `${adults} Adults, ${kids} Children`;
        if(document.getElementById('invRooms')) document.getElementById('invRooms').innerText = `${rooms} Room(s)`;
        
        const fmt = (num) => num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        if(document.getElementById('invRowUnit')) document.getElementById('invRowUnit').innerText = fmt(taxableValue);
        if(document.getElementById('invRowTaxable')) document.getElementById('invRowTaxable').innerText = fmt(taxableValue);
        if(document.getElementById('invRowTotal')) document.getElementById('invRowTotal').innerText = fmt(grandTotal);
        if(document.getElementById('invSumTaxable')) document.getElementById('invSumTaxable').innerText = "₹ " + fmt(taxableValue);
        if(document.getElementById('invSumGrand')) document.getElementById('invSumGrand').innerText = "₹ " + fmt(grandTotal);
        if(document.getElementById('invRowCgst')) document.getElementById('invRowCgst').innerText = isLocal ? fmt(cgst) : "0.00";
        if(document.getElementById('invRowSgst')) document.getElementById('invRowSgst').innerText = isLocal ? fmt(sgst) : "0.00";
        if(document.getElementById('invRowIgst')) document.getElementById('invRowIgst').innerText = !isLocal ? fmt(igst) : "0.00";
        
        function numberToWords(num) {
            const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
            const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
            if ((num = num.toString()).length > 9) return 'Overflow';
            const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
            if (!n) return ''; 
            let str = '';
            str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
            str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
            str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
            str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
            str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'Only' : 'Only';
            return str;
        }
        if(document.getElementById('invWordsText')) document.getElementById('invWordsText').innerText = "Rupees " + numberToWords(Math.round(grandTotal));

        const element = document.getElementById('traveltaraInvoice');
        const container = document.getElementById('invoicePrintContainer');
        if (!element || !container) return resolve(""); 

        container.style.display = 'block'; 
        container.style.position = 'absolute'; 
        container.style.top = '0'; 
        container.style.left = '0'; 
        container.style.zIndex = '-9999';

        setTimeout(() => {
            const opt = { 
                margin: 0, 
                filename: `${generatedInvoiceNo}.pdf`, 
                image: { type: 'jpeg', quality: 1 }, 
                html2canvas: { 
                    scale: 3, 
                    useCORS: true, 
                    windowWidth: 800,
                    x: 0,
                    y: 0,
                    scrollY: 0
                }, 
                jsPDF: { 
                    unit: 'pt', 
                    format: 'a4', 
                    orientation: 'portrait',
                    compress: true 
                } 
            };

            if (window.html2pdf) {
                const worker = html2pdf().set(opt).from(element);
                worker.save().then(() => {
                    worker.outputPdf('datauristring').then(function(pdfAsString) {
                        container.style.display = 'none'; 
                        resolve(pdfAsString.split(',')[1]);
                    });
                }).catch((err) => { 
                    container.style.display = 'none'; 
                    resolve(""); 
                });
            } else { 
                container.style.display = 'none'; 
                resolve(""); 
            }
        }, 150); 
    });
}