let revChart, locChart;
const API_URL = "admin_analytics.php"; // Hostinger endpoint

const fmt = (num) => "₹ " + num.toLocaleString('en-IN', { maximumFractionDigits: 0 });

async function loadDashboardData() {
    const range = document.getElementById('timeRangeFilter').value;
    
    try {
        const response = await fetch(`${API_URL}?range=${range}`);
        const data = await response.json();
        
        // 1. Render Top Cards
        const gross = parseFloat(data.gross_revenue) || 0;
        const expenses = gross * 0.75; // Assumed 75% operational expense
        const profit = gross * 0.25;   // Assumed 25% margin
        
        document.getElementById('valRevenue').innerText = fmt(gross);
        document.getElementById('valExpenses').innerText = fmt(expenses);
        document.getElementById('valProfit').innerText = fmt(profit);
        
        if (data.destinations.length > 0) {
            document.getElementById('valTopDest').innerText = data.destinations[0].Destination;
        } else {
            document.getElementById('valTopDest').innerText = "No Data";
        }

        // 2. Render Revenue Line Chart
        const labels = data.timeline.map(item => item.Date);
        const amounts = data.timeline.map(item => item.DailyTotal);
        
        if(revChart) revChart.destroy();
        const ctxRev = document.getElementById('revenueChart').getContext('2d');
        revChart = new Chart(ctxRev, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Daily Revenue (₹)',
                    data: amounts,
                    borderColor: '#C5A059',
                    backgroundColor: 'rgba(197, 160, 89, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4 // Smooth curves
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });

        // 3. Render Location Pie Chart
        const locLabels = data.locations.map(item => item.State.trim() || "Unknown");
        const locCounts = data.locations.map(item => item.Count);
        
        if(locChart) locChart.destroy();
        const ctxLoc = document.getElementById('locationChart').getContext('2d');
        locChart = new Chart(ctxLoc, {
            type: 'doughnut',
            data: {
                labels: locLabels,
                datasets: [{
                    data: locCounts,
                    backgroundColor: ['#0A1128', '#C5A059', '#27ae60', '#e74c3c', '#8e44ad'],
                    borderWidth: 0
                }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right' } } }
        });

        // 4. Generate AI Forecast & Suggestions
        generateForecast(data);

    } catch (err) {
        console.error("Dashboard Failed to Load:", err);
    }
}

function generateForecast(data) {
    const container = document.getElementById('aiForecastContainer');
    
    // Insufficient Data Fallback
    if(data.timeline.length < 3) {
        container.innerHTML = `<div class="tip-item">Not enough data points in this timeframe to generate an accurate forecast. Let the system collect more bookings.</div>`;
        return;
    }

    // Math: Calculate Trend (Comparing first half of timeframe to second half)
    const midPoint = Math.floor(data.timeline.length / 2);
    let firstHalfSum = 0, secondHalfSum = 0;
    
    for(let i = 0; i < midPoint; i++) firstHalfSum += parseFloat(data.timeline[i].DailyTotal);
    for(let i = midPoint; i < data.timeline.length; i++) secondHalfSum += parseFloat(data.timeline[i].DailyTotal);

    const isGrowing = secondHalfSum >= firstHalfSum;
    const growthRate = firstHalfSum === 0 ? 0 : ((secondHalfSum - firstHalfSum) / firstHalfSum);
    
    // Project next 30 days based on recent trajectory
    const dailyAvg = (firstHalfSum + secondHalfSum) / data.timeline.length;
    const projected30Days = (dailyAvg * 30) * (1 + (growthRate * 0.5)); // conservative projection

    let html = ``;

    // Box 1: Revenue Projection
    html += `
    <div class="tip-item">
        <h4 style="margin:0 0 5px 0; color:#C5A059;">Projected 30-Day Revenue</h4>
        <div style="font-size: 20px; font-weight: bold;">${fmt(Math.max(0, projected30Days))}</div>
        <p style="margin: 5px 0 0 0; font-size: 13px;">Based on current volume trajectory.</p>
    </div>`;

    // Box 2: Downfall / Growth Analysis
    if (isGrowing) {
        html += `
        <div class="tip-item">
            <h4 style="margin:0 0 5px 0; color:#C5A059;"><i class="fa-solid fa-arrow-trend-up"></i> Momentum Positive</h4>
            <p style="margin: 0; font-size: 13px;">Sales momentum is increasing by approx ${(growthRate*100).toFixed(1)}%. Continue current marketing efforts.</p>
        </div>`;
    } else {
        html += `
        <div class="tip-item warning">
            <h4 style="margin:0 0 5px 0; color:#e74c3c;"><i class="fa-solid fa-arrow-trend-down"></i> Warning: Downfall Detected</h4>
            <p style="margin: 0; font-size: 13px;">Recent volume is down ${(Math.abs(growthRate)*100).toFixed(1)}%. If nothing improves, projected revenue may drop below ${fmt(secondHalfSum * 2)}. Action required.</p>
        </div>`;
    }

    // Box 3: Focus Area (Weakest Package)
    if(data.destinations.length > 1) {
        const weakest = data.destinations[data.destinations.length - 1].Destination;
        html += `
        <div class="tip-item warning">
            <h4 style="margin:0 0 5px 0; color:#e74c3c;">Needs Focus</h4>
            <p style="margin: 0; font-size: 13px;"><b>${weakest}</b> is underperforming. Consider creating a targeted promotion or adjusting the pricing tier.</p>
        </div>`;
    }

    container.innerHTML = html;
}

// Load default data on start
document.addEventListener('DOMContentLoaded', loadDashboardData);