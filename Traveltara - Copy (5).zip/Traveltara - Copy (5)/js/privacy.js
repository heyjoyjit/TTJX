// =======================================================
// PRIVACY.JS (HISTORY ROUTING LOGIC)
// =======================================================

document.addEventListener('DOMContentLoaded', () => {
    const understandBtn = document.getElementById('understandBtn');

    if (understandBtn) {
        understandBtn.addEventListener('click', () => {
            // Visual feedback
            understandBtn.innerphp = '<i class="fa-solid fa-spinner fa-spin"></i> Returning...';
            understandBtn.style.pointerEvents = 'none';

            setTimeout(() => {
                // Check if the user has a browser history to go back to
                if (window.history.length > 1 && document.referrer !== "") {
                    // Takes them directly back to the checkout or booking form exactly as they left it
                    window.history.back();
                } else {
                    // Fallback: If they opened the policy in a new tab with no history, send them to the homepage
                    window.location.href = "index.php";
                }
            }, 500); // 0.5 second delay for a smooth UI transition
        });
    }
});