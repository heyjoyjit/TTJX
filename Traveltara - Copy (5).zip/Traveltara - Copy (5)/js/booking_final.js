// 🚀 ROUTE DIRECTLY TO HOSTINGER MYSQL DATABASE
const HOSTINGER_API_URL = "process_leads.php";

window.fetchPincodeData = async function(pincode, prefix) {
    const pinInput = document.getElementById(prefix + 'Pin');
    if (pinInput) pinInput.value = pincode.replace(/[^0-9]/g, '');
    if(pincode.length === 6) {
        try {
            let response = await fetch(`https://api.postalpincode.in/pincode/${pincode}`);
            let data = await response.json();
            if(data[0].Status === "Success") {
                let po = data[0].PostOffice[0];
                document.getElementById(prefix+'City').value = po.Block || po.Name;
                document.getElementById(prefix+'Dist').value = po.District;
                document.getElementById(prefix+'State').value = po.State;
                document.getElementById(prefix+'Country').value = "India"; 
            }
        } catch(e) { console.error("Pincode fetch failed"); }
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const savedName = sessionStorage.getItem('tara_guest_name');
    const savedPhone = sessionStorage.getItem('tara_guest_phone');
    const savedEmail = sessionStorage.getItem('tara_guest_email');
    const savedDest = sessionStorage.getItem('tara_package_name');

    if (savedName) {
        const nameParts = savedName.trim().split(' ');
        const fNameInput = document.getElementById('fName');
        const lNameInput = document.getElementById('lName');
        if (fNameInput) fNameInput.value = nameParts[0] || '';
        if (lNameInput && nameParts.length > 1) {
            lNameInput.value = nameParts.slice(1).join(' ');
        }
    }
    
    if (savedPhone) {
        const phoneInput = document.getElementById('primaryPhone');
        if (phoneInput) phoneInput.value = savedPhone;
    }
    
    if (savedEmail) {
        const emailInput = document.getElementById('email');
        const confirmEmailInput = document.getElementById('confirmEmail');
        if (emailInput) emailInput.value = savedEmail;
        if (confirmEmailInput) confirmEmailInput.value = savedEmail;
    }

    if (savedDest) {
        const destInput = document.getElementById('destination');
        if (destInput) destInput.value = savedDest;
    }

    const numericFields = ['primaryPhone', 'altPhone', 'aadhaar', 'resPin', 'permPin', 'offPin'];
    numericFields.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', function() { this.value = this.value.replace(/[^0-9]/g, ''); });
    });

    const sameAsRes = document.getElementById('sameAsResCheck');
    const addOffice = document.getElementById('addOfficeCheck');
    const permBlock = document.getElementById('permAddressBlock');
    const officeBlock = document.getElementById('officeAddressBlock');
    const deliveryContainer = document.getElementById('deliveryRadios');

    const permInputs = permBlock ? permBlock.querySelectorAll('input') : [];
    const offInputs = officeBlock ? officeBlock.querySelectorAll('input') : [];

    function updateDeliveryOptions() {
        let isPermAdded = sameAsRes && !sameAsRes.checked;
        let isOfficeAdded = addOffice && addOffice.checked;
        
        let html = `<label><input type="radio" name="deliveryPref" value="Residential" checked> Residential Address</label>`;
        if (isPermAdded) html += `<label><input type="radio" name="deliveryPref" value="Permanent"> Permanent Address</label>`;
        if (isOfficeAdded) html += `<label><input type="radio" name="deliveryPref" value="Office"> Office Address</label>`;
        if (deliveryContainer) deliveryContainer.innerHTML = html;
    }

    if(sameAsRes) sameAsRes.addEventListener('change', (e) => {
        if(e.target.checked) {
            permBlock.classList.add('hidden-section');
            permInputs.forEach(input => input.removeAttribute('required'));
        } else {
            permBlock.classList.remove('hidden-section');
            permInputs.forEach(input => input.setAttribute('required', 'true'));
        }
        updateDeliveryOptions();
    });

    if(addOffice) addOffice.addEventListener('change', (e) => {
        if(e.target.checked) {
            officeBlock.classList.remove('hidden-section');
            offInputs.forEach(input => input.setAttribute('required', 'true'));
        } else {
            officeBlock.classList.add('hidden-section');
            offInputs.forEach(input => input.removeAttribute('required'));
        }
        updateDeliveryOptions();
    });

    updateDeliveryOptions(); 

    const tourTypeSel = document.getElementById('tourType');
    const passportGroup = document.getElementById('passportGroup');
    const passportInput = document.getElementById('passport');
    
    if(tourTypeSel) tourTypeSel.addEventListener('change', function() {
        if(this.value === 'International') {
            passportGroup.classList.remove('hidden-section');
        } else {
            passportGroup.classList.add('hidden-section');
            if(passportInput) passportInput.value = ''; 
        }
    });

    const dateInput = document.getElementById('startDate');
    if(dateInput) {
        let today = new Date();
        let minDate = new Date(today); minDate.setDate(today.getDate() + 2); 
        let maxDate = new Date(today); maxDate.setDate(today.getDate() + 547); 
        dateInput.setAttribute('min', minDate.toISOString().split('T')[0]);
        dateInput.setAttribute('max', maxDate.toISOString().split('T')[0]);
    }

    const leadForm = document.getElementById('leadForm');
    if(leadForm) {
        leadForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const primaryPhone = document.getElementById('primaryPhone') ? document.getElementById('primaryPhone').value.trim() : "";
            if(primaryPhone.length !== 10) return alert("Primary Contact Number must be exactly 10 digits.");

            const email = document.getElementById('email') ? document.getElementById('email').value.trim() : "";
            const confirmEmail = document.getElementById('confirmEmail') ? document.getElementById('confirmEmail').value.trim() : "";
            const validEmailRule = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if(!validEmailRule.test(email)) {
                alert("Please enter a valid Email Address.");
                document.getElementById('email').focus(); return;
            }
            if (email !== confirmEmail) {
                alert("Your email addresses do not match.");
                document.getElementById('confirmEmail').focus(); return;
            }

            const btn = document.getElementById('submitBtn');
            const originalBtnText = btn.innerText;
            btn.innerText = "Securing Details...";
            btn.style.pointerEvents = "none";

            try {
                const bookingId = "TRV-" + Math.random().toString(36).substr(2, 6).toUpperCase();
                const getVal = (id) => { const el = document.getElementById(id); return el ? el.value.trim() : ""; };
                
                const fName = getVal('fName'); const lName = getVal('lName');
                const destination = getVal('destination'); const tier = getVal('tier');

                sessionStorage.setItem('tara_booking_id', bookingId);
                sessionStorage.setItem('tara_guest_name', `${fName} ${lName}`);
                sessionStorage.setItem('tara_guest_email', email);
                sessionStorage.setItem('tara_guest_phone', primaryPhone);
                sessionStorage.setItem('tara_package_name', destination);
                sessionStorage.setItem('tara_tour_tier', tier);
                sessionStorage.setItem('tara_start_date', getVal('startDate'));

                const resAddr = `${getVal('resLine1')}, ${getVal('resLandmark')}, ${getVal('resCity')}, ${getVal('resDist')}, ${getVal('resState')}, ${getVal('resCountry')} - ${getVal('resPin')}`;
                
                let permAddr = "Same as Residential";
                if (sameAsRes && !sameAsRes.checked) {
                    permAddr = `${getVal('permLine1')}, ${getVal('permLandmark')}, ${getVal('permCity')}, ${getVal('permDist')}, ${getVal('permState')}, ${getVal('permCountry')} - ${getVal('permPin')}`;
                }
                let officeAddr = "N/A";
                if (addOffice && addOffice.checked) {
                    officeAddr = `${getVal('offLine1')}, ${getVal('offLandmark')}, ${getVal('offCity')}, ${getVal('offDist')}, ${getVal('offState')}, ${getVal('offCountry')} - ${getVal('offPin')}`;
                }
                
                const deliveryRadio = document.querySelector('input[name="deliveryPref"]:checked');
                const deliveryPref = deliveryRadio ? deliveryRadio.value : 'Residential';

                const payload = {
                    action: 'LEAD_CAPTURE', bookingId: bookingId, prefix: getVal('prefix'), fName: fName, mName: getVal('mName'), lName: lName, primaryPhone: primaryPhone, altPhone: getVal('altPhone'), email: email, resAddress: resAddr, permAddress: permAddr, officeAddress: officeAddr, deliveryAddr: deliveryPref, aadhaar: getVal('aadhaar'), tourType: getVal('tourType'), passport: getVal('passport'), destination: destination, startDate: getVal('startDate'), tier: tier
                };

                // 🚀 PUSH ONLY TO HOSTINGER
                await fetch(HOSTINGER_API_URL, {
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' }, 
                    body: JSON.stringify(payload)
                });

                btn.style.backgroundColor = '#27ae60';
                btn.style.color = '#ffffff';
                btn.innerText = "Transferring to Room Allocation...";
                
                setTimeout(() => { window.location.href = "checkout.php"; }, 1200);

            } catch(error) {
                console.error(error);
                alert("An error occurred during submission. Please check your form and try again.");
                btn.innerText = originalBtnText;
                btn.style.pointerEvents = "auto";
            }
        });
    }
});