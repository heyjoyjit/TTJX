<?php
// Top of package-swiss-family.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹1,20,000"; 
$sheet_affordable_price = "₹1,75,000";
$sheet_super_price = "₹2,60,000";

// EXACT package name from Google Sheet
$target_package = "The Swiss Family Adventure 7D/6N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Family-Friendly 3-Star Hotels with Adjoining Rooms</li>
            <li><i class="fa-solid fa-train"></i> 2nd Class Swiss Travel Pass + Free Swiss Family Card</li>
            <li><i class="fa-solid fa-ticket"></i> Standard Entry to Lindt Home of Chocolate & Transport Museum</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Continental Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Hotels with Spacious Family Suites</li>
            <li><i class="fa-solid fa-train"></i> 1st Class Travel Pass for Extra Space & Comfort</li>
            <li><i class="fa-solid fa-cookie-bite"></i> Interactive Chocolate Making Workshop in Interlaken</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast + 2 Fun Family Dinners (Fondue/Pizza)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Luxury Resorts with Dedicated Kids Clubs & Pools</li>
            <li><i class="fa-solid fa-car"></i> Private Luxury Minivan Transfers for the Entire Family</li>
            <li><i class="fa-solid fa-crown"></i> Private Guided Tours & VIP Skip-the-Line Access Everywhere</li>
            <li><i class="fa-solid fa-utensils"></i> Premium Dining & Private Picnic by Lake Brienz</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Swiss Family Adventure 7 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="europe-itinerary.php">Europe Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Swiss Family Adventure (7D/6N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['swiss family hero']) ? $tourImages['swiss family hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 7 Days / 6 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Swiss Family Adventure</h1>
            <p>Chocolate factories, interactive museums, snow tubing, and magical train rides. The perfect, stress-free Alpine journey designed specifically for families.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Swiss Family Adventure 7D/6N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Traveling with children requires a different pace—less time packing and unpacking, and more time for interactive fun. This 7-day itinerary establishes two main "basecamps" (Lucerne and Interlaken) to minimize luggage hauling. We have curated activities that guarantee excitement for all ages: marveling at a 9-meter-tall chocolate fountain, exploring planes and trains at the Transport Museum, meeting the famous bears of Bern, and playing in the eternal snow atop Mount Titlis.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Zurich & The Lindt Home of Chocolate</h3>
                <p>Arrive at Zurich Airport (ZRH). Your family’s Swiss Travel Pass (and the free Swiss Family Card for kids) activates today. Before heading to your hotel, take a short train ride to Kilchberg to visit the spectacular Lindt Home of Chocolate. Kids will be mesmerized by the 9-meter-tall chocolate fountain. Enjoy interactive exhibits detailing the history of cocoa and indulge in unlimited tasting rooms. Afterwards, take the train to Lucerne (approx. 50 mins), check into your hotel, and relax.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Planes, Trains & The Lucerne Lake Cruise</h3>
                <p>After breakfast, take a beautiful boat ride across Lake Lucerne to the Swiss Museum of Transport—the most popular museum in Switzerland for families. It is incredibly interactive, allowing kids to explore real airplanes, climb into train cabs, and participate in a road construction arena. The complex also houses a massive Planetarium and the Swiss Chocolate Adventure ride. Return to Lucerne’s Old Town in the afternoon to feed the swans by the Chapel Bridge.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Snow Play at Mount Titlis</h3>
                <p>Today brings the ultimate Alpine thrill. Take a 45-minute train ride to Engelberg, then board a series of gondolas, including the rotating Titlis Rotair, to the summit of Mount Titlis. At the top, kids will absolutely love the Glacier Park, where they can grab a snow tube and race down the icy slopes (even in the middle of summer!). Walk through the magical, blue-lit Glacier Cave and brave the thrilling Cliff Walk suspension bridge. Return to Lucerne for the evening.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> The Scenic Train to Interlaken & Ballenberg</h3>
                <p>Pack your bags and board the famous Luzern-Interlaken Express. This 2-hour panoramic journey is captivating for all ages, passing deep blue lakes and waterfalls. Upon arriving in Interlaken, drop your bags at the hotel and head out to the Ballenberg Open-Air Museum. Set in a beautiful forest, kids can explore 100 centuries-old Swiss chalets, pet over 250 farm animals, and watch live demonstrations of traditional cheese-making and woodcarving.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Chocolate Making Workshop & Harder Kulm</h3>
                <p>Start your morning with a hands-on Chocolate Making Workshop right in Interlaken! Under the guidance of a master chocolatier, the whole family will learn to pour, decorate, and package their own Swiss chocolate bars to take home. In the late afternoon, take the funicular up to Harder Kulm (Interlaken’s local mountain). The ride is steep and exciting, and the viewing platform at the top offers a stunning view of the two lakes and the Jungfrau peak—a perfect spot for a family photo.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Day Trip to Bern: Bears & Clock Towers</h3>
                <p>Take a quick, 50-minute train ride to Bern, the capital of Switzerland. Bern’s medieval Old Town is a UNESCO World Heritage site and feels like a fairy tale. Visit the BärenPark (Bear Park) to see live bears—the symbol of the city—roaming in their riverside enclosure. Watch the mechanical figures of the Zytglogge (Clock Tower) perform their hourly show, and let the kids play in the incredible water fountains on the Parliament square before heading back to Interlaken.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Departure from Zurich</h3>
                <p>Enjoy your final Swiss family breakfast. When you are ready, use your Swiss Travel Pass to take the direct train from Interlaken straight into the terminal of Zurich Airport (approx. 2 hours). The Swiss railway's punctuality and spacious carriages make traveling to the airport with family luggage completely stress-free, ending your perfect vacation on a high note.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Family-Friendly 3-Star Hotels with Adjoining Rooms</li>
                <li><i class="fa-solid fa-train"></i> 2nd Class Swiss Travel Pass + Free Swiss Family Card</li>
                <li><i class="fa-solid fa-ticket"></i> Standard Entry to Lindt Home of Chocolate & Transport Museum</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Continental Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/swiss-family-7d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- FAMILY INSIGHTS HUB (6 GRID CARDS)                        -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Family Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to make traveling with children in Switzerland a breeze.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-child"></i></div>
                <h3>The Swiss Family Card</h3>
                <p>Incredible savings:</p>
                <ul>
                    <li><strong>Kids Travel Free:</strong> When parents purchase a Swiss Travel Pass, children under the age of 16 travel completely free of charge on all trains, buses, and boats when accompanied by at least one parent. We will issue this family card along with your tickets.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-baby-carriage"></i></div>
                <h3>Strollers & Accessibility</h3>
                <p>Navigating the stations:</p>
                <ul>
                    <li><strong>Pram-Friendly:</strong> Switzerland is incredibly stroller-friendly. Almost all major train stations have elevators and ramps. Many modern trains feature low-floor entries and designated family zones where you can park strollers without folding them.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Dressing for the Glaciers</h3>
                <p>Keeping kids warm:</p>
                <ul>
                    <li><strong>Mount Titlis:</strong> Even if you travel in August, the summit of Mount Titlis and the Glacier Park are freezing. Kids will be playing in the snow, so waterproof pants, heavy jackets, gloves, and sturdy shoes are absolutely mandatory for Day 3.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-pizza-slice"></i></div>
                <h3>Kid-Friendly Dining</h3>
                <p>Familiar foods:</p>
                <ul>
                    <li><strong>Picky Eaters:</strong> Swiss cuisine is very kid-friendly. Staples include rösti (crispy potato pancakes), pasta, and pizza, which are available at almost every restaurant. For a fun experience, cheese fondue is a must-try interactive dinner for older kids!</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase"></i></div>
                <h3>Basecamp Strategy</h3>
                <p>Minimal packing:</p>
                <ul>
                    <li><strong>Less Hassle:</strong> We designed this itinerary with only two hotel bases (Lucerne and Interlaken) to prevent the nightmare of unpacking and repacking with kids every day. Day trips are kept short, ensuring you are back at your "home base" easily by dinner time.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-tree"></i></div>
                <h3>Swiss Playgrounds</h3>
                <p>Burning off energy:</p>
                <ul>
                    <li><strong>World-Class Parks:</strong> Every Swiss town and even many mountain summits feature incredible, safe, and beautifully designed playgrounds. If the kids need a break from sightseeing, you are never more than 10 minutes away from a great play area.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, Tamil Nadu, Andhra Pradesh, Andaman, Lakshadweep, Dubai, Europe, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Swiss Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized Alpine family vacation.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="The Swiss Family Adventure 7D/6N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>