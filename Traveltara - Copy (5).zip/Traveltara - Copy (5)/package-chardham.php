<?php
// Top of package-chardham.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹38,500"; 
$sheet_affordable_price = "₹55,000";
$sheet_super_price = "₹85,000";

// EXACT package name from Google Sheet
$target_package = "Char Dham 11D/10N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Stays</li>
            <li><i class="fa-solid fa-car"></i> Private Innova / SUV</li>
            <li><i class="fa-solid fa-person-hiking"></i> Standard Darshan Assistance</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast & Dinner (Pure Veg)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Hotels</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> VIP Darshan Assistance</li>
            <li><i class="fa-solid fa-utensils"></i> All Meals + High Tea (Pure Veg)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star / Boutique Luxury</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-helicopter"></i> VIP Darshan & Heli-Shuttle</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Gourmet Meals (Pure Veg)</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Sacred Char Dham Yatra | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* ==========================================================================
           DESIGN: DESTINATION HUB (GRID CARDS)
           ========================================================================== */
        .info-hub-section {
            background: #f9fafb;
            border-top: 1px solid #eaeaea;
            padding: 80px 0;
        }
        .info-hub-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .info-card {
            background: #fff;
            border-radius: 12px;
            padding: 35px 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            border-top: 5px solid #C5A059;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .info-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.08);
        }
        .info-icon-wrapper {
            width: 60px;
            height: 60px;
            background: rgba(197, 160, 89, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        .info-icon-wrapper i {
            font-size: 1.5rem;
            color: #C5A059;
        }
        .info-card h3 {
            font-family: 'Playfair Display', serif;
            font-size: 1.4rem;
            color: #0A1128;
            margin-bottom: 15px;
        }
        .info-card p, .info-card li {
            font-family: 'Lato', sans-serif;
            font-size: 0.95rem;
            color: #555;
            line-height: 1.6;
        }
        .info-card ul {
            padding-left: 18px;
            margin-top: 10px;
        }
        .info-card li {
            margin-bottom: 8px;
        }
    </style>
</head>
<body>

    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Char Dham Yatra (11D/10N)</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['char dham hero']) ? $tourImages['char dham hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 11 Days / 10 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Sacred Char Dham</h1>
            <p>11 Days of Spiritual Awakening in the Himalayas</p>
        </div>
    </header>
    
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Char Dham 11D/10N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Embark on the ultimate spiritual pilgrimage through the serene peaks and deep valleys of Uttarakhand. This comprehensive 11-day itinerary takes you to the four holiest shrines—Yamunotri, Gangotri, Kedarnath, and Badrinath. Designed for comfort without compromising the authentic essence of the pilgrimage, this journey features well-planned road travel, comfortable stays, guided treks, and mesmerizing evening Aartis along the sacred rivers.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Haridwar / Rishikesh</h3>
                <p>Arrive in Haridwar or Dehradun, where our team will warmly welcome you. Transfer to your hotel and rest. In the evening, witness the deeply moving Ganga Aarti at Har Ki Pauri. Overnight stay at the hotel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Drive to Barkot</h3>
                <p>Begin your scenic drive into the mountains towards Barkot, passing through the beautiful hill station of Mussoorie and the Kempty Falls. Barkot is a serene town located at the foot of Yamunotri. Check into your comfortable hotel for a restful night.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Yamunotri Darshan</h3>
                <p>Early morning drive to Janki Chatti. The 6 km trek to Yamunotri can be covered on foot, by pony, or palanquin (palki). Take a holy dip in the thermal springs (Surya Kund) before enjoying the Darshan. Return to Barkot for the night.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Barkot to Uttarkashi</h3>
                <p>After breakfast, drive to Uttarkashi, a town deeply rooted in spiritual heritage situated on the banks of the Bhagirathi River. Visit the historic Kashi Vishwanath Temple in the evening. Overnight stay in Uttarkashi.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Gangotri Darshan</h3>
                <p>Drive to the pristine Gangotri shrine, passing through the breathtaking Harsil valley and stunning deodar forests. Take a holy dip in the icy waters of the Bhagirathi River and attend the Darshan at the Gangotri Temple. Drive back to Uttarkashi.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Uttarkashi to Guptkashi / Sitapur</h3>
                <p>Today involves a long but incredibly scenic drive alongside the Mandakini river towards Guptkashi or Sitapur, the base camps for the Kedarnath journey. Rest and prepare your belongings for the trek the following day.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Trek to Kedarnath Shrine</h3>
                <p>Early morning drop at Sonprayag/Gaurikund. Begin the rigorous but rewarding trek to Kedarnath (ponies and helicopters can be arranged). Arrive at the majestic temple surrounded by snow-capped peaks. Experience the powerful evening Aarti. Overnight stay in a guesthouse in Kedarnath.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Descend to Guptkashi</h3>
                <p>Wake up early for the morning Darshan of Lord Shiva. Begin your descent back to Gaurikund. Our driver will meet you and transfer you back to your hotel in Guptkashi/Sitapur to rest and recover from the trek.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Drive to Badrinath</h3>
                <p>Travel through the magnificent mountainous terrain, crossing Chopta and Joshimath, to reach Badrinath. Upon arrival, check into your hotel. In the evening, visit the grand Badrinath Temple for the evening Aarti. Overnight stay in Badrinath.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Badrinath Darshan & Return to Rudraprayag</h3>
                <p>Early morning, take a holy dip in the Tapt Kund before the final Darshan of Lord Badri Vishal. Visit the last Indian village of Mana, before driving down to Rudraprayag or Srinagar for your final overnight stay in the mountains.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Departure</h3>
                <p>After breakfast, begin your final descent to the plains. You will be dropped at the Haridwar Railway Station or Dehradun Airport for your onward journey, carrying a lifetime of spiritual memories.</p>
            </div>
        </div>

        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Stays</li>
                <li><i class="fa-solid fa-car"></i> Private Innova / SUV</li>
                <li><i class="fa-solid fa-person-hiking"></i> Standard Darshan Assistance</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast & Dinner (Pure Veg)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/chardham-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Yatra Guidelines</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Pilgrimage Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical information required for a safe, fulfilling, and compliant Char Dham Yatra experience.</p>
        </div>

        <div class="info-hub-grid">
            
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-calendar-check"></i></div>
                <h3>Travel Windows</h3>
                <p>The shrines are only open for a limited 6-month period every year:</p>
                <ul>
                    <li><strong>May to June:</strong> Peak season. Opens around Akshaya Tritiya. Pleasant days but massive crowds.</li>
                    <li><strong>July to August:</strong> Monsoon. High risk of landslides; generally not recommended for the faint-hearted.</li>
                    <li><strong>September to Oct:</strong> Best time for comfortable, scenic, and peaceful Darshans before closing around Diwali.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-snowflake"></i></div>
                <h3>Winter Migration</h3>
                <p><strong>From November to April</strong>, the main shrines are completely buried under heavy snow:</p>
                <ul>
                    <li>The deities are moved to their respective winter seats (Ukhimath, Joshimath, Mukhba, Kharsali).</li>
                    <li>The original temples at Kedarnath, Badrinath, Gangotri, and Yamunotri remain completely closed.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-helicopter"></i></div>
                <h3>Helicopter Operations</h3>
                <p>Heli-shuttles to Kedarnath save hours of trekking but are subject to strict rules:</p>
                <ul>
                    <li><strong>Weather Dependent:</strong> Flights are frequently grounded due to fog or high winds in the valley.</li>
                    <li><strong>Strict Booking:</strong> Tickets must be pre-booked directly via the IRCTC/Govt portal.</li>
                    <li><strong>Weight Limits:</strong> Strict baggage and personal weight limitations apply per passenger.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-heart-pulse"></i></div>
                <h3>Medical & Fitness</h3>
                <p>The Yatra involves extreme altitudes (Kedarnath is at 3,583m) and rigorous treks:</p>
                <ul>
                    <li><strong>Acclimatization:</strong> Ascend slowly. Drink plenty of water to avoid Acute Mountain Sickness (AMS).</li>
                    <li><strong>Registration:</strong> Mandatory biometric Yatra E-Pass registration is required by the Uttarakhand Govt.</li>
                    <li><strong>Clothing:</strong> Carry heavy woolens and raincoats, regardless of the summer month.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-road-barrier"></i></div>
                <h3>Transport Realities</h3>
                <p>Driving in the Garhwal Himalayas requires patience and adherence to safety laws:</p>
                <ul>
                    <li><strong>No Night Driving:</strong> Driving is strictly prohibited in the mountains after 8:00 PM.</li>
                    <li><strong>Traffic Hubs:</strong> Expect bottlenecks during peak season at narrow passes near Sonprayag and Joshimath.</li>
                    <li><strong>Vehicle Access:</strong> Standard cabs park at base camps; you must use local jeeps or trek the final miles to certain shrines.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bowl-rice"></i></div>
                <h3>Culinary & Lifestyle</h3>
                <p>The Char Dham route is a deeply sacred zone requiring strict lifestyle adherence:</p>
                <ul>
                    <li><strong>Sattvic Food Only:</strong> Meals provided are strictly vegetarian. No eggs or meat are available.</li>
                    <li><strong>No Alcohol:</strong> The consumption of alcohol is strictly prohibited and illegal on the Yatra route.</li>
                    <li><strong>Local Dhabas:</strong> While premium hotels have buffets, meals during transit are served at basic, hygienic mountain dhabas.</li>
                </ul>
            </div>

        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Char Dham Yatra (11D/10N)" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>