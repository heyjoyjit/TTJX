<?php
// Top of madhya-pradesh-itinerary.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Madhya Pradesh Tour Packages | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Madhya Pradesh Packages</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['mp hero']) ? $tourImages['mp hero'] : $fallbackImg; ?>') center/cover;">
        <div class="subpage-hero-content">
            <h1>The Heart of India</h1>
            <p>From the erotic temples of Khajuraho to the roaring tigers of Bandhavgarh, discover the ancient soul of Madhya Pradesh.</p>
        </div>
    </header>

    <!-- MAIN GRID SECTION -->
    <section class="section-padding" style="background-color: #fcfcfc;">
        <div style="max-width: 1200px; margin: auto; text-align: center; margin-bottom: 50px; padding: 0 20px;">
            <h2 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; color: #0A1128; margin-bottom: 15px;">Available Madhya Pradesh Circuits</h2>
            <p style="color: #666; max-width: 800px; margin: 0 auto;">Whether you seek the architectural brilliance of Orchha, the deep spirituality of Ujjain, or thrilling wildlife encounters in Kanha, our meticulously paced itineraries offer the perfect central Indian escape.</p>
        </div>

        <div class="grid-container" id="mpPackagesGrid">
            
            <!-- CARD 1: HERITAGE (NORTH) -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['mp heritage']) ? $tourImages['mp heritage'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">5-7 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Heritage Circuit</h3>
                    <p><strong>North Region:</strong> A journey through architectural supremacy. Explore the majestic Gwalior Fort, the hidden medieval palaces of Orchha, and the world-famous UNESCO temples of Khajuraho.</p>
                    <h4 class="package-price">Starts at ₹18,000</h4>
                    <a href="package-mp-heritage.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 2: MALWA & SPIRITUAL (WEST) -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['mp malwa']) ? $tourImages['mp malwa'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">5-7 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Malwa & Spiritual Circuit</h3>
                    <p><strong>West Region:</strong> Deep devotion meets royal history. Seek blessings at the Mahakaleshwar and Omkareshwar Jyotirlingas, and wander through the romantic ruins of Mandu and Maheshwar.</p>
                    <h4 class="package-price">Starts at ₹16,500</h4>
                    <a href="package-mp-malwa.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 3: WILDLIFE (EAST) -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['mp wildlife']) ? $tourImages['mp wildlife'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">6-8 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Wildlife Circuit</h3>
                    <p><strong>East Region:</strong> Step into the Jungle Book. Embark on thrilling jeep safaris across India's premier tiger reserves, including Bandhavgarh, Kanha, and the leopard-rich forests of Pench.</p>
                    <h4 class="package-price">Starts at ₹22,000</h4>
                    <a href="package-mp-wildlife.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 4: CENTRAL NATURE & UNESCO -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['mp central']) ? $tourImages['mp central'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">5-6 Days</div>
                </div>
                <div class="card-content">
                    <h3>Central Nature & UNESCO Circuit</h3>
                    <p><strong>Central Region:</strong> A blend of prehistory and pristine nature. Marvel at the Great Stupa of Sanchi, the ancient rock shelters of Bhimbetka, and the lush, misty hill station of Pachmarhi.</p>
                    <h4 class="package-price">Starts at ₹17,000</h4>
                    <a href="package-mp-central.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 5: GRAND ODYSSEY -->
            <div class="destination-card">
                <div class="card-image" style="background: url('<?php echo isset($tourImages['mp grand']) ? $tourImages['mp grand'] : $fallbackImg; ?>') center/cover; position: relative;">
                    <div class="duration-badge">12-15 Days</div>
                </div>
                <div class="card-content">
                    <h3>The Grand M.P. Odyssey</h3>
                    <p><strong>The Complete Loop:</strong> The ultimate mega-circuit combining the architectural marvels of the north, the sacred Jyotirlingas of the west, and the thrilling tiger safaris of the east.</p>
                    <h4 class="package-price">Starts at ₹45,000</h4>
                    <a href="package-mp-grand.php" class="btn-outline">View Itinerary</a>
                </div>
            </div>

            <!-- CARD 6: CUSTOM -->
            <div class="destination-card" style="background: #0A1128; color: #fff;">
                <div class="card-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%; padding: 40px 20px;">
                    <i class="fa-solid fa-compass" style="font-size: 3rem; color: #C5A059; margin-bottom: 20px;"></i>
                    <h3 style="color: #fff;">Build Your Own</h3>
                    <p style="color: #ccc;">Want to combine a tiger safari in Bandhavgarh with the temples of Khajuraho? Or plan a specialized spiritual yatra? Let us craft your bespoke Central Indian adventure.</p>
                    <button class="btn-primary" onclick="openLeadPopup()" style="margin-top: 20px; width: 100%;">Consult an Expert</button>
                </div>
            </div>

        </div>
    </section>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream Madhya Pradesh exploration.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Madhya Pradesh Packages" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>