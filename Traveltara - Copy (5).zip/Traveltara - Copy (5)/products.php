<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products & Services | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Products & Services</h1>
        <p>Discover how we craft your journey.</p>
    </header>

    <main class="info-container">
        <h2>Our Core Offerings</h2>
        <p>Traveltara operates differently than standard booking portals. We do not just sell hotel rooms; we engineer end-to-end travel experiences across India's most sought-after destinations, including Rajasthan, North Bengal, Sikkim, and Himachal Pradesh.</p>

        <h2>The Four-Tier Experience</h2>
        <p>Our dynamic booking engine allows you to scale your trip exactly to your preferred level of comfort and budget:</p>
        <ul>
            <li><strong>Budget Tours:</strong> Designed for the adventurous traveler seeking authenticity. We secure highly-rated, clean, and safe boutique homestays and standard transport, maximizing your time exploring rather than spending on amenities.</li>
            <li><strong>Affordable Luxury:</strong> Our most popular tier. Enjoy premium 4-star equivalent accommodations, upgraded private vehicles (like Innova Crysta), and complimentary daily breakfasts.</li>
            <li><strong>Super Luxury:</strong> Uncompromising opulence. This tier unlocks heritage palace stays, 5-star desert luxury camps, private guided excursions, and exclusive VIP transfers.</li>
            <li><strong>Customised Expeditions:</strong> A blank canvas. Work directly with our travel designers to build an itinerary from the ground up, tailored exactly to your specific dates, group size, and niche interests.</li>
        </ul>

        <h2>Corporate & Group Operations</h2>
        <p>Beyond individual leisure travel, we provide comprehensive MICE (Meetings, Incentives, Conferences, and Exhibitions) services and large-group coordination, complete with dedicated on-ground tour managers.</p>
    </main>

</body>
</html>