<?php
session_start();

// 🔒 SET YOUR SECRET ADMIN PASSWORD HERE
$admin_password = "tara2026"; 

// Handle Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin-dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['admin_pass'])) {
    if ($_POST['admin_pass'] === $admin_password) $_SESSION['admin_logged_in'] = true;
}

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Login | Traveltara</title>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
        <style>
            body { font-family: 'Lato', sans-serif; background: #f4f4f4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
            .login-box { background: #fff; padding: 40px; border-radius: 4px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border-top: 5px solid #0A1128; text-align: center; width: 100%; max-width: 400px; }
            h2 { font-family: 'Playfair Display', serif; color: #0A1128; margin-top: 0; }
            input { width: 100%; padding: 12px; margin: 20px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 16px; }
            button { width: 100%; background: #C5A059; color: #0A1128; font-weight: bold; border: none; padding: 15px; cursor: pointer; font-size: 16px; border-radius: 4px; transition: 0.3s; }
            button:hover { background: #0A1128; color: #fff; }
        </style>
    </head>
    <body>
        <div class="login-box">
            <h2>Traveltara Secure Portal</h2>
            <form method="POST">
                <input type="password" name="admin_pass" placeholder="Enter Master Password" required>
                <button type="submit">Unlock Dashboard</button>
            </form>
        </div>
    </body>
    </html>
<?php
    exit(); 
}

// 🟢 SECURE DATABASE CONNECTION
$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) { die("Database Connection Failed."); }

date_default_timezone_set('Asia/Kolkata');
$conn->query("SET time_zone = '+05:30'");

// Fetch Data for Tables
$crm_data = $conn->query("SELECT * FROM master_crm ORDER BY `Latest Activity` DESC");
$bookings_data = $conn->query("SELECT * FROM bookings ORDER BY `Timestamp` DESC");
$interactions_data = $conn->query("SELECT * FROM interactions ORDER BY `Timestamp` DESC");
$pricing_data = @$conn->query("SELECT * FROM pricing");
$coupons_data = @$conn->query("SELECT * FROM coupons");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Traveltara | Master Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="css/admin-dashboard.css?v=<?php echo time(); ?>">
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

    <div class="mobile-topbar">
        <h2>Traveltara Admin</h2>
        <button class="menu-toggle-btn" onclick="toggleMobileMenu()"><i class="fa-solid fa-bars"></i></button>
    </div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="sidebar" id="adminSidebar">
        <div class="sidebar-header"><h2>traveltara</h2><p>Admin Portal</p></div>
        <div class="nav-menu">
            <div class="nav-link active" onclick="switchTab('finance-tab', this)"><i class="fa-solid fa-chart-pie"></i> Omni Dashboard</div>
            <div class="nav-link" onclick="switchTab('expense-tab', this); loadExpenseData();"><i class="fa-solid fa-file-invoice-dollar"></i> Expense Tracker</div>
            <div class="nav-link" onclick="switchTab('pos-tab', this)"><i class="fa-solid fa-cash-register"></i> Master POS</div>
            
            <div class="nav-link" id="leadsToggleBtn" onclick="toggleDropdown('leadsDropdownMenu', 'leadsToggleBtn')"><i class="fa-solid fa-users"></i> Lead Management <i class="fa-solid fa-chevron-down dropdown-icon"></i></div>
            <div class="dropdown-container" id="leadsDropdownMenu">
                <div class="nav-link sub-link" onclick="switchTab('crm-tab', this)"><i class="fa-solid fa-address-book"></i> Master CRM</div>
                <div class="nav-link sub-link" onclick="switchTab('bookings-tab', this)"><i class="fa-solid fa-suitcase-rolling"></i> Booking Details</div>
                <div class="nav-link sub-link" onclick="switchTab('interactions-tab', this)"><i class="fa-solid fa-comments"></i> Interactions</div>
            </div>

            <div class="nav-link" id="salesToggleBtn" onclick="toggleDropdown('salesDropdownMenu', 'salesToggleBtn')"><i class="fa-solid fa-tags"></i> Sales & Pricing <i class="fa-solid fa-chevron-down dropdown-icon"></i></div>
            <div class="dropdown-container" id="salesDropdownMenu">
                <div class="nav-link sub-link" onclick="switchTab('pricing-tab', this)"><i class="fa-solid fa-indian-rupee-sign"></i> Pricing Engine</div>
                <div class="nav-link sub-link" onclick="switchTab('coupons-tab', this)"><i class="fa-solid fa-ticket"></i> Coupon Codes</div>
            </div>

            <div class="nav-link" onclick="switchTab('uploader-tab', this)"><i class="fa-solid fa-cloud-arrow-up"></i> Media Uploader</div>
        </div>
        <a href="?logout=true" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> Secure Logout</a>
    </div>

    <div class="main-content">
        
        <div id="finance-tab" class="tab-panel active">
            <div class="filter-bar">
                <h2 style="margin:0; color: #0A1128; font-size: 18px;"><i class="fa-solid fa-chart-line"></i> Omni Intelligence</h2>
                <div class="btn-action-group">
                    <select id="timeRangeFilter" onchange="loadDashboardData()">
                        <option value="mtd">Till Now (Month to Date)</option>
                        <option value="30days" selected>Last 30 Days</option>
                        <option value="last_month">Last Month</option>
                        <option value="last_year">Last Year (Trailing 12)</option>
                        <option value="prev_fy">Previous Financial Year</option>
                    </select>
                    <button class="btn-refresh" id="liveRefreshBtn" onclick="refreshAllData()"><i class="fa-solid fa-rotate-right"></i> Live Refresh</button>
                    <button class="btn-report" onclick="downloadExecutiveReport()"><i class="fa-solid fa-file-pdf"></i> Download Report</button>
                </div>
            </div>

            <div class="finance-grid">
                <div class="fin-card">
                    <h3>Gross Revenue</h3>
                    <div class="value" id="valRevenue">₹0</div>
                </div>
                <div class="fin-card">
                    <h3>Real Expenses</h3>
                    <div class="value" id="valExpenses" style="color: #e74c3c;">₹0</div>
                </div>
                <div class="fin-card">
                    <h3>Net Profit</h3>
                    <div class="value" id="valProfit" style="color: #27ae60;">₹0</div>
                </div>
                <div class="fin-card">
                    <h3>Total Pax</h3>
                    <div class="value" id="valPax" style="color: #2980b9;">0</div>
                    <div class="sub-text" id="valPaxSub">Adults: 0 | Children: 0</div>
                </div>
                <div class="fin-card">
                    <h3>Total Enquiries</h3>
                    <div class="value" id="valLeads" style="color: #8e44ad;">0</div>
                </div>
            </div>

            <div class="exec-report-container" id="executiveSummaryBox">
                <h3><i class="fa-solid fa-file-lines"></i> Executive Summary & Deep Analysis</h3>
                <div id="execReportText">Loading intelligence report...</div>
            </div>

            <div class="ai-query-container">
                <div class="ai-query-header"><i class="fa-solid fa-sparkles"></i> Traveltara Data AI Assistant</div>
                <div class="ai-query-chat" id="aiChatBox">
                    <div class="ai-msg"><b>System Online.</b> Ask me anything about your active database! Try: <i>"What are my sales in the last 1 hour?"</i> or <i>"What is my top destination?"</i></div>
                </div>
                <div class="ai-input-area">
                    <input type="text" id="aiQueryInput" placeholder="Ask anything... (e.g., 'Sales in last hour', 'Conversion rate')">
                    <button onclick="processAIQuery()"><i class="fa-solid fa-paper-plane"></i> Send</button>
                </div>
            </div>

            <div class="chart-grid">
                <div class="chart-container">
                    <div class="chart-header">
                        <h3><i class="fa-solid fa-money-bill-trend-up"></i> Revenue Timeline</h3>
                        <select class="chart-type-selector" onchange="changeChartType(revChart, this.value)"><option value="line">Line</option><option value="bar">Bar</option></select>
                    </div>
                    <div class="chart-canvas-wrapper"><canvas id="revenueChart"></canvas></div>
                </div>
                <div class="chart-container">
                    <div class="chart-header">
                        <h3><i class="fa-solid fa-map-location-dot"></i> Customer Locations</h3>
                        <select class="chart-type-selector" onchange="changeChartType(locChart, this.value)"><option value="doughnut">Doughnut</option><option value="pie">Pie</option><option value="bar">Bar</option></select>
                    </div>
                    <div class="chart-canvas-wrapper"><canvas id="locationChart"></canvas></div>
                </div>
            </div>
            
            <div class="chart-grid-3">
                <div class="chart-container">
                    <div class="chart-header">
                        <h3><i class="fa-solid fa-ranking-star"></i> Tour Tier Volume</h3>
                        <select class="chart-type-selector" onchange="changeChartType(tierChart, this.value)"><option value="bar">Bar</option><option value="pie">Pie</option></select>
                    </div>
                    <div class="chart-canvas-wrapper"><canvas id="tierChart"></canvas></div>
                </div>
                <div class="chart-container">
                    <div class="chart-header">
                        <h3><i class="fa-solid fa-plane"></i> Tour Type</h3>
                        <select class="chart-type-selector" onchange="changeChartType(typeChart, this.value)"><option value="pie">Pie</option><option value="doughnut">Doughnut</option><option value="bar">Bar</option></select>
                    </div>
                    <div class="chart-canvas-wrapper"><canvas id="typeChart"></canvas></div>
                </div>
                <div class="chart-container">
                    <div class="chart-header">
                        <h3><i class="fa-solid fa-mountain-sun"></i> Top Destinations</h3>
                        <select class="chart-type-selector" onchange="changeChartType(destChart, this.value)"><option value="bar">Bar</option><option value="line">Line</option></select>
                    </div>
                    <div class="chart-canvas-wrapper"><canvas id="destChart"></canvas></div>
                </div>
            </div>

            <div style="background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); margin-bottom: 20px; border: 1px solid #eee;">
                <h2 style="margin-top: 0; color: #0A1128; font-size: 20px;"><i class="fa-solid fa-sliders"></i> Custom Relational Explorer</h2>
                <p style="font-size: 13px; color: #666; margin-top: -5px; margin-bottom: 20px;">Manually link columns from your bookings database to discover deep relational insights.</p>
                
                <div style="display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap;">
                    <div style="flex: 1;">
                        <label style="display:block; font-size:12px; color:#888; margin-bottom:5px;">Group By (X-Axis)</label>
                        <select id="customX" class="explorer-select" onchange="renderCustomChart()">
                            <option value="Destination">Destination Name</option>
                            <option value="Tier">Tour Tier (Luxury/Budget)</option>
                            <option value="Type">Tour Type (Dom/Int)</option>
                            <option value="State">Customer State</option>
                        </select>
                    </div>
                    <div style="flex: 1;">
                        <label style="display:block; font-size:12px; color:#888; margin-bottom:5px;">Calculate Metric (Y-Axis)</label>
                        <select id="customY" class="explorer-select" onchange="renderCustomChart()">
                            <option value="Revenue">Total Revenue Generated (₹)</option>
                            <option value="Pax">Total Passengers Travelled</option>
                            <option value="Count">Number of Bookings Made</option>
                        </select>
                    </div>
                    <div style="flex: 1;">
                        <label style="display:block; font-size:12px; color:#888; margin-bottom:5px;">Chart Type</label>
                        <select class="explorer-select" onchange="changeChartType(customRelChart, this.value)">
                            <option value="bar">Bar Chart</option><option value="line">Line Chart</option><option value="pie">Pie Chart</option>
                        </select>
                    </div>
                </div>

                <div style="position: relative; height: 350px;">
                    <canvas id="customRelationalChart"></canvas>
                </div>
            </div>

            <div class="ai-forecast-box">
                <h2><i class="fa-solid fa-brain"></i> Advanced Strategy & Performance Forecast</h2>
                <div class="forecast-grid" id="aiForecastContainer">
                    <div style="text-align:center; width:100%; color:#888;">Analyzing historical data...</div>
                </div>
            </div>
        </div>

        <div id="expense-tab" class="tab-panel">
            <div class="filter-bar">
                <h2 style="margin:0; color: #0A1128;"><i class="fa-solid fa-wallet"></i> Real Profit & Loss Tracker</h2>
                <select id="expenseTimeFilter" onchange="loadExpenseData()">
                    <option value="30days" selected>Last 30 Days</option>
                    <option value="mtd">This Month (Till Now)</option>
                    <option value="last_month">Last Month</option>
                    <option value="all_time">All Time</option>
                </select>
            </div>

            <div class="finance-grid">
                <div class="fin-card"><h3>Total Sales Revenue</h3><div class="value" id="expRevValue" style="color: #0A1128;">₹0</div></div>
                <div class="fin-card"><h3>Actual Expenses</h3><div class="value" id="expTotalValue" style="color: #e74c3c;">₹0</div></div>
                <div class="fin-card" id="expPnLCard"><h3>Real Net Profit</h3><div class="value" id="expPnLValue">₹0</div></div>
            </div>

            <div class="table-container">
                <div class="table-header">
                    <h2>Expense Ledger</h2>
                    <button class="btn-add" onclick="openExpenseModal()" style="background:#e74c3c; color:#fff; border:none; padding:10px 15px; border-radius:4px; font-weight:bold; cursor:pointer;"><i class="fa-solid fa-plus"></i> Add Expense</button>
                </div>
                <table class="data-table">
                    <thead><tr><th>Action</th><th>Date</th><th>Category</th><th>Description</th><th>Amount (₹)</th></tr></thead>
                    <tbody id="expenseTableBody"><tr><td colspan="5" style="text-align:center;">Loading expenses...</td></tr></tbody>
                </table>
            </div>
        </div>
        
        <div id="pos-tab" class="tab-panel"><iframe src="admin_pos.php" class="pos-frame" title="Traveltara Master POS"></iframe></div>

        <div id="crm-tab" class="tab-panel">
            <div class="table-container">
                <div class="table-header">
                    <h2>Master CRM (All Leads)</h2>
                    <div class="table-actions">
                        <div style="position: relative; display: flex; align-items: center;">
                            <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 10px; color: #888; font-size: 13px;"></i>
                            <input type="text" placeholder="Search leads, phone..." onkeyup="filterTable(this, 'crmTbody')" style="padding: 8px 10px 8px 30px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; width: 220px; outline: none;">
                        </div>
                        <button class="btn-export" onclick="exportData('master_crm')"><i class="fa-solid fa-download"></i> Export</button>
                        <button class="btn-import" onclick="document.getElementById('importCrm').click()"><i class="fa-solid fa-upload"></i> Import</button>
                        <input type="file" id="importCrm" accept=".csv" style="display:none" onchange="importData(this, 'master_crm')">
                    </div>
                </div>
                <div class="wide-table-wrapper">
                    <table class="data-table">
                        <thead><tr><th>Action</th><th>Status</th><th>Phone Number</th><th>Name</th><th>Email Address</th><th>Client Type</th><th>Total Interactions</th><th>Latest Interest</th><th>Last Active</th></tr></thead>
                        <tbody id="crmTbody">
                            <?php if ($crm_data && $crm_data->num_rows > 0): while($row = $crm_data->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <button class="btn-edit" 
                                            data-phone="<?= htmlspecialchars($row['Phone Number'] ?? '', ENT_QUOTES) ?>"
                                            data-name="<?= htmlspecialchars($row['Name'] ?? '', ENT_QUOTES) ?>"
                                            data-email="<?= htmlspecialchars($row['Email Address'] ?? '', ENT_QUOTES) ?>"
                                            data-status="<?= htmlspecialchars($row['Action Status'] ?? '', ENT_QUOTES) ?>"
                                            data-ctype="<?= htmlspecialchars($row['Client Type'] ?? '', ENT_QUOTES) ?>"
                                            data-interest="<?= htmlspecialchars($row['Latest Interest'] ?? '', ENT_QUOTES) ?>"
                                            onclick="openCrmModal(this)"><i class="fa-solid fa-pen"></i> Edit
                                        </button>
                                    </td>
                                    <td><span class="status-badge"><?= htmlspecialchars($row['Action Status'] ?? '') ?></span></td>
                                    <td><strong><?= htmlspecialchars($row['Phone Number'] ?? '') ?></strong></td>
                                    <td><?= htmlspecialchars($row['Name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Email Address'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Client Type'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Total Interactions'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Latest Interest'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Latest Activity'] ?? '') ?></td>
                                </tr>
                            <?php endwhile; else: ?><tr><td colspan="9" style="text-align: center;">No records found.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="bookings-tab" class="tab-panel">
            <div class="table-container">
                <div class="table-header">
                    <h2>Booking Details</h2>
                    <div class="table-actions">
                        <div style="position: relative; display: flex; align-items: center;">
                            <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 10px; color: #888; font-size: 13px;"></i>
                            <input type="text" placeholder="Search ID, name, destination..." onkeyup="filterTable(this, 'bookingsTbody')" style="padding: 8px 10px 8px 30px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; width: 220px; outline: none;">
                        </div>
                        <button class="btn-export" onclick="exportData('bookings')"><i class="fa-solid fa-download"></i> Export</button>
                        <button class="btn-import" onclick="document.getElementById('importBookings').click()"><i class="fa-solid fa-upload"></i> Import</button>
                        <input type="file" id="importBookings" accept=".csv" style="display:none" onchange="importData(this, 'bookings')">
                    </div>
                </div>
                <div class="wide-table-wrapper">
                    <table class="data-table">
                        <thead><tr><th>Action</th><th>Booking ID</th><th>Timestamp</th><th>Status</th><th>Prefix</th><th>First Name</th><th>Middle Name</th><th>Last Name</th><th>Primary Phone</th><th>Alt Phone</th><th>Email</th><th>Destination</th><th>Commencement Date</th><th>Tour Tier</th><th>Tour Type</th><th>Adults</th><th>Children</th><th>Rooms</th><th>Total Paid</th><th>Payment Ref ID</th><th>Invoice No</th><th>Coupon Used</th><th>Aadhaar Number</th><th>Passport No</th><th>Residential Address</th><th>Permanent Address</th><th>Office Address</th><th>Delivery Address</th></tr></thead>
                        <tbody id="bookingsTbody">
                            <?php if ($bookings_data && $bookings_data->num_rows > 0): while($row = $bookings_data->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <button class="btn-edit" 
                                            data-id="<?= htmlspecialchars($row['Booking ID'] ?? '', ENT_QUOTES) ?>"
                                            data-prefix="<?= htmlspecialchars($row['Prefix'] ?? '', ENT_QUOTES) ?>"
                                            data-fname="<?= htmlspecialchars($row['First Name'] ?? '', ENT_QUOTES) ?>"
                                            data-mname="<?= htmlspecialchars($row['Middle Name'] ?? '', ENT_QUOTES) ?>"
                                            data-lname="<?= htmlspecialchars($row['Last Name'] ?? '', ENT_QUOTES) ?>"
                                            data-phone="<?= htmlspecialchars($row['Primary Phone'] ?? '', ENT_QUOTES) ?>"
                                            data-altphone="<?= htmlspecialchars($row['Alt Phone'] ?? '', ENT_QUOTES) ?>"
                                            data-email="<?= htmlspecialchars($row['Email'] ?? '', ENT_QUOTES) ?>"
                                            data-resaddr="<?= htmlspecialchars($row['Residential Address'] ?? '', ENT_QUOTES) ?>"
                                            data-permaddr="<?= htmlspecialchars($row['Permanent Address'] ?? '', ENT_QUOTES) ?>"
                                            data-offaddr="<?= htmlspecialchars($row['Office Address'] ?? '', ENT_QUOTES) ?>"
                                            data-deladdr="<?= htmlspecialchars($row['Delivery Address'] ?? '', ENT_QUOTES) ?>"
                                            data-aadhaar="<?= htmlspecialchars($row['Aadhaar Number'] ?? '', ENT_QUOTES) ?>"
                                            data-tourtype="<?= htmlspecialchars($row['Tour Type (Dom/Int)'] ?? '', ENT_QUOTES) ?>"
                                            data-passport="<?= htmlspecialchars($row['Passport No'] ?? '', ENT_QUOTES) ?>"
                                            data-dest="<?= htmlspecialchars($row['Destination'] ?? '', ENT_QUOTES) ?>"
                                            data-commdate="<?= htmlspecialchars($row['Commencement Date'] ?? '', ENT_QUOTES) ?>"
                                            data-tier="<?= htmlspecialchars($row['Tour Tier'] ?? '', ENT_QUOTES) ?>"
                                            data-adults="<?= htmlspecialchars($row['Adults'] ?? '', ENT_QUOTES) ?>"
                                            data-children="<?= htmlspecialchars($row['Children'] ?? '', ENT_QUOTES) ?>"
                                            data-rooms="<?= htmlspecialchars($row['Rooms'] ?? '', ENT_QUOTES) ?>"
                                            data-totalpaid="<?= htmlspecialchars($row['Total Paid'] ?? '', ENT_QUOTES) ?>"
                                            data-payref="<?= htmlspecialchars($row['Payment Ref ID'] ?? '', ENT_QUOTES) ?>"
                                            data-invoice="<?= htmlspecialchars($row['Invoice No'] ?? '', ENT_QUOTES) ?>"
                                            data-coupon="<?= htmlspecialchars($row['Coupon Used'] ?? '', ENT_QUOTES) ?>"
                                            data-status="<?= htmlspecialchars($row['Status'] ?? '', ENT_QUOTES) ?>"
                                            onclick="openBookingModal(this)"><i class="fa-solid fa-pen"></i> Full View
                                        </button>
                                    </td>
                                    <td><strong><?= htmlspecialchars($row['Booking ID'] ?? '') ?></strong></td>
                                    <td><?= htmlspecialchars($row['Timestamp'] ?? '') ?></td>
                                    
                                    <td>
                                        <?php 
                                            $rawStatus = $row['Status'] ?? '';
                                            $displayStatus = $rawStatus;
                                            $statusBg = '#fff3e0'; 
                                            $statusColor = '#e65100';
                                            
                                            if ($rawStatus === 'Payment Complete' || $rawStatus === 'PAID') {
                                                $displayStatus = 'PAID';
                                                $statusBg = '#e8f8f5'; 
                                                $statusColor = '#27ae60'; 
                                            } elseif ($rawStatus === 'Pending Payment' || $rawStatus === 'PENDING') {
                                                $displayStatus = 'PENDING';
                                                $statusBg = '#fdedec'; 
                                                $statusColor = '#e74c3c'; 
                                            }
                                        ?>
                                        <span class="status-badge" style="background:<?= $statusBg ?>; color:<?= $statusColor ?>;">
                                            <?= htmlspecialchars($displayStatus) ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($row['Prefix'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['First Name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Middle Name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Last Name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Primary Phone'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Alt Phone'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Email'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Destination'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Commencement Date'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Tour Tier'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Tour Type (Dom/Int)'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Adults'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Children'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Rooms'] ?? '') ?></td>
                                    <td><strong><?= htmlspecialchars($row['Total Paid'] ?? '') ?></strong></td>
                                    <td><?= htmlspecialchars($row['Payment Ref ID'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Invoice No'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Coupon Used'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Aadhaar Number'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Passport No'] ?? '') ?></td>
                                    <td title="<?= htmlspecialchars($row['Residential Address'] ?? '') ?>"><span class="truncate-text"><?= htmlspecialchars($row['Residential Address'] ?? '') ?></span></td>
                                    <td title="<?= htmlspecialchars($row['Permanent Address'] ?? '') ?>"><span class="truncate-text"><?= htmlspecialchars($row['Permanent Address'] ?? '') ?></span></td>
                                    <td title="<?= htmlspecialchars($row['Office Address'] ?? '') ?>"><span class="truncate-text"><?= htmlspecialchars($row['Office Address'] ?? '') ?></span></td>
                                    <td><?= htmlspecialchars($row['Delivery Address'] ?? '') ?></td>
                                </tr>
                            <?php endwhile; else: ?><tr><td colspan="28" style="text-align: center;">No records found.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="interactions-tab" class="tab-panel">
            <div class="table-container">
                <div class="table-header">
                    <h2>Live Interactions & Chat Transcripts</h2>
                    <div class="table-actions">
                        <div style="position: relative; display: flex; align-items: center;">
                            <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 10px; color: #888; font-size: 13px;"></i>
                            <input type="text" placeholder="Search chats, phone..." onkeyup="filterTable(this, 'interactionsTbody')" style="padding: 8px 10px 8px 30px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; width: 220px; outline: none;">
                        </div>
                        <button class="btn-export" onclick="exportData('interactions')"><i class="fa-solid fa-download"></i> Export</button>
                        <button class="btn-import" onclick="document.getElementById('importInteractions').click()"><i class="fa-solid fa-upload"></i> Import</button>
                        <input type="file" id="importInteractions" accept=".csv" style="display:none" onchange="importData(this, 'interactions')">
                    </div>
                </div>
                <div class="wide-table-wrapper">
                    <table class="data-table">
                        <thead><tr><th>Action</th><th>Phone Number</th><th>Source</th><th>Extracted Name</th><th>Extracted Email</th><th>Chat Transcript</th><th>Timestamp</th></tr></thead>
                        <tbody id="interactionsTbody">
                            <?php if ($interactions_data && $interactions_data->num_rows > 0): while($row = $interactions_data->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <button class="btn-edit" 
                                            data-id="<?= htmlspecialchars($row['id'] ?? '', ENT_QUOTES) ?>"
                                            data-phone="<?= htmlspecialchars($row['Phone Number'] ?? '', ENT_QUOTES) ?>"
                                            data-source="<?= htmlspecialchars($row['Source'] ?? '', ENT_QUOTES) ?>"
                                            data-name="<?= htmlspecialchars($row['Extracted Name'] ?? '', ENT_QUOTES) ?>"
                                            data-email="<?= htmlspecialchars($row['Extracted Email'] ?? '', ENT_QUOTES) ?>"
                                            data-transcript="<?= htmlspecialchars($row['Exact Message / Details'] ?? '', ENT_QUOTES) ?>"
                                            onclick="openInteractionModal(this)"><i class="fa-solid fa-pen"></i> Edit
                                        </button>
                                    </td>
                                    <td><strong><?= htmlspecialchars($row['Phone Number'] ?? '') ?></strong></td>
                                    <td><span class="status-badge" style="background:#e3f2fd; color:#1565c0;"><?= htmlspecialchars($row['Source'] ?? '') ?></span></td>
                                    <td><?= htmlspecialchars($row['Extracted Name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Extracted Email'] ?? '') ?></td>
                                    <td><div class="chat-cell"><?= htmlspecialchars($row['Exact Message / Details'] ?? '') ?></div></td>
                                    <td><?= htmlspecialchars($row['Timestamp'] ?? '') ?></td>
                                </tr>
                            <?php endwhile; else: ?><tr><td colspan="7" style="text-align: center;">No records found.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="pricing-tab" class="tab-panel">
            <div class="table-container">
                <div class="table-header">
                    <h2>Website Pricing Engine</h2>
                    <div class="table-actions">
                        <div style="position: relative; display: flex; align-items: center;">
                            <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 10px; color: #888; font-size: 13px;"></i>
                            <input type="text" placeholder="Search package, price..." onkeyup="filterTable(this, 'pricingTbody')" style="padding: 8px 10px 8px 30px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; width: 220px; outline: none;">
                        </div>
                        <button class="btn-add" onclick="openPricingModal()"><i class="fa-solid fa-plus"></i> Add Package</button>
                        <button class="btn-export" onclick="exportData('pricing')"><i class="fa-solid fa-download"></i> Export</button>
                        <button class="btn-import" onclick="document.getElementById('importPricing').click()"><i class="fa-solid fa-upload"></i> Import</button>
                        <input type="file" id="importPricing" accept=".csv" style="display:none" onchange="importData(this, 'pricing')">
                    </div>
                </div>
                <div class="wide-table-wrapper">
                    <table class="data-table">
                        <thead><tr><th>Action</th><th>Package Name</th><th>Budget (₹)</th><th>Affordable Luxury (₹)</th><th>Super Luxury (₹)</th></tr></thead>
                        <tbody id="pricingTbody">
                            <?php if ($pricing_data && $pricing_data->num_rows > 0): while($row = $pricing_data->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn-edit" 
                                                data-id="<?= htmlspecialchars($row['id'] ?? '', ENT_QUOTES) ?>"
                                                data-package="<?= htmlspecialchars($row['Package Name'] ?? '', ENT_QUOTES) ?>"
                                                data-budget="<?= htmlspecialchars($row['Budget'] ?? '', ENT_QUOTES) ?>"
                                                data-affordable="<?= htmlspecialchars($row['Affordable Luxury'] ?? '', ENT_QUOTES) ?>"
                                                data-super="<?= htmlspecialchars($row['Super Luxury'] ?? '', ENT_QUOTES) ?>"
                                                onclick="openPricingModal(this)"><i class="fa-solid fa-pen"></i>
                                            </button>
                                            <button class="btn-delete" onclick="deleteRecord('pricing', '<?= $row['id'] ?>')"><i class="fa-solid fa-trash"></i></button>
                                        </div>
                                    </td>
                                    <td><strong><?= htmlspecialchars($row['Package Name'] ?? '') ?></strong></td>
                                    <td><?= htmlspecialchars($row['Budget'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Affordable Luxury'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['Super Luxury'] ?? '') ?></td>
                                </tr>
                            <?php endwhile; else: ?><tr><td colspan="5" style="text-align: center;">No pricing data found. Click "Add Package" to start.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="coupons-tab" class="tab-panel">
            <div class="table-container">
                <div class="table-header">
                    <h2>Coupon Code Manager</h2>
                    <div class="table-actions">
                        <input type="text" placeholder="Search code..." onkeyup="filterTable(this, 'couponsTbody')" style="padding: 8px 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; width: 150px; outline: none;">
                        <button class="btn-add" onclick="openBulkCouponModal()" style="background:#8e44ad;"><i class="fa-solid fa-wand-magic-sparkles"></i> Auto-Generate</button>
                        <button class="btn-add" onclick="openCouponModal()"><i class="fa-solid fa-plus"></i> Add Single</button>
                        <button class="btn-export" onclick="exportData('coupons')"><i class="fa-solid fa-download"></i> Export</button>
                        <button class="btn-import" onclick="document.getElementById('importCoupons').click()"><i class="fa-solid fa-upload"></i> Import</button>
                        <input type="file" id="importCoupons" accept=".csv" style="display:none" onchange="importData(this, 'coupons')">
                        <button class="btn-delete" onclick="deleteAllCoupons()" style="padding: 8px 15px; font-size: 13px;"><i class="fa-solid fa-dumpster"></i> Delete All</button>
                    </div>
                </div>
                <div class="wide-table-wrapper">
                    <table class="data-table">
                        <thead><tr><th>Action</th><th>Coupon Code</th><th>Discount (%)</th><th>Status</th><th>Used By Booking ID</th></tr></thead>
                        <tbody id="couponsTbody">
                            <?php if ($coupons_data && $coupons_data->num_rows > 0): while($row = $coupons_data->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn-edit" 
                                                data-id="<?= htmlspecialchars($row['id'] ?? '', ENT_QUOTES) ?>"
                                                data-code="<?= htmlspecialchars($row['Coupon Code'] ?? '', ENT_QUOTES) ?>"
                                                data-discount="<?= htmlspecialchars($row['Discount (%)'] ?? '', ENT_QUOTES) ?>"
                                                data-status="<?= htmlspecialchars($row['Status'] ?? '', ENT_QUOTES) ?>"
                                                data-usedby="<?= htmlspecialchars($row['Used By Booking ID'] ?? '', ENT_QUOTES) ?>"
                                                onclick="openCouponModal(this)"><i class="fa-solid fa-pen"></i>
                                            </button>
                                            <button class="btn-delete" onclick="deleteRecord('coupons', '<?= $row['id'] ?>')"><i class="fa-solid fa-trash"></i></button>
                                        </div>
                                    </td>
                                    <td><strong><?= htmlspecialchars($row['Coupon Code'] ?? '') ?></strong></td>
                                    <td><?= htmlspecialchars($row['Discount (%)'] ?? '') ?></td>
                                    <td><span class="status-badge"><?= htmlspecialchars($row['Status'] ?? '') ?></span></td>
                                    <td><?= htmlspecialchars($row['Used By Booking ID'] ?? '') ?></td>
                                </tr>
                            <?php endwhile; else: ?><tr><td colspan="5" style="text-align: center;">No coupons found.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="uploader-tab" class="tab-panel">
            <div class="admin-box">
                <h2>Master Media Uploader</h2>
                
                <label>Where does this belong?</label>
                <select id="uploadCategory">
                    <option value="home_banner">Home Page (Main Banners & Sliders)</option>
                    <option value="destination_card">Main Destination Card (e.g., General Sikkim Card)</option>
                    <option value="sub_destination">Sub-Destination / Itinerary Page (e.g., Inside the 4D/3N page)</option>
                    <option value="blog_post">Blog Post Media</option>
                    <option value="general_asset">General Website Asset (Logos, Icons, Promos)</option>
                </select>

                <label>Unique Name / Title (Your Database Key)</label>
                <span class="helper-text">Crucial: This exact text is what you will use in your PHP code to pull this specific image.</span>
                <input type="text" id="itemName" placeholder="e.g., Sikkim Header Image" required>

                <label>Tour Plan / Duration (Optional)</label>
                <span class="helper-text">Leave blank if this is a Home Banner or Blog. Use only for specific packages.</span>
                <input type="text" id="tourType" placeholder="e.g., 4D/3N, 9D/8N">

                <label>High-Resolution Media (Image or Video)</label>
                <input type="file" id="mediaImage" accept="image/*,video/*" required>

                <button id="uploadBtn" onclick="uploadMedia()">Secure Upload & Save</button>
                
                <p id="statusMsg" style="text-align: center; font-weight: bold; margin-top: 15px;"></p>
                <img id="previewImage" src="" alt="Upload Preview">
            </div>
        </div>

    </div>

    <div class="edit-modal-overlay" id="expenseModalOverlay"><div class="edit-modal"><h3>Log New Expense</h3><label>Date of Expense</label><input type="date" id="expDate" required><label>Category</label><select id="expCategory" style="width: 100%; padding: 12px; margin: 10px 0 20px 0; border: 1px solid #ccc; border-radius: 4px; font-size: 16px;"><option value="Hotels & Accommodation">Hotels & Accommodation</option><option value="Flights & Transport">Flights & Transport</option><option value="Marketing & Ads">Marketing & Ads</option><option value="Software & Hosting">Software & Hosting</option><option value="Office & Admin">Office & Admin</option><option value="Miscellaneous">Miscellaneous</option></select><label>Description / Details</label><input type="text" id="expDesc" placeholder="e.g. Meta Ads for April" required><label>Amount (₹)</label><input type="number" id="expAmount" placeholder="e.g. 5000" required><div class="modal-buttons" style="margin-top: 20px;"><button class="btn-cancel" onclick="document.getElementById('expenseModalOverlay').style.display='none'">Cancel</button><button class="btn-save" onclick="saveExpense()" style="background:#e74c3c;">Save Expense</button></div></div></div>
    <div class="edit-modal-overlay" id="bulkCouponModalOverlay"><div class="edit-modal"><h3>Auto-Generate Coupons</h3><p style="font-size: 14px; color: #666; margin-top: 0;">Quickly create a batch of unique, active coupon codes.</p><label>How many coupons to generate?</label><input type="number" id="bulkCouponCount" placeholder="e.g., 50" min="1" max="500"><label>Discount Value</label><input type="text" id="bulkCouponDiscount" placeholder="e.g., 20% or ₹1500"><div class="modal-buttons"><button class="btn-cancel" onclick="closeModal('bulkCouponModalOverlay')">Cancel</button><button class="btn-save" onclick="generateBulkCoupons()" style="background:#8e44ad;">Generate Now</button></div></div></div>
    <div class="edit-modal-overlay" id="pricingModalOverlay"><div class="edit-modal"><h3 id="pricingModalTitle">Manage Pricing</h3><input type="hidden" id="priceId"><label>Package Name</label><input type="text" id="pricePackage"><div class="grid-2-col" style="margin-top: 15px;"><div><label>Budget (₹)</label><input type="text" id="priceBudget"></div><div><label>Affordable Luxury (₹)</label><input type="text" id="priceAffordable"></div></div><label>Super Luxury (₹)</label><input type="text" id="priceSuper"><div class="modal-buttons"><button class="btn-cancel" onclick="closeModal('pricingModalOverlay')">Cancel</button><button class="btn-save" onclick="savePricing()">Save Pricing</button></div></div></div>
    <div class="edit-modal-overlay" id="couponModalOverlay"><div class="edit-modal"><h3 id="couponModalTitle">Manage Coupon</h3><input type="hidden" id="couponId"><div class="grid-2-col"><div><label>Coupon Code</label><input type="text" id="couponCode"></div><div><label>Discount (%)</label><input type="text" id="couponDiscount" placeholder="e.g. 20"></div></div><div class="grid-2-col"><div><label>Status</label><select id="couponStatus"><option value="Active">Active</option><option value="Used">Used</option><option value="Expired">Expired</option></select></div><div><label>Used By Booking ID</label><input type="text" id="couponUsedBy" placeholder="TRV-XXXXXX"></div></div><div class="modal-buttons"><button class="btn-cancel" onclick="closeModal('couponModalOverlay')">Cancel</button><button class="btn-save" onclick="saveCoupon()">Save Coupon</button></div></div></div>
    <div class="edit-modal-overlay" id="crmModalOverlay"><div class="edit-modal"><h3>Update Master CRM</h3><input type="hidden" id="crmPhoneId"><div class="grid-2-col"><div><label>Action Status</label><select id="crmStatus"><option value="🟢 New Lead">🟢 New Lead</option><option value="🟡 Contacted">🟡 Contacted</option><option value="🟣 Negotiation">🟣 Negotiation</option><option value="🔵 Booked">🔵 Booked</option><option value="🔴 Lost/Spam">🔴 Lost/Spam</option><option value="🌟 RETURNING CUSTOMER!">🌟 RETURNING CUSTOMER!</option></select></div><div><label>Client Type</label><input type="text" id="crmClientType"></div></div><label>Full Name</label><input type="text" id="crmName"><label>Email Address</label><input type="email" id="crmEmail"><label>Latest Interest</label><input type="text" id="crmInterest"><div class="modal-buttons"><button class="btn-cancel" onclick="closeModal('crmModalOverlay')">Cancel</button><button class="btn-save" onclick="saveCrmEdits()">Save CRM</button></div></div></div>
    <div class="edit-modal-overlay" id="bookingModalOverlay"><div class="edit-modal" style="max-height: 90vh; overflow-y: auto; width: 800px; max-width: 95%;"><h3>Update Booking Dossier</h3><input type="hidden" id="bookId"><h4 style="margin-bottom: 10px; border-bottom: 2px solid #C5A059; padding-bottom: 5px;">1. Core Identity & Status</h4><div class="grid-2-col"><div><label>Pipeline Status</label><input type="text" id="bookStatus"></div><div><label>Tour Tier</label><input type="text" id="bookTier"></div></div><div class="grid-2-col" style="margin-top:10px;"><div style="display: flex; gap:10px;"><div style="flex: 1;"><label>Prefix</label><input type="text" id="bookPrefix"></div><div style="flex: 2;"><label>First Name</label><input type="text" id="bookFName"></div></div><div style="display: flex; gap:10px;"><div style="flex: 1;"><label>Middle Name</label><input type="text" id="bookMName"></div><div style="flex: 2;"><label>Last Name</label><input type="text" id="bookLName"></div></div></div><h4 style="margin-top: 20px; margin-bottom: 10px; border-bottom: 2px solid #C5A059; padding-bottom: 5px;">2. Contact & Documents</h4><div class="grid-2-col"><div><label>Primary Phone</label><input type="text" id="bookPhone"></div><div><label>Alt Phone</label><input type="text" id="bookAltPhone"></div><div><label>Email Address</label><input type="email" id="bookEmail"></div><div><label>Aadhaar Number</label><input type="text" id="bookAadhaar"></div><div><label>Passport Number</label><input type="text" id="bookPassport"></div></div><h4 style="margin-top: 20px; margin-bottom: 10px; border-bottom: 2px solid #C5A059; padding-bottom: 5px;">3. Trip Details</h4><div class="grid-2-col"><div><label>Destination</label><input type="text" id="bookDest"></div><div><label>Commencement Date</label><input type="text" id="bookCommDate"></div><div><label>Tour Type (Dom/Int)</label><input type="text" id="bookTourType"></div><div style="display: flex; gap: 10px;"><div style="flex:1"><label>Adults</label><input type="number" id="bookAdults"></div><div style="flex:1"><label>Children</label><input type="number" id="bookChildren"></div><div style="flex:1"><label>Rooms</label><input type="number" id="bookRooms"></div></div></div><h4 style="margin-top: 20px; margin-bottom: 10px; border-bottom: 2px solid #C5A059; padding-bottom: 5px;">4. Financials</h4><div class="grid-2-col"><div><label>Total Paid (₹)</label><input type="text" id="bookTotalPaid"></div><div><label>Payment Ref ID</label><input type="text" id="bookPayRef"></div><div><label>Invoice Number</label><input type="text" id="bookInvoice"></div><div><label>Coupon Used</label><input type="text" id="bookCoupon"></div></div><h4 style="margin-top: 20px; margin-bottom: 10px; border-bottom: 2px solid #C5A059; padding-bottom: 5px;">5. Associated Addresses</h4><div class="grid-2-col"><div><label>Residential Address</label><textarea id="bookResAddr" rows="2"></textarea></div><div><label>Permanent Address</label><textarea id="bookPermAddr" rows="2"></textarea></div><div><label>Office Address</label><textarea id="bookOffAddr" rows="2"></textarea></div><div><label>Delivery Address</label><textarea id="bookDelAddr" rows="2"></textarea></div></div><div class="modal-buttons" style="margin-top: 25px;"><button class="btn-cancel" onclick="closeModal('bookingModalOverlay')">Cancel</button><button class="btn-save" onclick="saveBookingEdits()">Save Full Dossier</button></div></div></div>
    <div class="edit-modal-overlay" id="interactionModalOverlay"><div class="edit-modal"><h3>Update Interaction</h3><input type="hidden" id="intId"><div class="grid-2-col"><div><label>Phone Number</label><input type="text" id="intPhone"></div><div><label>Source</label><input type="text" id="intSource"></div></div><div class="grid-2-col"><div><label>Extracted Name</label><input type="text" id="intName"></div><div><label>Extracted Email</label><input type="text" id="intEmail"></div></div><label>Chat Transcript / Details</label><textarea id="intTranscript"></textarea><div class="modal-buttons"><button class="btn-cancel" onclick="closeModal('interactionModalOverlay')">Cancel</button><button class="btn-save" onclick="saveInteractionEdits()">Save Interaction</button></div></div></div>

    <script src="js/admin-dashboard.js?v=<?php echo time(); ?>"></script>
    <script src="js/admin.js"></script>
</body>
</html>