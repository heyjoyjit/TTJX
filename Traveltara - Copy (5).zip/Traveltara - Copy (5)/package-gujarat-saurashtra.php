<?php
// Top of package-gujarat-saurashtra.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹24,000"; 
$sheet_affordable_price = "₹38,000";
$sheet_super_price = "₹62,000";

// EXACT package name from Google Sheet
$target_package = "Divine & Wild Coast 9D/8N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels & Beach Guesthouses</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Circuit</li>
            <li><i class="fa-solid fa-paw"></i> Shared Canter Safari in Gir National Park</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Sea-Facing Resorts & Jungle Lodges</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-camera"></i> Exclusive Open 4x4 Gypsy Safari in Gir</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Luxury Resorts (e.g., Fern Gir, Radisson Diu)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> VIP Temple Darshan Assistance & Premium Beach Cabanas</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining, Seafood Specials in Diu & Jungle BBQs</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Divine & Wild Coast 9 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="gujarat-itinerary.php">Gujarat</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Divine & Wild Coast (9D/8N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['saurashtra hero']) ? $tourImages['saurashtra hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 9 Days / 8 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Divine & Wild Coast</h1>
            <p>From the sacred temples of Dwarka and Somnath to the roar of Asiatic Lions in Gir.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Divine & Wild Coast 9D/8N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Explore the heart of the Saurashtra peninsula. Over 9 days, you will trace Gujarat's stunning western coastline, experiencing a profound mix of pilgrimage, wildlife, and history. Seek blessings at the legendary Dwarkadhish and Somnath temples, pay homage at Mahatma Gandhi's birthplace in Porbandar, track the majestic Asiatic Lion in Gir National Park, and unwind on the Portuguese-influenced beaches of Diu island.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Rajkot / Ahmedabad & Drive to Dwarka</h3>
                <p>Arrive at Rajkot Airport or Ahmedabad Airport. Your chauffeur will greet you and commence the drive to the holy city of Dwarka (approx. 4 to 7 hours depending on the arrival city), the ancient kingdom of Lord Krishna. Check into your hotel and spend a peaceful evening settling in.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Kingdom of Lord Krishna (Dwarka)</h3>
                <p>Begin your day with the deeply moving morning Darshan at the Dwarkadhish Temple. Later, take a short boat ride to Beyt Dwarka, the island believed to be the original residence of Lord Krishna. En route, visit the Nageshwar Jyotirlinga Temple, one of the 12 sacred Shiva shrines, and the Rukmini Devi Temple. Witness the sunset over the Gomti Ghat.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Dwarka to Somnath via Porbandar</h3>
                <p>Depart Dwarka and drive along the stunning coastal highway to Porbandar. Visit Kirti Mandir, the birthplace of Mahatma Gandhi. Continue your drive to the legendary temple town of Somnath. In the evening, attend the powerful Aarti at the Somnath Temple, situated right on the shores of the Arabian Sea, followed by the captivating Sound & Light show.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> The Coast to the Jungle: Somnath to Sasan Gir</h3>
                <p>Wake up for an optional morning Darshan at Somnath before driving to Sasan Gir (approx. 2 hours), the only natural habitat of the Asiatic Lion in the world. Check into your wilderness resort. Spend the afternoon relaxing by the pool or visiting the Crocodile Breeding Centre. Enjoy an evening of nature walks and a jungle-themed dinner.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Tracking the Asiatic Lion</h3>
                <p>Wake up before dawn for a thrilling morning jeep safari deep into the Gir National Park. Keep your cameras ready for lions, leopards, spotted deer, and a variety of birdlife. Return to your lodge for breakfast. After lunch, take a second afternoon safari to maximize your chances of spotting the king of the jungle.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Jungle to the Island: Sasan Gir to Diu</h3>
                <p>Bid farewell to the forest and drive down to the beautiful coastal enclave of Diu (approx. 2.5 hours). A former Portuguese colony, Diu offers a distinctly different vibe from the rest of Gujarat. Check into your beachside resort. Spend the afternoon unwinding on the golden sands of Nagoa Beach.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Portuguese Heritage & Caves (Diu Sightseeing)</h3>
                <p>Explore the massive Diu Fort, a 16th-century Portuguese citadel overlooking the sea, complete with cannons and a lighthouse. Visit the stunning St. Paul's Church and the intricate, naturally formed Naida Caves. Spend your evening enjoying water sports at Ghoghla Beach or simply relaxing with a sea-facing dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Diu to Junagadh / Rajkot</h3>
                <p>Depart from the island of Diu and drive inland towards Junagadh (approx. 3.5 hours). Visit the ancient Uparkot Fort, the mesmerizing gothic-Islamic architecture of Mahabat Maqbara, and the Ashoka Rock Edicts. Later, continue your drive to Rajkot to check into your hotel for your final night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Departure from Rajkot / Ahmedabad</h3>
                <p>Enjoy a final, relaxed breakfast. Depending on your flight schedule, you may explore the Watson Museum in Rajkot. Your chauffeur will provide a seamless transfer to the Rajkot Airport or drive you back to Ahmedabad Airport for your journey home, concluding your magnificent Saurashtra coast expedition.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels & Beach Guesthouses</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Circuit</li>
                <li><i class="fa-solid fa-paw"></i> Shared Canter Safari in Gir National Park</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/saurashtra-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- SAURASHTRA INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Coastal Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your journey through the holy temples and wild jungles of Gujarat is smooth and enriching.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Gir Park Closures</h3>
                <p>Wildlife tourism is heavily regulated:</p>
                <ul>
                    <li><strong>Monsoon Closure:</strong> Gir National Park is strictly closed from <strong>June 16th to October 15th</strong> every year. Safaris cannot be booked during this time.</li>
                    <li><strong>Winter/Spring:</strong> The best time to visit the region is between November and March for cool coastal weather.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-ticket"></i></div>
                <h3>Safari Permit Planning</h3>
                <p>Seeing the Asiatic Lion requires advance booking:</p>
                <ul>
                    <li><strong>Advance Booking:</strong> Government permits for the open gypsy safaris sell out weeks in advance. We must secure your permits early.</li>
                    <li><strong>Original IDs:</strong> Original government IDs (Aadhar, Passport) are mandatory and must match the booking details exactly to enter the forest gates.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Temple Etiquette & Security</h3>
                <p>Dwarka and Somnath have extremely strict security protocols:</p>
                <ul>
                    <li><strong>Electronics Ban:</strong> Mobile phones, cameras, smartwatches, and large bags are strictly prohibited inside the temple premises. You must deposit them in the official lockers outside.</li>
                    <li><strong>Dress Code:</strong> Modest dressing is mandatory. Shorts, sleeveless tops, and mini-skirts are not permitted inside the temples.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-martini-glass-citrus"></i></div>
                <h3>The Dry State Rule & Diu</h3>
                <p>Gujarat has unique laws regarding alcohol:</p>
                <ul>
                    <li><strong>Gujarat:</strong> Gujarat is a dry state. Alcohol is strictly prohibited. Tourists can obtain a temporary permit, but consumption is restricted to private hotel rooms.</li>
                    <li><strong>Diu Exception:</strong> Diu is a Union Territory. Alcohol is legally available and served in restaurants and beach shacks here.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Coastal Highways</h3>
                <p>The driving experience in Saurashtra is excellent:</p>
                <ul>
                    <li><strong>The Roads:</strong> The coastal highway connecting Dwarka to Porbandar to Somnath is incredibly scenic and generally very well maintained.</li>
                    <li><strong>Travel Times:</strong> Expect 4-6 hours of driving on most transition days. Sit back and enjoy the views of the Arabian Sea.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Delights</h3>
                <p>Saurashtra offers a brilliant mix of diets:</p>
                <ul>
                    <li><strong>Kathiyawadi Thali:</strong> In Dwarka and Somnath, enjoy the spicy, rich vegetarian Kathiyawadi cuisine (different from sweet Gujarati food).</li>
                    <li><strong>Diu Seafood:</strong> Diu offers an incredible shift in diet, featuring Portuguese-influenced seafood, prawns, and pomfret.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream coastal & wildlife escape.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Divine & Wild Coast 9D/8N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>