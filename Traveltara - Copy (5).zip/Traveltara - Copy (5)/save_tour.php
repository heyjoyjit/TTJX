<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') { http_response_code(200); exit(); }
header("Content-Type: application/json");

// YOUR HOSTINGER DATABASE CREDENTIALS
$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database Connection Failed"]));
}

$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

if (!$data) {
    echo json_encode(["status" => "error", "message" => "Invalid Request"]); exit;
}

$tourName = $conn->real_escape_string($data['tourName']);
$imageUrl = $conn->real_escape_string($data['imageUrl']);

// SAVE TO MYSQL (Assuming you created a 'tours' table)
$sql = "INSERT INTO tours (tour_name, image_url) VALUES ('$tourName', '$imageUrl')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Database save failed: " . $conn->error]);
}

$conn->close();
?>