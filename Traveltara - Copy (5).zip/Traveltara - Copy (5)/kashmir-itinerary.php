<?php
// Top of kashmir-itinerary.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹28,500"; 
$sheet_affordable_price = "₹42,000";
$sheet_super_price = "₹65,000";

// EXACT package name from Google Sheet
$target_package = "Kashmir 10D/9N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 3-Star Boutique Stays & Houseboat</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan / Tavera</li>
            <li><i class="fa-solid fa-camera"></i> Complete Sightseeing Tour</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast & Dinner</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 4-Star Premium Resorts & Nigeen Houseboat</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-ticket"></i> Phase 1 Gondola Tickets Included</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dining</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Properties (e.g., Khyber, Taj)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-gem"></i> VIP Union Taxis & Priority Passes</li>
            <li><i class="fa-solid fa-utensils"></i> Exclusive Culinary Experiences</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kashmir Grand Tour | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* ==========================================================================
           COMPLETELY NEW DESIGN: DESTINATION HUB (GRID CARDS)
           ========================================================================== */
        .info-hub-section {
            background: #f9fafb;
            border-top: 1px solid #eaeaea;
            padding: 80px 0;
        }
        .info-hub-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .info-card {
            background: #fff;
            border-radius: 12px;
            padding: 35px 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            border-top: 5px solid #C5A059;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .info-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.08);
        }
        .info-icon-wrapper {
            width: 60px;
            height: 60px;
            background: rgba(197, 160, 89, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        .info-icon-wrapper i {
            font-size: 1.5rem;
            color: #C5A059;
        }
        .info-card h3 {
            font-family: 'Playfair Display', serif;
            font-size: 1.4rem;
            color: #0A1128;
            margin-bottom: 15px;
        }
        .info-card p, .info-card li {
            font-family: 'Lato', sans-serif;
            font-size: 0.95rem;
            color: #555;
            line-height: 1.6;
        }
        .info-card ul {
            padding-left: 18px;
            margin-top: 10px;
        }
        .info-card li {
            margin-bottom: 8px;
        }
    </style>
</head>
<body>

    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Kashmir Grand Tour (10D/9N)</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['kashmir hero']) ? $tourImages['kashmir hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 10 Days / 9 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Kashmir Grand Tour</h1>
            <p>An immersive journey across Dal Lake, golden meadows, and alpine peaks.</p>
        </div>
    </header>
    
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Kashmir 10D/9N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Prepare for a captivating 10-day exploration of the Kashmir Valley. We have designed this route to offer an unhurried, deeply cultural, and visually spectacular adventure. From the historic streets of Srinagar to the high-altitude gondolas of Gulmarg, and the cinematic riversides of Pahalgam, every day presents a new facet of Paradise.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Welcome to Srinagar</h3>
                <p>Arrive at the Srinagar Airport where our team will receive you. Transfer to your luxury hotel and spend your first afternoon soaking in the mountain atmosphere. In the evening, visit a local café or take a light stroll near Dal Lake to adjust to the altitude.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Heritage & The Grand Shikara</h3>
                <p>Delve into Kashmir's rich history. Visit the exquisite terraced Mughal Gardens—Nishat Bagh (Garden of Joy) and Shalimar Bagh (Abode of Love). Seek panoramic valley views from the Shankaracharya Temple. As the sun begins to set, glide across Dal Lake in a private Shikara, exploring floating markets.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Glaciers of Sonmarg</h3>
                <p>Depart early for a day excursion to Sonmarg, renowned for its golden meadows and towering peaks. Follow the Sindh River to the base of the Thajiwas Glacier. Enjoy an optional pony ride through the alpine trails before returning to your hotel in Srinagar.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Journey to the Valley of Shepherds</h3>
                <p>Leave Srinagar behind and drive toward Pahalgam. This stunning route passes through the historic Awantipora ruins and the famous saffron fields of Pampore. Arrive in Pahalgam, check into your riverside resort, and listen to the soothing sounds of the Lidder River.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Pahalgam's Alpine Wonders</h3>
                <p>Switch to a local union vehicle to explore Pahalgam's legendary valleys. Wander through the lush, cinematic Betaab Valley, capture the scenic beauty of Aru Valley, and witness the rugged, snow-dusted landscapes of Chandanwari. Return to the resort for a warm dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Baisaran Valley & Leisure</h3>
                <p>Enjoy a slow morning. Today, you have the option to take a thrilling pony trek up to Baisaran Valley, famously dubbed "Mini Switzerland" for its dense pine forests and rolling meadows. The rest of the afternoon is yours to relax.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Transfer to Gulmarg</h3>
                <p>Bid farewell to Pahalgam and travel to the majestic heights of Gulmarg. As you ascend, the landscape transforms into dense forests of tall conifers. Arrive at the "Meadow of Flowers," check into your premium resort, and enjoy the crisp, alpine evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> The Epic Gondola Ride</h3>
                <p>Board the famous Gulmarg Gondola (Asia's largest and highest cable car). Ascend to Phase 1 (Kongdoori) or Phase 2 (Apharwat Peak) for unparalleled views of the Himalayas. The afternoon is free for photography, ATV rides, or simply enjoying the pristine environment.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Floating Luxury in Srinagar</h3>
                <p>Drive back to Srinagar and conclude your grand tour with a signature Kashmiri experience: staying on a traditional Houseboat. Marvel at the intricate cedar wood carvings, enjoy legendary hospitality, and sleep gently on the waters of Nigeen or Dal Lake.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Farewell to Paradise</h3>
                <p>After a beautiful breakfast on the water, pack your bags and memories. Your chauffeur will provide a seamless transfer to the Srinagar Airport for your journey back home.</p>
            </div>
        </div>

        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> 3-Star Boutique Stays & Houseboat</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan / Tavera</li>
                <li><i class="fa-solid fa-camera"></i> Complete Sightseeing Tour</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast & Dinner</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/kashmir-10d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Destination Intelligence</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Kashmir Travel Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Everything you need to know to plan your journey perfectly, from seasonal shifts to local operational rules.</p>
        </div>

        <div class="info-hub-grid">
            
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-cloud-sun"></i></div>
                <h3>Seasonal Rhythms</h3>
                <p>The Kashmir valley transforms completely based on when you visit. Here is what to expect:</p>
                <ul>
                    <li><strong>Spring (Apr-May):</strong> Floral blooms, cool breezes, and snow at high altitudes.</li>
                    <li><strong>Summer (Jun-Aug):</strong> Deep green valleys and flowing rivers. Highly accessible.</li>
                    <li><strong>Autumn (Sep-Oct):</strong> The premium season. Golden Chinar trees, clear skies, and absolute serenity.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-snowflake"></i></div>
                <h3>Winter Closures</h3>
                <p><strong>From November to March</strong>, the geography shifts drastically due to heavy snowfall. Please note the following closures:</p>
                <ul>
                    <li><strong>Sonmarg is fully closed</strong> due to avalanche risks.</li>
                    <li>Roads to offbeat locations like Yusmarg remain blocked.</li>
                    <li>Gulmarg becomes a ski-only zone requiring chained 4x4 vehicles.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-masks-theater"></i></div>
                <h3>Festivals & Magic</h3>
                <p>Time your trip to witness Kashmir's unique cultural and natural phenomenons:</p>
                <ul>
                    <li><strong>Tulip Festival (April):</strong> Witness millions of tulips in full bloom overlooking Dal Lake.</li>
                    <li><strong>Saffron Harvest (Late Oct):</strong> See the purple saffron fields of Pampore come alive.</li>
                    <li><strong>Snow Festival (Winter):</strong> Gulmarg hosts winter sports and local festivities.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-taxi"></i></div>
                <h3>Operational Rules</h3>
                <p>To preserve local employment, Kashmir enforces strict transport regulations:</p>
                <ul>
                    <li><strong>Pahalgam Local Union:</strong> Your main cab cannot take you to Aru or Betaab valley. You must switch to a local union taxi.</li>
                    <li><strong>Gulmarg Gondola:</strong> Tickets are strictly online and sell out fast. Pre-booking is mandatory.</li>
                    <li><strong>Pony Rides:</strong> Rates in Gulmarg and Pahalgam fluctuate; brief negotiation is standard.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-tower-cell"></i></div>
                <h3>Network & Comms</h3>
                <p>Stay connected by keeping these strict regional telecommunication rules in mind:</p>
                <ul>
                    <li><strong>Prepaid Restrictions:</strong> Non-J&K prepaid mobile connections will <strong>not</strong> work anywhere in Kashmir.</li>
                    <li><strong>Postpaid is Key:</strong> Bring a Postpaid Airtel, Jio, or BSNL SIM for reliable coverage.</li>
                    <li><strong>Wi-Fi:</strong> Premium hotels provide excellent Wi-Fi, but offbeat valleys may lack signal entirely.</li>
                </ul>
            </div>

            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-mug-hot"></i></div>
                <h3>Culinary Expectations</h3>
                <p>Prepare your tastebuds for the authentic, rich flavors of the mountain valley:</p>
                <ul>
                    <li><strong>Wazwan:</strong> The traditional multi-course Kashmiri feast (highly recommended for non-vegetarians).</li>
                    <li><strong>Kahwa:</strong> The signature saffron and almond-infused green tea that keeps you warm.</li>
                    <li><strong>Dietary Needs:</strong> Pure vegetarian and Jain food is readily available across all our premium hotel partners.</li>
                </ul>
            </div>

        </div>
    </section>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Kashmir 10D/9N" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>