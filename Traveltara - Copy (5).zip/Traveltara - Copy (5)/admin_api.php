<?php
session_start();

// 1. SECURITY WALL
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(403);
    die(json_encode(["status" => "error", "message" => "Unauthorized access."]));
}

// 2. SECURE DATABASE CONNECTION
$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";   
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed."]));
}

// 🚀 FORCE INDIAN STANDARD TIME (IST) FOR ALL TIMESTAMPS
date_default_timezone_set('Asia/Kolkata');
$conn->query("SET time_zone = '+05:30'");

$allowed_tables = ['master_crm', 'bookings', 'interactions', 'pricing', 'coupons'];

// ==========================================
// 🟢 EXPORT LOGIC (CSV/EXCEL DOWNLOAD)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'export') {
    $table = $_GET['table'];
    if (!in_array($table, $allowed_tables)) die("Invalid table name.");

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $table . '_export_' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    $result = $conn->query("SELECT * FROM `$table`");
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        fputcsv($output, array_keys($row));
        fputcsv($output, $row); 
        while ($row = $result->fetch_assoc()) { fputcsv($output, $row); }
    } else {
        fputcsv($output, ['No data found']);
    }
    fclose($output);
    exit();
}

// ==========================================
// 🔵 CRASH-PROOF IMPORT LOGIC (CSV UPLOAD)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'import') {
    header("Content-Type: application/json");
    $table = $_POST['table'];
    
    if (!in_array($table, $allowed_tables)) { echo json_encode(["status" => "error", "message" => "Invalid table."]); exit(); }
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) { echo json_encode(["status" => "error", "message" => "Upload failed."]); exit(); }

    $fileTmpName = $_FILES['file']['tmp_name'];
    $handle = fopen($fileTmpName, 'r');
    
    if ($handle !== false) {
        $headers = fgetcsv($handle); 
        if (!$headers) { echo json_encode(["status" => "error", "message" => "Empty CSV file."]); exit(); }
        
        $headers[0] = preg_replace('/^\xEF\xBB\xBF/', '', $headers[0]);
        $headers = array_map('trim', $headers);

        $successCount = 0; $errorCount = 0;
        $lastError = "";

        while (($data = fgetcsv($handle)) !== false) {
            if (count($headers) !== count($data)) continue; 
            
            $row = array_combine($headers, $data);
            $cols = []; $vals = []; $updates = [];
            
            foreach ($row as $col => $val) {
                if(empty($col)) continue; 
                
                $escCol = "`" . $conn->real_escape_string($col) . "`";
                $escVal = "'" . $conn->real_escape_string($val) . "'";
                $cols[] = $escCol; 
                $vals[] = $escVal;
                
                if ($col !== 'Phone Number' && $col !== 'Booking ID' && $col !== 'id') { 
                    $updates[] = "$escCol = $escVal";
                }
            }

            if (empty($cols)) continue;

            $colStr = implode(", ", $cols);
            $valStr = implode(", ", $vals);
            $updateStr = implode(", ", $updates);

            $sql = empty($updateStr) 
                ? "INSERT IGNORE INTO `$table` ($colStr) VALUES ($valStr)"
                : "INSERT INTO `$table` ($colStr) VALUES ($valStr) ON DUPLICATE KEY UPDATE $updateStr";

            try {
                if ($conn->query($sql)) $successCount++; 
                else { $errorCount++; $lastError = $conn->error; }
            } catch (Exception $e) {
                $errorCount++; $lastError = $e->getMessage();
            }
        }
        fclose($handle);
        
        if ($errorCount > 0 && $successCount === 0) echo json_encode(["status" => "error", "message" => "Import failed. Mismatched columns. Database says: " . $lastError]);
        else echo json_encode(["status" => "success", "message" => "Imported/Updated $successCount rows. Failed: $errorCount. " . ($lastError ? "Last error: $lastError" : "")]);
    } else {
        echo json_encode(["status" => "error", "message" => "Could not open file."]);
    }
    exit();
}

// ==========================================
// 🟣 LIVE EDIT, ADD & DELETE LOGIC
// ==========================================
header("Content-Type: application/json");
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

if (!$data || !isset($data['action'])) {
    echo json_encode(["status" => "error", "message" => "Invalid payload."]); exit();
}

$action = $data['action'];

if ($action === 'delete_record') {
    $table = $conn->real_escape_string($data['table']);
    $id = $conn->real_escape_string($data['id']);
    
    if (in_array($table, $allowed_tables)) {
        if ($conn->query("DELETE FROM `$table` WHERE id = '$id'")) echo json_encode(["status" => "success"]);
        else echo json_encode(["status" => "error", "message" => "Delete failed: " . $conn->error]);
    }
    exit();
}

// --- NEW: BULK GENERATE COUPONS ---
if ($action === 'generate_coupons') {
    $count = (int)$data['count'];
    $discount = $conn->real_escape_string($data['discount']);
    
    if ($count <= 0 || $count > 500) {
        echo json_encode(["status" => "error", "message" => "Please enter a valid count (1-500)."]); exit();
    }
    
    $success = 0;
    for ($i = 0; $i < $count; $i++) {
        // Generate a random 6-character alphanumeric string
        $randomStr = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6));
        $code = "TARA-" . $randomStr;
        
        $query = "INSERT INTO coupons (`Coupon Code`, `Discount (%)`, `Status`, `Used By Booking ID`) VALUES ('$code', '$discount', 'Active', '')";
        if ($conn->query($query)) $success++;
    }
    echo json_encode(["status" => "success", "message" => "Successfully generated $success unique coupons."]);
    exit();
}

// --- NEW: DELETE ALL COUPONS ---
if ($action === 'delete_all_coupons') {
    if ($conn->query("TRUNCATE TABLE coupons")) {
        echo json_encode(["status" => "success", "message" => "All coupons have been permanently deleted."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Delete failed: " . $conn->error]);
    }
    exit();
}

if ($action === 'save_pricing') {
    $id = $conn->real_escape_string($data['id']);
    $package = $conn->real_escape_string($data['package']);
    $budget = $conn->real_escape_string($data['budget']);
    $affordable = $conn->real_escape_string($data['affordable']);
    $super = $conn->real_escape_string($data['super']);
    
    if (empty($id)) $query = "INSERT INTO pricing (`Package Name`, `Budget`, `Affordable Luxury`, `Super Luxury`) VALUES ('$package', '$budget', '$affordable', '$super')";
    else $query = "UPDATE pricing SET `Package Name` = '$package', `Budget` = '$budget', `Affordable Luxury` = '$affordable', `Super Luxury` = '$super' WHERE id = '$id'";
    
    if ($conn->query($query)) echo json_encode(["status" => "success"]); 
    else echo json_encode(["status" => "error"]);
    exit();
}

if ($action === 'save_coupon') {
    $id = $conn->real_escape_string($data['id']);
    $code = $conn->real_escape_string($data['code']);
    $discount = $conn->real_escape_string($data['discount']);
    $status = $conn->real_escape_string($data['status']);
    $usedBy = $conn->real_escape_string($data['usedBy']);
    
    if (empty($id)) $query = "INSERT INTO coupons (`Coupon Code`, `Discount (%)`, `Status`, `Used By Booking ID`) VALUES ('$code', '$discount', '$status', '$usedBy')";
    else $query = "UPDATE coupons SET `Coupon Code` = '$code', `Discount (%)` = '$status', `Status` = '$status', `Used By Booking ID` = '$usedBy' WHERE id = '$id'";
    
    if ($conn->query($query)) echo json_encode(["status" => "success"]); 
    else echo json_encode(["status" => "error"]);
    exit();
}

// Existing CRM & Interaction Logic...
if ($action === 'update_crm') {
    $phone = $conn->real_escape_string($data['phone']);
    $name = $conn->real_escape_string($data['name']);
    $email = $conn->real_escape_string($data['email']);
    $status = $conn->real_escape_string($data['status']);
    $clientType = $conn->real_escape_string($data['clientType']);
    $interest = $conn->real_escape_string($data['interest']);
    $query = "UPDATE master_crm SET `Name` = '$name', `Email Address` = '$email', `Action Status` = '$status', `Client Type` = '$clientType', `Latest Interest` = '$interest' WHERE `Phone Number` = '$phone'";
    if ($conn->query($query)) echo json_encode(["status" => "success"]); else echo json_encode(["status" => "error"]);

} elseif ($action === 'update_interaction') {
    $id = $conn->real_escape_string($data['id']);
    $phone = $conn->real_escape_string($data['phone']);
    $source = $conn->real_escape_string($data['source']);
    $extName = $conn->real_escape_string($data['extName']);
    $extEmail = $conn->real_escape_string($data['extEmail']);
    $transcript = $conn->real_escape_string($data['transcript']);
    $query = "UPDATE interactions SET `Phone Number` = '$phone', `Source` = '$source', `Extracted Name` = '$extName', `Extracted Email` = '$extEmail', `Exact Message / Details` = '$transcript' WHERE `id` = '$id'";
    if ($conn->query($query)) echo json_encode(["status" => "success"]); else echo json_encode(["status" => "error"]);
    
// --- UPDATED MASTER BOOKING CATCHER (FOR POS & DASHBOARD) ---
} elseif ($action === 'update_booking' || $action === 'create_pos_booking') {
    
    // Safely extract ALL 27 possible fields from the POS or Dashboard
    $bookingId = $conn->real_escape_string($data['bookingId'] ?? '');
    $prefix = $conn->real_escape_string($data['prefix'] ?? '');
    $fName = $conn->real_escape_string($data['fName'] ?? '');
    $mName = $conn->real_escape_string($data['mName'] ?? '');
    $lName = $conn->real_escape_string($data['lName'] ?? '');
    $phone = $conn->real_escape_string($data['phone'] ?? '');
    $altPhone = $conn->real_escape_string($data['altPhone'] ?? '');
    $email = $conn->real_escape_string($data['email'] ?? '');
    $resAddress = $conn->real_escape_string($data['resAddress'] ?? '');
    $permAddress = $conn->real_escape_string($data['permAddress'] ?? '');
    $offAddress = $conn->real_escape_string($data['offAddress'] ?? '');
    $delAddress = $conn->real_escape_string($data['delAddress'] ?? '');
    $aadhaar = $conn->real_escape_string($data['aadhaar'] ?? '');
    $tourType = $conn->real_escape_string($data['tourType'] ?? '');
    $passport = $conn->real_escape_string($data['passport'] ?? '');
    $dest = $conn->real_escape_string($data['dest'] ?? '');
    $commDate = $conn->real_escape_string($data['commDate'] ?? '');
    $tier = $conn->real_escape_string($data['tier'] ?? '');
    $adults = (int)($data['adults'] ?? 0);
    $children = (int)($data['children'] ?? 0);
    $rooms = (int)($data['rooms'] ?? 0);
    $totalPaid = $conn->real_escape_string($data['totalPaid'] ?? '');
    $paymentRef = $conn->real_escape_string($data['paymentRef'] ?? '');
    $invoiceNo = $conn->real_escape_string($data['invoiceNo'] ?? '');
    $couponUsed = $conn->real_escape_string($data['couponUsed'] ?? '');
    $status = $conn->real_escape_string($data['status'] ?? 'Pending');

    if ($action === 'create_pos_booking') {
        // If coming from POS as a new booking
        if(empty($bookingId)) {
             $bookingId = 'TRV-POS-' . strtoupper(substr(md5(time()), 0, 5));
        }
        $query = "INSERT INTO bookings (`Booking ID`, `Prefix`, `First Name`, `Middle Name`, `Last Name`, `Primary Phone`, `Alt Phone`, `Email`, `Residential Address`, `Permanent Address`, `Office Address`, `Delivery Address`, `Aadhaar Number`, `Tour Type (Dom/Int)`, `Passport No`, `Destination`, `Commencement Date`, `Tour Tier`, `Adults`, `Children`, `Rooms`, `Total Paid`, `Payment Ref ID`, `Invoice No`, `Coupon Used`, `Status`) 
                  VALUES ('$bookingId', '$prefix', '$fName', '$mName', '$lName', '$phone', '$altPhone', '$email', '$resAddress', '$permAddress', '$offAddress', '$delAddress', '$aadhaar', '$tourType', '$passport', '$dest', '$commDate', '$tier', '$adults', '$children', '$rooms', '$totalPaid', '$paymentRef', '$invoiceNo', '$couponUsed', '$status')";
    } else {
        // If updating an existing booking from the dashboard
        $query = "UPDATE bookings SET 
                  `Prefix` = '$prefix', `First Name` = '$fName', `Middle Name` = '$mName', `Last Name` = '$lName', 
                  `Primary Phone` = '$phone', `Alt Phone` = '$altPhone', `Email` = '$email', 
                  `Residential Address` = '$resAddress', `Permanent Address` = '$permAddress', `Office Address` = '$offAddress', `Delivery Address` = '$delAddress', 
                  `Aadhaar Number` = '$aadhaar', `Tour Type (Dom/Int)` = '$tourType', `Passport No` = '$passport', 
                  `Destination` = '$dest', `Commencement Date` = '$commDate', `Tour Tier` = '$tier', 
                  `Adults` = '$adults', `Children` = '$children', `Rooms` = '$rooms', 
                  `Total Paid` = '$totalPaid', `Payment Ref ID` = '$paymentRef', `Invoice No` = '$invoiceNo', `Coupon Used` = '$couponUsed', `Status` = '$status' 
                  WHERE `Booking ID` = '$bookingId'";
    }

    if ($conn->query($query)) {
        echo json_encode(["status" => "success", "bookingId" => $bookingId]);
    } else {
        echo json_encode(["status" => "error", "message" => $conn->error]);
    }
}
$conn->close();
?>