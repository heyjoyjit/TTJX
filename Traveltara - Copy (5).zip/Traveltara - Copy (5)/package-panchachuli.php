<?php
// Top of package-panchachuli.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹22,000"; 
$sheet_affordable_price = "₹35,000";
$sheet_super_price = "₹55,000";

// EXACT package name from Google Sheet
$target_package = "Panchachuli Base Camp 9D/8N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Basic Guesthouses & Clean Alpine Homestays</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Non-AC SUV (Sumo/Bolero) for Darma Valley</li>
            <li><i class="fa-solid fa-person-hiking"></i> Local Trekking Guide Included</li>
            <li><i class="fa-solid fa-utensils"></i> All Meals Included During the Trek (Simple Veg)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 3/4-Star Hotels (Basecamps) & Best Available Swiss Tents</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta + Private 4x4 Bolero for Extreme Terrain</li>
            <li><i class="fa-solid fa-star"></i> Permits, Porters & Expert Mountaineering Guide</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners & Packed High-Energy Trek Meals</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Top-Tier Luxury Resorts (Basecamps) & Premium Glamping Tents</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) + Customized 4x4 Expedition Vehicle</li>
            <li><i class="fa-solid fa-crown"></i> VIP Support, Oxygen Backup & Private Bonfires</li>
            <li><i class="fa-solid fa-utensils"></i> Premium Vegetarian Fine Dining & Custom Expedition Menu</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panchachuli Base Camp 9 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="uttarakhand-itinerary.php">Uttarakhand</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Panchachuli Base Camp (9D/8N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['panchachuli hero']) ? $tourImages['panchachuli hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 9 Days / 8 Nights</div>
        <div class="subpage-hero-content">
            <h1>Panchachuli Base Camp</h1>
            <p>Journey into the heart of the Darma Valley to witness the magnificent five peaks of Panchachuli.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Panchachuli Base Camp 9D/8N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Prepare for an offbeat, deeply rewarding expedition into the Darma Valley. The Panchachuli Base Camp trek offers an incredible mix of rugged 4x4 mountain driving, vibrant alpine meadows, dense forests of birch and rhododendron, and authentic interactions with the local Bhotia tribes. The ultimate reward is standing at the edge of the glacier, completely dwarfed by the majestic five snow-capped peaks of the Panchachuli range.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Kathgodam & Drive to Almora / Chaukori</h3>
                <p>Your expedition begins at Pantnagar Airport or Kathgodam Railway Station. Your chauffeur will warmly welcome you and begin the scenic drive into the Kumaon hills. Depending on your arrival time, you will stay overnight in either the cultural hub of Almora or the serene, tea-garden hamlet of Chaukori. Check into your hotel and rest.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Gateway to Darma Valley: Drive to Dharchula</h3>
                <p>After breakfast, embark on a beautiful drive along the Kali River, which acts as the natural border between India and Nepal. Arrive in the bustling border town of Dharchula (approx. 4-5 hours). Today, your guide will assist you in securing your Inner Line Permits (ILP) required for the border regions. Check into your hotel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Dharchula to Dar via 4x4 & Trek to Urthing</h3>
                <p>Leave your standard vehicle in Dharchula and switch to a rugged 4x4. Drive deep into the dramatic gorges of the Darma Valley up to the village of Dar. From Dar, your actual trek begins! Walk along a beautiful, gradually ascending trail to the small settlement of Urthing (approx. 5 km). Overnight in a basic trekking tent or local homestay.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Trek from Urthing to Nangling</h3>
                <p>Wake up to crisp mountain air. Today’s trek takes you higher through dense forests of birch and rhododendron, accompanied by the roaring sound of the Dhauliganga River. You will cross stunning wooden bridges and pass plunging waterfalls before arriving at the scenic village of Nangling (approx. 8 km). Camp overnight under a canopy of stars.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Nangling to the Base Villages: Son & Duktu</h3>
                <p>The landscape changes dramatically today as you leave the tree line behind and enter the alpine zone. Trek through the vibrant, high-altitude meadows (bugyals) toward the twin villages of Son and Duktu (approx. 10 km). As you approach Duktu, the colossal Panchachuli peaks will finally reveal themselves in all their glory. Check into your base camp.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Climax: Panchachuli Base Camp (Zero Point)</h3>
                <p>Wake up before dawn. Trek from Duktu through a breathtaking meadow directly to the Panchachuli Glacier / Zero Point (approx. 4 km one way). Stand in absolute awe as the five towering peaks (ranging from 6,334m to 6,904m) loom directly above you, representing the five cooking hearths (Chulhas) of the Pandavas. After spending ample time soaking in the views, return to Duktu for the night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Descent: Duktu to Dar & Drive to Dharchula</h3>
                <p>Bid farewell to the magnificent peaks. With the downhill advantage, trek rapidly back down the valley from Duktu, passing through Nangling and Urthing, all the way back to the road head at Dar. Reconnect with your 4x4 vehicle and drive back to the comforts of Dharchula. Check into your hotel for a much-needed hot shower.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Dharchula to the Lake District (Nainital / Bhimtal)</h3>
                <p>Transfer back to your luxury SUV or Sedan. Begin the long, reflective descent out of the extreme Himalayas, driving back through the Kumaon region toward the beautiful lake district of Nainital or Bhimtal (approx. 8-9 hours). Check into your premium resort and enjoy a celebratory farewell dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Departure from Kathgodam</h3>
                <p>Enjoy a final, relaxed breakfast overlooking the lakes. Depending on your travel schedule, you may do some quick local sightseeing or shopping. Your chauffeur will provide a seamless 1-hour drive down to Kathgodam Railway Station or Pantnagar Airport, concluding your extraordinary Panchachuli expedition.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Basic Guesthouses & Clean Alpine Homestays</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Non-AC SUV (Sumo/Bolero) for Darma Valley</li>
                <li><i class="fa-solid fa-person-hiking"></i> Local Trekking Guide Included</li>
                <li><i class="fa-solid fa-utensils"></i> All Meals Included During the Trek (Simple Veg)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/panchachuli-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- EXPEDITION INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Darma Valley Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your trek to the Panchachuli glacier is safe, compliant, and comfortable.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Trekking Window</h3>
                <p>The Darma Valley is inaccessible for half the year:</p>
                <ul>
                    <li><strong>Pre-Monsoon (May - June):</strong> Excellent weather, though you will still find significant snow patches near the glacier.</li>
                    <li><strong>Post-Monsoon (Sep - Oct):</strong> The absolute best time. The skies are crystal clear, offering razor-sharp views of the Panchachuli peaks.</li>
                    <li><strong>Closed:</strong> The route is buried in snow and closed from November to April.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-person-hiking"></i></div>
                <h3>Trek Difficulty & Fitness</h3>
                <p>Panchachuli is a moderate to difficult trek:</p>
                <ul>
                    <li><strong>The Terrain:</strong> While the gradients are not as punishing as the Panch Kedar treks, the distances are long (up to 12 km a day).</li>
                    <li><strong>Preparation:</strong> Good cardiovascular fitness and stamina are required. Start jogging or stair-climbing at least a month prior.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-id-card"></i></div>
                <h3>Inner Line Permits (ILP)</h3>
                <p>The Darma Valley is highly restricted:</p>
                <ul>
                    <li><strong>Mandatory Documents:</strong> You must carry original government IDs (Aadhar/Passport) and passport-sized photos. Your guide will process the ILP at the SDM office in Dharchula.</li>
                    <li><strong>Foreign Nationals:</strong> Face stricter scrutiny and must apply for specific border permits well in advance.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bed"></i></div>
                <h3>Accommodation Reality</h3>
                <p>Luxury ends at Dharchula:</p>
                <ul>
                    <li><strong>Homestays & Tents:</strong> In villages like Urthing, Nangling, and Duktu, you will be staying in highly basic Bhotia homestays or alpine trekking tents.</li>
                    <li><strong>Amenities:</strong> Expect no running hot water or western toilets in the higher camps. Embrace the raw expedition lifestyle.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-wifi"></i></div>
                <h3>Total Network Blackout</h3>
                <p>Prepare for a complete digital detox:</p>
                <ul>
                    <li><strong>No Signal:</strong> Beyond Dharchula, mobile network coverage drops to zero. You will be off the grid for the entire 5-day trekking duration.</li>
                    <li><strong>Emergencies:</strong> Our premium expedition leaders carry emergency communication devices, and the local ITBP camps have satellite phones.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Weather & Survival Gear</h3>
                <p>Glacial winds are unforgiving:</p>
                <ul>
                    <li><strong>Temperatures:</strong> Nighttime temperatures at Duktu (Base Camp) drop below freezing, even in May.</li>
                    <li><strong>Essentials:</strong> A high-quality (-10°C) sleeping bag (provided in premium tiers), heavy thermal innerwear, down jackets, and waterproof trekking boots are mandatory.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your extreme Panchachuli expedition.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Panchachuli Base Camp 9D/8N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>