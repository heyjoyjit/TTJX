<?php
// Top of package-swiss-luxury-11d.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹3,15,000"; 
$sheet_affordable_price = "₹5,20,000";
$sheet_super_price = "₹9,50,000";

// EXACT package name from Google Sheet
$target_package = "The Ultimate Swiss Luxury Tour 11D/10N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'PREMIUM CLASS - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 4-Star Superior Hotels in Prime City/Alpine Locations</li>
            <li><i class="fa-solid fa-train"></i> 1st Class Swiss Travel Pass Included</li>
            <li><i class="fa-solid fa-ticket"></i> Premium Access to Jungfraujoch & Gornergrat</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Gourmet Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => '5-STAR LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Iconic 5-Star Heritage Hotels (e.g., Victoria-Jungfrau)</li>
            <li><i class="fa-solid fa-car"></i> Mercedes S-Class Chauffeur Transfers between Major Cities</li>
            <li><i class="fa-solid fa-wine-glass"></i> Private Wine Tasting in Lavaux & VIP Gondola Rides</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast + 3 Pre-Booked Fine Dining Experiences</li>
        '
    ],
    'super' => [
        'label' => 'ULTRA VIP / ROYAL - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Superior Signature Suites (e.g., Badrutt\'s Palace, The Alpina Gstaad)</li>
            <li><i class="fa-solid fa-helicopter"></i> Private Scenic Helicopter Transfers Across the Alps</li>
            <li><i class="fa-solid fa-crown"></i> "Excellence Class" on the Glacier Express & VIP Airport Meet-and-Greet</li>
            <li><i class="fa-solid fa-utensils"></i> Michelin-Star Dining, Private Lakeside Chef, and Champagne Brunches</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Ultimate Swiss Luxury Tour 11 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="europe-itinerary.php">Europe Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Ultimate Swiss Luxury (11D/10N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['swiss luxury 11d hero']) ? $tourImages['swiss luxury 11d hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 11 Days / 10 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Grand Ultimate Swiss Luxury</h1>
            <p>11 unhurried days of absolute perfection. Helicopter transfers over the Alps, Excellence Class panoramic trains, world-class spas, and Michelin-star dining.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Ultimate Swiss Luxury Tour 11D/10N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>This 11-day grand tour is meticulously crafted for the world's most discerning travelers. By extending the journey, we ensure relaxed, multi-night stays at the finest properties in Europe. We have replaced the crowds and queues with private, white-glove services. You will be whisked from the tarmac at Zurich airport directly to your hotel, soar over the glaciers in a private helicopter to Zermatt, ride the highly exclusive "Excellence Class" carriage on the Glacier Express, and stay in the iconic suites of Switzerland's finest historic palace hotels in St. Moritz, Zermatt, Interlaken, Gstaad, and Geneva.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> VIP Arrival in Zurich & Private Yacht</h3>
                <p>Arrive at Zurich Airport (ZRH). Experience VIP Airport Meet & Greet services right at the aircraft door, fast-tracking you through immigration and customs. Your private chauffeur will transfer you to the legendary Dolder Grand hotel (or similar 5-star superior) overlooking the city. In the afternoon, board a private luxury yacht for a sun-drenched cruise on Lake Zurich, complete with champagne and caviar. Enjoy a Michelin-star welcome dinner in the city center.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Alpine Drive to St. Moritz</h3>
                <p>After a gourmet breakfast, your chauffeur will drive you through the spectacular Julier Pass—one of the most scenic alpine roads in the world—arriving in the glitzy resort town of St. Moritz. Check into the iconic Badrutt’s Palace Hotel or the Kulm Hotel, the historic playgrounds of royals and celebrities. Spend the afternoon taking a private, romantic horse-drawn carriage ride into the secluded Val Roseg valley, stopping for afternoon tea.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Engadine Valley at Leisure</h3>
                <p>Today is a day to immerse yourself in the luxurious lifestyle of St. Moritz. Indulge in a late breakfast overlooking the lake. Enjoy a private guided tour of the stunning Engadine Valley, taking the funicular up to Muottas Muragl for a spectacular panoramic view and a gourmet lunch at 2,456 meters. Spend the afternoon shopping at the ultra-high-end boutiques on Via Serlas, or relaxing in your hotel's world-class Alpine Spa.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> The Excellence Class: Glacier Express to Zermatt</h3>
                <p>Today features the most exclusive train ride in Europe. Board the Glacier Express and step into "Excellence Class"—a premium carriage with guaranteed window seating, an exclusive bar, and a dedicated concierge. As you traverse the spectacular Rhine Gorge and the 2,033m Oberalp Pass, enjoy a 5-course gourmet menu with paired regional wines served at your seat. Arrive in the car-free village of Zermatt and check into the Mont Cervin Palace or The Omnia.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Private Matterhorn Excursion & Spa</h3>
                <p>Bypass the crowds with a private guide for your ascent to the Matterhorn Glacier Paradise, the highest cable car station in Europe (3,883m). Sip champagne in a VIP crystal gondola on the way up. Enjoy private access to the glacier viewing platforms before descending. Spend the afternoon rejuvenating in your hotel's world-class wellness spa, followed by an exclusive dining experience overlooking the illuminated village.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Helicopter Transfer over the Alps to Interlaken</h3>
                <p>Check out and experience the absolute thrill of a private helicopter transfer from Zermatt directly to the Bernese Oberland. Soar right past the peak of the Matterhorn, over the massive Aletsch Glacier, and land near Interlaken. A chauffeur will transfer you to the historic Victoria-Jungfrau Grand Hotel & Spa. Enjoy a private boat charter on the emerald waters of Lake Thun in the late afternoon.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Platinum Access: Jungfraujoch</h3>
                <p>Experience the "Top of Europe" with unparalleled privacy. You will be escorted onto the Eiger Express VIP Gondola, arriving at Jungfraujoch with access to the exclusive Platinum Lounge. Avoid the public areas as your guide shows you the Ice Palace and the Sphinx Observatory. Enjoy a private gourmet lunch at the summit before descending back to Interlaken for an evening of luxury casino entertainment or fine dining.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> The GoldenPass to Gstaad</h3>
                <p>Your chauffeur will drive you (or you may take the ultra-premium Prestige Class on the GoldenPass Express) through the scenic Simmen Valley to the ultra-exclusive village of Gstaad, a favorite winter retreat for global royalty. Check into The Alpina Gstaad or Gstaad Palace. Take some time to shop at the luxury boutiques lining the promenade, or enjoy the unparalleled luxury of your resort’s Six Senses Spa.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> The Swiss Riviera & Lavaux Vineyards</h3>
                <p>Continue your journey down the winding mountain roads until the breathtaking expanse of Lake Geneva appears, bringing you to the elegant Swiss Riviera. Stop in the UNESCO-listed Lavaux Vineyards for a highly exclusive, private wine tasting experience in a historic cellar overlooking the lake. Arrive in Geneva and check into the Four Seasons Hotel des Bergues or the Beau-Rivage.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Watchmaking Heritage & Private Shopping</h3>
                <p>Dive into Switzerland's most famous luxury export. Enjoy a private, behind-the-scenes tour of a prestigious Swiss watchmaking atelier (such as Patek Philippe or Vacheron Constantin) to witness masters at work. Spend the afternoon with a dedicated personal shopper exploring Geneva’s Rue du Rhône, home to the world's finest designer boutiques. Conclude your tour with a lavish, private farewell dinner on a terrace overlooking the Jet d'Eau fountain.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> VIP Departure from Geneva</h3>
                <p>Enjoy your final, leisurely morning in the comfort of your suite. Your chauffeur will transfer you to Geneva Airport (GVA). You will be escorted to the VIP terminal/lounge, ensuring a completely seamless, private, and stress-free boarding process for your flight home.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill" onclick="updateTier('budget', this)">PREMIUM CLASS</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">5-STAR LUXURY</button>
                <button class="tier-pill active" onclick="updateTier('super', this)">ULTRA VIP</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">ULTRA VIP / ROYAL - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_super_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> 5-Star Superior Signature Suites (e.g., Badrutt's Palace, The Alpina Gstaad)</li>
                <li><i class="fa-solid fa-helicopter"></i> Private Scenic Helicopter Transfers Across the Alps</li>
                <li><i class="fa-solid fa-crown"></i> "Excellence Class" on the Glacier Express & VIP Airport Meet-and-Greet</li>
                <li><i class="fa-solid fa-utensils"></i> Michelin-Star Dining, Private Lakeside Chef, and Champagne Brunches</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult a VIP Expert</button>
            <a href="assets/swiss-luxury-11d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- LUXURY INSIGHTS HUB (6 GRID CARDS)                        -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">VIP Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Prestige Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details and exclusive services for our Ultra-Luxury clients.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-plane-arrival"></i></div>
                <h3>VIP Airport Protocol</h3>
                <p>Bypassing the crowds:</p>
                <ul>
                    <li><strong>Tarmac Transfers:</strong> For our Ultra VIP guests, we arrange the Zurich ZRH and Geneva GVA VIP Services. You are greeted directly at the aircraft door, transferred via limousine across the tarmac, and wait in a private lounge while officials process your passport and collect your luggage.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-helicopter"></i></div>
                <h3>Helicopter Logistics</h3>
                <p>Flying over the Alps:</p>
                <ul>
                    <li><strong>Weather & Luggage:</strong> Helicopter transfers are strictly subject to weather conditions and visual flight rules. Additionally, helicopters have strict weight and luggage dimension limits. Your heavy suitcases will be forwarded separately via our ground concierge team.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-martini-glass"></i></div>
                <h3>Excellence Class Rules</h3>
                <p>The Glacier Express:</p>
                <ul>
                    <li><strong>Ultimate Exclusivity:</strong> Excellence Class is limited to only 20 seats per train. It guarantees everyone a window seat, includes a dedicated concierge, tablet infotainment, and a 5-course menu with wine pairings. It must be booked months in advance.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bag-shopping"></i></div>
                <h3>Private Personal Shoppers</h3>
                <p>Geneva & Gstaad:</p>
                <ul>
                    <li><strong>Curated Access:</strong> We provide dedicated personal shoppers who arrange private viewings at high-end boutiques and watch ateliers (such as Patek Philippe or Rolex). Private salon access can be secured with advance notice.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Michelin Star Dining</h3>
                <p>Securing the best tables:</p>
                <ul>
                    <li><strong>Concierge Reservations:</strong> Switzerland boasts an incredibly high density of Michelin-starred restaurants. From Anne-Sophie Pic in Lausanne to The Restaurant at the Dolder Grand, our concierge team will secure the most sought-after tables for your evenings.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-user-tie"></i></div>
                <h3>White-Glove Ground Handling</h3>
                <p>Seamless transitions:</p>
                <ul>
                    <li><strong>Chauffeur & Porter Service:</strong> From the moment you land until the moment you depart, you will not have to handle a single piece of luggage. Our coordinated network of chauffeurs and hotel porters ensures your belongings magically appear in your suite.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, Tamil Nadu, Andhra Pradesh, Andaman, Lakshadweep, Dubai, Europe, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Premium Class</option>
                            <option value="Affordable Luxury">5-Star Luxury</option>
                            <option value="Super Luxury">Ultra VIP / Royal</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a VIP Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized grand luxury tour.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="The Ultimate Swiss Luxury Tour 11D/10N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>