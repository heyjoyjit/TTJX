<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Travel | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>Group & Corporate Travel</h1>
        <p>Flawless execution at scale.</p>
    </header>

    <main class="info-container">
        <h2>Corporate Offsites & MICE</h2>
        <p>Traveltara provides comprehensive end-to-end logistics for corporate retreats, offsites, and MICE (Meetings, Incentives, Conferences, and Exhibitions) events. From securing luxury conference venues to organizing large-scale airport transfers, our team manages the complexities so your organization can focus on its objectives.</p>

        <h2>Large Family & Leisure Groups</h2>
        <p>Traveling with a large family or organization requires specialized care. We offer dedicated tour managers who travel alongside your group to ensure seamless check-ins, managed meal plans, and real-time itinerary adjustments.</p>

        <h2>Group Booking Inquiries</h2>
        <p>For groups requiring more than 5 rooms, our dynamic pricing engine is bypassed in favor of a custom, highly negotiated group rate. Please contact our corporate desk directly at <strong>booking.traveltara@gmail.com</strong> to begin designing your group expedition.</p>
    </main>

</body>
</html>