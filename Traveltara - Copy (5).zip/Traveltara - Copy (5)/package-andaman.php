<?php
// Top of package-andaman.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks just in case the API takes a second
$sheet_budget_price = "₹35,000"; 
$sheet_affordable_price = "₹55,000";
$sheet_super_price = "₹85,000";

// The EXACT name of the package as written in Column A of your sheet
$target_package = "Andaman 6D/5N"; 

// 2. Fetch JSON data using cURL
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match Data
if ($response !== false) {
    $data = json_decode($response, true);
    
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build the Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels</li>
            <li><i class="fa-solid fa-ship"></i> Standard Govt/Private Ferry</li>
            <li><i class="fa-solid fa-car"></i> Dedicated AC Cabs</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Beach Resorts</li>
            <li><i class="fa-solid fa-ship"></i> Premium Ferry (Makruzz/Green Ocean)</li>
            <li><i class="fa-solid fa-water"></i> Complimentary Scuba/Snorkeling Session</li>
            <li><i class="fa-solid fa-utensils"></i> Breakfast & Dinner Included</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Beachfront Luxury (e.g., Taj)</li>
            <li><i class="fa-solid fa-crown"></i> VIP Royal Class Ferry Seats</li>
            <li><i class="fa-solid fa-sailboat"></i> Private Sunset Yacht Experience</li>
            <li><i class="fa-solid fa-utensils"></i> Exclusive Curated Fine Dining</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tropical Andaman Escape | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        
        <div class="menu-toggle" id="mobile-menu">
            <i class="fa-solid fa-bars"></i>
        </div>
        
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>

        <div class="nav-contact" id="navContact">
            <i class="fa-solid fa-phone"></i> +91 9477709755
        </div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Andaman (6D/5N)</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['andaman hero']) ? $tourImages['andaman hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 6 Days / 5 Nights</div>
        <div class="subpage-hero-content">
            <h1>Tropical Elegance in Andaman</h1>
            <p>Pristine white sands, crystal-clear waters, and unmatched island luxury.</p>
        </div>
    </header>
    
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Andaman 6D/5N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>

                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>

            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>

                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>

                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>

            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>

                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>

        </div>
    </div>

    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Immerse yourself in the breathtaking tropical paradise of the Andaman Islands. This meticulously designed 6-day itinerary seamlessly blends historical exploration in Port Blair with the ultimate beachfront luxury in Havelock and Neil Islands. Indulge in world-class scuba diving, sail on premium ferries, and relax on Asia's most pristine white-sand beaches.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Port Blair & Historic Trails</h3>
                <p>Touch down at Veer Savarkar International Airport, where our representative will welcome you and transfer you to your premium hotel. In the afternoon, visit the historic Cellular Jail to explore India's poignant freedom struggle. As dusk falls, witness the spectacular Light and Sound Show that brings history to life.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Premium Cruise to Havelock & Radhanagar Beach</h3>
                <p>After an early breakfast, board a premium private cruise (Makruzz/Green Ocean) to Havelock Island. Upon arrival, check into your luxurious beachfront resort. In the afternoon, head to Radhanagar Beach—crowned one of the best beaches in Asia. Unwind on its powdery white sands and witness a breathtaking sunset over the azure waters.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Underwater Wonders at Elephant Beach</h3>
                <p>Embark on an exhilarating boat ride to Elephant Beach, known for its crystal-clear waters and vibrant coral reefs. Enjoy complimentary water sports or choose to experience world-class scuba diving and sea walking. Return to your resort for a relaxed, lavish evening accompanied by exquisite coastal cuisine.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Sail to Neil Island & Natural Bridge</h3>
                <p>Board your morning luxury ferry to the tranquil and romantic Neil Island. Check into your resort and spend the afternoon exploring the pristine Bharatpur and Laxmanpur beaches. Marvel at the unique rock formations of the Natural Bridge during low tide, capturing stunning photographs of the marine life trapped in tidal pools.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Return to Port Blair & Chidiya Tapu Sunset</h3>
                <p>Enjoy a final morning beach walk before taking the ferry back to Port Blair. After settling into your hotel, drive to the lush, green landscapes of Chidiya Tapu (Bird Island). Experience one of the most stunning sunsets in the Andaman archipelago before enjoying your final farewell dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Departure with Memories</h3>
                <p>Enjoy a relaxed breakfast at your hotel. Depending on your flight schedule, you may pick up some local pearl or shell handicrafts from the Aberdeen Bazaar. Our chauffeur will ensure a seamless transfer to the airport for your journey home, carrying memories of an unforgettable island paradise.</p>
            </div>
            
        </div>

        <aside class="itinerary-sidebar">
            
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels</li>
                <li><i class="fa-solid fa-ship"></i> Standard Govt/Private Ferry</li>
                <li><i class="fa-solid fa-car"></i> Dedicated AC Cabs</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/andaman-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <footer class="site-footer">
        <div class="footer-grid">
            
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
            
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

   <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>
        
    </div>

    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Andaman (6D/5N)" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>