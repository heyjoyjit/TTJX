<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | Traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/info-pages.css">
</head>
<body>

    <header class="slim-hero">
        <h1>About Traveltara</h1>
        <p>Tailored trips just for you.</p>
    </header>

    <main class="info-container">
        <h2>Our Heritage</h2>
        <p>Traveltara was founded on a singular vision: to craft luxurious, unforgettable journeys across the most breathtaking landscapes of India and beyond. We believe that travel is not just about visiting a destination; it is about immersing yourself in the culture, luxury, and untold stories of the region.</p>

        <h2>Our Expertise</h2>
        <p>We specialize in curating highly personalized itineraries across premium destinations, including:</p>
        <ul>
            <li><strong>North Bengal & Sikkim:</strong> Alpine lakes, monasteries, and unparalleled Himalayan luxury.</li>
            <li><strong>Rajasthan:</strong> Live like royalty in heritage forts and desert luxury camps.</li>
            <li><strong>Himachal Pradesh & Munnar:</strong> Serene high-altitude escapes and lush green retreats.</li>
        </ul>

        <h2>The Traveltara Promise</h2>
        <p>From the moment you begin your booking to the day you return home, our dedicated team ensures every detail is meticulously planned. Whether you are seeking an affordable luxury getaway or a super luxury customized expedition, we handle the logistics so you can focus on the experience.</p>
    </main>

</body>
</html>