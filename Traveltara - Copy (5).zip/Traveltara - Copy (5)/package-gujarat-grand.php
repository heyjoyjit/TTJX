<?php
// Top of package-gujarat-grand.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹42,000"; 
$sheet_affordable_price = "₹68,000";
$sheet_super_price = "₹1,10,000";

// EXACT package name from Google Sheet
$target_package = "Gujarat Grand Odyssey 14D/13N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels & Traditional Mud Bhungas</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the 14-Day Loop</li>
            <li><i class="fa-solid fa-camera"></i> Standard Sightseeing & Shared Gir Safari</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Heritage Properties, Jungle Lodges & Tents</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-paw"></i> Exclusive Open Gypsy Safari in Gir & Little Rann</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Palaces, Beach Resorts & Ultra-Luxury Tent Cities</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> VIP Temple Darshans & Statue of Unity Express Entry</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining, Seafood Specials & Traditional Gujarati Feasts</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Grand Gujarat Odyssey 14 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="gujarat-itinerary.php">Gujarat</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Grand Gujarat Odyssey (14D/13N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['gujarat grand hero']) ? $tourImages['gujarat grand hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 14 Days / 13 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Grand Gujarat Odyssey</h1>
            <p>The ultimate 14-day loop covering the heritage, deserts, wildlife, and divine coastlines of Gujarat.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Gujarat Grand Odyssey 14D/13N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Experience the absolute entirety of Gujarat's vibrant landscape. This meticulously crafted 14-day mega-circuit takes you from the UNESCO alleys of Ahmedabad to the towering Statue of Unity. You will cross the wild Little Rann, witness the surreal white salt flats of Kutch, seek blessings at the sacred temples of Dwarka and Somnath, track the Asiatic lion in Gir, and relax on the colonial beaches of Diu before completing the loop.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Ahmedabad & Heritage Walk</h3>
                <p>Welcome to India's first UNESCO World Heritage City! Arrive at Sardar Vallabhbhai Patel International Airport. Your luxury chauffeur will transfer you to your hotel. After resting, take an introductory walk along the Sabarmati Riverfront or visit the serene Gandhi Ashram. Enjoy an authentic Gujarati welcome dinner.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Colossus: Ahmedabad to Statue of Unity</h3>
                <p>After breakfast, depart for Kevadia (approx. 4 hours). Check into your premium resort. Spend the afternoon marveling at the Statue of Unity, the world's tallest statue. Take the high-speed elevator to the viewing gallery. In the evening, witness the spectacular laser projection show on the statue and the illuminated Sardar Sarovar Dam.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Kevadia to the Little Rann of Kutch</h3>
                <p>Leave the lush Narmada district and drive towards the arid, cracked earth of the Little Rann of Kutch (approx. 5-6 hours). Check into a traditional eco-resort in Dasada or Zainabad. In the late afternoon, embark on a thrilling open-jeep safari into the salt marsh to spot the rare, endangered Indian Wild Ass and vibrant flocks of flamingos.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Little Rann to Bhuj & The Great White Desert</h3>
                <p>Drive further west into the heart of Kutch towards Bhuj (approx. 5 hours). Upon arrival, explore the ornate Aina Mahal and Prag Mahal. Later, continue your drive to the Dhordo/Hodka region. Check into your traditional Bhunga (mud hut) or luxury tent. As evening falls, step out onto the endless expanse of the Great Rann salt flats for an unforgettable sunset.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Kutch Villages & Drive to Rajkot</h3>
                <p>Wake up early for a final glimpse of the shimmering white desert. After breakfast, visit nearby artisan villages like Nirona or Bhujodi to witness world-class Kutchi embroidery and Rogan art. Begin your journey down into the Saurashtra peninsula, arriving in the bustling city of Rajkot (approx. 5 hours) for an overnight stay.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Rajkot to the Kingdom of Krishna (Dwarka)</h3>
                <p>Drive to the sacred coastal city of Dwarka (approx. 4.5 hours). Check into your hotel. In the evening, visit the magnificent Dwarkadhish Temple to witness the deeply moving Aarti. Take a peaceful stroll along the Gomti River ghats as the sun sets over the Arabian Sea.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Beyt Dwarka & Nageshwar Jyotirlinga</h3>
                <p>Take a short ferry ride to Beyt Dwarka, an island believed to be the original residence of Lord Krishna. Upon returning, visit the Nageshwar Jyotirlinga Temple, one of the 12 supreme shrines of Lord Shiva, and the beautiful Rukmini Devi Temple. Relax in Dwarka for the evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> The Coastal Highway: Dwarka to Somnath</h3>
                <p>Depart Dwarka and drive along the stunning coastal highway towards Somnath (approx. 4 hours). En route, stop at Porbandar to visit Kirti Mandir, the birthplace of Mahatma Gandhi. Arrive in Somnath and check into your hotel. Attend the powerful evening Aarti at the legendary Somnath Temple, positioned spectacularly against the crashing waves.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> The Coast to the Jungle: Somnath to Sasan Gir</h3>
                <p>After an optional morning Darshan at Somnath, take a short drive into the dense, dry deciduous forests of Sasan Gir (approx. 2 hours), the last refuge of the Asiatic Lion. Check into your wilderness lodge. Spend the afternoon relaxing by the pool or visiting the local Crocodile Breeding Centre.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Tracking the Asiatic Lion & Drive to Diu</h3>
                <p>Wake up before dawn for a thrilling jeep safari deep into Gir National Park. Track lions, leopards, and diverse wildlife. After breakfast, bid farewell to the jungle and drive to the idyllic coastal enclave of Diu (approx. 2.5 hours). A former Portuguese colony, Diu offers a completely different vibe. Check into your beachside resort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Diu Island Sightseeing & Leisure</h3>
                <p>Explore the massive 16th-century Diu Fort, overlooking the Arabian Sea. Visit the intricate Naida Caves and the beautiful St. Paul's Church. Spend the rest of the day unwinding on the golden sands of Nagoa Beach, enjoying water sports, or indulging in the island's famous Portuguese-infused seafood.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> Diu to Bhavnagar / Velavadar</h3>
                <p>Depart Diu and drive northeast toward Bhavnagar (approx. 5 hours). En route, you may opt to stop at the Velavadar Blackbuck National Park, a stunning golden grassland that is home to massive herds of elegant blackbucks and wolves. Check into your heritage hotel in Bhavnagar for the night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Bhavnagar to Ahmedabad via Lothal</h3>
                <p>Begin your final leg back to Ahmedabad (approx. 4 hours). En route, stop at Lothal, one of the most prominent and well-excavated cities of the ancient Indus Valley Civilization, featuring the world's oldest known artificial dockyard. Arrive in Ahmedabad by late afternoon, completing your grand loop of the state. Enjoy a farewell dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 14</span> Departure from Ahmedabad</h3>
                <p>Enjoy your final breakfast in Gujarat. Depending on your flight or train schedule, you may do some last-minute shopping for Patola silks or Bandhani textiles in Ahmedabad's vibrant markets. Your chauffeur will provide a seamless transfer to the airport or railway station, concluding your monumental 14-day Gujarat Odyssey.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hotels & Traditional Mud Bhungas</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the 14-Day Loop</li>
                <li><i class="fa-solid fa-camera"></i> Standard Sightseeing & Shared Gir Safari</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/gujarat-grand-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- GUJARAT INSIGHTS HUB (6 GRID CARDS)                       -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Grand Loop Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your massive 14-day journey across Gujarat's diverse landscapes is perfectly planned.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>The Crucial Travel Window</h3>
                <p>This grand loop requires highly specific timing:</p>
                <ul>
                    <li><strong>The Sweet Spot (Nov - Feb):</strong> This is the ONLY time when all components of this tour align perfectly. Gir National Park is open, the weather is pleasant, and most importantly, the Great Rann of Kutch is dry and white.</li>
                    <li><strong>Monsoon/Summer:</strong> If traveling outside winter, the Rann of Kutch component must be skipped as it floods, and Gir is closed during the monsoon.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-ticket"></i></div>
                <h3>Permits & Advance Bookings</h3>
                <p>Gujarat's top attractions sell out quickly:</p>
                <ul>
                    <li><strong>Gir Safari:</strong> Jeep safaris must be booked up to 90 days in advance.</li>
                    <li><strong>Statue of Unity:</strong> Express Entry tickets are essential to avoid hours of waiting.</li>
                    <li><strong>Kutch Permits:</strong> Border permits are required for the salt flats. Original IDs must be carried at all times.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Highway Travel & Pacing</h3>
                <p>This mega-circuit covers over 2,000 kilometers:</p>
                <ul>
                    <li><strong>Vehicle Comfort:</strong> Given the extensive driving required on Days 3, 4, 5, 8, and 12, we strongly recommend upgrading to an SUV (Innova Crysta) for superior legroom and shock absorption.</li>
                    <li><strong>The Roads:</strong> Gujarat's highway infrastructure is phenomenal, making these long drives smooth and enjoyable.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Temple Protocols</h3>
                <p>Dwarka and Somnath are highly secured pilgrimage sites:</p>
                <ul>
                    <li><strong>Electronics Ban:</strong> Mobile phones, cameras, smartwatches, and large bags are strictly prohibited inside the temple premises.</li>
                    <li><strong>Dress Code:</strong> Modest dressing is mandatory. Shorts and sleeveless tops are not permitted inside the sanctums.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-martini-glass-citrus"></i></div>
                <h3>The Dry State Dynamics</h3>
                <p>Navigating alcohol laws across the state:</p>
                <ul>
                    <li><strong>Gujarat:</strong> Alcohol is completely banned in public. Tourists can obtain a temporary permit, but consumption is restricted strictly to private hotel rooms.</li>
                    <li><strong>Diu:</strong> Diu is a Union Territory, and the dry state rule does NOT apply here. You can freely enjoy a drink by the beach.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Packing for Extremes</h3>
                <p>You will experience varied micro-climates:</p>
                <ul>
                    <li><strong>Kutch:</strong> Freezing winds at night on the salt flats require heavy winter jackets, while daytime heat requires high-SPF sunscreen.</li>
                    <li><strong>Coastal/Cities:</strong> Ahmedabad, Dwarka, and Diu will be comfortably warm and breezy during the day. Layering is key for this 14-day trip.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your ultimate 14-Day Gujarat expedition.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Gujarat Grand Odyssey 14D/13N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>