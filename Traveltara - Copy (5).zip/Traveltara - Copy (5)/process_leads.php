<?php
// 1. ALLOW SECURE CONNECTIONS FOR ALL POPUPS AND FORMS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') { http_response_code(200); exit(); }
header("Content-Type: application/json");

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // 2. DATABASE CREDENTIALS
    $db_host = "localhost";
    $db_name = "u505532187_traveltara"; 
    $db_user = "u505532187_admin";      
    $db_pass = "Traveltara@2026";       
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    
    // FORCE INDIAN STANDARD TIME (IST)
    date_default_timezone_set('Asia/Kolkata');
    $conn->query("SET time_zone = '+05:30'");

    // ====================================================================
    // 🔵 GET REQUESTS (Live Pricing, Coupons, Razorpay Orders)
    // ====================================================================
    $getAction = $_GET['action'] ?? '';

    if ($getAction === 'getPricing') {
        $res = $conn->query("SELECT * FROM pricing");
        $prices = [];
        if($res) {
            while($row = $res->fetch_assoc()) {
                $prices[$row['Package Name']] = [
                    "Budget" => (int)$row['Budget'],
                    "Affordable Luxury" => (int)$row['Affordable Luxury'],
                    "Super Luxury" => (int)$row['Super Luxury']
                ];
            }
        }
        echo json_encode($prices); exit;
    }

    if ($getAction === 'verifyCoupon') {
        $code = $conn->real_escape_string($_GET['code'] ?? '');
        $res = $conn->query("SELECT `Discount (%)` FROM coupons WHERE `Coupon Code` = '$code' AND `Status` = 'Active' LIMIT 1");
        if ($res && $res->num_rows > 0) {
            $row = $res->fetch_assoc();
            echo json_encode(["valid" => true, "discount" => (int)$row['Discount (%)']]);
        } else {
            echo json_encode(["valid" => false]);
        }
        exit;
    }

    if ($getAction === 'createOrder') {
        $amount = (int)($_GET['amount'] ?? 0);
        $key_id = "rzp_live_SfkS8TnfvHiudv"; 
        
        // 🚨 PASTE YOUR RAZORPAY SECRET HERE:
        $key_secret = "rNTDRBhT9c7TLQCG98GSyamZ"; 
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.razorpay.com/v1/orders');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['amount' => $amount, 'currency' => 'INR']));
        curl_setopt($ch, CURLOPT_USERPWD, $key_id . ':' . $key_secret);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;
        exit;
    }

    // ====================================================================
    // 🟣 POST REQUESTS (Dynamic Merging Engine for Lead Capture & Mark Paid)
    // ====================================================================
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true) ?: [];
    $action = $data['action'] ?? $_REQUEST['action'] ?? '';

    if ($action === 'LEAD_CAPTURE' || $action === 'MARK_PAID') {
        $bookingId = $conn->real_escape_string($data['bookingId']);
        
        // 🔥 This map ensures every specific column gets matched to the exact JSON payload
        $fields = [
            'Prefix' => 'prefix',
            'First Name' => 'fName',
            'Middle Name' => 'mName',
            'Last Name' => 'lName',
            'Primary Phone' => 'primaryPhone',
            'Alt Phone' => 'altPhone',
            'Email' => 'email',
            'Residential Address' => 'resAddress',
            'Permanent Address' => 'permAddress',
            'Office Address' => 'officeAddress',
            'Delivery Address' => 'deliveryAddr',
            'Aadhaar Number' => 'aadhaar',
            'Tour Type (Dom/Int)' => 'tourType',
            'Passport No' => 'passport',
            'Destination' => 'destination',
            'Commencement Date' => 'startDate',
            'Tour Tier' => 'tier',
            'Total Paid' => 'totalPaid',
            'Payment Ref ID' => 'paymentRef',
            'Coupon Used' => 'couponUsed',
            'Invoice No' => 'invoiceNo',
            'Status' => 'status'
        ];

        $updateParts = [];
        $insertCols = ['`Booking ID`'];
        $insertVals = ["'$bookingId'"];

        // Dynamically build the SQL so it never overwrites existing data with Nulls
        foreach ($fields as $dbCol => $jsonKey) {
            if (isset($data[$jsonKey]) && $data[$jsonKey] !== '') {
                $safeVal = $conn->real_escape_string($data[$jsonKey]);
                $updateParts[] = "`$dbCol`='$safeVal'";
                $insertCols[] = "`$dbCol`";
                $insertVals[] = "'$safeVal'";
            }
        }

        // Handle numeric fields safely
        if (isset($data['adults'])) {
            $adults = (int)$data['adults'];
            $updateParts[] = "`Adults`=$adults";
            $insertCols[] = "`Adults`"; $insertVals[] = $adults;
        }
        if (isset($data['children'])) {
            $children = (int)$data['children'];
            $updateParts[] = "`Children`=$children";
            $insertCols[] = "`Children`"; $insertVals[] = $children;
        }
        if (isset($data['rooms'])) {
            $rooms = (int)$data['rooms'];
            $updateParts[] = "`Rooms`=$rooms";
            $insertCols[] = "`Rooms`"; $insertVals[] = $rooms;
        }

        // Check if row exists. If yes, UPDATE dynamically. If no, INSERT completely.
        $check = $conn->query("SELECT id FROM bookings WHERE `Booking ID` = '$bookingId'");
        if ($check && $check->num_rows > 0) {
            if (!empty($updateParts)) {
                $updateStr = implode(", ", $updateParts);
                $conn->query("UPDATE bookings SET $updateStr WHERE `Booking ID` = '$bookingId'");
            }
        } else {
            $colStr = implode(", ", $insertCols);
            $valStr = implode(", ", $insertVals);
            $conn->query("INSERT INTO bookings ($colStr) VALUES ($valStr)");
        }

        // Push to Master CRM (Only on initial capture)
        $phone = $conn->real_escape_string($data['primaryPhone'] ?? '');
        $fName = $conn->real_escape_string($data['fName'] ?? '');
        $lName = $conn->real_escape_string($data['lName'] ?? '');
        $email = $conn->real_escape_string($data['email'] ?? '');
        if ($action === 'LEAD_CAPTURE' && $phone !== '') {
            $conn->query("INSERT INTO master_crm (`Phone Number`, `Name`, `Email Address`, `Client Type`, `Total Interactions`, `Latest Interest`, `Action Status`) VALUES ('$phone', trim('$fName $lName'), '$email', 'Lead', 1, 'Booking Started', '🟡 Contacted') ON DUPLICATE KEY UPDATE `Latest Interest` = 'Booking Started'");
        }

        // Lock Coupon
        $coupon = $conn->real_escape_string($data['couponUsed'] ?? '');
        if(!empty($coupon) && $coupon !== 'N/A' && $coupon !== 'MANUAL_ENTRY') {
            $conn->query("UPDATE coupons SET `Status` = 'Used', `Used By Booking ID` = '$bookingId' WHERE `Coupon Code` = '$coupon'");
        }

        echo json_encode(["status" => "success"]); exit;
    }

    // ====================================================================
    // 🟠 GENERAL FORMS & WHATSAPP CHAT SYNC
    // ====================================================================
    $rawPhone = $data['Phone'] ?? $data['phone'] ?? $_REQUEST['Phone'] ?? $_REQUEST['phone'] ?? '';
    $pPhone = $conn->real_escape_string($rawPhone);
    $rawName = $data['Name'] ?? $data['name'] ?? $_REQUEST['Name'] ?? $_REQUEST['name'] ?? 'Unknown Guest';
    $pName = $conn->real_escape_string($rawName);
    $pEmail = $conn->real_escape_string($data['Email'] ?? $data['email'] ?? $_REQUEST['Email'] ?? $_REQUEST['email'] ?? '');
    $pSource = $conn->real_escape_string($data['Source'] ?? $data['source'] ?? $_REQUEST['Source'] ?? $_REQUEST['source'] ?? 'Website Form');
    $pDetails = $conn->real_escape_string($data['Message'] ?? $_REQUEST['Message'] ?? $data['Details'] ?? $_REQUEST['Details'] ?? 'No details provided');

    if (!empty($pPhone) && $pPhone !== "No Number Provided") {
        $upsertCRM = "INSERT INTO master_crm (`Phone Number`, `Name`, `Email Address`, `Client Type`, `Total Interactions`, `Latest Interest`, `Action Status`) 
                      VALUES ('$pPhone', '$pName', '$pEmail', 'Lead', 1, '$pSource', '🟢 New Lead')
                      ON DUPLICATE KEY UPDATE 
                      `Total Interactions` = `Total Interactions` + 1, `Latest Interest` = '$pSource',
                      `Action Status` = IF(LOWER(`Client Type`) = 'customer' OR LOWER(`Client Type`) = 'existing customer', '🌟 RETURNING CUSTOMER!', '🔥 Active Again')";
        $conn->query($upsertCRM);

        if ($action === 'CUSTOM_REQUEST') {
            $destination = $conn->real_escape_string($data['package'] ?? 'General Inquiry');
            $tier = $conn->real_escape_string($data['tier'] ?? 'N/A');
            $bId = 'TRV-LEAD-' . strtoupper(substr(md5(time()), 0, 5));
            $conn->query("INSERT INTO bookings (`Booking ID`, `First Name`, `Primary Phone`, `Destination`, `Tour Tier`, `Status`) VALUES ('$bId', '$pName', '$pPhone', '$destination', '$tier', 'Redirected to WhatsApp')");
            $conn->query("INSERT INTO interactions (`Phone Number`, `Source`, `Extracted Name`, `Exact Message / Details`) VALUES ('$pPhone', 'WhatsApp Popup', '$pName', 'Lead captured via WhatsApp')");
            echo json_encode(["status" => "success"]); exit;
        }

        $detectedEmail = "";
        if (preg_match('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', $pDetails, $matches)) $detectedEmail = $matches[0];

        $checkRecent = $conn->query("SELECT id, `Exact Message / Details` FROM interactions WHERE `Phone Number` = '$pPhone' AND `Source` = '$pSource' AND `Timestamp` >= NOW() - INTERVAL 2 HOUR ORDER BY `id` DESC LIMIT 1");
        if ($checkRecent && $checkRecent->num_rows > 0) {
            $row = $checkRecent->fetch_assoc();
            $recentId = $row['id'];
            $oldDetails = $row['Exact Message / Details'];
            $updateQuery = "UPDATE interactions SET `Timestamp` = NOW()";
            if (strpos($oldDetails, $pDetails) === false) $updateQuery .= ", `Exact Message / Details` = CONCAT(`Exact Message / Details`, '\n💬 ', '$pDetails')";
            if ($detectedEmail !== "") $updateQuery .= ", `Extracted Email` = '$detectedEmail'";
            if ($pName !== 'Unknown Guest' && $pName !== 'Chat User') $updateQuery .= ", `Extracted Name` = '$pName'";
            $conn->query("$updateQuery WHERE id = $recentId");
        } else {
            $conn->query("INSERT INTO interactions (`Phone Number`, `Source`, `Extracted Name`, `Extracted Email`, `Exact Message / Details`) VALUES ('$pPhone', '$pSource', IF('$pName' NOT IN ('Unknown Guest', 'Chat User'), '$pName', ''), '$detectedEmail', '💬 $pDetails')");
        }
        echo json_encode(["status" => "success"]); exit;
    }

    echo json_encode(["status" => "error", "message" => "No valid action or phone number"]);

} catch (Exception $e) {
    http_response_code(200);
    echo json_encode(["status" => "error", "message" => "SYSTEM CRASH: " . $e->getMessage()]);
}
$conn->close();
?>