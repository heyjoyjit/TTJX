<?php
// Top of package-tn-ultimate.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹42,000"; 
$sheet_affordable_price = "₹65,000";
$sheet_super_price = "₹98,000";

// EXACT package name from Google Sheet
$target_package = "The Ultimate Tamil Nadu Expedition 14D/13N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hotels / Heritage Lodges</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the 14-Day Route</li>
            <li><i class="fa-solid fa-ticket"></i> Standard Monument Entry & Ferry Tickets Included</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Heritage Resorts, Palaces & Mountain Retreats</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta for Maximum Inter-City Comfort</li>
            <li><i class="fa-solid fa-map-location-dot"></i> Expert Guided Monument Tours & Heritage Walks</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP) highlighting Regional Cuisines</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Palaces & Ultra-Luxury Retreats (e.g., Taj, Chidambara Vilas, Savoy)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive VIP Darshans, 1st Class Toy Train & Private Safaris</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Dining, Royal Chettinad Feasts & Private High Teas</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Ultimate Tamil Nadu Expedition 14 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="tamil-nadu-itinerary.php">Tamil Nadu Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Ultimate Expedition (14D/13N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['tn ultimate hero']) ? $tourImages['tn ultimate hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 14 Days / 13 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Ultimate Tamil Nadu Expedition</h1>
            <p>A magnificent 14-day grand loop through monumental Chola temples, deep spiritual corridors, pristine coasts, and the misty peaks of the Nilgiris.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="The Ultimate Tamil Nadu Expedition 14D/13N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>To truly understand the depth of South India, one must traverse its profound contrasts. We have designed this 14-day expedition to be entirely comprehensive, ensuring no region is left unexplored or rushed. You will begin in the colonial heart of Chennai, trace the Bay of Bengal through Mahabalipuram and French Pondicherry, step into the golden era of the Chola Empire in Thanjavur, witness staggering devotion in Madurai and Rameswaram, and finally ascend into the cool, aromatic heights of Kodaikanal and Ooty in the Western Ghats.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Chennai & The Coromandel Coast</h3>
                <p>Arrive at Chennai International Airport (MAA). Your private chauffeur will receive you and transfer you to your hotel. Spend the afternoon exploring the colonial legacy of Madras. Visit Fort St. George, the first English fortress in India, and the historic San Thome Basilica. In the evening, take a leisurely stroll down the iconic Marina Beach, the second longest urban beach in the world, and soak in the vibrant atmosphere.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The City of Silk & Shore Monoliths</h3>
                <p>After breakfast, drive to Kanchipuram (approx. 2 hours). Visit the towering Ekambareswarar Temple and witness traditional weavers crafting pure Kanjeevaram silk sarees with real gold thread. Later, drive to the coastal town of Mahabalipuram (approx. 1.5 hours). Explore the 7th-century UNESCO World Heritage Pallava monuments, including the majestic Shore Temple, the Five Rathas, and Arjuna's Penance. Check into your sea-facing resort for the night.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The French Riviera of the East (Pondicherry)</h3>
                <p>Drive south along the scenic East Coast Road to the Union Territory of Puducherry (approx. 2 hours). Check into your heritage hotel in the French Quarter (White Town). Spend the day walking the mustard-yellow, bougainvillea-draped streets. Visit the serene Sri Aurobindo Ashram, the pristine Promenade Beach, and enjoy an authentic French-Tamil fusion dinner at a local heritage café.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> The Great Chola Empire (Thanjavur)</h3>
                <p>Check out and drive deeper into the Cauvery Delta. En route, stop at the magnificent Nataraja Temple in Chidambaram. Continue to Thanjavur (Tanjore) (approx. 4.5 hours), the ancient capital of the Cholas. Stand in awe of the Brihadeeswara Temple, a UNESCO World Heritage site carved entirely from granite and topped with an 80-ton monolithic cupola. Check into your heritage hotel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Mansions & Spices (Chettinad)</h3>
                <p>After a morning visit to the Thanjavur Maratha Palace, drive to the Karaikudi/Chettinad region (approx. 2 hours). This area is famous for its opulent, palatial mansions built by the wealthy Chettiar merchant community using teak from Burma and tiles from Italy. Explore the architectural marvels, visit local tile-making workshops, and indulge in a fiery, multi-course Chettinad feast served on a banana leaf.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Athens of the East (Madurai)</h3>
                <p>Drive to Madurai (approx. 2 hours), one of the oldest continuously inhabited cities in the world. Check into your hotel and rest. In the late afternoon, head to the awe-inspiring Meenakshi Amman Temple. Marvel at the 14 towering gopurams covered in thousands of colorful stone figures. In the evening, witness the mesmerizing nightly closing ceremony, where Lord Shiva is carried to Goddess Meenakshi's shrine amidst chanting and drumbeats.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> The Holy Corridors & Dhanushkodi (Rameswaram)</h3>
                <p>Check out and drive toward the sacred island of Rameswaram (approx. 3.5 hours), crossing the spectacular 2-kilometer-long Pamban Bridge over the Bay of Bengal. Visit the Ramanathaswamy Temple, renowned for the longest temple corridor in the world. In the afternoon, hire a specialized 4x4 jeep to visit Dhanushkodi, the haunting "Ghost Town" destroyed by a 1964 cyclone, situated at the very tip of the island.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Drive to Land's End (Kanyakumari)</h3>
                <p>Embark on a highly scenic drive south along the coastal highways toward Kanyakumari (approx. 5.5 hours), the southernmost tip of the Indian subcontinent where three mighty oceans converge. Take the short ferry ride to the Vivekananda Rock Memorial and the towering stone statue of Thiruvalluvar. Head to the shoreline in the evening to witness a breathtaking, uninterrupted sunset over the tri-sea confluence.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Ascent to the Princess of Hill Stations (Kodaikanal)</h3>
                <p>Bid farewell to the coast and begin the long, dramatic ascent into the Palani Hills of the Western Ghats towards Kodaikanal (approx. 6.5 hours). The temperature drops significantly as you enter the dense pine forests. Arrive by late afternoon, check into your mountain resort, and relax by a warm bonfire, completely disconnected from the heat of the plains.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Misty Pines & Star-Shaped Lakes</h3>
                <p>Spend a full day exploring Kodaikanal. Take a peaceful morning walk along Coaker's Walk, offering stunning views of the valleys below. Visit the dramatic Pillar Rocks and the serene Pine Forest. In the afternoon, enjoy a relaxing Shikara or pedal boat ride on the iconic, star-shaped Kodai Lake. Explore the local markets for homemade chocolates and eucalyptus oil.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> The Grand Valley Drive to Ooty</h3>
                <p>Check out and embark on another spectacular drive, descending the Palani Hills and ascending the Nilgiri Ghats towards Ooty (Udhagamandalam) (approx. 6.5 hours). The drive features 36 hairpin bends and endless views of tea estates. Arrive in the "Queen of Hill Stations," check into your colonial-style resort, and spend the evening enjoying the crisp mountain air.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> The Heritage Toy Train & Coonoor</h3>
                <p>Head to the Ooty railway station to board the UNESCO-listed Nilgiri Mountain Railway (Toy Train). This spectacular, slow-paced journey winds through tunnels and over deep ravines to Coonoor. Your chauffeur will meet you there. Explore Sim's Park, take in the panoramic views at Dolphin's Nose, and walk through a working tea factory to taste freshly brewed Nilgiri tea. Return to Ooty in the evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Descent to Coimbatore & Isha Foundation</h3>
                <p>Enjoy a final mountain breakfast, then check out and drive down the ghats toward Coimbatore (approx. 3 hours). In the afternoon, visit the profoundly peaceful Isha Yoga Center at the foothills of the Velliangiri Mountains. Marvel at the colossal 112-foot Adiyogi Shiva statue and spend time meditating in the serene Dhyanalinga workspace. Check into your Coimbatore hotel for your final night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 14</span> Departure from Coimbatore</h3>
                <p>Your ultimate Tamil Nadu expedition comes to an end. After breakfast, check out of your hotel. Your chauffeur will transfer you to the Coimbatore International Airport (CJB) or Railway Station for your onward journey, leaving you with memories of a perfectly complete Southern exploration.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hotels / Heritage Lodges</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the 14-Day Route</li>
                <li><i class="fa-solid fa-ticket"></i> Standard Monument Entry & Ferry Tickets Included</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/tn-ultimate-14d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- GRAND LOOP INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The 14-Day Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for this massive, multi-terrain endurance journey across an entire state.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-plane-departure"></i></div>
                <h3>Flight Logistics</h3>
                <p>Avoiding a 10-hour backtrack:</p>
                <ul>
                    <li><strong>Gateways:</strong> Because this is a massive coastal-to-mountain loop, it is absolutely vital to book your arrival flight into Chennai (MAA) and your departure flight out of Coimbatore (CJB) or Madurai (IXM). Driving from Ooty back to Chennai takes over 10 hours and is highly discouraged.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase-rolling"></i></div>
                <h3>Packing for 2 Extremes</h3>
                <p>Strategic layering is key:</p>
                <ul>
                    <li><strong>The Variations:</strong> The first 8 days (Chennai to Kanyakumari) are intensely hot and highly humid (pack light cottons and modest temple wear). Days 9 to 13 (Kodaikanal and Ooty) are high-altitude mountain stations that get quite chilly, especially at night (pack light jackets and sweaters).</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Temple Dress Codes</h3>
                <p>Strict rules throughout the state:</p>
                <ul>
                    <li><strong>Preparation:</strong> Meenakshi, Ramanathaswamy, and Brihadeeswara temples enforce absolute dress codes. Men must wear long trousers or dhotis (no shorts). Women must wear sarees, long skirts, or salwar kameez. Jeans and leggings are frequently rejected.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car-side"></i></div>
                <h3>Vehicle Upgrade Recommended</h3>
                <p>Managing the long drives:</p>
                <ul>
                    <li><strong>Road Fatigue:</strong> Over 14 days, you will be on the road frequently, transitioning between coasts, plains, and winding mountains. We highly advise upgrading to an Innova Crysta (even for couples) simply for the superior suspension and legroom over thousands of kilometers.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-train"></i></div>
                <h3>Toy Train Realities</h3>
                <p>Securing the heritage ride:</p>
                <ul>
                    <li><strong>Extreme Demand:</strong> The Nilgiri Mountain Railway is a UNESCO site with very limited seating. Tickets sell out exactly 120 days in advance. If train tickets are unavailable during your booking window, we will substitute this with a highly scenic car drive from Ooty to Coonoor.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Diversity</h3>
                <p>Changing flavors:</p>
                <ul>
                    <li><strong>The Transitions:</strong> You will experience incredible food diversity: French-Tamil fusion in Pondicherry, fiery meat curries in Chettinad, pure vegetarian Iyer food in Kumbakonam, and fresh tea/chocolates in the Nilgiris. Embrace the local diet for the full experience.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, Tamil Nadu, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized 14-day Tamil Nadu Grand Loop.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="The Ultimate Tamil Nadu Expedition 14D/13N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>