<?php
// Top of package-dalhousie-dharamshala.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹18,000"; 
$sheet_affordable_price = "₹26,000";
$sheet_super_price = "₹40,000";

// EXACT package name from Google Sheet
$target_package = "Kangra & Chamba 6D/5N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hill-View Hotels</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan Transfers</li>
            <li><i class="fa-solid fa-camera"></i> Standard Khajjiar & McLeod Ganj Tour</li>
            <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Boutique Pine Resorts</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> Guided Dalai Lama Temple Walk</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Heritage Luxury & Spa Retreats</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Kangra Valley Tea Estate Tour</li>
            <li><i class="fa-solid fa-utensils"></i> Exclusive Fine Dining & Tibetan Feasts</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kangra & Chamba Circuit | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="himachal-itinerary.php">Himachal</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Kangra & Chamba (6D/5N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['dalhousie hero']) ? $tourImages['dalhousie hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 6 Days / 5 Nights</div>
        <div class="subpage-hero-content">
            <h1>Spiritual Kangra & Colonial Chamba</h1>
            <p>Wander through pristine pine forests, rolling meadows, and Tibetan spiritual havens.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Kangra & Chamba 6D/5N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Designed for those who prefer serenity over crowds, this 6-day expedition uncovers the hidden gems of the Dhauladhar range. Begin in the colonial hill station of Dalhousie, walk across the emerald pastures of Khajjiar, and cross over into the Kangra Valley. Conclude your journey in Dharamshala and McLeod Ganj, the peaceful residence of His Holiness the Dalai Lama, surrounded by vibrant Tibetan culture and roaring waterfalls.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & Ascent to Dalhousie</h3>
                <p>Arrive at Pathankot Railway Station or Dharamshala/Chandigarh Airport. Your private luxury chauffeur will greet you for a scenic, winding ascent into the Chamba district. Arrive in Dalhousie, famous for its colonial-era architecture and dense oak and pine forests. Check into your hotel and spend the evening enjoying a quiet stroll down Garam Sadak or Thandi Sadak.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Colonial Heritage & Dalhousie Panoramas</h3>
                <p>After a warm mountain breakfast, embark on a local sightseeing tour. Visit the picturesque Panchpula waterfall, surrounded by majestic hills. Continue to Subhash Baoli, a serene pine-fringed spring, and the historic St. John's Church. Spend the late afternoon at your leisure, enjoying the panoramic views of the Pir Panjal range from your resort.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Mini Switzerland of India</h3>
                <p>Today features a spectacular drive to Khajjiar. Walk across the famous saucer-shaped meadow surrounded by towering cedar trees and a serene central lake. Enjoy horseback riding or zorbing across the pastures. Pass through the Kalatop Wildlife Sanctuary en route. In the late afternoon, drive down into the Kangra Valley to reach Dharamshala by evening. Check in and relax.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> The Tibetan Heart of McLeod Ganj</h3>
                <p>Immerse yourself in Tibetan culture today. Head to upper Dharamshala (McLeod Ganj) and visit the Tsuglagkhang Complex, the spiritual residence of the Dalai Lama. Walk the holy Kora trail, visit the Tibet Museum, and take a short hike to the cascading Bhagsu Waterfall. Spend the evening cafe-hopping and shopping for Tibetan handicrafts in the vibrant local markets.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Kangra Valley & Palampur Tea Gardens</h3>
                <p>Embark on a cultural and scenic excursion across the Kangra Valley. Visit the historic Kangra Fort, one of the oldest and largest forts in the Himalayas. Later, drive toward the lush, rolling tea gardens of Palampur. Enjoy a refreshing walk through the estates and visit the revered Chamunda Devi Temple before returning to your hotel in Dharamshala.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Serene Departure</h3>
                <p>Enjoy a final, peaceful breakfast overlooking the towering Dhauladhar mountains. You may visit the HPCA Cricket Stadium (one of the highest in the world) if time permits. Your chauffeur will provide a seamless drop-off at Dharamshala Airport or Pathankot/Chandigarh Railway Station for your journey home.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Hill-View Hotels</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan Transfers</li>
                <li><i class="fa-solid fa-camera"></i> Standard Khajjiar & McLeod Ganj Tour</li>
                <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/dalhousie-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- KANGRA & CHAMBA INSIGHTS HUB (6 GRID CARDS)               -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- UNIVERSAL CORE ICONS USED FOR 100% COMPATIBILITY          -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Kangra & Chamba Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details and cultural rules to ensure a flawless journey through the Dhauladhar ranges.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time to Visit</h3>
                <p>This circuit offers uniquely different seasonal charms:</p>
                <ul>
                    <li><strong>Spring & Summer (Mar - Jun):</strong> The absolute best time for clear skies, comfortable sightseeing, and lush greenery in Khajjiar.</li>
                    <li><strong>Winter (Dec - Feb):</strong> Dalhousie receives beautiful snowfall, transforming it into a winter wonderland, though it gets very cold.</li>
                    <li><strong>Monsoon (Jul - Aug):</strong> Dharamshala receives heavy rainfall; mist covers the valleys, but travel can be disrupted.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Spiritual Etiquette</h3>
                <p>McLeod Ganj is deeply sacred to Tibetan Buddhism:</p>
                <ul>
                    <li><strong>Monastery Rules:</strong> Maintain strict silence inside temple halls. Photography of the central deities is often prohibited.</li>
                    <li><strong>Prayer Wheels:</strong> Always walk around stupas and spin prayer wheels in a clockwise direction.</li>
                    <li><strong>Dress Code:</strong> Dress modestly, covering shoulders and knees when visiting the Tsuglagkhang Complex.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Mountain Transport</h3>
                <p>Patience is required on these specific mountain routes:</p>
                <ul>
                    <li><strong>McLeod Ganj Traffic:</strong> The roads in upper Dharamshala are extremely narrow. Expect severe traffic jams during peak season; walking is often faster.</li>
                    <li><strong>Winding Roads:</strong> The drive up to Dalhousie features sharp hairpin bends. Keep motion sickness medication handy.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-cloud-sun"></i></div>
                <h3>Weather & Khajjiar</h3>
                <p>Altitude creates rapid micro-climate shifts:</p>
                <ul>
                    <li><strong>Khajjiar Chills:</strong> Even if Dharamshala feels warm, the high-altitude meadow of Khajjiar can be windy and chilly. Always carry a light jacket.</li>
                    <li><strong>Winter Roadblocks:</strong> In heavy winters, the direct road from Dalhousie to Khajjiar may close, requiring a longer detour.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bag-shopping"></i></div>
                <h3>Tibetan Shopping</h3>
                <p>McLeod Ganj offers some of the best cultural shopping in India:</p>
                <ul>
                    <li><strong>Thangka Paintings:</strong> Exquisite, hand-painted Buddhist scrolls. Buy from authentic Tibetan refugee shops for quality.</li>
                    <li><strong>Singing Bowls:</strong> A perfect spiritual souvenir; ask the shopkeeper to demonstrate the correct technique to make them "sing."</li>
                    <li><strong>Warm Wear:</strong> Excellent quality Tibetan woolens are available across local markets.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Highlights</h3>
                <p>Experience a delightful mix of Himachali and Tibetan flavors:</p>
                <ul>
                    <li><strong>Tibetan Delights:</strong> Do not leave McLeod Ganj without trying authentic Steamed Momos, hearty Thukpa (noodle soup), and fluffy Tingmo bread.</li>
                    <li><strong>Himachali Madra:</strong> In Dalhousie, ask your hotel for Madra, a rich, yogurt-based chickpea or kidney bean curry traditional to Chamba.</li>
                    <li><strong>Cafe Culture:</strong> Dharamshala boasts world-class bakeries and cafes offering excellent mountain coffee and cakes.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Kangra & Chamba 6D/5N" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>