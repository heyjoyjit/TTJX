<?php
// Top of package-kerala-complete.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹35,000"; 
$sheet_affordable_price = "₹55,000";
$sheet_super_price = "₹85,000";

// EXACT package name from Google Sheet
$target_package = "Complete Kerala Grand Loop 13D/12N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hotels & Deluxe Houseboat</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the 13-Day Route</li>
            <li><i class="fa-solid fa-ship"></i> 1-Night Backwater Houseboat Cruise Included</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Mountain Resorts, Beach Villas & Premium Houseboat</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta for Maximum Inter-City Comfort</li>
            <li><i class="fa-solid fa-spa"></i> Complimentary Ayurvedic Massage & Spice Plantation Tour</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP) Highlighting Kerala Cuisine</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Palaces & Ultra-Luxury Retreats (e.g., Taj, Niraamaya, CGH Earth)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Sunset Motorboat Cruises, VIP Darshans & Private Kathakali Shows</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Dining, Private Beach BBQs & Authentic Sadya Feasts</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Complete Kerala Grand Loop 13 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="kerala-itinerary.php">Kerala Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Complete Grand Loop (13D/12N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['kerala grand loop hero']) ? $tourImages['kerala grand loop hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 13 Days / 12 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Complete Kerala Grand Loop</h1>
            <p>A magnificent 13-day expedition spanning colonial ports, mist-covered tea estates, dense spice jungles, tranquil backwaters, and golden coastal cliffs.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Complete Kerala Grand Loop 13D/12N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Experience the absolute pinnacle of God's Own Country. This comprehensive 13-day Grand Loop ensures you witness every shade of Kerala's incredible diversity without ever feeling rushed. You will begin by tracing the colonial history of Fort Kochi before ascending into the emerald tea gardens of Munnar and the dense, elephant-filled jungles of Thekkady. You will then glide across the backwaters on a private houseboat, relax on the dramatic cliffs of Varkala, and finally arrive at the southernmost beaches and monumental temples of Trivandrum and Kovalam.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Kochi & The Colonial Port</h3>
                <p>Arrive at Cochin International Airport (COK). Your private chauffeur will receive you and transfer you to the historic Fort Kochi district. Check into your heritage hotel. Spend the afternoon taking a walking tour of the 500-year-old colonial streets. Visit the iconic Chinese Fishing Nets, St. Francis Church, and the Dutch Palace. In the evening, attend a vibrant Kathakali classical dance performance.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Ascent to the Tea Capital (Munnar)</h3>
                <p>After breakfast, leave the coast and begin your scenic ascent into the Western Ghats towards Munnar (approx. 4 hours). Stop en route to view the magnificent Cheeyappara and Valara Waterfalls cascading down the mountainside. Arrive in Munnar, perfectly situated at 5,200 feet above sea level, and check into your mountain resort. Spend the evening relaxing amidst the rolling, mist-covered tea estates.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Emerald Highlands & Rare Wildlife</h3>
                <p>A full day dedicated to the beauty of Munnar. Start early and visit Eravikulam National Park to spot the endangered Nilgiri Tahr against the backdrop of Anamudi, South India's highest peak. Later, visit the Mattupetty Dam, offering stunning views and optional speed boating. Proceed to Echo Point for panoramic valley views and conclude the day with a visit to the Tata Tea Museum to understand the legacy of tea cultivation in the region.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Drive to the Spice Jungles (Thekkady)</h3>
                <p>Check out and enjoy a beautiful, winding drive south towards the Cardamom Hills of Thekkady (approx. 3.5 hours). The air will fill with the aroma of natural spices. Check into your jungle resort near the Periyar Tiger Reserve. In the late afternoon, enjoy a fascinating guided walk through a local spice plantation to see how pepper, cardamom, and cinnamon are grown. End the day watching an adrenaline-pumping Kalaripayattu martial arts show.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Periyar Lake Safari & Jungle Patrol</h3>
                <p>Wake up early for the iconic Periyar Lake Boat Safari. Cruising the lake at dawn offers the best chance to spot herds of wild Asiatic elephants, bison, and exotic birds on the shores. Return to the resort for breakfast. The rest of the day is free for optional eco-tourism activities: participate in a guided border hike, take a nature walk with indigenous tribal guides, or explore the bustling spice markets of Kumily.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Descent to the Backwaters (Kumarakom)</h3>
                <p>Bid farewell to the mountains and drive down to the tranquil plains of Kumarakom (approx. 4 hours), situated on the banks of the massive Vembanad Lake. Check into your luxury backwater resort. In the afternoon, visit the Kumarakom Bird Sanctuary, a haven for migratory birds like Siberian storks and egrets. Enjoy a deeply relaxing evening watching the sunset over the lake's vast expanse.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> The Great Houseboat Voyage (Alleppey)</h3>
                <p>After breakfast, take a short drive to Alleppey (Alappuzha) to board your private, traditional Kettuvallam (houseboat). Set sail at noon through the intricate labyrinth of canals, lagoons, and emerald paddy fields. Your onboard chef will prepare a lavish, authentic Kerala lunch. Watch the rural life of the backwater villages drift by before the boat drops anchor at sunset for a peaceful, starlit dinner on the water.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Disembarkation & The Cliffs of Varkala</h3>
                <p>Wake up to the gentle lapping of the backwaters. Disembark the houseboat after breakfast and drive south along the coastal highway to Varkala (approx. 3 hours). Varkala is unique for its dramatic red laterite cliffs standing adjacent to the Arabian Sea. Check into your cliff-top or beachside resort. Spend the evening exploring the vibrant cliff promenade, lined with bohemian cafes and yoga centers.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Coastal Serenity & Janardhanaswamy Temple</h3>
                <p>A day of absolute relaxation. Walk down the cliff stairs to swim in the pristine waters of Papanasam Beach, believed to wash away sins. Visit the ancient, 2,000-year-old Janardhanaswamy Temple located near the beach. We highly recommend dedicating the afternoon to a traditional Ayurvedic rejuvenation therapy at a certified wellness center. Enjoy a spectacular cliffside sunset dinner.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> The Royal Capital (Trivandrum) & Kovalam Beach</h3>
                <p>Check out and drive south to the capital city, Thiruvananthapuram (Trivandrum) (approx. 1.5 hours). Explore the regal history of the Travancore Kings by visiting the spectacular Napier Museum and the Kuthira Malika Palace. Proceed to the iconic Padmanabhaswamy Temple (viewing from outside, or Darshan subject to strict dress codes). Later, drive to the famous crescent-shaped beaches of Kovalam and check into your beach resort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> The Golden Sands & Poovar Island</h3>
                <p>Enjoy the golden sands of Kovalam's Lighthouse Beach and Hawa Beach. In the afternoon, take a short drive to the serene Poovar Island estuary (approx. 45 mins). Embark on a beautiful mangrove motorboat cruise where the river, backwaters, and the Arabian Sea seamlessly merge, creating a breathtaking sandbank. Return to Kovalam for a relaxed evening.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 12</span> Leisure, Wellness & Cultural Shopping</h3>
                <p>Your final full day in Kerala is deliberately left open. Enjoy the luxurious amenities of your Kovalam resort, soak up the sun, or indulge in a final Ayurvedic spa session. If you wish, take a short trip into Trivandrum city to purchase authentic Kerala souvenirs, including Kasavu (gold-bordered) sarees, exquisite rosewood carvings, and local spices. Enjoy a grand farewell dinner by the sea.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 13</span> Departure from Trivandrum</h3>
                <p>Your ultimate Kerala Grand Loop comes to a close. Enjoy a final South Indian breakfast. Your chauffeur will transfer you to the Trivandrum International Airport (TRV) or Railway Station for your onward journey, leaving you with memories of a perfectly complete tropical expedition.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Clean & Comfortable 3-Star Hotels & Deluxe Houseboat</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan (Dzire/Etios) for the 13-Day Route</li>
                <li><i class="fa-solid fa-ship"></i> 1-Night Backwater Houseboat Cruise Included</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included (CP Plan)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/kerala-complete-13d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- GRAND LOOP INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Grand Loop Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for this massive, 13-day multi-terrain tropical journey.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-plane-departure"></i></div>
                <h3>Flight Logistics</h3>
                <p>Avoiding a 7-hour backtrack:</p>
                <ul>
                    <li><strong>Gateways:</strong> Because this is a massive north-to-south loop, it is absolutely vital to book your arrival flight into Kochi (COK) and your departure flight out of Trivandrum (TRV). Driving from Kovalam back to Kochi on Day 13 is exhausting and highly discouraged.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase-rolling"></i></div>
                <h3>Packing for 3 Climates</h3>
                <p>Strategic layering is key:</p>
                <ul>
                    <li><strong>The Variations:</strong> Kochi, Alleppey, and Kovalam are deeply tropical, hot, and highly humid (pack light cottons and linens). Munnar and Thekkady, however, are high-altitude mountain stations that get quite chilly, especially at night (pack light jackets and sweaters).</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-ship"></i></div>
                <h3>Houseboat Realities</h3>
                <p>Setting cruise expectations:</p>
                <ul>
                    <li><strong>AC Operations:</strong> On Standard/Deluxe houseboats, the AC only functions from 9 PM to 6 AM while the boat is anchored. For 24/7 AC, you must select the Premium or Luxury tier. Boats must anchor at 5:30 PM by government law to allow fishermen to cast nets.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Temple Dress Codes</h3>
                <p>Strict rules in Trivandrum:</p>
                <ul>
                    <li><strong>Padmanabhaswamy Temple:</strong> This temple enforces one of the strictest dress codes in India. Men must wear only a white Mundu/Dhoti (no shirts). Women must wear a Saree or a long skirt with a half-saree draped over it. Modern clothing is strictly forbidden inside.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car-side"></i></div>
                <h3>The Winding Ghat Drives</h3>
                <p>Navigating the mountains:</p>
                <ul>
                    <li><strong>Motion Sickness:</strong> The drives from Kochi to Munnar and Munnar to Thekkady involve continuous, winding hairpin bends for several hours. If you are prone to motion sickness, please carry medication and inform your driver to maintain a moderate pace.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-cloud-showers-heavy"></i></div>
                <h3>Monsoon Seasonality</h3>
                <p>Traveling during the rains:</p>
                <ul>
                    <li><strong>June to August:</strong> Kerala receives massive monsoons. While the state turns a brilliant green and Ayurvedic treatments are highly recommended during this time, beach swimming in Varkala and Kovalam is strictly prohibited due to dangerous, rough seas.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Assam, Karnataka, Kerala, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your completely customized 13-day Grand Loop.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Complete Kerala Grand Loop 13D/12N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>