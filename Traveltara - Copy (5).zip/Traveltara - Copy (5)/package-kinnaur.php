<?php
// Top of package-kinnaur.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹24,000"; 
$sheet_affordable_price = "₹32,000";
$sheet_super_price = "₹48,000";

// EXACT package name from Google Sheet
$target_package = "Kinnaur 7D/6N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Valley View Stays</li>
            <li><i class="fa-solid fa-car"></i> Dedicated SUV for Rough Terrains</li>
            <li><i class="fa-solid fa-mountain"></i> Sangla & Chitkul Exploration</li>
            <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Boutique Apple Orchard Resorts</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> Guided Kalpa Village & Monastery Walk</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Dinners Featuring Local Flavors</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Equivalent Luxury Tents & Heritage Stays</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Riverside Picnic in Baspa Valley</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining & Premium Bonfire Evenings</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Kinnaur Valley Explorer | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="himachal-itinerary.php">Himachal</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Kinnaur Explorer (7D/6N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['kinnaur hero']) ? $tourImages['kinnaur hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 7 Days / 6 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Kinnaur Valley Explorer</h1>
            <p>A slow-travel immersion into the "Land of Gods," surrounded by apple orchards and towering snow peaks.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Kinnaur 7D/6N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Designed for those who seek majestic isolation, this 7-day slow-travel expedition delves deep into the Kinnaur Valley. Journey alongside the Sutlej and Baspa rivers, walk through centuries-old apple orchards in Sangla, stand at the very edge of India in Chitkul, and witness the sunrise illuminate the sacred Kinner Kailash range from Kalpa.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & Ascent to Narkanda</h3>
                <p>Begin your journey from Chandigarh Airport/Railway Station. Your expert hill chauffeur will navigate the scenic ascent past Shimla, bringing you to the tranquil, pine-scented town of Narkanda. This serves as the perfect, unhurried stopover to acclimatize before entering the high-altitude Kinnaur district. Check into your hotel and enjoy a serene evening.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Gateway to Kinnaur: Narkanda to Sangla</h3>
                <p>After breakfast, descend to the Sutlej River valley, driving along some of the most dramatic and awe-inspiring cliff-hanger roads in the world (the famous Taranda Dhak). Cross into the lush, green Baspa Valley and arrive in Sangla, completely surrounded by towering snow-capped peaks and endless apple orchards. Check into your premium resort or luxury camp.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> India's Last Village: Chitkul Excursion</h3>
                <p>Take a mesmerizing morning drive alongside the crystal-clear Baspa River to Chitkul (3,450m), the last inhabited village on the old Indo-Tibetan trade route. Walk through the rustic wooden houses, breathe the crisp mountain air, and enjoy a hot meal at "Hindustan Ka Aakhri Dhaba" (India's Last Dhaba). Return to Sangla for a relaxed evening.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Sangla to Kalpa via Reckong Peo</h3>
                <p>In the morning, visit the ancient Kamru Fort in Sangla, a stunning tower-like structure blending Hindu and Buddhist architecture. Proceed to Reckong Peo, the district headquarters, to pick up local Kinnauri shawls or pine nuts. Ascend further to Kalpa, a picturesque village offering the most unobstructed, majestic views of the sacred Kinner Kailash peak. Check into your hotel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Magic of Kalpa & Roghi Village</h3>
                <p>Wake up early to witness a magical sunrise, as the Kinner Kailash peaks turn golden. After breakfast, explore Kalpa's ancient Hu-Bu-Lan-Kar monastery and the Narayan-Nagini temple. Take a thrilling drive (or walk) to the famous "Suicide Point" for heart-stopping views of the vertical gorge, and visit the traditional Roghi village to witness authentic Kinnauri daily life.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Return Journey: Kalpa to Shimla</h3>
                <p>Bid farewell to the towering peaks of Kinnaur. Begin your long, scenic descent back through the Sutlej Valley, retracing the dramatic cliffside roads. Arrive in the colonial capital of Shimla by late afternoon. Check into your premium city hotel and spend your final evening enjoying a celebratory dinner on the famous Mall Road.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Departure</h3>
                <p>Enjoy a relaxed morning breakfast. Your chauffeur will provide a comfortable and seamless drive back down to the Chandigarh Airport or Railway Station, bringing an end to your spectacular Himalayan expedition.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Valley View Stays</li>
                <li><i class="fa-solid fa-car"></i> Dedicated SUV for Rough Terrains</li>
                <li><i class="fa-solid fa-mountain"></i> Sangla & Chitkul Exploration</li>
                <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/kinnaur-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- KINNAUR INSIGHTS HUB (6 GRID CARDS)                       -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- UNIVERSAL CORE ICONS USED FOR 100% COMPATIBILITY          -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Kinnaur Travel Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details and cultural rules to ensure a flawless journey through the high Himalayas.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time to Visit</h3>
                <p>The Kinnaur landscape changes dramatically with the seasons:</p>
                <ul>
                    <li><strong>Spring (Apr - May):</strong> The valleys burst into color with pink and white apple blossoms. Highly recommended.</li>
                    <li><strong>Autumn (Sep - Oct):</strong> The harvest season. The orchards are full of bright red apples, and the skies are crystal clear.</li>
                    <li><strong>Monsoon (Jul - Aug):</strong> Not recommended. The cliffside roads become highly prone to landslides and shooting stones.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-mountain"></i></div>
                <h3>Altitude & Acclimatization</h3>
                <p>You will be traveling to altitudes exceeding 11,000 feet (Chitkul):</p>
                <ul>
                    <li><strong>Pacing:</strong> This is why we halt at Narkanda on Day 1. Gradual ascent is the only way to prevent Acute Mountain Sickness (AMS).</li>
                    <li><strong>Hydration:</strong> Drink plenty of water and avoid alcohol during the first 48 hours in the high-altitude zones.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Transport Realities</h3>
                <p>Kinnaur boasts some of the most dramatic roads on the planet:</p>
                <ul>
                    <li><strong>The "Half-Tunnel" Roads:</strong> The drive through Taranda Dhak involves roads literally carved into sheer rock faces. Our expert local drivers are highly trained for this terrain.</li>
                    <li><strong>Vehicle Type:</strong> High ground-clearance SUVs (Innova, Fortuner) are strictly recommended over sedans for this circuit.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Cultural Etiquette</h3>
                <p>Kinnaur represents a beautiful, seamless blend of Hinduism and Buddhism:</p>
                <ul>
                    <li><strong>Temple Rules:</strong> Many local temples (like Kamru Fort) require you to wear a traditional Kinnauri cap and tie a sash around your waist before entering. These are provided at the gates.</li>
                    <li><strong>Respect:</strong> Always ask permission before photographing local tribal residents in traditional attire.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-wifi"></i></div>
                <h3>Network & Connectivity</h3>
                <p>Prepare for a digital detox in the deeper valleys:</p>
                <ul>
                    <li><strong>Mobile Network:</strong> BSNL and Jio offer the most reliable connectivity in Kalpa and Sangla. Airtel and Vodafone may lose signal entirely in Chitkul.</li>
                    <li><strong>Wi-Fi:</strong> While premium hotels offer Wi-Fi, expect slow speeds due to the remote mountainous terrain.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Highlights</h3>
                <p>Indulge in authentic, hyper-local Himalayan flavors:</p>
                <ul>
                    <li><strong>Chilgoza (Pine Nuts):</strong> Kinnaur is one of the only places in India that produces these expensive, buttery nuts. Buy them fresh in Reckong Peo.</li>
                    <li><strong>Apple Products:</strong> Enjoy locally produced apple juices, jams, and ciders right from the orchards.</li>
                    <li><strong>Tibetan Influence:</strong> Warm up with excellent Momos, Thukpa, and butter tea in the local dhabas.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Kinnaur Explorer 7D/6N" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>