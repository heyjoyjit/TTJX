<?php
// Top of package-ladakh.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹48,000"; 
$sheet_affordable_price = "₹65,000";
$sheet_super_price = "₹95,000";

// EXACT package name from Google Sheet
$target_package = "Leh Ladakh Epic 11D/10N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Standard Guesthouses & Alpine Tents</li>
            <li><i class="fa-solid fa-car"></i> Dedicated SUV (Xylo/Scorpio)</li>
            <li><i class="fa-solid fa-id-card"></i> Inner Line Permits Included</li>
            <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium Boutique Hotels & Luxury Swiss Camps</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta for entire route</li>
            <li><i class="fa-solid fa-star"></i> Oxygen Cylinder in Vehicle for High Passes</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Top-Tier Luxury Retreats (e.g., Grand Dragon, Chamba Camp)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Monastery & Stargazing Tours</li>
            <li><i class="fa-solid fa-utensils"></i> Premium Dining & Exclusive Bonfires</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Trans-Himalayan Epic | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="himachal-itinerary.php">Himachal</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Trans-Himalayan Epic (11D/10N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['leh ladakh hero']) ? $tourImages['leh ladakh hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 11 Days / 10 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Trans-Himalayan Epic</h1>
            <p>The ultimate road trip. Traverse the legendary Manali-Leh Highway into the "Land of High Passes."</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Leh Ladakh Epic 11D/10N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>This is the holy grail of road trips. Designed for absolute safety and proper acclimatization, this 11-day expedition takes you from the green pine valleys of Manali, across five formidable mountain passes, into the stark, breathtaking cold desert of Ladakh. Witness the crystal-clear waters of Pangong Tso, ride the double-humped camels in the dunes of Nubra Valley, and experience the deep Buddhist spirituality of ancient monasteries.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Manali</h3>
                <p>Arrive in Manali (via flight to Kullu or drive from Chandigarh). Check into your premium resort. Spend the day resting and acclimatizing to the altitude. Take a gentle evening stroll through Old Manali to prepare for the epic journey ahead.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Manali to Jispa via Atal Tunnel</h3>
                <p>The epic journey begins! Drive through the engineering marvel of the Atal Tunnel (or the majestic Rohtang Pass, weather permitting), leaving the green Kullu valley and entering the barren landscapes of Lahaul. Drive alongside the Chandra River to reach the tranquil village of Jispa. Check into your hotel or luxury camp for the night.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Jispa to Sarchu (Crossing Baralacha La)</h3>
                <p>Ascend further into the trans-Himalayas. Stop at the crystal-clear Deepak Tal and Suraj Tal lakes before crossing the formidable Baralacha La Pass (16,040 ft). Descend into the spectacular, wind-swept plains of Sarchu, the border between Himachal Pradesh and Ladakh. Overnight in an alpine camp under a blanket of stars.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Sarchu to Leh via Tanglang La</h3>
                <p>Brace yourself for an incredible driving day. Navigate the famous 21 hairpin bends of the Gata Loops, cross Nakee La and Lachulung La, and drive across the vast, flat Morey Plains. Finally, cross Tanglang La (17,480 ft), the second highest motorable pass in the world, before descending into the Indus Valley to reach Leh. Check into your premium hotel and rest.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Leh Local Sightseeing & Acclimatization</h3>
                <p>Take the day slow to adjust to Leh's altitude (11,500 ft). Visit the towering Shanti Stupa for panoramic views of the city, explore the historic 17th-century Leh Palace, and browse the vibrant Leh Market in the evening. This relaxed day is crucial for your body to fully adapt.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Sham Valley Tour</h3>
                <p>Drive west along the Indus River toward Kargil. Experience the gravity-defying phenomenon at Magnetic Hill, visit the revered Gurudwara Pathar Sahib, and witness the stunning confluence (Sangam) of the Indus and Zanskar rivers. Continue to the ancient Alchi Monastery, known for its rare 11th-century frescoes, before returning to Leh.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Leh to Nubra Valley via Khardung La</h3>
                <p>Drive up to the legendary Khardung La (18,380 ft), long claimed as the world's highest motorable road. Descend into the spectacular Nubra Valley, known as the "Valley of Flowers." Visit the majestic Diskit Monastery and head to the Hunder Sand Dunes to ride the rare Bactrian (double-humped) camels. Overnight in a luxury camp in Nubra.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Nubra Valley to Pangong Tso via Shyok</h3>
                <p>Today features a thrilling, off-the-beaten-path drive running parallel to the Shyok River. Traverse rugged terrains and water crossings to reach the breathtaking Pangong Tso, the highest saltwater lake in the world. Watch the lake's pristine waters change colors from deep blue to turquoise. Overnight in a lakeside camp.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Pangong Tso to Leh via Chang La</h3>
                <p>Wake up to a freezing, spectacular sunrise over Pangong Lake. After breakfast, begin your journey back to Leh. You will cross the mighty Chang La Pass (17,586 ft), the third highest motorable pass. Stop at the famous Thiksey Monastery, known for its towering Maitreya Buddha statue, before arriving in Leh for the night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Buffer Day & Leh Leisure</h3>
                <p>A completely free day in Leh. Use this day to relax, visit local cafes, buy authentic Pashmina shawls or Tibetan handicrafts in the market, or simply recover from the high-altitude drives. (This day also serves as an essential safety buffer in case of any road blockages during the Pangong/Nubra circuit).</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 11</span> Departure from Leh</h3>
                <p>Enjoy your final breakfast in the "Land of High Passes." Your chauffeur will provide a seamless drop-off at the Kushok Bakula Rimpochee Airport (Leh Airport) for your flight back home, carrying a lifetime of epic memories.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Standard Guesthouses & Alpine Tents</li>
                <li><i class="fa-solid fa-car"></i> Dedicated SUV (Xylo/Scorpio)</li>
                <li><i class="fa-solid fa-id-card"></i> Inner Line Permits Included</li>
                <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/ladakh-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- LADAKH INSIGHTS HUB (6 GRID CARDS)                        -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- UNIVERSAL CORE ICONS USED FOR 100% COMPATIBILITY          -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Ladakh Survival Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details and safety protocols for undertaking India's toughest road trip.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>The Travel Window</h3>
                <p>The Manali-Leh highway is governed strictly by snowfall:</p>
                <ul>
                    <li><strong>Mid-June to Sep:</strong> The ONLY time the highway is fully open and safe for tourist travel. Snow is cleared from the passes.</li>
                    <li><strong>Winter (Oct - May):</strong> The highway is completely blocked by feet of snow. Leh can only be accessed via direct flights.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase-medical"></i></div>
                <h3>Altitude & AMS</h3>
                <p>Acute Mountain Sickness (AMS) is a severe reality on this route:</p>
                <ul>
                    <li><strong>Sarchu Danger:</strong> Sarchu sits at 14,000+ feet. Do not overexert yourself here. Walk slowly and drink plenty of water.</li>
                    <li><strong>Oxygen:</strong> Premium tours include an emergency oxygen cylinder in the vehicle. Keep Diamox handy (consult your doctor).</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-id-card"></i></div>
                <h3>Inner Line Permits</h3>
                <p>Ladakh shares sensitive borders with China and Pakistan:</p>
                <ul>
                    <li><strong>Requirement:</strong> Indian and foreign nationals require Inner Line Permits (ILP) or Protected Area Permits (PAP) to visit Nubra Valley and Pangong Lake.</li>
                    <li><strong>Processing:</strong> Traveltara handles all permit processing. Ensure you carry original, valid Government ID cards (Aadhar, Passport) at all times.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Transport & Local Unions</h3>
                <p>Ladakh has very strict local taxi union rules:</p>
                <ul>
                    <li><strong>Vehicle Swaps:</strong> The vehicle that brings you from Manali <strong>cannot</strong> be used for local sightseeing in Leh, Nubra, or Pangong. You must switch to a Leh-registered taxi for the Ladakh leg.</li>
                    <li><strong>No Sedans:</strong> The water crossings (Nallahs) on the Manali-Leh highway destroy sedans. High-clearance SUVs are mandatory.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Weather & Packing</h3>
                <p>Prepare for freezing nights and burning days:</p>
                <ul>
                    <li><strong>Sun Protection:</strong> The UV rays at 15,000 feet will cause severe sunburns quickly. High-SPF sunscreen and UV sunglasses are non-negotiable.</li>
                    <li><strong>Layers:</strong> Sarchu and Pangong will be near-freezing at night, even in July. Pack heavy thermals, windproof jackets, and woolen caps.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-wifi"></i></div>
                <h3>Network Blackout</h3>
                <p>Prepare to disconnect from the modern world completely at times:</p>
                <ul>
                    <li><strong>Postpaid Only:</strong> <strong>Prepaid SIM cards from outside J&K/Ladakh DO NOT WORK in Ladakh.</strong> You must carry a Postpaid connection.</li>
                    <li><strong>Coverage:</strong> BSNL and Jio work well in Leh city. Expect zero network coverage in Sarchu, and highly erratic coverage in Nubra and Pangong.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Leh Ladakh Epic 11D/10N" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>