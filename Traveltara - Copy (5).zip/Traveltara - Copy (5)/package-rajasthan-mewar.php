<?php
// Top of package-rajasthan-mewar.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 LIVE HOSTINGER DATABASE CONNECTION (UNIVERSAL PRICING ENGINE)
// =========================================================================

// EXACT package name from your Admin Dashboard
$target_package = "Palaces of Mewar 8D/7N"; 

// Call the universal brain file to fetch the live prices!
require_once 'live_pricing.php';

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Heritage Guesthouses</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Route</li>
            <li><i class="fa-solid fa-water"></i> Standard Group Boat Ride on Lake Pichola</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Boutique Lake-View Havelis</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> Guided Fort Walks at Kumbhalgarh & Chittorgarh</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Lake Palaces (Taj/Oberoi/Leela properties)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Private Sunset Cruise on Lake Pichola</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining & Heritage Courtyard Meals</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Palaces of Mewar 8 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="rajasthan-itinerary.php">Rajasthan</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Palaces of Mewar (8D/7N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['udaipur hero']) ? $tourImages['udaipur hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 8 Days / 7 Nights</div>
        <div class="subpage-hero-content">
            <h1>Palaces of Mewar</h1>
            <p>An elegant, immersive journey through shimmering lakes, impregnable forts, and the majestic Aravalli hills.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Palaces of Mewar 8D/7N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Delve into the deeply romantic and fiercely proud history of the Mewar Kingdom. This 8-day circuit focuses exclusively on Southern Rajasthan, allowing for a luxurious, slow-paced exploration. You will begin in the romantic City of Lakes (Udaipur), ascend to the colossal walls of Kumbhalgarh, retreat to the cool, highland breezes of Mount Abu, and explore the largest fort in India at Chittorgarh.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in the City of Lakes (Udaipur)</h3>
                <p>Arrive at Maharana Pratap Airport or Udaipur Railway Station. Your luxury chauffeur will transfer you to your lakeside heritage property. Spend a serene afternoon unwinding. In the evening, witness a mesmerizing sunset as you take your first boat ride upon the tranquil waters of Lake Pichola, sailing past Jag Mandir and the iconic Taj Lake Palace.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The Royal Splendor of Udaipur</h3>
                <p>After breakfast, step into the grandeur of the Udaipur City Palace, the largest palace complex in Rajasthan, filled with courtyards, pavilions, and hanging gardens. Visit the intricately carved Jagdish Temple and stroll through the lush Saheliyon Ki Bari (Garden of the Maidens). In the evening, attend the vibrant Dharohar folk dance show at Bagore Ki Haveli.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Udaipur to the Great Wall (Kumbhalgarh)</h3>
                <p>Depart Udaipur and drive through the scenic Aravalli hills to Kumbhalgarh (approx. 2.5 hours). Check into your nature resort nestled in the valley. Spend the afternoon exploring the massive Kumbhalgarh Fort, a UNESCO World Heritage site featuring the second-longest continuous wall on the planet. Stay for the captivating evening sound and light show that illuminates the citadel.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Kumbhalgarh to Mount Abu via Ranakpur</h3>
                <p>Leave Kumbhalgarh and drive toward Rajasthan's only hill station, Mount Abu. En route, stop deep in a forested valley to explore the Ranakpur Jain Temple, a true architectural wonder supported by 1,444 uniquely carved, pale marble pillars. Continue your ascent into the cool breezes of Mount Abu. Check into your highland retreat and relax.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Highland Retreat (Mount Abu)</h3>
                <p>Spend the day exploring the cool, lush landscapes of Mount Abu. Visit the world-renowned Dilwara Jain Temples, known for their breathtakingly intricate marble carvings. Enjoy a peaceful boat ride on Nakki Lake, surrounded by hills and unique rock formations like Toad Rock. Drive up to Guru Shikhar, the highest peak in the Aravalli Range, for sweeping panoramic views.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Mount Abu to the Citadel of Pride (Chittorgarh)</h3>
                <p>Descend from the hills and drive to the legendary city of Chittorgarh (approx. 4.5 hours). Upon arrival, check into your hotel. Spend the late afternoon taking a preliminary drive around the colossal Chittorgarh Fort plateau, the largest fort in India, standing as a testament to Rajput courage and chivalry.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Epic Chittorgarh & Return to Udaipur</h3>
                <p>Dedicate the morning to a deep exploration of Chittorgarh Fort. Visit the towering Vijay Stambh (Tower of Victory), Kirti Stambh, Rana Kumbha Palace, and the sacred Meera Temple. Learn the epic tales of Queen Padmini and Rani Karnavati. In the afternoon, embark on the short drive back to Udaipur (approx. 2 hours) for a final, celebratory royal dinner by the lake.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Departure from Udaipur</h3>
                <p>Enjoy a final, unhurried breakfast overlooking the Aravalli hills. Depending on your flight or train schedule, you may explore the local bazaars for authentic Pichwai miniature paintings or leather crafts. Your chauffeur will provide a seamless transfer to the Udaipur Airport or Railway Station for your journey home.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Comfortable 3-Star Heritage Guesthouses</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Route</li>
                <li><i class="fa-solid fa-water"></i> Standard Group Boat Ride on Lake Pichola</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/mewar-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- MEWAR INSIGHTS HUB (6 GRID CARDS)                         -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Royal Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical insights to ensure your journey through the Mewar region is seamless, comfortable, and culturally enriching.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>Best Time to Visit</h3>
                <p>The Mewar region's hilly terrain offers unique seasonal charms:</p>
                <ul>
                    <li><strong>Monsoon (Jul - Sep):</strong> Arguably the most beautiful time. The Aravallis turn lush green, the lakes fill up, and Kumbhalgarh looks magical hidden in the mist.</li>
                    <li><strong>Winter (Oct - Mar):</strong> The peak season with perfect, sunny days. Mount Abu gets delightfully chilly at night.</li>
                    <li><strong>Summer (Apr - Jun):</strong> Hot in Udaipur and Chittorgarh, making Mount Abu a welcome highland escape.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-hands-praying"></i></div>
                <h3>Temple Etiquette</h3>
                <p>This region houses some of India's most breathtaking Jain temples:</p>
                <ul>
                    <li><strong>Ranakpur & Dilwara:</strong> Both have exceptionally strict dress codes (shoulders and knees must be covered). </li>
                    <li><strong>Leather Ban:</strong> You must leave all leather items (belts, shoes, wallets, bags) in your vehicle before entering these sacred complexes. Photography is often heavily restricted inside.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-camera"></i></div>
                <h3>Monument Realities</h3>
                <p>Exploring these massive forts requires pacing:</p>
                <ul>
                    <li><strong>Chittorgarh:</strong> This fort is so massive (700 acres) that you actually explore it via your car, stopping at different palatial ruins and towers.</li>
                    <li><strong>Kumbhalgarh:</strong> Features very steep, cobbled ramps. Wear excellent walking shoes. The fort is beautifully illuminated for a short time every evening.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-water"></i></div>
                <h3>Lake Pichola Rules</h3>
                <p>Udaipur's famous lake has strict operational protocols:</p>
                <ul>
                    <li><strong>Sunset Cruises:</strong> Sunset boat rides are the most heavily booked activity in Udaipur. Premium packages secure these in advance, but availability is strictly regulated by the palace trust.</li>
                    <li><strong>Water Levels:</strong> During severe summer droughts, the lake water levels can recede, occasionally impacting boat operations.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bag-shopping"></i></div>
                <h3>Mewar Shopping</h3>
                <p>Udaipur is an artisanal paradise for royal crafts:</p>
                <ul>
                    <li><strong>Miniature Paintings:</strong> Udaipur is globally renowned for Pichwai and miniature paintings done on silk, camel bone, or antique paper.</li>
                    <li><strong>Leather Goods:</strong> Excellent quality camel leather journals and bags are available in the city bazaars.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Culinary Delights</h3>
                <p>Rajput cuisine is rich, fiery, and deeply flavorful:</p>
                <ul>
                    <li><strong>Dal Baati Churma:</strong> The quintessential Rajasthani vegetarian dish. Hard wheat rolls served with lentil curry and sweet crushed wheat.</li>
                    <li><strong>Laal Maas:</strong> A fiery, smoky mutton curry prepared with special Mathania red chilies—a must-try for non-vegetarians.</li>
                    <li><strong>Mount Abu:</strong> Being a prominent Jain pilgrimage site, Mount Abu features incredible, pure vegetarian and vegan dining options.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream royal escape to Rajasthan.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Palaces of Mewar 8D/7N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>