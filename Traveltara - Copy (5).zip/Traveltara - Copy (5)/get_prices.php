<?php
// This is a public API. It only READS data, so it is safe.
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$conn = new mysqli("localhost", "u505532187_admin", "Traveltara@2026", "u505532187_traveltara");

if ($conn->connect_error) {
    die(json_encode(["error" => "Database connection failed"]));
}

$result = $conn->query("SELECT `Package Name`, `Budget`, `Affordable Luxury`, `Super Luxury` FROM pricing");

$pricing_data = [];
while($row = $result->fetch_assoc()) {
    // Organize by package name for easy JS searching
    $pricing_data[$row['Package Name']] = $row;
}

echo json_encode($pricing_data);
$conn->close();
?>