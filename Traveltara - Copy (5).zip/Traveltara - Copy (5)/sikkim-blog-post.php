<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Ultimate 5-Day Luxury Itinerary for North Sikkim | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <header class="hero" style="height: 50vh; background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/sikkim-blog.jpg') center/cover;"></header>

    <main class="single-post-container section-padding">
        <div class="post-header">
            <span class="blog-category">Destination Guide</span>
            <h1>The Ultimate 5-Day Luxury Itinerary for North Sikkim</h1>
            <div class="post-meta-details">
                <p><i class="fa-regular fa-calendar"></i> April 2, 2026</p>
                <p><i class="fa-regular fa-user"></i> By Traveltara Experts</p>
                <p><i class="fa-regular fa-clock"></i> 5 min read</p>
            </div>
        </div>

        <article class="post-content">
            <p class="lead-paragraph">Discover the secrets of high-altitude luxury. From the sacred Gurudongmar Lake to boutique chalets in Lachen, here is how to experience Sikkim without compromising on comfort.</p>

            <p>North Sikkim is widely considered one of the final frontiers of untouched Himalayan beauty. However, the rugged terrain often deters those who prefer the comforts of luxury travel. At <strong>traveltara</strong>, we have redefined the North Sikkim experience by blending raw alpine adventure with premium hospitality.</p>

            <blockquote class="post-quote">
                "True luxury is not just a soft bed; it is having a hot cup of Darjeeling tea waiting for you at 15,000 feet."
            </blockquote>

            <h2>Days 1 & 2: Acclimatizing in Gangtok</h2>
            <p>Before heading to the high altitudes, your journey begins in Gangtok. Rather than standard hotels, we place our guests in 5-star spa resorts overlooking the valley. Spend your days visiting the Rumtek Monastery and enjoying private dining experiences that fuse traditional Sikkimese ingredients with modern culinary techniques.</p>

            <h2>Days 3 & 4: Lachen and Lachung</h2>
            <p>The drive to Lachen is breathtaking but long. Traveltara ensures you travel in premium SUVs equipped with amenities and an expert local guide. In Lachen and Lachung, we partner with exclusive boutique chalets that offer heated bedding, gourmet meals, and uninterrupted views of snow-capped peaks.</p>

            <div class="in-post-cta">
                <h3>Ready to conquer the Himalayas in style?</h3>
                <p>Let our experts design your perfect high-altitude escape.</p>
                <button class="btn-primary" onclick="openLeadPopup()">Consult an Expert</button>
            </div>

            <h2>Day 5: Gurudongmar Lake</h2>
            <p>Visiting one of the highest lakes in the world requires an early start. Our concierges arrange for packed luxury breakfasts and ensure all your VIP permits are handled in advance, allowing you to focus entirely on the spiritual and visual majesty of the crystal-clear glacial waters.</p>
        </article>
        
        <div class="author-box">
            <div class="author-avatar"><i class="fa-solid fa-user-tie"></i></div>
            <div class="author-info">
                <h4>Traveltara Experts</h4>
                <p>Curators of high-altitude luxury and bespoke Himalayan experiences.</p>
            </div>
        </div>
    </main>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">Internation</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/917439877604" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

    <a href="https://wa.me/917439877604" class="whatsapp-sticky" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Book Your Sikkim Escape</h3>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Reference *</label><input type="text" value="Sikkim Blog Post" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>