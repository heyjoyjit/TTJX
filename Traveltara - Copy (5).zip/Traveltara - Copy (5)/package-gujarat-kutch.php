<?php
// Top of package-gujarat-kutch.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹18,500"; 
$sheet_affordable_price = "₹28,000";
$sheet_super_price = "₹45,000";

// EXACT package name from Google Sheet
$target_package = "White Desert Odyssey 7D/6N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Standard 3-Star Hotels & Traditional Mud Bhungas</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Route</li>
            <li><i class="fa-solid fa-ticket"></i> Rann Permit Assistance Included</li>
            <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Heritage Havelis & AC Swiss Tents</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> Guided Tour of Harappan Ruins (Dholavira)</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Kutchi Buffet Dinners (MAP)</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> 5-Star Palaces & Premium Tents at Rann Utsav (Tent City)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) or Premium Van</li>
            <li><i class="fa-solid fa-crown"></i> Exclusive Sunset High-Tea on the White Rann</li>
            <li><i class="fa-solid fa-utensils"></i> Fine Dining, Beachside Seafood & Private Cultural Shows</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The White Desert Odyssey 7 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="gujarat-itinerary.php">Gujarat</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">The White Desert Odyssey (7D/6N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['kutch hero']) ? $tourImages['kutch hero'] : $fallbackImg; ?>') center/cover; padding: 60px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 7 Days / 6 Nights</div>
        <div class="subpage-hero-content">
            <h1>The White Desert Odyssey</h1>
            <p>Step into the surreal, shimmering salt flats and vibrant tribal culture of the Kutch region.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="White Desert Odyssey 7D/6N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Welcome to Kutch, a land that feels entirely disconnected from the rest of the world. This 7-day odyssey begins in the historic capital of Bhuj, exploring its earthquake-surviving palaces. You will journey out to the immense, shimmering white salt flats of the Great Rann, stay in traditional Bhunga (mud huts), stand at the edge of the Indo-Pak border at Kalo Dungar, explore the 4,500-year-old Harappan ruins of Dholavira, and relax by the Arabian Sea at the royal town of Mandvi.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Bhuj: The Heart of Kutch</h3>
                <p>Arrive at Bhuj Airport or Railway Station (alternatively, fly into Ahmedabad and drive). Your chauffeur will transfer you to your heritage hotel. Spend the afternoon exploring the royal complex of Bhuj: visit the Aina Mahal (Palace of Mirrors) and the Italian-Gothic Prag Mahal. In the evening, visit the beautiful Shree Swaminarayan Temple.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Bhuj to the Great Rann of Kutch</h3>
                <p>After breakfast, depart for the vast Rann of Kutch (approx. 2 hours). Arrive at Dhordo or Hodka village and check into your traditional, beautifully painted circular mud hut (Bhunga) or luxury tent. In the late afternoon, drive into the Great Rann. Walk out onto the endless expanse of the white salt flats to witness one of the most surreal and spectacular sunsets on Earth.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Kalo Dungar & Kutchi Craft Villages</h3>
                <p>Wake up early for an optional sunrise visit to the salt flats. After breakfast, drive up to Kalo Dungar (Black Hill), the highest point in Kutch, offering a panoramic view of the Great Rann extending all the way to the Indo-Pak border. Visit the 400-year-old Dattatreya Temple. In the afternoon, visit artisan villages like Nirona to witness the rare Rogan art, bell making, and intricate Kutchi embroidery.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> The Road to Dholavira (The Harappan Ruins)</h3>
                <p>Prepare for one of India's most spectacular drives. Depart the Dhordo region and drive to Dholavira (approx. 5 hours) via the "Road to Heaven," a stunning highway that cuts directly through a massive lake in the Rann. Arrive and explore the UNESCO World Heritage Site of Dholavira, a remarkably well-planned, 4,500-year-old ancient metropolis of the Indus Valley Civilization. Check into your local eco-resort.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Dholavira to the Royal Coast (Mandvi)</h3>
                <p>After a quiet breakfast, leave the ancient ruins behind and drive south through the arid landscape toward the coastal town of Mandvi (approx. 5-6 hours). Once a major port for the spice trade, Mandvi is now a serene beach retreat. Check into your beachside resort or heritage camp and enjoy a relaxed evening listening to the Arabian Sea.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> Palaces, Ships, and Beaches of Mandvi</h3>
                <p>Spend the day exploring Mandvi. Visit the majestic Vijay Vilas Palace, set amidst 450 acres of lush greenery and famous for its red sandstone architecture (and numerous Bollywood film shoots). Later, visit the traditional ship-building yard where massive wooden dhows are still crafted by hand. Spend your final evening relaxing on the pristine sands of Mandvi Beach.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Departure from Bhuj</h3>
                <p>Enjoy a final coastal breakfast. Your chauffeur will drive you back to Bhuj (approx. 1.5 hours) for some last-minute shopping at the vibrant Bhujodi craft village or Vande Mataram Memorial. You will be seamlessly transferred to Bhuj Airport, Railway Station, or driven back to Ahmedabad for your onward journey home.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Standard 3-Star Hotels & Traditional Mud Bhungas</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Sedan for the Entire Route</li>
                <li><i class="fa-solid fa-ticket"></i> Rann Permit Assistance Included</li>
                <li><i class="fa-solid fa-utensils"></i> Daily Breakfast Included</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/kutch-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- KUTCH INSIGHTS HUB (6 GRID CARDS)                         -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Travel Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Desert Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to ensure your journey through the extreme landscapes of Kutch is seamless and culturally enriching.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>The Rann Utsav & Best Time</h3>
                <p>The White Rann is entirely seasonal:</p>
                <ul>
                    <li><strong>Winter (Nov - Feb):</strong> The absolute best time to visit. The salt marsh is completely dry and brilliant white. This coincides with the vibrant Rann Utsav festival.</li>
                    <li><strong>Monsoon/Summer:</strong> During the monsoon, the Rann floods with seawater and is inaccessible. Summer is blisteringly hot and should be avoided.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-id-card"></i></div>
                <h3>Border Permits</h3>
                <p>Kutch borders Pakistan, and security is tight:</p>
                <ul>
                    <li><strong>Mandatory Permits:</strong> A government permit is required to enter the White Rann salt flats and to drive up to Kalo Dungar.</li>
                    <li><strong>Documentation:</strong> Original government-issued IDs (Aadhar, Passport) must be carried at all times. Our team handles the permit processing for you.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Extreme Temperatures</h3>
                <p>The desert plays tricks with the temperature:</p>
                <ul>
                    <li><strong>Daytime:</strong> Even in December, the stark white salt reflects the sun intensely. High-SPF sunscreen and sunglasses are mandatory to prevent snow-blindness effects.</li>
                    <li><strong>Nighttime:</strong> Once the sun sets over the salt flats, the temperature plummets dramatically. Heavy winter jackets are essential for the evening.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bed"></i></div>
                <h3>The Bhunga Experience</h3>
                <p>Embrace the local architecture:</p>
                <ul>
                    <li><strong>Mud Huts:</strong> In the Dhordo/Hodka region, you will stay in traditional circular mud huts called Bhungas. These are specifically designed by locals to withstand earthquakes and regulate desert temperatures.</li>
                    <li><strong>Premium Comfort:</strong> In our affordable and super luxury tiers, these traditional huts are fully air-conditioned and feature modern western bathrooms.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bag-shopping"></i></div>
                <h3>Artisanal Shopping</h3>
                <p>Kutch is the handicraft capital of India:</p>
                <ul>
                    <li><strong>Textiles:</strong> World-famous for intricate mirror-work embroidery, Ajrakh block printing, and Bandhani.</li>
                    <li><strong>Rogan Art:</strong> Visit Nirona village to witness Rogan art—a 300-year-old fabric painting tradition practiced by only one surviving family in the world.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Kutchi Cuisine</h3>
                <p>The local diet is simple, hearty, and largely vegetarian:</p>
                <ul>
                    <li><strong>Kutchi Thali:</strong> Enjoy authentic meals featuring Bajra (pearl millet) rotis, severe garlic chutneys, and buttermilk.</li>
                    <li><strong>Dabeli:</strong> Do not leave Bhuj or Mandvi without trying the famous Kutchi Dabeli, a sweet, spicy, and tangy potato-filled bun that originated in this very region.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Himachal Pradesh, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your dream White Desert expedition.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="White Desert Odyssey 7D/6N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>