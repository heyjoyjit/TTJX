<?php
// Top of package-sikkim-complete.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹32,000"; 
$sheet_affordable_price = "₹48,000";
$sheet_super_price = "₹75,000";

// EXACT package name from Google Sheet
$target_package = "Complete Sikkim Grand Loop 10D/9N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Clean 3-Star Hotels & Authentic Alpine Homestays</li>
            <li><i class="fa-solid fa-car"></i> Dedicated Utility Vehicle (Bolero/Sumo/WagonR based on terrain)</li>
            <li><i class="fa-solid fa-ticket"></i> All Standard Inner Line & North Sikkim Permits Included</li>
            <li><i class="fa-solid fa-utensils"></i> All Meals in North/East Sikkim; Breakfast elsewhere</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium 4-Star Resorts & AC Boutique Camps</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta / Xylo for Superior Comfort</li>
            <li><i class="fa-solid fa-mountain-sun"></i> Offbeat Excursions to Dzongu & Darap Village</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Buffet Dinners (MAP Plan) & Local Delicacies</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Top-Tier 5-Star Heritage Luxury (e.g., Elgin, Mayfair)</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner) for Maximum Safety on Mountain Roads</li>
            <li><i class="fa-solid fa-crown"></i> VIP Permit Assistance, Private Oxygen & Exclusive Cultural Evenings</li>
            <li><i class="fa-solid fa-utensils"></i> Gourmet Dining, Traditional Tibetan Feasts & Riverside Picnics</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Complete Sikkim Grand Loop 10 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit; font-weight: bold;"><strong>traveltara</strong></a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="sikkim-itinerary.php">Sikkim Packages</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Complete Grand Loop (10D/9N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION (Compact Padding) -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['complete sikkim hero']) ? $tourImages['complete sikkim hero'] : $fallbackImg; ?>') center/cover; padding: 40px 20px;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 10 Days / 9 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Complete Sikkim Grand Loop</h1>
            <p>From the frozen extremes of Gurudongmar to the ancient Silk Route and the spiritual heart of the West.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Complete Sikkim Grand Loop 10D/9N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>This is the ultimate, comprehensive Himalayan odyssey. In 10 days, you will cross all four cardinal zones of Sikkim. You'll navigate the dizzying hairpins of the East's ancient Silk Route, stand breathless before the sacred, high-altitude Gurudongmar Lake in the North, and gaze at Mount Kanchenjunga from the ancient monasteries of the West. To make this loop entirely unique, we deliberately take you off the commercial path—sleeping in the restricted Lepcha reserve of Dzongu and exploring the rustic beauty of Darap Village.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & The East Sikkim Gateway</h3>
                <p>Arrive at Bagdogra Airport (IXB) or NJP. Your mountain chauffeur will drive you into East Sikkim towards the ancient Silk Route. Stop at Rongli for permit processing and ascend to the offbeat hamlet of Phadamchen or Zuluk (approx. 5 hours). Check into your local homestay, acclimatize to the 9,000 ft altitude, and prepare for the expedition ahead.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> The 95 Hairpins & Transfer to Gangtok</h3>
                <p>Wake up before dawn and drive up the legendary 95-hairpin bends of the Zuluk loop to witness the spectacular sunrise over Kanchenjunga from Thambi Viewpoint (11,200 ft). Traverse the high-altitude Nathang Valley, cross the Elephant Lake, and descend via the winding mountain roads into the bustling capital, Gangtok. Check into your hotel and enjoy a lively evening at MG Marg.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> The Offbeat North: Dzongu Lepcha Reserve</h3>
                <p>After breakfast, step off the tourist trail entirely. We bypass the commercial North Sikkim transit towns and drive directly into Dzongu (approx. 3.5 hours)—a highly restricted, deeply forested reserve meant exclusively for the indigenous Lepcha community. Walk through the pristine cardamom forests, cross the traditional cane bridges, and experience untouched Himalayan serenity by the Teesta River.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Ascent to Lachen (9,000 ft)</h3>
                <p>Bid farewell to the Lepchas and re-join the North Sikkim highway at Mangan. Drive past massive, plunging waterfalls like Seven Sisters and Naga Falls. The air grows noticeably thinner and colder as you arrive at the remote alpine village of Lachen in the late afternoon. Settle into your hotel and sleep early for tomorrow’s extreme altitude start.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> The Frozen Desert (Gurudongmar) & Lachung</h3>
                <p>An extreme 4:00 AM start. Drive through the dark, frozen Thangu Valley to reach the breathtaking Gurudongmar Lake (17,800 ft). Spend a short, sacred moment at one of the highest lakes in the world, surrounded by snow-capped peaks. Return to Lachen for a quick lunch, then cross the mountain ranges to settle into the picturesque valley of Lachung (8,600 ft) for the night.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Valley of Flowers & Descent to Gangtok</h3>
                <p>After breakfast, drive to the sweeping Yumthang Valley (11,800 ft). Known as the Valley of Flowers, it transforms from a rhododendron paradise in spring to a snow-covered wonderland in winter. <em>(Optional visit to Zero Point).</em> Begin your descent back to Gangtok (approx. 5 hours), arriving by late evening to relax and recover from the high altitudes.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> South Sikkim: Ravangla & The Colossal Buddha</h3>
                <p>Leave the capital and drive towards South Sikkim (approx. 2.5 hours). Arrive in the peaceful ridge-town of Ravangla. Visit the magnificent Tathagata Tsal (Buddha Park), featuring a massive 130-foot statue of Lord Buddha against a Himalayan backdrop. If time permits, visit the quiet offbeat village of Borong nearby for its natural hot springs. Stay overnight in Ravangla.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> West Sikkim: Pelling & Darap Village</h3>
                <p>Drive to Pelling in West Sikkim (approx. 2.5 hours), offering the absolute best, up-close views of the Kanchenjunga range. En route, we take an offbeat detour to Darap Village, a pristine settlement of the Limboo tribe. Interact with the locals, walk through the terraced fields, and visit the serene Rimbi Waterfalls. Check into your Pelling resort.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> The Skywalk, Ruins & Sacred Lakes</h3>
                <p>Dedicate the day to Pelling's rich heritage. Walk across India's first glass-bottomed Skywalk at the Chenrezig Statue. Visit the premier Pemayangtse Monastery and wander through the atmospheric Rabdentse Ruins, the ancient capital of the Namgyal kingdom. Finally, seek blessings at the wish-fulfilling Khecheopalri Lake, surrounded by dense prayer flags.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Descent to the Plains & Departure</h3>
                <p>Wake up for one final, majestic sunrise over the Himalayas. After breakfast, check out of your resort and begin the scenic descent alongside the roaring Teesta River. Your chauffeur will drop you at Bagdogra Airport (IXB) or NJP Railway Station (approx. 4.5 hours), concluding your ultimate 10-day Grand Loop of Sikkim.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Clean 3-Star Hotels & Authentic Alpine Homestays</li>
                <li><i class="fa-solid fa-car"></i> Dedicated Utility Vehicle (Bolero/Sumo/WagonR based on terrain)</li>
                <li><i class="fa-solid fa-ticket"></i> All Standard Inner Line & North Sikkim Permits Included</li>
                <li><i class="fa-solid fa-utensils"></i> All Meals in North/East Sikkim; Breakfast elsewhere</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/sikkim-complete-10d-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- GRAND LOOP INSIGHTS HUB (6 GRID CARDS)                    -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Grand Loop Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details to set the right expectations for this massive, multi-terrain, 10-day Himalayan endurance run.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-id-card-clip"></i></div>
                <h3>Heavy Permit Logistics</h3>
                <p>Crossing borders requires paperwork:</p>
                <ul>
                    <li><strong>Documents:</strong> This trip requires multiple permits (Silk Route, North Sikkim, Dzongu). You must carry at least 8 passport-size photos and original Government IDs (Voter ID or Passport). <em>Aadhar is invalid for military zones.</em></li>
                    <li><strong>Foreigners:</strong> Foreign nationals cannot do this exact loop as Gurudongmar Lake and the Silk Route are strictly off-limits. We will alter the itinerary accordingly.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-heart-pulse"></i></div>
                <h3>High Altitude Endurance</h3>
                <p>Managing the physical toll:</p>
                <ul>
                    <li><strong>The Extremes:</strong> You will hit 13,500 ft (Nathang) on Day 2, and an extreme 17,800 ft (Gurudongmar) on Day 5. Acute Mountain Sickness is a real risk. Stay incredibly hydrated, avoid running, and communicate any discomfort to your driver immediately.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase-rolling"></i></div>
                <h3>Packing for 4 Climates</h3>
                <p>Strategic layering is key:</p>
                <ul>
                    <li><strong>The Variations:</strong> Bagdogra/Siliguri will be hot. Gangtok/Ravangla will be pleasantly cool. North Sikkim and the Silk Route will be freezing (sub-zero). You must pack heavily for the extreme cold, but use layers so you can strip down in the lower valleys.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car-side"></i></div>
                <h3>The Vehicle Changes</h3>
                <p>Safety over luxury on bad roads:</p>
                <ul>
                    <li><strong>Transfers:</strong> Gangtok standardizes transport. You will have one vehicle for the Silk Route, switch to a specialized rugged vehicle for North Sikkim, and likely another for West Sikkim. Due to steep, rocky terrain in the North and East, expect bumpy, long driving days.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bed"></i></div>
                <h3>Managing Expectations</h3>
                <p>Luxury fades in the high altitudes:</p>
                <ul>
                    <li><strong>The Reality:</strong> While Gangtok and Pelling offer lavish 5-star hotels, North Sikkim and the Silk Route only have basic (but clean) homestays and rudimentary hotels. Power outages and frozen pipes are common in winter. Embrace the adventure over the amenities.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-utensils"></i></div>
                <h3>Mixed Meal Plans</h3>
                <p>Adapting to the location:</p>
                <ul>
                    <li><strong>AP vs CP:</strong> In remote areas like Zuluk, Dzongu, and Lachen, all meals are included (AP) because there are no restaurants. In Gangtok, Ravangla, and Pelling, your package typically covers only Breakfast (CP) or Dinner (MAP), allowing you to explore local cafes.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand" style="font-weight: bold;"><strong>traveltara</strong><span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Gujarat, Madhya Pradesh, Odisha, Uttarakhand, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
    
    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge" style="background: #0A1128; color: #C5A059;">VIP Welcome Offer</span>
                <h3>Speak with a Travel Expert</h3>
                <p class="popup-subtitle">Let us craft your ultimate 10-day Sikkim expedition.</p>
            </div>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Complete Sikkim Grand Loop 10D/9N" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>