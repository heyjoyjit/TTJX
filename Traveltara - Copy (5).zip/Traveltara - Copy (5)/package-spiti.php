<?php
// Top of package-spiti.php
require_once 'db.php'; 

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();

// =========================================================================
// 🚀 YOUR CUSTOM GOOGLE WEB APP API CONNECTION
// =========================================================================
$webapp_url = "https://script.google.com/macros/s/AKfycbxkTxiGX2SDVtrMzsTjqZMrmi_Vf5fguzg8B10U5hILAlmgDzXguJwuEZ6N2LxYQJzQdA/exec?action=getPricing&t=" . time();

// 1. Hardcoded fallbacks
$sheet_budget_price = "₹38,000"; 
$sheet_affordable_price = "₹52,000";
$sheet_super_price = "₹75,000";

// EXACT package name from Google Sheet
$target_package = "Spiti Expedition 10D/9N"; 

// 2. Fetch JSON data
$ch = curl_init($webapp_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

// 3. Decode and Match
if ($response !== false) {
    $data = json_decode($response, true);
    if (is_array($data) && isset($data[$target_package])) {
        $package_data = $data[$target_package];
        if (isset($package_data['Budget']) && $package_data['Budget'] > 0) {
            $sheet_budget_price = "₹" . number_format((float)$package_data['Budget']);
        }
        if (isset($package_data['Affordable Luxury']) && $package_data['Affordable Luxury'] > 0) {
            $sheet_affordable_price = "₹" . number_format((float)$package_data['Affordable Luxury']);
        }
        if (isset($package_data['Super Luxury']) && $package_data['Super Luxury'] > 0) {
            $sheet_super_price = "₹" . number_format((float)$package_data['Super Luxury']);
        }
    }
}

// 4. Build Javascript Array
$tierDataArray = [
    'budget' => [
        'label' => 'BUDGET - STARTING FROM',
        'price' => $sheet_budget_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Standard Guesthouses & Swiss Tents</li>
            <li><i class="fa-solid fa-car"></i> Dedicated High-Clearance SUV (Xylo/Scorpio)</li>
            <li><i class="fa-solid fa-mountain"></i> Complete Circuit Tour (Shimla to Manali)</li>
            <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
        '
    ],
    'affordable' => [
        'label' => 'AFFORDABLE LUXURY - STARTING FROM',
        'price' => $sheet_affordable_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Premium Boutique Stays & Luxury Camps</li>
            <li><i class="fa-solid fa-car"></i> Private Innova Crysta</li>
            <li><i class="fa-solid fa-star"></i> Guided Monastery Tours & Fossil Hunting</li>
            <li><i class="fa-solid fa-utensils"></i> Curated Meals with Local Tibetan Dishes</li>
        '
    ],
    'super' => [
        'label' => 'SUPER LUXURY - STARTING FROM',
        'price' => $sheet_super_price,
        'highlights' => '
            <li><i class="fa-solid fa-bed"></i> Best Available Premium Properties in Spiti</li>
            <li><i class="fa-solid fa-car"></i> Luxury SUV (Fortuner/Endeavour)</li>
            <li><i class="fa-solid fa-crown"></i> Oxygen Cylinder in Vehicle & Priority Support</li>
            <li><i class="fa-solid fa-utensils"></i> Premium Dining & Bonfire Evenings</li>
        '
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Grand Spiti Expedition | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar" style="position: sticky; top: 0; z-index: 2147483647;">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a> </div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item active">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 9477709755</div>
    </nav>

    <!-- BREADCRUMBS -->
    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="himachal-itinerary.php">Himachal & Ladakh</a> <i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Spiti Expedition (10D/9N)</li>
            </ul>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('<?php echo isset($tourImages['spiti hero']) ? $tourImages['spiti hero'] : $fallbackImg; ?>') center/cover;">
        <div class="duration-badge"><i class="fa-regular fa-clock"></i> 10 Days / 9 Nights</div>
        <div class="subpage-hero-content">
            <h1>The Grand Spiti Expedition</h1>
            <p>Traverse from the lush apple orchards of Kinnaur to the ancient, moonscape deserts of Spiti Valley.</p>
        </div>
    </header>
    
    <!-- ACTION BAR -->
    <div class="package-action-bar">
        <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Spiti Expedition 10D/9N">
            BOOK NOW <i class="fa-solid fa-chevron-right"></i>
        </button>
    </div>

    <!-- MAIN ITINERARY LAYOUT -->
    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>Prepare for the road trip of a lifetime. This 10-day circuit is meticulously designed for safe acclimatization, taking you through the lush green valleys of Shimla and Kinnaur before entering the stark, high-altitude cold desert of the Spiti Valley. You will explore 1000-year-old monasteries, visit the highest villages in the world, camp by the mesmerizing Chandratal Lake, and cross the mighty Kunzum and Rohtang passes before descending into Manali.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival & Ascent to Narkanda</h3>
                <p>Begin your adventure at Chandigarh Airport/Railway Station. Your expert hill chauffeur will drive you past Shimla to the serene, pine-scented town of Narkanda. This is a crucial, unhurried stopover to acclimatize before entering the high-altitude districts. Check into your hotel and enjoy a quiet mountain evening.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Narkanda to Sangla (Entering Kinnaur)</h3>
                <p>Descend into the Sutlej River valley, driving along the dramatic cliff-hanger roads of Taranda Dhak. Cross into the lush Baspa Valley and arrive in Sangla, surrounded by towering snow-capped peaks and endless apple orchards. Visit the ancient Kamru Fort and check into your premium riverside camp or resort.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Sangla to Kalpa via Chitkul</h3>
                <p>Drive alongside the Baspa River to Chitkul, the last inhabited village near the Indo-Tibetan border. Enjoy the crisp mountain air and stunning valley views. Later, proceed to Kalpa, a picturesque village offering the most magnificent, unobstructed views of the sacred Kinner Kailash peak. Overnight stay in Kalpa.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Entering the Cold Desert: Kalpa to Tabo</h3>
                <p>Today, the landscape changes dramatically from green to barren. Drive along the Spiti River on the treacherous but beautiful Hindustan-Tibet Highway. Stop at Nako village to see the serene Nako Lake. Enter the Spiti Valley and reach Tabo. Visit the 1000-year-old Tabo Monastery, known as the "Ajanta of the Himalayas." Overnight in Tabo.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 5</span> Tabo to Kaza via Dhankar</h3>
                <p>After breakfast, drive toward Kaza, the commercial center of Spiti. En route, visit the breathtaking Dhankar Monastery, spectacularly perched on a cliff edge overlooking the confluence of the Spiti and Pin rivers. Arrive in Kaza (3,800m), check into your premium hotel, and rest to acclimatize to the extreme altitude.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 6</span> The Roof of the World: Kaza Local Sightseeing</h3>
                <p>A day of high-altitude superlatives. Visit the iconic Key Monastery, resembling a fortress on a hill. Drive to Kibber and cross the Chicham Bridge (Asia's highest suspension bridge). Continue to Hikkim to post a letter from the World's Highest Post Office, visit Komic (World's Highest Village), and see the giant Buddha statue at Langza. Return to Kaza.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 7</span> Kaza to Chandratal Lake</h3>
                <p>Leave Kaza and begin a rugged, off-road ascent toward the mighty Kunzum Pass (4,590m). Stop to pay respects at the Kunzum Mata temple before descending on a thrilling off-road trail to the mesmerizing, crescent-shaped Chandratal Lake (Lake of the Moon). Check into your luxury Swiss tent camp (located a few kilometers from the lake as per eco-rules).</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 8</span> Chandratal to Manali via Rohtang / Atal Tunnel</h3>
                <p>Wake up early to witness the lake changing colors at sunrise. After breakfast, embark on the most adventurous leg of the journey. Drive through the rugged riverbeds of Batal and Chhatru. Cross into the lush Kullu Valley either via the majestic Rohtang Pass or the engineering marvel of the Atal Tunnel. Arrive in Manali, checking into your premium resort for a well-deserved hot shower and rest.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 9</span> Manali Leisure & Buffer Day</h3>
                <p>A relaxed day in Manali to recover from the tough mountain roads. Enjoy a late breakfast. Visit the ancient Hadimba Temple, stroll through the pine forests, or spend the afternoon cafe-hopping and shopping in the vibrant lanes of Old Manali. This day also serves as a crucial buffer day in case of any road closures during the Spiti circuit.</p>
            </div>

            <div class="day-block">
                <h3><span class="day-badge">Day 10</span> Departure to Chandigarh</h3>
                <p>Enjoy your final Himalayan breakfast. Your chauffeur will drive you down alongside the Beas River, concluding the epic journey with a drop-off at the Chandigarh Airport or Railway Station for your onward journey.</p>
            </div>
        </div>

        <!-- SIDEBAR -->
        <aside class="itinerary-sidebar">
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                <button class="tier-pill active" onclick="updateTier('budget', this)">BUDGET</button>
                <button class="tier-pill" onclick="updateTier('affordable', this)">AFFORDABLE LUXURY</button>
                <button class="tier-pill" onclick="updateTier('super', this)">SUPER LUXURY</button>
            </div>

            <div class="sidebar-price-box">
                <span class="price-label" id="tierLabel">BUDGET - STARTING FROM</span>
                <div class="price-amount" id="tierPrice"><?php echo $sheet_budget_price; ?><span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list" id="tierHighlights">
                <li><i class="fa-solid fa-bed"></i> Standard Guesthouses & Swiss Tents</li>
                <li><i class="fa-solid fa-car"></i> Dedicated High-Clearance SUV (Xylo/Scorpio)</li>
                <li><i class="fa-solid fa-mountain"></i> Complete Circuit Tour (Shimla to Manali)</li>
                <li><i class="fa-solid fa-utensils"></i> MAP (Daily Breakfast & Dinner)</li>
            </ul>
            
            <hr class="sidebar-divider">
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/spiti-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
    
    <!-- ========================================================= -->
    <!-- SPITI INSIGHTS HUB (6 GRID CARDS)                         -->
    <!-- STYLED BY YOUR MASTER STYLE.CSS                           -->
    <!-- UNIVERSAL CORE ICONS USED FOR 100% COMPATIBILITY          -->
    <!-- ========================================================= -->
    <section class="info-hub-section">
        <div class="section-header text-center" style="margin-bottom: 50px;">
            <span class="popup-badge" style="background: #0A1128; color: #C5A059; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">Expedition Guide</span>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128;">The Spiti Survival Compass</h2>
            <p style="color: #555; max-width: 800px; margin: 0 auto;">Critical operational details and safety protocols for surviving and enjoying the ultimate high-altitude desert.</p>
        </div>

        <div class="info-hub-grid">
            
            <!-- Card 1 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-regular fa-calendar-check"></i></div>
                <h3>The Travel Window</h3>
                <p>The complete Spiti Circuit is only open for a few months a year:</p>
                <ul>
                    <li><strong>Mid-June to Sep:</strong> The ONLY time the entire circuit (including Kunzum Pass and Chandratal Lake) is fully open and accessible.</li>
                    <li><strong>Winter (Dec - Mar):</strong> Kunzum Pass is buried in snow. Spiti can only be accessed via the Shimla-Kinnaur route, returning the same way. Strictly for extreme winter survivalists.</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-suitcase-medical"></i></div>
                <h3>Altitude & AMS</h3>
                <p>Acute Mountain Sickness (AMS) is the biggest risk on this trip:</p>
                <ul>
                    <li><strong>Acclimatization:</strong> Starting from Shimla/Kinnaur (gradual ascent) is infinitely safer than starting from Manali (rapid ascent).</li>
                    <li><strong>Precautions:</strong> Keep Diamox handy (consult a doctor). Drink 3-4 liters of water daily. Avoid overexertion at Kaza and Chandratal.</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-car"></i></div>
                <h3>Treacherous Terrains</h3>
                <p>This is not a smooth highway drive; it is an expedition:</p>
                <ul>
                    <li><strong>Vehicle Needs:</strong> Sedans cannot survive the water crossings (Nallahs) between Kaza and Manali. High-clearance SUVs (Innova, Fortuner, Scorpio) are mandatory.</li>
                    <li><strong>Road Conditions:</strong> Expect hours of driving on unpaved dirt, rocks, and riverbeds. Bumpy rides are guaranteed.</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-tower-cell"></i></div>
                <h3>Network Blackout</h3>
                <p>Prepare to disconnect from the world:</p>
                <ul>
                    <li><strong>Connectivity:</strong> BSNL and Jio work decently in Kaza and Tabo. Airtel and Vodafone are virtually useless past Kinnaur.</li>
                    <li><strong>Chandratal:</strong> There is absolutely zero network coverage, electricity, or permanent concrete structures at Chandratal Lake.</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-temperature-arrow-down"></i></div>
                <h3>Weather & Packing</h3>
                <p>The cold desert experiences massive temperature swings:</p>
                <ul>
                    <li><strong>Layers are Key:</strong> The sun is blindingly harsh during the day, but temperatures can drop to near freezing at night in Kaza and Chandratal, even in July.</li>
                    <li><strong>Essentials:</strong> High-SPF sunscreen, sunglasses, lip balm, and heavy thermal wear are non-negotiable.</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div class="info-card">
                <div class="info-icon-wrapper"><i class="fa-solid fa-bed"></i></div>
                <h3>Accommodation Reality</h3>
                <p>Luxury has a different definition in Spiti:</p>
                <ul>
                    <li><strong>Manage Expectations:</strong> While Kinnaur and Manali offer 4/5-star comforts, the "best" hotels in Spiti (Kaza/Tabo) are equivalent to premium 3-star guesthouses.</li>
                    <li><strong>Chandratal Camps:</strong> The Swiss tents are comfortable and have attached toilets, but hot water is provided in buckets, and generator electricity is limited to a few hours at night.</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- EXACT FOOTER -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com" style="color: #C5A059;">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="about.php">About the site</a>
                <a href="products.php">Products and services</a>
                <a href="custom-trip.php">Tailored Trips</a>
                <a href="group-travel.php">Group Travels</a>
                <a href="career.php">Career</a>
                <a href="sitemap.php">Site Map</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a>
                <a href="#">Internation</a>
                <a href="offers.php">Offers & Promotions</a>
                <a href="guidelines.php">Travel Guidelines</a>
                <a href="visa.php">Visa & Immigration</a>
                <a href="payments.php">Payment Policy</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><a href="contact.php" style="color: inherit; text-decoration: none;"><i class="fa-solid fa-envelope" style="margin-right: 8px;"></i> Help & Support Page</a></p>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div style="margin-top: 15px;">
            <a href="https://traveltara.com/admin-dashboard.php" class="admin-login-btn"><i class="fa-solid fa-lock"></i> Admin Portal</a>
        </div>
        <div class="footer-bottom">
            <div style="margin-bottom: 12px; display: flex; justify-content: center; flex-wrap: wrap; gap: 15px;">
                <a href="terms.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Terms & Conditions</a>
                <a href="privacy.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Privacy Policy</a>
                <a href="refunds.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Refunds & Cancellations</a>
                <a href="disclaimer.php" style="color: #bbb; text-decoration: none; font-size: 0.85rem; transition: color 0.3s;" onmouseover="this.style.color='#C5A059'" onmouseout="this.style.color='#bbb'">Legal Disclaimer</a>
            </div>
            <p>&copy; 2026 traveltara. All rights reserved.</p>
        </div>
    </footer>

    <!-- GATEWAY MODALS -->
    <div id="taraGatewayModal" class="gateway-overlay">
        <div class="gateway-box">
            <div id="gatewayStep1">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                    <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
                </div>
                <form id="taraRegFormStep1">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                        <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div class="input-group" style="margin-bottom: 25px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                        <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                        <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                        <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                    </div>
                </form>
            </div>
            <div id="gatewayStep2" class="hidden-step">
                <div class="dossier-header" style="margin-bottom: 20px;">
                    <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                    <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
                </div>
                <form id="taraRegFormStep2">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                        <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                        <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                            <option value="" disabled selected>Select an option...</option>
                            <option value="Budget">Budget</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Customised">Customised (Discuss with Agent)</option>
                        </select>
                    </div>
                    <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                        <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                        <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                        <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                    </div>
                </form>
            </div>
            <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
                <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
                <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
                <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
                <div style="margin-bottom: 25px;">
                    <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                        <span id="redirectCountdown">5</span>
                    </div>
                    <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
                </div>
                <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
            </div>
        </div>
    </div>

    <!-- WHATSAPP WIDGET -->
    <div class="wa-widget-container">
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>
        <div class="wa-popup" id="waPopup">
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');"></div>
            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <!-- LEAD POPUP -->
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box premium-popup">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <div class="popup-header">
                <span class="popup-badge">VIP Welcome Offer</span>
                <h3>Get 20% Off Your Dream Escape!</h3>
                <p class="popup-subtitle">Join the Traveltara VIP club today. Tell us where you want to go, and we will apply a 20% discount to your first luxury itinerary.</p>
            </div>
            <form id="vipForm" class="lead-form" onsubmit="submitVipForm(event)">
                <div class="form-group">
                    <input type="text" id="vipName" name="Name" autocomplete="name" required placeholder="Your Full Name *">
                </div>
                <div class="form-group">
                    <input type="tel" id="vipPhone" name="Phone" autocomplete="tel" required placeholder="WhatsApp / Phone Number *">
                </div>
                <div class="form-group">
                    <input type="text" id="vipDest" name="Destination" required placeholder="Where do you want to travel? *" value="Spiti Expedition 10D/9N" readonly style="background: #e9ecef; cursor: not-allowed;">
                </div>
                <button type="submit" class="btn-primary full-width popup-btn">Claim My 20% Off</button>
            </form>
            <p class="popup-spam-note"><i class="fa-solid fa-lock"></i> 100% Secure. We never share your details.</p>
        </div>
    </div>

    <!-- SCRIPT INJECTION FOR MAIN.JS -->
    <script>
        const tourTierData = <?php echo json_encode($tierDataArray); ?>;
    </script>
    <script src="js/main.js"></script>

</body>
</html>