<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>South Goa Sanctuary | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .itinerary-container { max-width: 1000px; margin: auto; display: flex; gap: 40px; padding: 50px 5%; flex-wrap: wrap; }
        .itinerary-content { flex: 2; min-width: 300px; }
        .itinerary-sidebar { flex: 1; min-width: 300px; position: sticky; top: 100px; height: fit-content; background: var(--light-bg); padding: 30px; border-radius: 8px; border: 1px solid #eaeaea; }
        .day-block { margin-bottom: 30px; border-left: 3px solid var(--primary-gold); padding-left: 20px; }
        .day-block h3 { color: var(--dark-navy); margin-bottom: 10px; }
        .amenities-list { list-style: none; margin-top: 20px; }
        .amenities-list li { margin-bottom: 10px; font-weight: bold; }
        .amenities-list i { color: var(--primary-gold); margin-right: 10px; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <header class="hero" style="height: 60vh; background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/city-goa.jpg') center/cover;">
        <div class="hero-content">
            <h1>The South Goa Sanctuary</h1>
            <p>4 Days / 3 Nights of Coastal Luxury</p>
        </div>
    </header>

    <div class="itinerary-container">
        <div class="itinerary-content">
            <div class="section-header" style="text-align: left; margin-bottom: 30px;">
                <h2>Trip Overview</h2>
                <p>Trade the crowded beaches for private luxury. This itinerary focuses on the tranquil, high-end resorts of South Goa, featuring private yachts, Portuguese heritage, and total relaxation.</p>
            </div>
            <div class="day-block">
                <h3>Day 1: Coastal Arrival</h3>
                <p>Arrive and transfer to a sprawling 5-star beachfront resort in South Goa. Spend the afternoon unwinding by your private plunge pool or walking along the pristine, uncrowded sands.</p>
            </div>
            <div class="day-block">
                <h3>Day 2: Portuguese Heritage</h3>
                <p>A private guided tour of Old Goa’s spectacular churches (Basilica of Bom Jesus) followed by an exclusive lunch at a beautifully restored Indo-Portuguese heritage mansion.</p>
            </div>
            <div class="day-block">
                <h3>Day 3: Private Yacht Sunset</h3>
                <p>Morning at leisure for signature spa treatments. In the late afternoon, board a private luxury yacht for a sunset cruise on the Mandovi River, complete with champagne and canapés.</p>
            </div>
            <div class="day-block">
                <h3>Day 4: Departure</h3>
                <p>Enjoy a final leisurely breakfast overlooking the Arabian Sea before your seamless transfer to the airport.</p>
            </div>
        </div>
        <div class="itinerary-sidebar">
            <h3 style="margin-bottom: 20px;">Trip Highlights</h3>
            <ul class="amenities-list">
                <li><i class="fa-solid fa-bed"></i> 5-Star Beachfront Resort</li>
                <li><i class="fa-solid fa-ship"></i> Private Sunset Yacht</li>
                <li><i class="fa-solid fa-spa"></i> Signature Coastal Spa</li>
                <li><i class="fa-solid fa-user-shield"></i> Dedicated Concierge</li>
            </ul>
            <hr style="margin: 20px 0; border: 0; border-top: 1px solid #ccc;">
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Book This Escape</button>
        </div>
    </div>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">Internation</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <p><i class="fa-solid fa-phone"></i> +91 94776 72195</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/917439877604" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

     <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Plan Your City Escape</h3>
            <form action="https://api.web3forms.com/submit" method="POST" class="lead-form">
                <input type="hidden" name="access_key" value="9c6e22cb-aa85-4e4b-83b0-603a658c95ea">
                <div class="form-group"><label>Full Name *</label><input type="text" name="Name" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" name="Phone" required></div>
                <div class="form-group"><label>Package *</label><input type="text" name="Destination" value="South Goa Sanctuary" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>