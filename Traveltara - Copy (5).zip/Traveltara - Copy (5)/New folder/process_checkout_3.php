<?php
// 1. ALLOW SECURE CONNECTIONS & BYPASS BROWSER CORS SHIELD
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

header("Content-Type: application/json");

// 2. DATABASE CONNECTION
$db_host = "localhost";
$db_name = "u505532187_traveltara"; 
$db_user = "u505532187_admin";      
$db_pass = "Traveltara@2026";       

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database Connection Failed"]));
}

$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

if (!$data || !isset($data['action'])) {
    echo json_encode(["status" => "error", "message" => "Invalid Request"]);
    exit;
}

$action = $data['action'];
$bookingId = $conn->real_escape_string($data['bookingId']);
$email = isset($data['email']) ? $conn->real_escape_string($data['email']) : '';
$guestName = isset($data['guestName']) ? $conn->real_escape_string($data['guestName']) : '';
$amount = isset($data['totalAmount']) ? (int)$data['totalAmount'] : 0;

$adminEmail = "booking.traveltara@gmail.com";
$from_email = "booking@traveltara.com"; 

// ====================================================================
// VERIFY PAYMENT LINK (Used by checkout page to lock inputs)
// ====================================================================
if ($action === 'VERIFY_PAYMENT_LINK') {
    $res = $conn->query("SELECT total_amount, payment_id, guest_name, email FROM bookings WHERE booking_ref = '$bookingId' LIMIT 1");
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        echo json_encode([
            "status" => "success", 
            "amount" => $row['total_amount'], 
            "payment_id" => $row['payment_id'], 
            "guestName" => $row['guest_name'], 
            "email" => $row['email']
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Link not found"]);
    }
    exit;
}

// ====================================================================
// SCENARIO 1: PAID BOOKING (Generates PDF & Sends Confirmed Email)
// ====================================================================
if ($action === 'HOSTINGER_EMAIL') {
    
    $paymentId = $conn->real_escape_string($data['paymentId']);
    $pdfBase64 = isset($data['invoicePdf']) ? $data['invoicePdf'] : '';

    // Update row if it was PENDING, otherwise insert new
    $check = $conn->query("SELECT id FROM bookings WHERE booking_ref = '$bookingId'");
    if ($check && $check->num_rows > 0) {
        $conn->query("UPDATE bookings SET payment_id = '$paymentId', total_amount = $amount, guest_name = '$guestName', email = '$email' WHERE booking_ref = '$bookingId'");
    } else {
        $conn->query("INSERT INTO bookings (booking_ref, guest_name, email, phone, total_amount, payment_id) VALUES ('$bookingId', '$guestName', '$email', 'Stored in CRM', $amount, '$paymentId')");
    }

    $boundary = md5(time());
    $headers = "From: Traveltara <$from_email>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

    $message = "--$boundary\r\n";
    $message .= "Content-Type: text/html; charset=UTF-8\r\n\r\n";
    $message .= "
    <div style='font-family: Arial, sans-serif; color: #0A1128; max-width: 600px; margin: auto; border: 1px solid #eeeeee; border-radius: 8px; overflow: hidden;'>
        <div style='background-color: #0A1128; padding: 30px; text-align: center; border-bottom: 4px solid #C5A059;'>
            <h1 style='color: #ffffff; margin: 0; font-size: 32px; letter-spacing: 2px; font-family: \"Playfair Display\", serif;'>traveltara</h1>
        </div>
        <div style='padding: 40px 30px; text-align: center;'>
            <h2 style='color: #C5A059; margin-top: 0; font-size: 24px; font-family: \"Playfair Display\", serif;'>Your Journey is Confirmed.</h2>
            <p style='line-height: 1.6; color: #444; font-size: 16px; margin-bottom: 30px;'>Dear <strong>$guestName</strong>,</p>
            <p style='line-height: 1.6; color: #444; font-size: 16px;'>Thank you for choosing Traveltara. Your payment was successful, and your bespoke reservation is now fully secured.</p>
            <div style='background-color: #fdfbf7; border: 1px dashed #C5A059; padding: 25px; border-radius: 6px; margin: 35px 0; text-align: left;'>
                <h3 style='margin-top: 0; color: #0A1128; border-bottom: 1px solid #eaeaea; padding-bottom: 10px; font-family: \"Playfair Display\", serif;'>Booking Overview</h3>
                <p style='margin: 10px 0; font-size: 15px; color: #444;'><strong>Booking Ref:</strong> <span style='color: #0A1128;'>$bookingId</span></p>
                <p style='margin: 10px 0; font-size: 15px; color: #444;'><strong>Amount Paid:</strong> <span style='color: #27ae60; font-weight: bold;'>₹ " . number_format($amount) . "</span></p>
                <p style='margin: 10px 0; font-size: 15px; color: #444;'><strong>Transaction ID:</strong> <span style='color: #0A1128;'>$paymentId</span></p>
                <div style='margin-top: 20px; padding-top: 15px; border-top: 1px solid #eaeaea; text-align: center;'>
                    <p style='color: #C5A059; font-weight: bold; font-size: 14px; margin: 0;'>Please find your official Tax Invoice attached as a PDF.</p>
                </div>
            </div>
            <p style='line-height: 1.6; color: #666; font-size: 14px;'>Our concierge team is currently preparing your itinerary. If you require any immediate assistance, simply reply directly to this email.</p>
            <br>
            <p style='line-height: 1.6; color: #444; font-size: 16px;'>Warm Regards,<br><strong style='color: #0A1128;'>The Traveltara Team</strong></p>
        </div>
    </div>
    \r\n"; 

    if (!empty($pdfBase64)) {
        $pdfDecoded = base64_decode($pdfBase64);
        $message .= "\r\n--$boundary\r\n";
        $message .= "Content-Type: application/pdf; name=\"Invoice_$bookingId.pdf\"\r\n";
        $message .= "Content-Transfer-Encoding: base64\r\n";
        $message .= "Content-Disposition: attachment; filename=\"Invoice_$bookingId.pdf\"\r\n\r\n";
        $message .= chunk_split(base64_encode($pdfDecoded)) . "\r\n";
    }
    $message .= "--$boundary--";

    mail($adminEmail, "🚨 Paid Booking: " . $bookingId, $message, $headers, "-f " . $from_email);
    if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL) && $email !== "no-email-provided") {
        mail($email, "Your Traveltara Booking is Confirmed", $message, $headers, "-f " . $from_email);
    }
    echo json_encode(["status" => "success"]);
}

// ====================================================================
// SCENARIO 2: SEND SECURE PAYMENT LINK (NO PDF)
// ====================================================================
elseif ($action === 'SEND_PAYMENT_LINK') {
    
    $destination = isset($data['destination']) ? $conn->real_escape_string($data['destination']) : "Multiple Destinations";
    $totalAmountFmt = number_format($amount, 2);
    
    $conn->query("INSERT INTO bookings (booking_ref, guest_name, email, phone, total_amount, payment_id) VALUES ('$bookingId', '$guestName', '$email', 'Stored in CRM', $amount, 'PENDING_LINK_SENT')");

    $paymentUrl = "https://traveltara.com/checkout.php?ref=" . $bookingId . "&dest=" . urlencode($destination); 

    $subject = "Complete Your Booking: Secure Payment Link from Traveltara";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8\r\n";
    $headers .= "From: Traveltara Concierge <$from_email>\r\n";

    $message = "
    <html>
    <head>
        <style>
            body { font-family: 'Arial', sans-serif; background-color: #f4f5f7; padding: 20px; }
            .email-container { max-width: 600px; margin: 0 auto; background: #ffffff; padding: 40px; border-top: 5px solid #0A1128; border-radius: 4px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
            h2 { color: #0A1128; margin-top: 0; }
            p { color: #555; line-height: 1.6; font-size: 15px; }
            .details-box { background: #fdfbf7; border-left: 4px solid #C5A059; padding: 15px; margin: 25px 0; }
            .btn { display: inline-block; padding: 14px 30px; background-color: #C5A059; color: #0A1128 !important; text-decoration: none; font-weight: bold; border-radius: 4px; margin-top: 10px; }
        </style>
    </head>
    <body>
        <div class='email-container'>
            <h2>Hi $guestName,</h2>
            <p>Your bespoke itinerary for <strong>$destination</strong> has been finalized by our team.</p>
            <div class='details-box'>
                <p style='margin:0;'><strong>Booking Reference:</strong> $bookingId<br><strong>Total Amount:</strong> ₹$totalAmountFmt</p>
            </div>
            <p>To secure your reservations, please click the button below to complete your payment via our secure gateway. Once paid, your official Tax Invoice will be generated and sent to this email automatically.</p>
            <center><a href='$paymentUrl' class='btn'>Complete Secure Payment</a></center>
            <p style='margin-top: 40px; font-size: 13px; color: #888;'>If you have any questions, simply reply to this email or reach out to your dedicated agent on WhatsApp.</p>
            <p style='margin-top: 10px; font-size: 14px;'>Warm regards,<br><strong style='color: #0A1128;'>Traveltara Concierge</strong></p>
        </div>
    </body>
    </html>
    ";

    if(mail($email, $subject, $message, $headers, "-f " . $from_email)) {
        echo json_encode(["status" => "success", "message" => "Payment link sent successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Mail server failed."]);
    }
}
$conn->close();
?>