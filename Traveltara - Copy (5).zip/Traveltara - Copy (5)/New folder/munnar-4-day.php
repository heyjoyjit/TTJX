<?php
// Top of destinations.php
require_once 'db.php'; // This one line logs you in!

$tourImages = [];
$fallbackImg = "https://res.cloudinary.com/traveltaracloud/image/upload/v1/default-placeholder.jpg";

// Ask for the images from the 'tours' table
$sql = "SELECT place_name, image_url FROM tours";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $placeKey = strtolower(trim($row['place_name']));
        $tourImages[$placeKey] = $row['image_url'];
    }
}
$conn->close();
?>
<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Munnar Tea Trail - 4 Days | traveltara</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo"><a href="index.php" style="text-decoration: none; color: inherit;">traveltara</a></div>
        <div class="menu-toggle" id="mobile-menu"><i class="fa-solid fa-bars"></i></div>
        <div class="nav-links" id="navLinks">
            <a href="index.php" class="nav-item">Home</a>
            <a href="destinations.php" class="nav-item">Destinations</a>
            <a href="custom-trip.php" class="nav-item">Tailored Trips</a>
            <a href="blog.php" class="nav-item">Blog</a>
        </div>
        <div class="nav-contact" id="navContact"><i class="fa-solid fa-phone"></i> +91 7439877604</div>
    </nav>

    <div class="breadcrumbs-bar">
        <div class="breadcrumbs-container">
            <ul class="breadcrumbs">
                <li><a href="index.php">Home</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li><a href="munnar-itinerary.php">Munnar Packages</a></li>
                <li><i class="fa-solid fa-chevron-right"></i></li>
                <li class="current-page">Munnar Tea Trail (4D/3N)</li>
            </ul>
        </div>
    </div>

    <header class="subpage-hero" style="background: linear-gradient(rgba(10, 17, 40, 0.4), rgba(10, 17, 40, 0.8)), url('images/munnar-short.jpg') center/cover;">
        <div class="subpage-hero-content">
            <h1>Munnar Tea Trail</h1>
            <p>4 Days / 3 Nights of Emerald Serenity</p>
        </div>
    </header>
    <div class="package-action-bar">
    <button id="openBookingModal" class="btn-gold-solid book-now-btn" data-package="Sikkim 4D/3N">
    BOOK NOW <i class="fa-solid fa-chevron-right"></i>
    </button>
</div>

<div id="taraGatewayModal" class="gateway-overlay">
    <div class="gateway-box">
        
        <div id="gatewayStep1">
            <div class="dossier-header" style="margin-bottom: 20px;">
                <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Guest Registration</h2>
                <p style="font-size: 0.9rem;">Generate your secure booking session. <br><strong>Step 1 of 2</strong></p>
            </div>
            
            <form id="taraRegFormStep1">
                <div class="input-group" style="margin-bottom: 15px;">
                    <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Full Legal Name <span style="color: red;">*</span></label>
                    <input type="text" id="regName" placeholder="e.g. Rahul Sharma" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                </div>

                <div class="input-group" style="margin-bottom: 25px;">
                    <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Mobile Number <span style="color: red;">*</span></label>
                    <input type="text" inputmode="numeric" id="regPhone" placeholder="10-digit number" maxlength="10" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px;">
                    <span id="phoneError" style="color: red; font-size: 0.8rem; display: none; margin-top: 5px;">Must be exactly 10 digits.</span>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="button" id="cancelRegBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Cancel</button>
                    <button type="submit" id="nextStepBtn" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Next: Itinerary & Pricing</button>
                </div>
            </form>
        </div>

        <div id="gatewayStep2" class="hidden-step">
            <div class="dossier-header" style="margin-bottom: 20px;">
                <h2 style="font-size: 1.5rem; color: #0A1128; font-family: 'Playfair Display', serif; margin-bottom: 5px;">Select Tour Tier</h2>
                <p style="font-size: 0.9rem;">Finalize your preferences. <br><strong>Step 2 of 2</strong></p>
            </div>
            
            <form id="taraRegFormStep2">
                <div class="input-group" style="margin-bottom: 15px;">
                    <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Selected Itinerary</label>
                    <input type="text" id="regPackageName" readonly style="width: 100%; padding: 10px; background: #e9ecef; border: 1px dashed #b0b0b0; color: #555; border-radius: 3px; cursor: not-allowed; font-weight: bold;">
                </div>

                <div class="input-group" style="margin-bottom: 15px;">
                    <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Tour Type <span style="color: red;">*</span></label>
                    <select id="regTourTier" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 3px; outline: none; background: #fff;">
                        <option value="" disabled selected>Select an option...</option>
                        <option value="Budget">Budget</option>
                        <option value="Affordable Luxury">Affordable Luxury</option>
                        <option value="Super Luxury">Super Luxury</option>
                        <option value="Customised">Customised (Discuss with Agent)</option>
                    </select>
                </div>

                <div class="input-group" id="priceDisplayWrapper" style="margin-bottom: 25px; display: none;">
                    <label style="font-size: 0.85rem; font-weight: bold; color: #0A1128;">Estimated Price (Per Person)</label>
                    <input type="text" id="regPrice" readonly style="width: 100%; padding: 10px; background: #f4fdf8; border: 1px solid #27ae60; color: #27ae60; border-radius: 3px; font-weight: 900; font-size: 1.1rem; cursor: not-allowed;">
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="button" id="backStepBtn" class="btn-outline" style="flex: 1; padding: 12px; background: #f4f4f4; border: 1px solid #ccc; color: #333; cursor: pointer; font-weight: bold;">Back</button>
                    <button type="submit" class="btn-gold-solid" style="flex: 2; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Confirm & Register</button>
                </div>
            </form>
        </div>

        <div id="gatewaySuccessStep" class="hidden-step" style="text-align: center;">
            <i class="fa-solid fa-circle-check" style="font-size: 3.5rem; color: #27ae60; margin-bottom: 15px;"></i>
            <h2 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 1.6rem; margin-bottom: 5px;">Registration Successful</h2>
            <p style="color: #555; margin-bottom: 20px;">Your secure session has been generated.</p>
            
            <div style="margin-bottom: 25px;">
                <div style="width: 60px; height: 60px; border-radius: 50%; border: 3px solid #C5A059; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-size: 1.5rem; font-weight: bold; color: #0A1128;">
                    <span id="redirectCountdown">5</span>
                </div>
                <p style="font-size: 0.9rem; font-weight: bold; color: #C5A059;">Transferring to booking page...</p>
            </div>

            <button id="instantRedirectBtn" class="btn-gold-solid" style="width: 100%; padding: 12px; border: none; cursor: pointer; font-weight: bold;">Redirect Now</button>
        </div>

    </div>
</div>

    <div class="itinerary-layout-container">
        
        <div class="itinerary-main-content">
            <div class="itinerary-overview">
                <h2>Trip Overview</h2>
                <p>A perfectly paced retreat into the lush green hills of Kerala. Breathe in the crisp mountain air, stroll through manicured tea gardens, and witness the majestic waterfalls that make Munnar famous.</p>
            </div>
            
            <div class="day-block">
                <h3><span class="day-badge">Day 1</span> Arrival in Cochin & Drive to Munnar</h3>
                <p>Arrive at Cochin Airport/Railway Station. Board your private cab for a breathtaking 4-hour drive up to Munnar. En route, stop at the magnificent Cheeyappara and Valara Waterfalls. Check into your resort and relax.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 2</span> Eravikulam & Tea Museum</h3>
                <p>Visit the Eravikulam National Park, home to the endangered Nilgiri Tahr. Later, explore the Tata Tea Museum to learn about the region's rich tea-making history, followed by an evening walk through the estates.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 3</span> Mattupetty Dam & Echo Point</h3>
                <p>After breakfast, head out to the scenic Mattupetty Dam for an optional boat ride. Continue to Echo Point and the beautifully landscaped Carmelagiri Elephant Park. Return to the hotel for a cozy dinner.</p>
            </div>
            <div class="day-block">
                <h3><span class="day-badge">Day 4</span> Departure</h3>
                <p>Enjoy a fresh Kerala-style breakfast before checking out. Your chauffeur will drive you safely back to Cochin for your onward journey.</p>
            </div>
        </div>

        <aside class="itinerary-sidebar">
            <div class="sidebar-price-box">
                <span class="price-label">Starting From</span>
                <div class="price-amount">₹12,500<span class="price-person">/pp</span></div>
            </div>
            
            <h3>Trip Highlights</h3>
            <ul class="amenities-list">
                <li><i class="fa-solid fa-bed"></i> Premium Hill-View Resorts</li>
                <li><i class="fa-solid fa-car"></i> Private Sedan / SUV</li>
                <li><i class="fa-solid fa-leaf"></i> Guided Tea Estate Tour</li>
                <li><i class="fa-solid fa-user-shield"></i> 24/7 Expert Assistance</li>
            </ul>
            
            <hr class="sidebar-divider">
            
            <h4 style="text-align: center; margin-bottom: 15px;">Ready to explore?</h4>
            <button class="btn-primary" style="width: 100%; margin-bottom: 15px;" onclick="openLeadPopup()">Consult an Expert</button>
            <a href="assets/munnar-short-brochure.pdf" download class="btn-outline" style="width: 100%; text-align: center; display: block; padding: 12px 0;">
                <i class="fa-solid fa-download"></i> Download Brochure
            </a>
        </aside>
    </div>
 <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <h2 class="footer-brand">traveltara<span class="gold-com">.com</span></h2>
                <p>Crafting luxurious, unforgettable journeys across North Bengal, Sikkim, Rajasthan, Himachal Pradesh, Munnar, Madhya Pradesh, and beyond.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <a href="#">About the site</a><a href="#">Products and services</a><a href="custom-trip.php">Tailored Trips</a><a href="#">Career</a>
            </div>
            <div class="footer-col">
                <h4>Discover</h4>
                <a href="#">Trending themes</a><a href="#">Internation</a><a href="#">Travel Guidelines</a>
            </div>
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fa-solid fa-phone"></i> +91 7439877604</p>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://wa.me/917439877604" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom"><p>&copy; 2026 traveltara. All rights reserved.</p></div>
    </footer>

    <div class="wa-widget-container">
        
        <div class="whatsapp-sticky" onclick="toggleWaPopup()">
            <span class="wa-tooltip">Need help? Chat with us!</span>
            <i class="fa-brands fa-whatsapp"></i>
        </div>

        <div class="wa-popup" id="waPopup">
            
            <div class="wa-header">
                <div class="wa-header-info">
                    <div class="wa-avatar">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <div>
                        <h4>Traveltara Concierge</h4>
                        <p>Typically replies instantly</p>
                    </div>
                </div>
                <span class="wa-close" onclick="toggleWaPopup()">&times;</span>
            </div>
            
            <div class="wa-body" id="waChatCanvas" style="background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');">
                </div>

            <div class="wa-input-area">
                <input type="text" id="waInputField" placeholder="Type a message..." autocomplete="off" onkeypress="handleWaEnter(event)">
                <button class="wa-send-circle" id="waSendBtn" onclick="processUserMessage()">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
            
        </div>
        
    </div>
    
    <div class="popup-overlay" id="leadPopup">
        <div class="popup-box">
            <span class="close-btn" onclick="closeLeadPopup()">&times;</span>
            <h3>Speak with a Travel Expert</h3>
            <form action="#" method="POST" class="lead-form">
                <div class="form-group"><label>Full Name *</label><input type="text" required></div>
                <div class="form-group"><label>Phone Number *</label><input type="tel" required></div>
                <div class="form-group"><label>Interested In *</label><input type="text" value="Madhya Pradesh Packages" readonly></div>
                <button type="submit" class="btn-primary full-width">Request Call Back</button>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>

</body>
</html>