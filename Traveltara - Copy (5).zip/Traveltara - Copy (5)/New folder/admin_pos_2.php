<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Admin POS | Traveltara</title>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="css/booking.css">
    <link rel="stylesheet" href="css/checkout.css">
    
    <style>
        .admin-hero { background: #0A1128; color: #fff; padding: 25px 20px; text-align: center; border-bottom: 4px solid #C5A059; }
        .admin-hero h1 { font-family: 'Playfair Display', serif; color: #C5A059; margin: 0; font-size: 2rem;}
        .location-row { background: #fdfbf7; border: 1px solid #C5A059; padding: 20px; border-radius: 8px; margin-bottom: 15px; position: relative; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .remove-loc-btn { position: absolute; top: 15px; right: 15px; background: #e74c3c; color: #fff; border: none; border-radius: 4px; padding: 5px 10px; cursor: pointer; }
        .add-loc-btn { background: transparent; color: #C5A059; border: 2px dashed #C5A059; padding: 12px; width: 100%; border-radius: 8px; cursor: pointer; font-weight: bold; margin-bottom: 20px; transition: 0.3s; }
        .add-loc-btn:hover { background: rgba(197, 160, 89, 0.1); }
        .pos-container { max-width: 1100px; margin: 20px auto; padding: 0 20px; }
        .editable-highlight { background: #fff !important; border: 1px solid #154b9b !important; }
        .payment-toggle-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .payment-radio-card { cursor: pointer; }
        .payment-radio-card input { display: none; }
        .payment-radio-card .radio-content { border: 2px solid #eaeaea; border-radius: 8px; padding: 20px; text-align: center; background: #fff; transition: all 0.3s ease; }
        .payment-radio-card .radio-content i { font-size: 2rem; color: #888; margin-bottom: 10px; transition: color 0.3s ease; }
        .payment-radio-card .radio-content h4 { font-family: 'Playfair Display', serif; color: #333; margin-bottom: 5px; font-size: 1.2rem; }
        .payment-radio-card .radio-content p { font-family: 'Lato', sans-serif; font-size: 0.85rem; color: #777; margin: 0; }
        .payment-radio-card input:checked + .radio-content { border-color: #C5A059; background: #fdfbf7; box-shadow: 0 10px 20px rgba(197, 160, 89, 0.15); }
        .payment-radio-card input:checked + .radio-content i { color: #C5A059; }
        .payment-radio-card input:checked + .radio-content h4 { color: #0A1128; }
        @media(max-width: 768px) { .payment-toggle-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body style="background: #f4f5f7;">

    <header class="admin-hero">
        <h1>traveltara | MASTER POS</h1>
        <div style="font-family: 'Lato', sans-serif; color: #ccc; margin-top: 5px; letter-spacing: 1px;">Full Manual Override & Invoice Generation</div>
    </header>

    <main class="pos-container">
        <form id="adminPosForm">
            
            <div class="checkout-form-section">
                <h2 class="checkout-section-title">I. Primary Guest Details</h2>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Prefix *</label>
                        <select id="prefix" required class="editable-highlight">
                            <option value="Mr.">Mr.</option><option value="Mrs.">Mrs.</option><option value="Ms.">Ms.</option><option value="Dr.">Dr.</option>
                        </select>
                    </div>
                    <div class="form-group"><label>First Name *</label><input type="text" id="fName" required class="editable-highlight"></div>
                    <div class="form-group"><label>Middle Name</label><input type="text" id="mName" class="editable-highlight"></div>
                    <div class="form-group"><label>Last Name *</label><input type="text" id="lName" required class="editable-highlight"></div>
                </div>

                <div class="form-grid" style="margin-top: 15px;">
                    <div class="form-group"><label>Primary Phone *</label><input type="tel" id="primaryPhone" maxlength="10" required class="editable-highlight"></div>
                    <div class="form-group"><label>Alternate Phone</label><input type="tel" id="altPhone" maxlength="10" class="editable-highlight"></div>
                    <div class="form-group"><label>Email Address *</label><input type="email" id="email" required class="editable-highlight"></div>
                </div>
            </div>

            <div class="checkout-form-section">
                <h2 class="checkout-section-title">II. Address Configuration</h2>
                
                <h3 style="font-size: 1.1rem; color: #0A1128; margin-bottom: 10px;">Residential Address</h3>
                <div class="form-grid">
                    <div class="form-group"><label>Address Line 1 *</label><input type="text" id="resLine1" required class="editable-highlight"></div>
                    <div class="form-group"><label>Landmark</label><input type="text" id="resLandmark" class="editable-highlight"></div>
                    <div class="form-group"><label>Pincode *</label><input type="text" id="resPin" maxlength="6" oninput="fetchPincodeData(this.value, 'res')" required class="editable-highlight"></div>
                    <div class="form-group"><label>City *</label><input type="text" id="resCity" required class="editable-highlight"></div>
                    <div class="form-group"><label>State *</label><input type="text" id="resState" required class="editable-highlight"></div>
                    <div class="form-group"><label>Country *</label><input type="text" id="resCountry" value="India" required class="editable-highlight"></div>
                </div>

                <div style="margin: 20px 0;">
                    <input type="checkbox" id="sameAsResCheck" checked> 
                    <label for="sameAsResCheck" style="display:inline; font-weight: bold; color: #154b9b;">Permanent Address is Same as Residential</label>
                </div>
                <div class="form-grid hidden-section" id="permAddressBlock">
                    <div class="form-group"><label>Address Line 1 *</label><input type="text" id="permLine1" class="editable-highlight"></div>
                    <div class="form-group"><label>Pincode *</label><input type="text" id="permPin" maxlength="6" oninput="fetchPincodeData(this.value, 'perm')" class="editable-highlight"></div>
                    <div class="form-group"><label>City *</label><input type="text" id="permCity" class="editable-highlight"></div>
                    <div class="form-group"><label>State *</label><input type="text" id="permState" class="editable-highlight"></div>
                </div>

                <div style="margin: 20px 0;">
                    <input type="checkbox" id="addOfficeCheck"> 
                    <label for="addOfficeCheck" style="display:inline; font-weight: bold; color: #154b9b;">Add an Office Address</label>
                </div>
                <div class="form-grid hidden-section" id="officeAddressBlock">
                    <div class="form-group"><label>Address Line 1 *</label><input type="text" id="offLine1" class="editable-highlight"></div>
                    <div class="form-group"><label>Pincode *</label><input type="text" id="offPin" maxlength="6" oninput="fetchPincodeData(this.value, 'off')" class="editable-highlight"></div>
                    <div class="form-group"><label>City *</label><input type="text" id="offCity" class="editable-highlight"></div>
                    <div class="form-group"><label>State *</label><input type="text" id="offState" class="editable-highlight"></div>
                </div>
            </div>

            <div class="checkout-form-section">
                <h2 class="checkout-section-title">III. Verification & Party Config</h2>
                <div class="form-grid">
                    <div class="form-group"><label>Aadhaar Number *</label><input type="text" id="aadhaar" maxlength="12" required class="editable-highlight"></div>
                    <div class="form-group">
                        <label>Tour Type *</label>
                        <select id="tourType" required class="editable-highlight">
                            <option value="Domestic">Domestic</option>
                            <option value="International">International</option>
                        </select>
                    </div>
                    <div class="form-group"><label>Passport No. (If Intl)</label><input type="text" id="passport" class="editable-highlight"></div>
                    <div class="form-group"><label>Commencement Date *</label><input type="date" id="startDate" required class="editable-highlight"></div>
                    <div class="form-group">
                        <label>Tour Tier *</label>
                        <select id="tier" required class="editable-highlight">
                            <option value="Super Luxury">Super Luxury</option>
                            <option value="Affordable Luxury">Affordable Luxury</option>
                            <option value="Budget">Budget</option>
                            <option value="Customised" selected>Customised</option>
                        </select>
                    </div>
                    <div class="form-group"><label>Adults</label><input type="number" id="adults" value="2" min="1" class="editable-highlight"></div>
                    <div class="form-group"><label>Children (<12)</label><input type="number" id="child" value="0" min="0" class="editable-highlight"></div>
                    <div class="form-group"><label>Rooms</label><input type="number" id="rooms" value="1" min="1" class="editable-highlight"></div>
                </div>
            </div>

            <div class="checkout-form-section">
                <h2 class="checkout-section-title">IV. Multi-Destination Billing (Taxable Amounts)</h2>
                <div id="locationsContainer"></div>
                <button type="button" class="add-loc-btn" onclick="addLocationRow()"><i class="fa-solid fa-plus"></i> Add Destination / Service</button>
            </div>

            <div class="checkout-form-section" id="pricingSection">
                <h2 class="checkout-section-title">V. Settlement & Payment Mode</h2>
                <div class="price-box" style="margin-bottom: 20px;">
                    <div class="price-label">Total Amount (Incl. 5% GST)</div>
                    <div class="price-value" id="displayTotalCost">₹ 0.00</div>
                </div>

                <h3 style="font-size: 1.1rem; color: #0A1128; margin-bottom: 15px;">Select Payment Action <span class="required">*</span></h3>
                
                <div class="payment-toggle-grid">
                    <label class="payment-radio-card">
                        <input type="radio" name="posPaymentMode" value="cash" checked onchange="updatePosSubmitBtn()">
                        <div class="radio-content">
                            <i class="fa-solid fa-money-bill-wave"></i>
                            <h4>Cash / Direct Bank</h4>
                            <p>Generate Invoice Instantly</p>
                        </div>
                    </label>
                    <label class="payment-radio-card">
                        <input type="radio" name="posPaymentMode" value="link" onchange="updatePosSubmitBtn()">
                        <div class="radio-content">
                            <i class="fa-solid fa-link"></i>
                            <h4>Payment Gateway</h4>
                            <p>Send Secure Pay Link</p>
                        </div>
                    </label>
                </div>
                
                <button type="submit" class="submit-btn" id="generateBillBtn" style="font-size: 1.1rem; padding: 18px; max-width: none; background: #27ae60;">
                    <i class="fa-solid fa-file-invoice"></i> Record Cash Payment & Generate Invoice
                </button>
            </div>

        </form>
    </main>

    <!-- HIDDEN INVOICE TEMPLATE FOR PDF GENERATION -->
    <div id="invoicePrintContainer" style="display: none;">
        <div id="traveltaraInvoice" style="width: 800px; height: 1122px; padding: 40px; background: #ffffff; font-family: 'Lato', Arial, sans-serif; color: #333; box-sizing: border-box; margin: 0; position: relative;">
            
            <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
                <tr>
                    <td style="padding-bottom: 20px; border-bottom: 3px solid #C5A059;" colspan="2">
                        <table style="width: 100%;">
                            <tr>
                                <td style="width: 50%; vertical-align: top;">
                                    <h1 style="font-family: 'Playfair Display', serif; color: #0A1128; font-size: 32px; margin: 0 0 5px 0; font-weight: 700;">traveltara</h1>
                                    <p style="color: #C5A059; font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; margin: 0;">Bespoke Luxury Journeys</p>
                                </td>
                                <td style="width: 50%; vertical-align: top; text-align: right; font-size: 13px; line-height: 1.4; color: #555;">
                                    <h3 style="color: #0A1128; font-size: 22px; margin: 0 0 8px 0; font-weight: 900; letter-spacing: 1px;">TAX INVOICE</h3>
                                    <p style="margin: 2px 0;"><strong>Traveltara Pvt. Ltd.</strong></p>
                                    <p style="margin: 2px 0;">123 Luxury Avenue, Sector 5, Kolkata, WB 700091</p>
                                    <p style="margin: 2px 0;">Phone: +91 74398 77604 | Email: booking@traveltara.com</p>
                                    <p style="margin: 2px 0;"><strong>GSTIN:</strong> 19AAAAA0000A1Z5 | <strong>PAN:</strong> AAAAA0000A</p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr><td colspan="2" style="height: 20px;"></td></tr>
                <tr>
                    <td colspan="2" style="background: #fdfbf7; border: 1px solid #eaeaea; border-radius: 4px; padding: 15px;">
                        <table style="width: 100%;">
                            <tr>
                                <td style="width: 50%; font-size: 13px; color: #444; line-height: 1.6;">
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Invoice No:</strong> <span id="invRealNo">INV-XXXXX</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Booking Ref No:</strong> <span id="invNo">TRV-XXXXX</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Invoice Date:</strong> <span id="invDate">DD-MMM-YYYY</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Transaction ID:</strong> <span id="invPaymentId" style="color: #27ae60; font-family: monospace; font-weight: bold;">OFFLINE_POS_SETTLEMENT</span></p>
                                </td>
                                <td style="width: 50%; font-size: 13px; color: #444; text-align: right; line-height: 1.6;">
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Due Date:</strong> <span id="invDueDate">DD-MMM-YYYY</span></p>
                                    <p style="margin: 0;"><strong style="color: #0A1128;">Place of Supply:</strong> <span id="invSupplyPlace">West Bengal (19)</span></p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr><td colspan="2" style="height: 20px;"></td></tr>
                <tr>
                    <td style="width: 50%; padding-right: 15px; vertical-align: top;">
                        <div style="font-size: 12px; font-weight: 900; color: #C5A059; border-bottom: 1px solid #C5A059; padding-bottom: 5px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px;">BILL TO</div>
                        <p style="margin: 4px 0; font-size: 14px; color: #0A1128; font-weight: bold;" id="invGuestName">Guest Name</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;" id="invGuestPhone">+91 XXXXXXXXXX</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;" id="invGuestEmail">guest@email.com</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444; word-wrap: break-word;" id="invGuestAddress">Address Not Provided</p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;">State: <strong id="invGuestState">West Bengal</strong></p>
                    </td>
                    <td style="width: 50%; padding-left: 15px; vertical-align: top;">
                        <div style="font-size: 12px; font-weight: 900; color: #C5A059; border-bottom: 1px solid #C5A059; padding-bottom: 5px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px;">TRAVEL DETAILS</div>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Primary Destination:</strong> <span id="invPackage">Multiple Locations</span></p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Travel Date:</strong> <span id="invTravelDate">TBD</span></p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Tier:</strong> <span id="invTier">Customised</span></p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Travelers:</strong> <span id="invPax">2 Adults, 0 Children</span></p>
                        <p style="margin: 4px 0; font-size: 13px; color: #444;"><strong style="color: #0A1128;">Rooms:</strong> <span id="invRooms">1 Room(s)</span></p>
                    </td>
                </tr>
                <tr><td colspan="2" style="height: 20px;"></td></tr>
                <tr>
                    <td colspan="2">
                        <table style="width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid #0A1128; table-layout: fixed;">
                            <thead>
                                <tr>
                                    <th style="background: #0A1128; color: #ffffff; text-align: left; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 28%;">Description</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: center; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 9%;">HSN/SAC</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: center; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 6%;">Qty</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 11%;">Unit Price</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 12%;">Taxable</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 8%;">CGST</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 8%;">SGST</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 8%;">IGST</th>
                                    <th style="background: #0A1128; color: #ffffff; text-align: right; padding: 10px; font-weight: 700; border: 1px solid #0A1128; width: 10%;">Total (₹)</th>
                                </tr>
                            </thead>
                            <tbody id="invTableBody"></tbody>
                        </table>
                    </td>
                </tr>
                <tr><td colspan="2" style="height: 20px;"></td></tr>
                <tr>
                    <td style="width: 55%; padding-right: 15px; vertical-align: top;">
                        <div style="background: #f9f9f9; padding: 15px; border-radius: 4px; border-left: 3px solid #C5A059;">
                            <p style="margin: 0 0 5px 0; font-size: 13px;"><strong>Total Amount in Words:</strong></p>
                            <p id="invWordsText" style="font-style: italic; color: #0A1128; margin: 0; font-size: 13px;">Rupees Zero Only</p>
                        </div>
                    </td>
                    <td style="width: 45%; vertical-align: bottom;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr><td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total Taxable Value:</td><td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumTaxable">₹ 0.00</td></tr>
                            <tr><td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total CGST:</td><td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumCgst">₹ 0.00</td></tr>
                            <tr><td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total SGST:</td><td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumSgst">₹ 0.00</td></tr>
                            <tr><td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555;">Total IGST:</td><td style="padding: 8px 0; border-bottom: 1px solid #eee; font-size: 13px; color: #555; text-align: right;" id="invSumIgst">₹ 0.00</td></tr>
                            <tr><td style="padding: 10px 0 0 0; font-size: 18px; color: #0A1128; font-weight: 900; border-top: 2px solid #0A1128;">Grand Total:</td><td style="padding: 10px 0 0 0; font-size: 18px; color: #0A1128; font-weight: 900; text-align: right; border-top: 2px solid #0A1128;" id="invSumGrand">₹ 0.00</td></tr>
                        </table>
                    </td>
                </tr>
            </table>

            <table style="width: 720px; position: absolute; bottom: 40px; left: 40px; border-top: 1px solid #ddd; padding-top: 20px;">
                <tr>
                    <td style="width: 65%; vertical-align: top;">
                        <h4 style="font-size: 13px; color: #0A1128; margin: 0 0 8px 0; text-transform: uppercase;">Bank & Payment Details</h4>
                        <p style="margin: 2px 0; font-size: 11px; color: #666;"><strong>Bank:</strong> HDFC Bank Ltd. &nbsp;|&nbsp; <strong>A/C Name:</strong> Traveltara Pvt Ltd</p>
                        <p style="margin: 2px 0; font-size: 11px; color: #666;"><strong>A/C No:</strong> 50200012345678 &nbsp;|&nbsp; <strong>IFSC:</strong> HDFC0001234</p>
                        <p style="margin: 2px 0; font-size: 11px; color: #666;"><strong>UPI ID:</strong> traveltara@hdfcbank</p>
                    </td>
                    <td style="width: 35%; vertical-align: bottom; text-align: right;">
                        <div style="border: 2px dashed #C5A059; padding: 15px; border-radius: 4px; background: #fdfbf7; display: inline-block; text-align: center;">
                            <p style="font-weight: 900; color: #0A1128; font-size: 12px; margin: 0; text-transform: uppercase; letter-spacing: 1px;">Automated POS Invoice</p>
                            <p style="color: #666; font-size: 10px; margin: 5px 0 0 0; line-height: 1.4;">Computer-generated document.<br>No physical signature required.</p>
                        </div>
                    </td>
                </tr>
            </table>

        </div>
    </div>

    <script src="js/admin_pos_2.js"></script>
</body>
</html>